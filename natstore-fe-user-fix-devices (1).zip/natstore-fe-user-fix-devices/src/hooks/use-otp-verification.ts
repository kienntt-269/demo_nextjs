import { useEffect, useState, useRef } from "react";

export const useOtpVerification = ({
  resendCooldown = 60,
  otpValidity = 300,
  onResend,
}: {
  resendCooldown?: number;
  otpValidity?: number;
  onResend?: () => void;
}) => {
  const [otp, setOtp] = useState("");
  const [timeLeft, setTimeLeft] = useState(resendCooldown);
  const [canResend, setCanResend] = useState(false);
  const [isExpiredOtp, setIsExpiredOtp] = useState(otpValidity);

  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  const handleResend = () => {
    setOtp("");
    setTimeLeft(resendCooldown);
    setIsExpiredOtp(otpValidity);
    setCanResend(false);
    onResend?.();
  };

  useEffect(() => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
    }

    intervalRef.current = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev > 1) return prev - 1;
        if (prev === 1) setCanResend(true);
        return 0;
      });

      setIsExpiredOtp((prev) => {
        return prev > 0 ? prev - 1 : 0;
      });
    }, 1000);

    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [resendCooldown, otpValidity]);

  return {
    otp,
    setOtp,
    timeLeft,
    canResend,
    isExpiredOtp,
    handleResend,
  };
};
