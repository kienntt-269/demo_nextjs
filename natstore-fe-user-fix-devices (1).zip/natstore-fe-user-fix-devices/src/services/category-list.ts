import http from "@/lib/http";
import { IDataServiceCategoriesRes } from "@/schemaValidations/service-categories";

const URL_CATEGORY = "v1/public/homepage/service-categories/mobile-services";

const categoryApiRequest = {
  getDataCategories: () => {
    return http.get<IDataServiceCategoriesRes>(`${URL_CATEGORY}`, {
      cache: "no-cache",
    });
  },
};

export default categoryApiRequest;
