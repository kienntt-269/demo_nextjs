import http from "@/lib/http";
import { IShowroomSwapSimRes } from "@/schemaValidations/mobile-package.schema";
import { IAffiliateFAQRes } from "@/types/affiliate";

export const warrantyService = {
  getShowroom: async (params: {
    searchKey?: string;
    addressId?: string | number;
  }) => {
    return await http.get<IShowroomSwapSimRes>(
      `/v1/public/warranty/showrooms?searchKey=${params.searchKey || ""}&addressId=${params.addressId || ""}`
    );
  },
  getInformation: async () =>
    await http.get<{
      code: string;
      message: string;
      data: {
        information: string;
      };
    }>("/v1/public/warranty/information"),
  getFaqs: async (searchKey?: string) =>
    await http.get<IAffiliateFAQRes>(
      `/v1/public/warranty/faqs?searchKey=${searchKey || ""}`
    ),
};
