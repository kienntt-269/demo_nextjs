import http from "@/lib/http";
import { ServiceChatType } from "@/types/common";
import {
  CheckRoomIsExistResponseType,
  GetMessageResponseType,
  GetRoomResponseType,
} from "@/types/response";

export const chatApiRequest = {
  ratingConversation: async (rating: number, roomId: string) => {
    return http.post("/v1/public/chat/rate-chat", {
      rate: rating,
      roomId: roomId,
    } as unknown as BodyInit);
  },
  getRoomId: async (phone: string, cusName: string) =>
    http.post<GetRoomResponseType>("/v1/public/chat/get-room", {
      phoneNumber: phone,
      cusName: cusName,
    } as unknown as BodyInit),
  getHistory: async (roomId: string, lastMessageId?: string) =>
    http.post<GetMessageResponseType>("/v1/public/chat/get-history", {
      roomId: roomId,
      lastMessageId: lastMessageId,
    } as unknown as BodyInit),
  checkRoomExist: async (phone: string) =>
    http.post<CheckRoomIsExistResponseType>(
      "/v1/public/chat/check-exist-room",
      {
        phoneNumber: phone,
      } as unknown as BodyInit
    ),
  readMessages: async (messageIds: string[]) =>
    http.post<CheckRoomIsExistResponseType>("/v1/public/chat/mark-seen", {
      messageIds: messageIds,
    } as unknown as BodyInit),
  getListService: async () =>
    http.get<{ data: ServiceChatType[] }>("/v1/public/chat/chat-service"),
  getListServiceSuggestion: async (serviceId: string) =>
    http.get<{ data: ServiceChatType[] }>(
      `/v1/public/chat/chat-service-suggestion?chatServiceId=${serviceId}`
    ),
};
