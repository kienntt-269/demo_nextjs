import envConfig from "@/config";
import http from "@/lib/http";
import {
  IActivateStatusUserRes,
  IBannerSwapSimRes,
  IDevicesSwapSimRes,
  IEnterInfoFormRes,
  IFaqsRes,
  IFormsSwapSimRes,
  IReceivingMethodFormRes,
  IRequestOtpFormRes,
  IRoamingDetailRes,
  IRoamingListRes,
  IRoamingMetadataRes,
  IRoamingRegisterRes,
  IRoamingStatusRes,
  IShowroomSwapSimRes,
  ISwapApproveRes,
  IVasCategoriesRes,
  IVasListRes,
} from "@/schemaValidations/mobile-package.schema";
import { IDataPlanRes } from "@/schemaValidations/mobile-service.schema";
import {
  FormsPostType,
  PayPostType,
  ReceivingMethodPostType,
} from "@/schemaValidations/swap-sim.schema";
import { VasListParams } from "@/types/mobile-package";

const mobilePackageApiRequest = {
  //roaming
  getStatus: () =>
    http.get<IActivateStatusUserRes>(`/api/proxy/v1/api/roaming/status`, {
      cache: "no-cache",
      baseUrl: envConfig.NEXT_PUBLIC_URL,
    }),
  getListRoaming: () =>
    http.get<IRoamingListRes>(`/v1/public/roaming`, {
      cache: "no-cache",
    }),

  getDetailRoaming: (id: number) =>
    http.get<IRoamingDetailRes>(`/v1/public/roaming/${id}`, {
      cache: "no-cache",
    }),

  getMetadata: (id: number) =>
    http.get<IRoamingMetadataRes>(
      `/api/proxy/v1/public/roaming/${id}/metadata`,
      {
        cache: "no-cache",
        baseUrl: envConfig.NEXT_PUBLIC_URL,
      }
    ),
  activateRoaming: () =>
    http.put<IRoamingStatusRes>(
      `/api/proxy/v1/api/roaming/activate`,
      JSON.stringify(""),
      {
        baseUrl: envConfig.NEXT_PUBLIC_URL,
      }
    ),

  deactivateRoaming: () =>
    http.put<IRoamingStatusRes>(
      `/api/proxy/v1/api/roaming/deactivate`,
      JSON.stringify(""),
      {
        baseUrl: envConfig.NEXT_PUBLIC_URL,
      }
    ),

  registerRoaming: (id: number, phone?: string) =>
    http.put<IRoamingRegisterRes>(
      `/api/proxy/v1/api/roaming/${id}/register` +
        (!!phone ? `?phoneNumber=${phone}` : ""),
      JSON.stringify(""),
      {
        baseUrl: envConfig.NEXT_PUBLIC_URL,
      }
    ),
  getListVas: (vO: VasListParams) =>
    http.get<IVasListRes>(
      `/v1/public/vas?categorySlug=${vO.categorySlug}&sortBy=PRICE_DESC`,
      {
        cache: "no-cache",
      }
    ),

  getDetailVas: (idOrSlug: string) =>
    http.get<IDataPlanRes>(`/v1/public/vas/${idOrSlug}`, {
      cache: "no-cache",
    }),
  getVasHomePage: (id: number) =>
    http.get<IVasListRes>(`/v1/public/vas/homepage?categoryId=${id}`, {
      cache: "no-cache",
    }),
  getVasCategories: () =>
    http.get<IVasCategoriesRes>(`/v1/public/vas/categories`, {
      cache: "no-cache",
    }),

  // swap sim
  getFaqs: (at: "SWAP_SIM" | "SYSTEM" | "INTERNET") =>
    http.get<IFaqsRes>(`/v1/public/homepage/faq?at=${at}`, {
      cache: "no-cache",
    }),
  getShowrooms: () =>
    http.get<IShowroomSwapSimRes>(`/v1/public/swap-sim/showrooms`, {
      cache: "no-cache",
    }),
  getBanners: () =>
    http.get<IBannerSwapSimRes>(`/v1/public/swap-sim/banners`, {
      cache: "no-cache",
    }),
  getDevices: () =>
    http.get<IDevicesSwapSimRes>(`/v1/public/swap-sim/devices`, {
      cache: "no-cache",
    }),
  requestsSwapSim: (data: FormData) =>
    http.post<IEnterInfoFormRes>(
      `/v1/public/swap-sim/requests`,
      data as FormData
    ),
  requestsOtpSwapSim: (data: { phoneNumber: string }) =>
    http.post<IRequestOtpFormRes>(
      `/v1/public/swap-sim/requests/otp-request`,
      data as unknown as BodyInit
    ),
  receivingMethodSwapSim: (requestId: string, data: ReceivingMethodPostType) =>
    http.post<IReceivingMethodFormRes>(
      `/v1/public/swap-sim/requests/${requestId}/receiving-method`,
      data as unknown as BodyInit
    ),
  paySwapSim: (requestId: string, data: PayPostType) =>
    http.post<IReceivingMethodFormRes>(
      `/v1/public/swap-sim/requests/${requestId}/pay`,
      data as unknown as BodyInit
    ),
  formsSwapSim: (requestId: string, data: FormsPostType) =>
    http.post<IFormsSwapSimRes>(
      `/v1/public/swap-sim/requests/${requestId}/forms`,
      data as unknown as BodyInit
    ),
  putSwapApprove: (id: number) =>
    http.put<ISwapApproveRes>(
      `/api/proxy/v1/public/sim/swap/approve`,
      {
        id,
      } as unknown as BodyInit,
      {
        baseUrl: envConfig.NEXT_PUBLIC_URL,
      }
    ),
};

export default mobilePackageApiRequest;
