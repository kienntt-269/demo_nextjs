import http from "@/lib/http";
import {
  IDataListMenuRes,
  ILanguageRes,
} from "@/schemaValidations/list-menu.chema";

const URL_LIST_MENU = "/v1/public/homepage/menus";

const listMenuApiRequest = {
  getDataMenu: () => {
    return http.get<IDataListMenuRes>(`${URL_LIST_MENU}`, {
      cache: "no-cache",
    });
  },

  getLanguage: () => {
    return http.get<ILanguageRes>(`/v1/public/homepage/languages`);
  },
};

export default listMenuApiRequest;
