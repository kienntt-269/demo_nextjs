import http from "@/lib/http";
import { IDataBannerRes } from "@/schemaValidations/banner.schema";

const URL_BANNER = "/v1/public/homepage/banners";

const bannerApiRequest = {
  getDataBanner: () => {
    return http.get<IDataBannerRes>(`${URL_BANNER}`, {
      cache: "no-cache",
    });
  },
};

export default bannerApiRequest;
