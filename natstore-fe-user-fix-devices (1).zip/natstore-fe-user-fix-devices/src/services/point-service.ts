import http from "@/lib/http";
import envConfig from "@/config";
import { PointHistoryResType } from "@/schemaValidations/point.schema";

const POINT_SERVICE_URL = "/api/proxy/v1/api/point/management";

const pointApiRequest = {
  getMyBalance: (userId: number) => {
    return http.get<{ code: number; message: string; data: number }>(
      `${POINT_SERVICE_URL}/balance`,
      {
        headers: {
          "user-id": `${userId}`,
        },
        baseUrl: envConfig.NEXT_PUBLIC_URL,
      }
    );
  },
  getMyHistory: ({
    filter,
    from,
    to,
    page,
    size,
    userId,
    searchKey,
  }: {
    filter: number | string;
    from: string;
    to: string;
    page: number;
    size: number;
    userId: number;
    searchKey?: string;
  }) => {
    return http.post<PointHistoryResType>(
      `${POINT_SERVICE_URL}/history?search=${searchKey || ""}`,
      {
        filter,
        from,
        to,
        page,
        size,
      } as unknown as BodyInit,
      {
        headers: {
          "user-id": `${userId}`,
        },
        baseUrl: envConfig.NEXT_PUBLIC_URL,
      }
    );
  },
};

export default pointApiRequest;
