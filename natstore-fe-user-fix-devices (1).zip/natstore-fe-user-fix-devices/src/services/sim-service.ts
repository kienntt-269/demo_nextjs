import http from "@/lib/http";
import { buildEndpoint } from "@/lib/utils";
import { IShowroomSwapSimRes } from "@/schemaValidations/mobile-package.schema";
import {
  ISimCardListRes,
  IHotKeyListRes,
  IAddressRes,
  ISimTypeRes,
  SimDetailRes,
  ISimCardOrderRes,
  IVerifyPaymentSimCardRes,
} from "@/schemaValidations/sim-card.schema";
// import { ISimCardOrder } from "@/types/mobile-package";
import {
  IParamsSimCard,
  IParamsAddress,
  IVerifyPaymentSimCard,
} from "@/types/swap-sim";

const simApiRequest = {
  getListSim: (params: IParamsSimCard) => {
    const url = buildEndpoint("/v1/public/sim", { ...params });
    return http.get<ISimCardListRes>(url, {
      cache: "no-cache",
    });
  },

  getSimTypeDetail(id: string) {
    return http.get<ISimTypeRes>(`/v1/public/sim/sim-type/${id}`, {
      cache: "no-cache",
    });
  },

  getSimDetail(id: string) {
    return http.get<SimDetailRes>(`/v1/public/sim/${id}`, {
      cache: "no-cache",
    });
  },

  getHotKey() {
    return http.get<IHotKeyListRes>(`/v1/public/sim/hot-key`, {
      cache: "no-cache",
    });
  },

  orderSimCard(data: FormData) {
    return http.post<ISimCardOrderRes>(
      "/v1/public/sim-card-order",
      data as unknown as BodyInit,
    );
  },

  verifyPayment(data: IVerifyPaymentSimCard) {
    return http.post<IVerifyPaymentSimCardRes>(
      "/v1/public/sim-card-order/verify-payment",
      data as unknown as BodyInit,
    );
  },

  getAddress(params: IParamsAddress) {
    const url = buildEndpoint("/v1/public/sim-card-order/address", {
      ...params,
    });
    return http.get<IAddressRes>(url, {
      cache: "no-cache",
    });
  },

  getShowroomSim(addressId: string) {
    return http.get<IShowroomSwapSimRes>(
      `/v1/public/sim-card-order/showroom?addressId=${addressId}`,
    );
  },
};

export default simApiRequest;
