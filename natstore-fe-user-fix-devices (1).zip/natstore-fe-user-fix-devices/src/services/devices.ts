import http from "@/lib/http";
import {
  ICategoryListRes,
  IDataPreOrderRes,
  IDeviceDetailRes,
  IDeviceListRes,
} from "@/schemaValidations/device.schema";
import { DeviceListParams, IDeviceOrder } from "@/types/device";

const devicesApiRequest = {
  getProduct: (vO: DeviceListParams) => {
    const params = new URLSearchParams();
    Object.entries(vO).forEach(([key, value]) => {
      if (value !== undefined && value !== null) {
        params.append(key, String(value));
      }
    });
    const queryString = decodeURIComponent(params.toString());
    const url = `/v1/public/product${queryString ? `?${queryString}` : ""}`;
    return http.get<IDeviceListRes>(url, {
      cache: "no-cache",
    });
  },

  getDetailProduct: (idOrSlug: string) =>
    http.get<IDeviceDetailRes>(`/v1/public/product/${idOrSlug}`, {
      cache: "no-cache",
    }),

  getCategoryProduct: () => {
    return http.get<ICategoryListRes>(`/v1/public/product/category`, {
      cache: "no-cache",
    });
  },

  postPreOrder: async (data: IDeviceOrder) => {
    return http.post<IDataPreOrderRes>(
      "/v1/public/product-registration",
      data as unknown as BodyInit
    );
  },
};

export default devicesApiRequest;
