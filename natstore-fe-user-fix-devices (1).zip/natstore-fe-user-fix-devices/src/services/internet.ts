import http from "@/lib/http";
import {
  IDataCaptchaRes,
  IDataBeginNasthCardRes,
  IDataInternetCategoriesRes,
  IDataInternetDetailPaymentRes,
  IDataInternetDetailPaymentTotalRes,
  IDataInternetDetailRes,
  IDataInternetRes,
  IDataVerifyNasthCardRes,
  IDataInternetDebtRes,
} from "@/schemaValidations/internet.shema";
import { PaymentParams } from "@/types/common";

const URL = "/v1/public/internet";

const internetApiRequest = {
  getDataInternet: (body: { type: string }) => {
    return http.post<IDataInternetRes>(`${URL}`, body as BodyInit);
  },

  getDetailData: (idOrSlug: string) =>
    http.get<IDataInternetDetailRes>(`/v1/public/internet/${idOrSlug}`, {
      cache: "no-cache",
    }),

  postBeginNasthCard: (data: FormData) =>
    http.post<IDataBeginNasthCardRes>(
      `/v1/public/internet/begin-natcash-payment`,
      data as FormData
    ),

  postRegisterInternet: (data: FormData) =>
    http.post<IDataBeginNasthCardRes>(
      `/v1/public/internet/register-package`,
      data as FormData
    ),

  postVerifyNatcashPayment: async ({
    transactionId,
    code,
    ncTransId,
    signature,
  }: PaymentParams) => {
    return http.post<IDataVerifyNasthCardRes>(
      "/v1/public/internet/verify-natcash-payment",
      {
        transactionId,
        code,
        ncTransId,
        signature,
      } as unknown as BodyInit
    );
  },

  getDetailDataPayment: (idOrSlug: string) =>
    http.get<IDataInternetDetailPaymentRes>(
      `/v1/public/internet/${idOrSlug}/payment-plan`,
      {
        cache: "no-cache",
      }
    ),

  getDetailDataTotalPayment: (idOrSlug: string, idPaymentPlan: string) =>
    http.get<IDataInternetDetailPaymentTotalRes>(
      `/v1/public/internet/${idOrSlug}/calculate-price/${idPaymentPlan}`,
      {
        cache: "no-cache",
      }
    ),

  getDataInternetCategory: () =>
    http.get<IDataInternetCategoriesRes>(`/v1/public/internet/categories`, {
      cache: "no-cache",
    }),
  getCaptcha: () =>
    http.get<IDataCaptchaRes>(`/v1/public/internet/generate-captcha`),
  getDebtInfo: ({
    numberAccount,
    idCardNumber,
  }: {
    numberAccount?: string;
    idCardNumber?: string;
  }) => {
    return http.post<IDataInternetDebtRes>(
      `/v1/public/internet/get-debt-info`,
      {
        numberAccount,
        idCardNumber,
      } as unknown as BodyInit
    );
  },
};

export default internetApiRequest;
