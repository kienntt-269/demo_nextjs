import envConfig from "@/config";
import http from "@/lib/http";

const uploaderApiRequest = {
  async uploadFile(formData: FormData) {
    const response = await http.post<{ data: { url: string } }>(
      "/api/proxy/v1/api/chat/upload/image",
      formData,
      { baseUrl: envConfig.NEXT_PUBLIC_URL }
    );
    const url = new URL(response?.payload?.data?.url);
    return {
      url: url?.pathname + url?.search,
    };
  },
};

export default uploaderApiRequest;
