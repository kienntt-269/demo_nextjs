import http from "@/lib/http";
import {
  DataPlansTypeList,
  ICategoryDataRes,
} from "@/schemaValidations/mobile-service.schema";

const mobileCategoriesApiRequest = {
  getDataChildren: (id: number) => {
    return http.get<DataPlansTypeList>(
      `v1/public/data/homepage?categoryId=${id}`,
      {
        cache: "no-cache",
      },
    );
  },
  getDataChildrenVas: (id: number) => {
    return http.get<DataPlansTypeList>(
      `/v1/public/vas/homepage?categoryId=${id}`,
      {
        cache: "no-cache",
      },
    );
  },
  getDetailMobileService: (slug: string) => {
    return http.get<ICategoryDataRes>(
      `/v1/public/homepage/service-categories/${slug}`,
    );
  },

  getMobileServiceDetail: (slug: string) => {
    return http.get<ICategoryDataRes>(`/v1/public/data/${slug}/categories`);
  },
};

export default mobileCategoriesApiRequest;
