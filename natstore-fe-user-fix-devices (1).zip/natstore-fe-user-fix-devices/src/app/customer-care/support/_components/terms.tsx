import SupportContent from "@/app/customer-care/support/_components/support-content";
import {
  ICustomerSupportFaq,
  ICustomerSupportTerms,
} from "@/schemaValidations/customer-support.schema";
import customerSupportApiRequest from "@/services/customer-service";
import { getTranslations } from "next-intl/server";
import React from "react";

const getTerms = async () => {
  try {
    const res = await customerSupportApiRequest.getTerms();
    return res.payload.data;
  } catch (error) {
    console.log(error);
    throw Error("error");
  }
};

const Terms = async () => {
  const t = await getTranslations();
  const terms = await getTerms();
  const _terms: ICustomerSupportFaq[] = terms.map(
    (item: ICustomerSupportTerms) => ({
      id: item.id,
      question: item.name,
      answer: item.content,
      sortOrder: item.sortOrder,
      faqCategoryId: item.sortOrder,
    })
  );
  return (
    <div className="">
      <SupportContent tabName={t("customer_support.terms")} faqs={_terms} />
    </div>
  );
};

export default Terms;
