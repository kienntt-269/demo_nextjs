import React from "react";
import PageContent from "@/components/page-content";
import { useTranslations } from "next-intl";
import { ILinks } from "@/types/package";
import BreadCrumbCommon from "@/components/breadcrumb-common";
import Image from "next/image";
import ButtonSeeMore from "@/components/btn-see-more";
import CardNews from "@/components/card-news";
import CarouselData from "@/components/common/carousel-data/carousel-data";
import { Metadata } from "next";

const PromotionDetail = () => {
  const t = useTranslations();
  const breadCrumb: ILinks[] = [
    {
      label: t("personal.home"),
      link: "/",
    },
    {
      label: t("search.promotion"),
      link: "/promotion",
    },
    {
      label: t("footer.news"),
      link: "/promotion/news",
    },
  ];

  const listRelateNews = [1, 2, 3, 4, 5];
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Product",
    name: "Natcom Mobile Data Plans",
    description:
      "Discover Natcom's affordable and high-speed mobile data plans tailored for every need. Stay connected anytime, anywhere in Haiti.",
    brand: {
      "@type": "Organization",
      name: "Natcom",
      url: "https://natcomstore.arabicatech.vn/promotion/news",
      logo: "https://image.natcom.com.ht/1624982790848.jpeg",
    },
    image: "https://your-cdn.com/images/natcom-data-banner.jpg",
    url: "https://image.natcom.com.ht/1624982790848.jpeg",
    offers: {
      "@type": "AggregateOffer",
      lowPrice: "1.00",
      highPrice: "15.00",
      priceCurrency: "USD",
      offerCount: "5",
      offers: [
        {
          "@type": "Offer",
          price: "1.00",
          priceCurrency: "USD",
          description: "Daily data pack - 100MB",
        },
        {
          "@type": "Offer",
          price: "3.00",
          priceCurrency: "USD",
          description: "Weekly data pack - 500MB",
        },
        {
          "@type": "Offer",
          price: "5.00",
          priceCurrency: "USD",
          description: "Weekly data pack - 1GB",
        },
        {
          "@type": "Offer",
          price: "10.00",
          priceCurrency: "USD",
          description: "Monthly data pack - 3GB",
        },
        {
          "@type": "Offer",
          price: "15.00",
          priceCurrency: "USD",
          description: "Monthly data pack - 5GB",
        },
      ],
    },
  };
  return (
    <PageContent>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />
      <div className="mt-6 max-lg:mt-4">
        <BreadCrumbCommon content={breadCrumb} />
      </div>
      <div className="mt-10 px-[10%]">
        <Image
          src={"/mobile-package/exclusive_benefits_natcom.png"}
          alt=""
          width={1032}
          height={403}
          unoptimized
          quality={100}
          className="rounded-3xl object-cover w-full"
        />
        <div className="mt-10">
          <div className="text-[14px] text-primary">#kinh nghiệm hay</div>
          <div className="mt-4 text-[28px] font-bold">
            Ổ cứng di động là gì? Lợi ích khi sở hữu ổ cứng di động bạn nên biết
          </div>
          <div className="mt-4 text-[14px]">
            Cập nhật ngày 02/02/2022, lúc 16:24
          </div>
          <div className="mt-10">
            Ổ cứng di động là một thiết bị ổ cứng gắn ngoài cho các thiết bị
            mạng, laptop được kết nối với máy tính quá cáp kết nối. Nó được cấu
            tạo giống như một ổ cứng bình thường nhưng có thiết kế nhỏ gọn. Hiểu
            đơn giản, ổ cứng di động giống như chiếc USB, bạn có thể mang đi bất
            cứ đâu, tuy nhiên nó có dung lượng cùng tốc độ truyền tải dữ liệu
            cao hơn nhiều lần so với USB. Ngoài khả năng lưu trữ dung lượng lớn,
            chạy được các phần mềm thì ổ cứng còn có độ bền cao nếu bạn bảo quản
            tốt có thể sử dụng trong một thời gian dài.
          </div>
          <div className="mt-10">
            Cấu tạo bên trong Ổ đĩa di động có cấu tạo từ đĩa từ, là một đầu đĩa
            kim loại hình tròn, gồm nhiều đĩa cứng làm bằng nhôm hoặc các hợp
            chất gốm thủy tinh. Các đĩa được phủ một lớp từ hoặc lớp bảo vệ ở cả
            2 mặt, xếp chồng lên nhau và gắn liền với một trục quay. Cũng chính
            vì vậy mà các đĩa được quay nhanh với cùng một tốc độ trong suốt
            phiên dùng máy, đảm bảo quá trình hoạt động đạt hiệu quả tốt nhất.
          </div>
        </div>
        <div className="mt-10">
          <div className="flex justify-between items-center">
            <div className="font-bold text-[28px]">
              {t("affiliate.related_news")}
            </div>
            <ButtonSeeMore href="/" classes="2xl:text-[28px]" />
          </div>
          <div className="mt-6">
            <CarouselData
              quantity={3}
              length={listRelateNews.length}
              quantityMobile={1.5}
              quantityLg={2.5}
              quantityMd={2}
              quantitySm={2}
              quantityXs={2}
              quantityXl={3}
            >
              {listRelateNews.map((item, i) => {
                return <CardNews key={i} />;
              })}
            </CarouselData>
          </div>
        </div>
      </div>
    </PageContent>
  );
};

export const generateMetadata = async ({
  params,
}: {
  params: { slug: string };
}): Promise<Metadata> => {
  console.log(params.slug);
  return {
    title: "Natcom Mobile Data Plans - Fast and Affordable Internet",
    description:
      "Discover Natcom's affordable and high-speed mobile data plans tailored for every need. Stay connected anytime, anywhere in Haiti.",
    openGraph: {
      title: "Natcom Mobile Data Plans - Fast and Affordable Internet",
      description:
        "Explore our mobile data packages and enjoy seamless internet connectivity with Natcom, a trusted telecommunications provider in Haiti.",
      url: "https://natcomstore.arabicatech.vn/promotion/news",
      siteName: "Natcom",
      images: [
        {
          url: "https://image.natcom.com.ht/1624982790848.jpeg",
          width: 1200,
          height: 630,
          alt: "Natcom Mobile Data Banner",
        },
      ],
      locale: "en_US",
      type: "website",
    },
    twitter: {
      card: "summary_large_image",
      title: "Natcom Mobile Data Plans",
      description:
        "Choose from a variety of Natcom data packages to suit your internet needs anytime, anywhere.",
      images: ["https://image.natcom.com.ht/1624982790848.jpeg"],
    },
  };
};

export default PromotionDetail;
