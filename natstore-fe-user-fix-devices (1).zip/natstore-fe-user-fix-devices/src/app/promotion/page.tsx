import React from "react";

const PromotionPage = () => {
  return <div>PromotionPage</div>;
};

export default PromotionPage;
