"use client";
import { DateRangePicker } from "@/components/ui/date-range-picker";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { IColumnTable } from "@/types/common";
import clsx from "clsx";
import { useTranslations } from "next-intl";
import Image from "next/image";
import React, { useState } from "react";

interface IDataReport {
  id?: string;
  timeOrder?: string;
  orderID?: string;
  status?: string;
}

const ReportDashboard = () => {
  const [status, setStatus] = useState<string>("");
  const [productFilter, setProductFilter] = useState<string>("");
  const t = useTranslations();
  const column: IColumnTable<IDataReport>[] = [
    {
      header: t("common.no"),
      key: "id",
      classStyleHeader: "pl-4 text-center",
      render: () => {
        return <div className="text-sm">1</div>;
      },
    },
    {
      header: t("affiliate.click_time"),
      key: "id",
      classStyleHeader: "text-center",
      render: () => {
        return <div className="text-sm w-[128px]">2024-04-08 10:15</div>;
      },
    },
    {
      header: t("affiliate.order_placement_time"),
      key: "id",
      classStyleHeader: "pl-8 text-center",
      render: () => {
        return <div className="text-sm w-[156px]">2024-04-08 10:15</div>;
      },
    },
    {
      header: t("payment.order_id"),
      key: "id",
      classStyleHeader: "pl-8 text-center",
      render: () => {
        return <div className="text-sm w-[120px]">ORD12345678</div>;
      },
    },
    {
      header: t("payment_package_internet.status"),
      key: "id",
      classStyleHeader: "pl-8 text-center",
      render: () => {
        return <div className="text-sm w-20">Completed</div>;
      },
    },
    {
      header: t("affiliate.order_value"),
      key: "id",
      classStyleHeader: "pl-8 text-center",
      render: () => {
        return <div className="text-sm w-24">100 HTG</div>;
      },
    },
    {
      header: t("affiliate.details"),
      key: "id",
      classStyleHeader: "pl-8 text-center",
      render: () => {
        return <div className="text-sm w-24">FTTH 3M plan</div>;
      },
    },
    {
      header: t("affiliate.commission"),
      key: "id",
      classStyleHeader: "pl-8 text-center",
      render: () => {
        return <div className="text-sm w-24">10 HTG</div>;
      },
    },
    {
      header: t("affiliate.tax"),
      key: "id",
      classStyleHeader: "pl-8 text-center",
      render: () => {
        return <div className="text-sm w-16">1 HTG</div>;
      },
    },
    {
      header: t("affiliate.commission_after_tax"),
      key: "id",
      classStyleHeader: "pl-8 text-center",
      render: () => {
        return <div className="text-sm w-[154px]">4.5 HTG</div>;
      },
    },
    {
      header: t("affiliate.affiliate_id"),
      key: "id",
      classStyleHeader: "pl-8 text-center",
      render: () => {
        return <div className="text-sm w-24">987123456</div>;
      },
    },
    {
      header: t("affiliate.channel"),
      key: "id",
      classStyleHeader: "pl-8 text-center",
      render: () => {
        return <div className="text-sm">Facebook</div>;
      },
    },
  ];
  const dataLink: IDataReport[] = [
    {
      id: "string",
      orderID: "123",
      status: "string",
      timeOrder: "string",
    },
  ];

  return (
    <div>
      <div className="flex justify-between items-center">
        <div className="text-[28px] max-lg:text-[20px] font-bold">
          {t("affiliate.report")}
        </div>
        <div className="max-2xl:block hidden">
          <button className="border-black px-5 py-3 max-lg:px-3 max-lg:text-[14px] max-lg:py-[6px] font-bold border border-solid rounded-3xl flex gap-x-2 items-center">
            <Image
              src={"/images/icon/filter.svg"}
              alt=""
              unoptimized
              quality={100}
              height={24}
              width={24}
              className="max-lg:size-4"
            />
            {t("common.filter")}
          </button>
        </div>
      </div>
      <div className="flex gap-x-6 mt-8 max-lg:mt-6 items-end">
        <div className="grid grid-cols-3 max-2xl:grid-cols-2 max-2xl:gap-4 max-lg:grid-cols-1 gap-x-6 flex-1">
          <div>
            <label htmlFor="" className="max-lg:text-[14px]">
              {t("affiliate.tracking_time")}
            </label>
            <div className="mt-2">
              {/* <DatePicker
                onChange={(date) => {
                  console.log(date);
                }}
              /> */}
              <DateRangePicker />
            </div>
          </div>
          <div>
            <label htmlFor="" className="mb-2 max-lg:text-[14px]">
              {t("affiliate.product")}
            </label>
            <Select
              value={productFilter}
              onValueChange={(val) => {
                setProductFilter(val);
              }}
            >
              <SelectTrigger className="w-full mt-2">
                <div
                  className={clsx({
                    "text-neutral": !productFilter,
                  })}
                >
                  <SelectValue
                    className="input-box-shadow"
                    placeholder="Choose product"
                  />
                </div>
              </SelectTrigger>
              <SelectContent>
                <SelectGroup>
                  <SelectItem value="apple">Sim</SelectItem>
                  <SelectItem value="banana">Data Plans</SelectItem>
                  <SelectItem value="blueberry">Internet</SelectItem>
                  <SelectItem value="grapes">Phone</SelectItem>
                  <SelectItem value="pineapple">Router</SelectItem>
                </SelectGroup>
              </SelectContent>
            </Select>
          </div>{" "}
          <div>
            <label htmlFor="" className="max-lg:text-[14px]">
              {t("payment_package_internet.status")}
            </label>
            <Select
              value={status}
              onValueChange={(val) => {
                setStatus(val);
              }}
            >
              <SelectTrigger className="w-full mt-2">
                <div
                  className={clsx({
                    "text-neutral": !status,
                  })}
                >
                  <SelectValue
                    className="input-box-shadow"
                    placeholder="Choose status"
                  />
                </div>
              </SelectTrigger>
              <SelectContent>
                <SelectGroup>
                  <SelectItem value="apple">
                    {t("affiliate.completed")}
                  </SelectItem>
                  <SelectItem value="banana">
                    {t("affiliate.failed")}
                  </SelectItem>
                  <SelectItem value="blueberry">
                    {t("affiliate.pending")}
                  </SelectItem>
                  <SelectItem value="grapes">{t("affiliate.all")}</SelectItem>
                </SelectGroup>
              </SelectContent>
            </Select>
          </div>
        </div>
        <button className="border-black px-5 py-3 font-bold border border-solid rounded-3xl flex gap-x-2 items-center max-2xl:hidden">
          <Image
            src={"/images/icon/filter.svg"}
            alt=""
            unoptimized
            quality={100}
            height={24}
            width={24}
          />{" "}
          {t("common.filter")}
        </button>
      </div>
      <div className="mt-8 max-lg:mt-6">
        <div className="overflow-hidden border border-solid border-[#F2F2F2] rounded-xl">
          <Table>
            <TableHeader className="bg-[#DEDEDE] h-11">
              <TableRow>
                {column.map((col, index) => (
                  <TableHead
                    key={`header-table${index}`}
                    className={`text-[#212121] font-bold text-sm- max-md:text-[12px] ${col.classStyleHeader}`}
                  >
                    {col.header}
                  </TableHead>
                ))}
              </TableRow>
            </TableHeader>
            <TableBody>
              {dataLink?.length > 0 &&
                dataLink?.map((row, indexRow) => (
                  <TableRow
                    key={indexRow}
                    className="text-sm h-14 max-md:h-[54px]"
                  >
                    {column.map((col, i) => (
                      <TableCell
                        className={`text-[#212121] ${col.classStyleHeader}`}
                        key={i}
                      >
                        {col?.render
                          ? col.render(
                              row[col.key as keyof typeof row],
                              row,
                              indexRow
                            )
                          : (row as unknown as Record<string, string>)[col.key]}
                      </TableCell>
                    ))}
                  </TableRow>
                ))}
            </TableBody>
          </Table>
        </div>
        <div className="font-bold text-[20px] mt-8 max-lg:mt-6 max-lg:text-[16px]">
          {t("affiliate.commission_by_product")}
        </div>
        <div className="mt-4">
          <div className="rounded-t-lg md:rounded-xl overflow-hidden border border-solid border-[#F2F2F2]">
            <Table>
              <TableHeader className="bg-[#DEDEDE] h-11">
                <TableRow>
                  <TableHead
                    className={`text-[#212121] font-bold text-sm- max-md:text-[12px] bg-[#C5C5C5] `}
                  >
                    {t("affiliate.product")}
                  </TableHead>{" "}
                  <TableHead
                    className={`text-[#212121] font-bold text-sm- max-md:text-[12px] `}
                  >
                    Sim
                  </TableHead>{" "}
                  <TableHead
                    className={`text-[#212121] font-bold text-sm- max-md:text-[12px] `}
                  >
                    Data Plans
                  </TableHead>{" "}
                  <TableHead
                    className={`text-[#212121] font-bold text-sm- max-md:text-[12px] `}
                  >
                    Internet
                  </TableHead>{" "}
                  <TableHead
                    className={`text-[#212121] font-bold text-sm- max-md:text-[12px] `}
                  >
                    Phone
                  </TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                <TableRow className="text-sm h-14 max-md:h-[54px]">
                  <TableCell
                    className={`text-[#212121] bg-[#C5C5C5] font-bold`}
                  >
                    {t("affiliate.commission")}
                  </TableCell>
                  <TableCell className={`text-[#212121] `}>10%</TableCell>
                  <TableCell className={`text-[#212121] `}>10%</TableCell>
                  <TableCell className={`text-[#212121] `}>10%</TableCell>
                  <TableCell className={`text-[#212121] `}>10%</TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ReportDashboard;
