import { useTranslations } from "next-intl";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import React, { useState } from "react";
import { IColumnTable } from "@/types/common";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";

interface IDataLink {
  id: string;
  name: string;
  link: string;
  natcom_link: string;
  createAt: string;
  router: string;
}

const TrackingLinkDashboard = () => {
  const t = useTranslations();
  const [isGetLink, setIsGetLink] = useState<boolean>(false);
  const column: IColumnTable<IDataLink>[] = [
    {
      header: t("common.no"),
      key: "id",
      classStyleHeader: "pl-8 max-lg:pl-2 text-center",
      render: () => {
        return <div className="text-sm max-lg:text-xs max-lg:w-[120px]">1</div>;
      },
    },
    {
      header: t("internet.product_name"),
      key: "id",
      classStyleHeader: "pl-8 max-lg:pl-2 text-center",
      render: () => {
        return (
          <div className="text-sm max-lg:text-xs max-lg:w-[120px]">
            Bundle Plans
          </div>
        );
      },
    },
    {
      header: t("affiliate.natcom_link"),
      key: "id",
      classStyleHeader: "pl-8 max-lg:pl-2 text-center",
      render: () => {
        return (
          <div className="text-sm max-lg:text-xs max-lg:w-[120px]">abcxyz</div>
        );
      },
    },
    {
      header: t("affiliate.your_link"),
      key: "id",
      classStyleHeader: "pl-8 max-lg:pl-2 text-center",
      render: () => {
        return (
          <div className="text-sm max-lg:text-xs max-lg:w-[120px]">10%</div>
        );
      },
    },
    {
      header: t("affiliate.create_at"),
      key: "id",
      classStyleHeader: "pl-8 max-lg:pl-2 text-center",
      render: () => {
        return (
          <div className="text-sm max-lg:text-xs max-lg:w-[120px]">
            10:00:25 25/03/2025
          </div>
        );
      },
    },
    {
      header: t("affiliate.router"),
      key: "id",
      classStyleHeader: "pl-8 max-lg:pl-2 text-center",
      render: () => {
        return (
          <Button variant={"secondary"} className="h-8 text-sm" size={"sm"}>
            Copy Link
          </Button>
        );
      },
    },
  ];

  const dataLink: IDataLink[] = [
    {
      id: "string",
      name: "string",
      link: "string",
      natcom_link: "string",
      createAt: "string",
      router: "string",
    },
  ];
  return (
    <div>
      <div className="text-[28px] font-bold max-lg:text-[20px]">
        {t("affiliate.tracking_link")}
      </div>
      <div className="mt-8 max-lg:mt-6">
        <div className="max-lg:text-[14px]">
          {t("affiliate.create_link_direct")}
        </div>
        <Textarea
          className="rounded-xl h-20 max-h-20 mt-2 shadow placeholder:text-neutral max-lg:hidden"
          placeholder={t("affiliate.paste_your_link")}
        />
        <Input
          className="max-lg:block hidden shadow-input-custom h-12 rounded-xl mt-2"
          placeholder={t("affiliate.paste_your_link")}
        />
        <div className="flex justify-center mt-6 max-lg:mt-4">
          <Dialog
            open={isGetLink}
            onOpenChange={(open) => {
              setIsGetLink(open);
            }}
          >
            <DialogTrigger asChild>
              <Button className="w-[243px] max-md:w-full max-md:h-8 max-md:text-[14px]">
                {t("affiliate.get_link")}
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[504px]">
              <DialogHeader>
                <DialogTitle>
                  <div className="text-center text-[24px] font-bold">
                    {t("affiliate.your_link")}
                  </div>
                </DialogTitle>
              </DialogHeader>
              <div className="mt-6">{t("affiliate.please_copy_your_link")}</div>
              <div className="mt-2">
                <Textarea className="rounded-2xl bg-[#F5F6F7] max-h-[88px] min-h-[88px] border-[2px] border-solid border-[#E3E4E5]" />
              </div>
              <div className="flex justify-center">
                <Button className="w-[212px] mt-6 ">
                  {t("affiliate.copy_link")}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>
      <div className="mt-8 max-lg:mt-6">
        <div className="font-bold text-[20px] max-lg:text-[16px]">
          {t("affiliate.manage_your_link")}
        </div>
        <div className="rounded-t-lg md:rounded-xl mt-4 overflow-hidden border border-solid border-[#F2F2F2]">
          <Table>
            <TableHeader className="bg-[#DEDEDE] h-11">
              <TableRow>
                {column.map((col, index) => (
                  <TableHead
                    key={`header-table${index}`}
                    className={`text-[#212121] font-bold text-sm- max-md:text-[12px] ${col.classStyleHeader}`}
                  >
                    {col.header}
                  </TableHead>
                ))}
              </TableRow>
            </TableHeader>
            <TableBody>
              {dataLink?.length > 0 &&
                dataLink?.map((row, indexRow) => (
                  <TableRow
                    key={indexRow}
                    className="text-sm h-14 max-md:h-[54px]"
                  >
                    {column.map((col, i) => (
                      <TableCell
                        className={`text-[#212121] ${col.classStyleHeader}`}
                        key={i}
                      >
                        {col?.render
                          ? col.render(
                              row[col.key as keyof typeof row],
                              row,
                              indexRow
                            )
                          : (row as unknown as Record<string, string>)[col.key]}
                      </TableCell>
                    ))}
                  </TableRow>
                ))}
            </TableBody>
          </Table>
        </div>
      </div>
    </div>
  );
};

export default TrackingLinkDashboard;
