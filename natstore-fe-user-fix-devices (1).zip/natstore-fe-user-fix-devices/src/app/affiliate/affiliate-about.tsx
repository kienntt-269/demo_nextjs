import React from "react";
import Image from "next/image";

interface IProps {
  title: string;
  description: string;
}

const AffiliateAbout = ({ title, description }: IProps) => {
  return (
    <div className="rounded-2xl bg-gray p-6 max-lg:flex max-lg:gap-x-4 max-lg:px-4">
      <Image
        quality={100}
        unoptimized
        alt=""
        width={48}
        height={48}
        src={"./mobile-package/store_front.png"}
        className="max-lg:flex-shrink-0 max-lg:size-8"
      />
      <div>
        <div className="mt-6 max-lg:mt-0 font-bold text-xl text-black max-lg:text-[14px] max-lg:leading-5">
          {title}
        </div>
        <div className="mt-2 text-neutral-dark-04 font-bold leading-[21px] max-lg:font-normal max-lg:text-[14px]">
          {description}
        </div>
      </div>
    </div>
  );
};

export default AffiliateAbout;
