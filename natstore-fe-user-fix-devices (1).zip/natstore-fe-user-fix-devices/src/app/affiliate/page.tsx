"use client";
import React, { useEffect, useState } from "react";
import PageContent from "@/components/page-content";
import { ILinks } from "@/types/package";
import TitleStyle from "@/components/title-common";
import BreadCrumbCommon from "@/components/breadcrumb-common";
import AffiliateAbout from "@/app/affiliate/affiliate-about";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import affiliateApiRequest from "@/services/affiliate";
import { useTranslations } from "next-intl";
import { IAffiliateFAQ, IBannerAffiliate } from "@/types/affiliate";
import Image from "next/image";
import { getImageUrl } from "@/constants/imageUrl";

const AffiliatePage = () => {
  const t = useTranslations();
  const [listFAQ, setListFAQ] = useState<IAffiliateFAQ[]>([]);
  const [banner, setBanner] = useState<IBannerAffiliate>();
  const breadCrumb: ILinks[] = [
    {
      label: t("personal.home"),
      link: "/",
    },
    {
      label: t("affiliate.title"),
      link: "/affiliate",
    },
  ];

  const getListFAQ = async () => {
    try {
      const res = await affiliateApiRequest.getFAQ();
      console.log(res);
      setListFAQ(res.payload.data ?? []);
    } catch (error) {
      console.log(error);
    }
  };

  const getBanner = async () => {
    try {
      const res = await affiliateApiRequest.getBannerAffiliate();
      setBanner(res.payload.data);
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    getBanner();
    getListFAQ();
  }, []);
  return (
    <PageContent>
      <Image
        src={getImageUrl(`${banner?.imagePath}`)}
        alt="illustration roaming"
        width={1524}
        height={313}
        className="w-full h-[136px] md:h-[313px] md:rounded-3xl rounded-2xl"
        unoptimized
      />
      <div className="mt-6 max-lg:mt-4">
        <BreadCrumbCommon content={breadCrumb} />
      </div>
      <div className="mt-10 max-lg:mt-8 bg-white rounded-3xl p-8 max-lg:p-4">
        <TitleStyle classStyle="text-center">
          {t("affiliate.what_affiliate")}
        </TitleStyle>
        <div className="grid grid-cols-3 gap-x-6 mt-6 max-lg:flex max-lg:flex-col max-lg:gap-4">
          <AffiliateAbout
            title={t("affiliate.commission_policy")}
            description={t("affiliate.commission_description")}
          />{" "}
          <AffiliateAbout
            title={t("affiliate.unlimited_income")}
            description={t("affiliate.unlimited_description")}
          />{" "}
          <AffiliateAbout
            title={t("affiliate.product_diversity")}
            description={t("affiliate.product_description")}
          />
        </div>
      </div>
      <div className="mt-10 max-lg:mt-6 bg-white rounded-3xl p-8 max-lg:px-4 max-lg:py-6">
        <TitleStyle classStyle="text-center">
          {t("mobile_package.swap_sim.faq")}
        </TitleStyle>
        <div className="mt-8 max-lg:mt-4 max-lg:flex max-lg:flex-col max-lg:gap-4 grid grid-cols-2 gap-8 items-start">
          {listFAQ?.map((val) => {
            return (
              <div
                key={val.id}
                className="border-solid border border-[#C5C5C5] bg-gray rounded-lg h-auto w-full"
              >
                <Accordion type="single" collapsible>
                  <AccordionItem value={"1"}>
                    <AccordionTrigger className="!no-underline p-4 font-bold">
                      {val.question}
                    </AccordionTrigger>
                    <AccordionContent className="px-4 text-[14px] font-normal text-[#212121] whitespace-pre-line mt-3">
                      {val.answer}
                    </AccordionContent>
                  </AccordionItem>
                </Accordion>
              </div>
            );
          })}{" "}
        </div>
      </div>
    </PageContent>
  );
};

export default AffiliatePage;
