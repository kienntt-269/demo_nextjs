"use client";

import BreadCrumbCommon from "@/components/breadcrumb-common";
import { InputField } from "@/components/form";
import { InputPhoneNumberField } from "@/components/form/input-phone-number-field";
import PageContent from "@/components/page-content";
import { Form } from "@/components/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  DeviceOrderInformation,
  DeviceOrderInformationType,
  IDevicePreOrder,
} from "@/schemaValidations/device.schema";
import { ILinks } from "@/types/package";
import { useTranslations } from "next-intl";
import React, { useEffect, useMemo, useState } from "react";
import Image from "next/image";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Controller } from "react-hook-form";
import { IShowroomDetail } from "@/types/swap-sim";
import { IAddressDetail } from "@/schemaValidations/sim-card.schema";
import simApiRequest from "@/services/sim-service";
import clsx from "clsx";
import { IShowroomSwapSim } from "@/schemaValidations/mobile-package.schema";
import DateTimePickerField from "@/components/form/date-time-field";
import { Checkbox } from "@/components/ui/checkbox";
import OrderDevice from "@/app/devices/_components/order-device";
import { useRouter, useSearchParams } from "next/navigation";
import devicesApiRequest from "@/services/devices";
import { FAIL_CODE, SUCCESS_CODE3 } from "@/constants/http-response";
import { useProfileStore } from "@/_stores/useProfile.store";
import { useLoadingStore } from "@/_stores/useLoading,store";
import { formatPhoneSubmit } from "@/lib/utils";
import dayjs from "dayjs";
import { IDeviceOrder } from "@/types/device";
import { toastError, toastSuccess } from "@/hooks/use-toast";

const OrderInformation = ({ params }: { params: { deviceSlug: string } }) => {
  console.log("🚀 ~ OrderInformation ~ params:", params);
  const t = useTranslations("");
  const router = useRouter();
  const { user } = useProfileStore();
  const { setIsLoading } = useLoadingStore();
  const searchParams = useSearchParams();
  const schema = useMemo(() => DeviceOrderInformation(), []);
  const defaultValues = React.useMemo(
    () => ({
      email: user?.email ?? "",
      fullName: user?.userName ?? "",
      mobileNumber: user?.phoneNumber ?? "",
      districtId: "",
      paymentMethod: 1,
      receivedType: "1",
      vatPrice: 0,
      showroomId: null,
      provinceId: null,
      communeId: null,
      color: searchParams.get("color"),
      productId: Number(searchParams.get("id")),
      quantity: Number(searchParams.get("quantity")),
      price: Number(searchParams.get("price")),
    }),
    [user?.email, user?.userName, user?.phoneNumber, searchParams]
  );
  const [detailShowroom, setDetailShowroom] = useState<IShowroomDetail>({});
  const [provinces, setProvinces] = useState<IAddressDetail[]>([
    { name: t("common.no_data"), id: 0 },
  ]);
  const [districts, setDistricts] = useState<IAddressDetail[]>([
    { name: t("common.no_data"), id: 0 },
  ]);
  const [showRooms, setShowRooms] = useState<IShowroomSwapSim>([
    {
      name: t("common.no_data"),
      id: "0",
      location: "",
      order: "",
      active: false,
    },
  ]);
  const breadCrumb: ILinks[] = [
    {
      label: t("personal.home"),
      link: "/",
    },
    {
      label: t("search.device"),
      link: `/devices/${params.deviceSlug}?name=${searchParams.get("name")}`,
    },
    {
      label: t("common.order"),
      link: ``,
    },
  ];

  const getProvince = async () => {
    try {
      const res = await simApiRequest.getAddress({
        type: 1,
      });
      setProvinces(res.payload.data);
    } catch (error) {
      console.log(error);
    }
  };

  const getShowRoom = async (id: string) => {
    try {
      const res = await simApiRequest.getShowroomSim(id);
      if (res.payload.data.length > 0) {
        setShowRooms(res.payload.data);
      } else {
        setShowRooms([
          {
            name: t("common.no_data"),
            id: "0",
            location: "",
            order: "",
            active: false,
          },
        ]);
      }
    } catch (error) {
      console.log(error);
    }
  };

  const getDistrict = async (id: string) => {
    try {
      const res = await simApiRequest.getAddress({
        type: 2,
        parentId: id,
      });
      setDistricts(
        res?.payload?.data.length > 0
          ? res.payload.data
          : [{ name: t("common.no_data"), id: 0 }]
      );
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    getProvince();
  }, []);

  const handleSubmit = async (data: DeviceOrderInformationType) => {
    setIsLoading(true);
    try {
      const newData: IDeviceOrder = {
        email: data.email ?? "",
        fullName: data.fullName ?? "",
        mobileNumber: formatPhoneSubmit(data.mobileNumber ?? ""),
        showroomId: Number(data.showroomId),
        provinceId: Number(data.provinceId),
        districtId: data.districtId,
        timeOfReceiving: dayjs(data.timeOfReceiving).format(
          "DD/MM/YYYY hh:mm A"
        ),
        // paymentMethod: data.paymentMethod ?? "",
        receivedType: Number(data.receivedType),
        communeId: Number(data.communeId),
        productId: data.productId,
        quantity: data.quantity,
        price: data.price,
      };
      const res = await devicesApiRequest.postPreOrder(newData);
      if (res.payload.code === SUCCESS_CODE3) {
        toastSuccess(t("mobile_package.sim_normal.order_created_successfully"));
      } else if (res.payload.code === FAIL_CODE) {
        toastError(res.payload.message);
      }
      setIsLoading(false);
    } catch (error) {
      console.log("🚀 ~ handleSubmit ~ error:", error);
    }
  };

  return (
    <PageContent>
      <BreadCrumbCommon content={breadCrumb} />
      <Form<DeviceOrderInformationType, typeof schema>
        schema={schema}
        onSubmit={handleSubmit}
        options={{
          mode: "onChange",
        }}
        defaultValue={defaultValues}
        isUpdateDefault={true}
      >
        {({ control, formState: { errors, isValid }, watch, setValue }) => {
          const values = watch();
          return (
            <div className="grid grid-cols-7fr-3fr gap-x-6 mt-10 max-lg:mt-8 max-md:mt-4 max-xl:block">
              <div className="w-full bg-white rounded-3xl max-md:rounded-2xl p-8 max-md:p-4">
                <div className="text-[28px] max-md:text-[20px] font-bold">
                  {t("mobile_package.sim_normal.customer_information")}
                </div>
                <div className="mt-4 text-neutral-dark-04 text-[14px] max-md:text-[12px]">
                  (*) {t("mobile_package.sim_normal.please_fill_in")}
                </div>
                <div className="text-[20px] font-bold mt-8 max-md:mt-6 max-md:text-[16px]">
                  {t("mobile_package.sim_normal.personal_information")}
                </div>
                <div className="grid grid-cols-3 gap-x-6 gap-y-4 max-lg:gap-2 max-md:grid-cols-1 mt-4 max-md:mt-2">
                  <InputField
                    maxLength={50}
                    name="fullName"
                    label={t("mobile_package.swap_sim.full_name")}
                    classNameLabel="!font-normal text-sm lg:text-base !text-neutral-dark-01"
                    placeholder={t("mobile_package.swap_sim.full_name")}
                    type="text"
                    control={control}
                    errors={errors}
                    required
                    isPassValue
                  />
                  <InputPhoneNumberField
                    label={t("register.phone_number")}
                    control={control}
                    errors={errors}
                    id="mobileNumber"
                    name="mobileNumber"
                    type="text"
                    classNameLabel="!font-normal text-sm lg:text-base !text-neutral-dark-01"
                    placeholder={t("register.phone_number")}
                    required
                  />
                  <InputField
                    maxLength={255}
                    name="email"
                    label={t("register.email")}
                    classNameLabel="!font-normal text-sm lg:text-base !text-neutral-dark-01"
                    placeholder={t("register.email")}
                    type="text"
                    control={control}
                    errors={errors}
                    required
                    isPassValue
                  />
                </div>
                <div className="text-[20px] font-bold mt-8 mb-4 max-md:mt-6 max-md:text-[16px]">
                  {t("phone_device.delivery_method")}
                </div>
                <Controller
                  name="receivedType"
                  control={control}
                  render={({ field }) => (
                    <RadioGroup
                      {...field}
                      value={values.receivedType}
                      onValueChange={(event) => {
                        setValue("receivedType", event);
                        setValue("showroomId", null);
                        setValue("provinceId", null);
                        setValue("timeOfReceiving", undefined);
                        setDetailShowroom({});
                      }}
                    >
                      <div
                        className={`grid grid-cols-3 gap-x-4 max-md:grid-cols-1 max-2xl:grid-cols-2 max-2xl:gap-2`}
                      >
                        <label
                          htmlFor="in_store"
                          className={`w-full flex items-center cursor-pointer justify-between ${values.receivedType === "1" ? "bg-primary/20 border-primary text-primary font-bold" : "bg-[#F5F6F7] border-neutral font-normal text-neutral-dark-04"}   border-[2px] border-solio rounded-2xl py-3 px-6`}
                        >
                          <div className="flex items-center space-x-2 cursor-pointer gap-x-2 max-lg:text-[14px]">
                            <RadioGroupItem
                              value="1"
                              id="in_store"
                              className={`${values.receivedType === "1" ? "border-primary" : "border-neutral"}  border-[2px]`}
                            />
                            {t("mobile_package.sim_normal.in_store")}
                          </div>
                          <Image
                            src={
                              values.receivedType === "1"
                                ? "/store_app_active.svg"
                                : "/store_app.png"
                            }
                            width={24}
                            height={24}
                            unoptimized
                            quality={100}
                            alt="store app"
                          />
                        </label>
                      </div>
                    </RadioGroup>
                  )}
                />
                <div className="mt-4 grid grid-cols-2 gap-4 max-md:grid-cols-1 max-md:gap-2">
                  <div>
                    <label
                      htmlFor=""
                      className="text-sm lg:text-base max-md:font-medium"
                    >
                      {t("mobile_package.sim_normal.province_city")}
                    </label>
                    <span className="text-red-500">*</span>
                    <Controller
                      name="provinceId"
                      control={control}
                      render={({
                        field: { onChange },
                        fieldState: { error },
                      }) => {
                        return (
                          <div className="flex flex-col">
                            <Select
                              onValueChange={(value) => {
                                setValue("showroomId", "");
                                setDetailShowroom({});
                                getShowRoom(value);
                                onChange(value);
                                getDistrict(value);
                              }}
                            >
                              <SelectTrigger
                                className={clsx(
                                  "flex-1 py-[12px] px-[16px] h-[48px] rounded-xl mt-2 border-2 data-[placeholder]:text-neutral-mid-01",
                                  {
                                    "border-solid border border-error": !!error,
                                  }
                                )}
                              >
                                <SelectValue
                                  placeholder={t(
                                    "mobile_package.sim_normal.province_city"
                                  )}
                                />
                              </SelectTrigger>
                              <SelectContent>
                                {provinces?.map((val) => {
                                  return (
                                    <SelectItem
                                      key={val.id}
                                      value={`${val.id}`}
                                      className=""
                                      disabled={provinces?.[0].id === 0}
                                    >
                                      {val.name}
                                    </SelectItem>
                                  );
                                })}
                              </SelectContent>
                            </Select>
                            {error && (
                              <p className="text-red-500 text-sm mt-1">
                                {error.message}
                              </p>
                            )}
                          </div>
                        );
                      }}
                    />
                  </div>
                  <div>
                    <label className="text-sm md:text-base" htmlFor="">
                      {t("mobile_package.sim_normal.disctrict")}
                      <span className="text-red-500">*</span>
                    </label>
                    <Controller
                      name="districtId"
                      control={control}
                      render={({
                        field: { onChange, value },
                        fieldState: { error },
                      }) => {
                        return (
                          <div className="flex flex-col">
                            <Select
                              onValueChange={(value) => {
                                onChange(value);
                              }}
                              value={value}
                            >
                              <SelectTrigger
                                className={clsx(
                                  "flex-1 py-[12px] px-[16px] h-[48px] rounded-xl mt-2 data-[placeholder]:text-neutral-mid-01",
                                  {
                                    "border-solid border border-error": !!error,
                                  }
                                )}
                              >
                                <SelectValue
                                  placeholder={t(
                                    "mobile_package.sim_normal.disctrict"
                                  )}
                                />
                              </SelectTrigger>
                              <SelectContent>
                                {districts?.map((val) => {
                                  return (
                                    <SelectItem
                                      key={val.id}
                                      value={`${val.id ? val.id : null}`}
                                      disabled={districts?.[0].id === 0}
                                    >
                                      {val.name}
                                    </SelectItem>
                                  );
                                })}
                              </SelectContent>
                            </Select>
                            {error && (
                              <p className="text-red-500 text-sm mt-1">
                                {t(`common.message.${error.message}`)}
                              </p>
                            )}
                          </div>
                        );
                      }}
                    />
                  </div>
                  <div>
                    <label
                      htmlFor=""
                      className="text-sm lg:text-base max-md:font-medium"
                    >
                      {t("mobile_package.sim_normal.time_of_receiving")}
                    </label>{" "}
                    <span className="text-red-500">*</span>
                    <div className="mt-2">
                      <DateTimePickerField
                        name="timeOfReceiving"
                        control={control}
                        errors={errors}
                        placeholder={t(
                          "mobile_package.sim_normal.time_of_receiving"
                        )}
                        className="h-12"
                      />
                    </div>
                  </div>
                  <div>
                    <label
                      htmlFor=""
                      className="text-sm lg:text-base max-md:font-medium"
                    >
                      {t("common.store")}
                    </label>{" "}
                    <span className="text-red-500">*</span>
                    <Controller
                      name="showroomId"
                      control={control}
                      render={({
                        field: { onChange },
                        fieldState: { error },
                      }) => {
                        return (
                          <div className="flex flex-col">
                            <Select
                              onValueChange={(event) => {
                                const dataShowroom: IShowroomDetail =
                                  showRooms.find(
                                    (val) => val.id === event
                                  ) as IShowroomDetail;
                                setDetailShowroom(dataShowroom);
                                onChange(event);
                              }}
                            >
                              <SelectTrigger
                                className={clsx(
                                  "flex-1 py-[12px] px-[16px] h-[48px] rounded-xl mt-2 data-[placeholder]:text-neutral-mid-01",
                                  {
                                    "border-solid border border-error": !!error,
                                  }
                                )}
                              >
                                <SelectValue placeholder={t("common.store")} />
                              </SelectTrigger>
                              <SelectContent>
                                {showRooms?.map((val) => {
                                  return (
                                    <SelectItem
                                      key={val.id}
                                      value={val.id}
                                      disabled={showRooms?.[0].id === "0"}
                                    >
                                      {val.name}
                                    </SelectItem>
                                  );
                                })}
                              </SelectContent>
                            </Select>
                            {error && (
                              <p className="text-red-500 text-sm mt-1">
                                {error.message}
                              </p>
                            )}
                          </div>
                        );
                      }}
                    />
                    {detailShowroom?.id && (
                      <div className="mt-2 text-xs lg:text-base">
                        {t("mobile_package.sim_normal.store_address")}:
                        {detailShowroom?.location}
                        {detailShowroom?.districtName
                          ? `, ${detailShowroom.districtName}`
                          : ""}
                      </div>
                    )}
                  </div>
                </div>
                <div className="flex items-center flex-row max-md:flex-col max-md:items-start gap-4 mt-8 mb-4 max-md:my-6">
                  <div className="text-[20px] max-md:text-[16px] font-bold">
                    {t("mobile_package.swap_sim.payment_method")}
                  </div>
                  <RadioGroup
                    defaultValue={"1"}
                    value={"1"}
                    // onValueChange={(event) => {
                    //   setPaymentMethod(event);
                    // }}
                  >
                    <div className="grid grid-cols-3 gap-x-4 max-md:grid-cols-1 max-md:gap-y-2">
                      <label
                        htmlFor="paymentMethod"
                        className={`w-full flex items-center cursor-pointer justify-between`}
                      >
                        <div className="flex items-center space-x-2 cursor-pointer gap-x-2 max-lg:text-[14px]">
                          <RadioGroupItem
                            value="1"
                            id="paymentMethod"
                            className={`border-primary border-[2px]`}
                          />
                          {t("payment.cash_on_delivery")}
                        </div>
                      </label>
                    </div>
                  </RadioGroup>
                </div>

                <div className="flex gap-x-2 items-start">
                  <Controller
                    name="checkCondition"
                    control={control}
                    render={({ field: { onChange } }) => {
                      return (
                        <>
                          <Checkbox
                            checked={values.checkCondition}
                            onCheckedChange={(value) =>
                              onChange(value as boolean)
                            }
                            className="size-6"
                          />
                          <div className="text-sm text-[#A2A2A2]">
                            {t("payment.i_agree_to_the")}
                            <span
                              className="font-semibold text-primary underline ml-1 cursor-pointer"
                              onClick={() => {
                                router.push(
                                  `/customer-care/support?name=terms`
                                );
                              }}
                            >
                              {t("payment.terms_of_purchase")}
                            </span>
                          </div>
                        </>
                      );
                    }}
                  />
                </div>
              </div>
              <div className="w-full bg-white rounded-3xl max-md:rounded-2xl p-8 max-md:p-4 h-fit max-xl:mt-8 max-md:mt-4">
                <OrderDevice
                  isFormModified={!isValid}
                  data={
                    Object.fromEntries(
                      searchParams.entries()
                    ) as unknown as IDevicePreOrder
                  }
                />
              </div>
            </div>
          );
        }}
      </Form>
    </PageContent>
  );
};

export default OrderInformation;
