"use client";

import NumberInput from "@/components/form/input-number";
import TextWithTooltip from "@/components/text-width-tooltip";
import { Button } from "@/components/ui/button";
import { Ratings } from "@/components/ui/rating";
import { useIsMobile } from "@/hooks/use-mobile";
import { IDeviceDetail } from "@/schemaValidations/device.schema";
import dayjs from "dayjs";
import { useTranslations } from "next-intl";
import Image from "next/image";
import { useRouter } from "next/navigation";
import React, { useMemo, useRef, useState } from "react";

type PreOrderDeviceType = {
  data?: IDeviceDetail;
};

const PreOrderDevice = ({ data }: PreOrderDeviceType) => {
  const t = useTranslations("");
  const router = useRouter();
  const isMobile = useIsMobile();
  const inputRef = useRef<HTMLInputElement>(null);
  const [quantity, setQuantity] = useState<number>(1);
  const [color, setColor] = useState<string>();
  const [error, setError] = useState<string | null>(null);

  const priceOne = useMemo(() => {
    const today = dayjs();
    const start = dayjs(data?.promotionStartTime, "YYYY-MM-DD");
    const end = dayjs(data?.promotionEndTime, "YYYY-MM-DD");
    const price = Number(data?.price || 0);
    let finalPrice = price;

    if (today.isAfter(start, "day") && today.isBefore(end, "day")) {
      if (data?.discountType === 0) {
        // Giảm theo %: discountValue = 10 → giảm 10%
        finalPrice = price * (1 - (data?.discountValue ?? 0) / 100);
      } else {
        // Giảm theo số tiền cố định
        finalPrice = price - (data?.discountValue ?? 0);
      }
    }

    return finalPrice;
  }, [
    data?.promotionStartTime,
    data?.promotionEndTime,
    data?.price,
    data?.discountType,
    data?.discountValue,
  ]);

  const vat = useMemo(
    () => (data?.price ? Number((data.price * (data?.tax || 0)) / 100) : 0),
    [data?.price, data?.tax]
  );

  const handlePreOrder = () => {
    router.push(
      `/devices/${data?.slug}/order-infor?id=${data?.id}` +
        `${data?.color ? `&color=${data?.color}` : ""}` +
        `&quantity=${quantity}&name=${data?.name}` +
        `${data?.description ? `&description=${data?.description}` : ""}` +
        `&price=${(priceOne + vat) * quantity}&imagePath=${data?.imagePath}`
    );
  };

  const handleChangeNumberInput = (number: number) => {
    if (number) {
      setQuantity(number);
      // if (number > Number(data?.stockNumber)) {
      if (number > 999) {
        setError(t("common.message.number_input.max"));
      } else {
        setError("");
      }
    }
  };

  return (
    <div className="lg:px-8">
      <div className="flex items-center gap-4">
        <h2 className="text-xl lg:text-[28px] lg:leading-[34px] font-bold text-black">
          {data?.name}
        </h2>
        {data?.stockNumber === 0 && (
          <div className="text-sm py-1 px-[14px] text-neutral-mid-01 bg-[#E3E4E5] rounded-[34px] font-bold">
            {t("phone_device.out_of_stock")}
          </div>
        )}
      </div>
      {data?.ratePoint && (
        <div className="my-6 lg:my-8">
          <p className="text-sm lg:text-base text-black font-bold mb-1 lg:mb-2">
            {t("common.rating")}
          </p>
          <Ratings
            rating={data?.ratePoint ?? 0}
            variant="orange"
            className="flex"
            size={isMobile ? 16 : 24}
          />
        </div>
      )}
      <div className="mb-6 lg:mb-8 flex gap-4">
        <div className="flex-1">
          <p className="text-sm lg:text-base text-black font-bold mb-2">
            {t("common.quantity")}
          </p>
          <NumberInput
            defaultValue={1}
            value={quantity}
            onValueChange={handleChangeNumberInput}
            min={1}
            max={999}
            ref={inputRef}
            error={error}
            setError={setError}
            // customClassName="h-[24px]"
          />
        </div>
        {!!data?.colors?.length && (
          <div className="flex-1">
            <p className="text-sm lg:text-base text-black font-bold mb-2">
              {t("common.color")}
            </p>
            <div className="flex items-center gap-1">
              {data?.colors?.map((item) => (
                <div
                  key={item}
                  className={`size-5 rounded-full cursor-pointer relative border border-solid`}
                  style={{
                    borderColor: item !== color ? "white" : item,
                    backgroundColor: item === color ? "white" : item,
                  }}
                  onClick={() => setColor(item)}
                >
                  {item === color && (
                    <div
                      className="absolute rounded-full top-2/4 left-2/4 transform -translate-x-1/2 -translate-y-1/2 size-[10px]"
                      style={{ backgroundColor: item === color ? color : item }}
                    ></div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
      <div className="">
        {!!data?.promotion || !!data?.discountValue ? (
          <div className="bg-[#FF860029] rounded-2xl p-4 text-[#212121]">
            {!!data?.promotion && (
              <div className="mb-4 flex justify-between items-center gap-x-4">
                <div className="text-sm md:text-base font-bold self-start">
                  {t("internet.promotion")}
                </div>
                <div className="font-bold text-sm md:text-base max-w-40 md:max-w-96 whitespace-pre-line">
                  <TextWithTooltip content={data?.promotion} />
                </div>
              </div>
            )}
            {!!data.discountValue && (
              <div className="flex justify-between items-center gap-x-4">
                <div className="text-sm md:text-base font-bold self-start">
                  {t("phone_device.discount")}
                </div>
                <div className="font-bold text-sm md:text-base">
                  {data?.discountValue}%
                </div>
              </div>
            )}
          </div>
        ) : null}
        <div className="bg-[#F5F5F5] rounded-2xl p-4 text-[#212121] mt-2">
          <div className="mb-4 text-sm md:text-base font-bold self-start">
            {t("payment.estimated_cost")}
          </div>
          <div className="mb-4 flex justify-between items-center gap-x-4">
            <div className="text-sm md:text-base font-bold self-start">
              {t("common.vat")}
            </div>
            <div className="font-bold text-sm md:text-base max-w-40 md:max-w-96">
              {Number(vat)?.toLocaleString("en-US")} {t("internet.htg")}
            </div>
          </div>
          <div className="mb-4 flex justify-between items-center gap-x-4">
            <div className="flex flex-col gap-1">
              <div className="text-sm md:text-base font-bold">
                {t("common.price")}
              </div>
              {!!data?.discountValue && (
                <div className="text-[#616161] text-xs">
                  {t("common.original_device_price")}
                </div>
              )}
            </div>
            <div className="flex flex-col gap-1 items-end">
              {!!data?.discountValue ? (
                <>
                  <div className="font-bold text-sm md:text-base max-w-40 md:max-w-96 text-primary">
                    {Number(priceOne * quantity || 0)?.toLocaleString("en-US")}{" "}
                    {t("internet.htg")}
                  </div>
                  <div className="font-bold text-sm md:text-base max-w-40 md:max-w-96 line-through">
                    {Number(data?.price || 0)?.toLocaleString("en-US")}{" "}
                    {t("internet.htg")}
                  </div>
                </>
              ) : (
                <div className="font-bold text-sm md:text-base max-w-40 md:max-w-96 text-primary">
                  {Number(priceOne * quantity || 0)?.toLocaleString("en-US")}{" "}
                  {t("internet.htg")}
                </div>
              )}
            </div>
          </div>
          <div className="mb-4 w-full h-[1px] bg-[#E3E4E5]"></div>
          <div className="flex justify-between gap-x-4">
            <div className="flex flex-col gap-1">
              <div className="text-base md:text-xl font-bold text-[#333333]">
                {t("common.total")}
              </div>
              <div className="text-[#616161] text-xs">
                {`(${t("common.included_vat")})`}
              </div>
            </div>
            <div className="font-bold text-base md:text-xl max-w-40 md:max-w-96">
              {Number(priceOne * quantity + vat)?.toLocaleString("en-US")}{" "}
              {t("internet.htg")}
            </div>
          </div>
        </div>
        <div className="mt-4 lg:mt-6 flex flex-col md:flex-row xl:flex-col 2xl:flex-row items-center flex-wrap gap-2 lg:gap-4">
          <Button
            className="flex-1 w-full font-bold rounded-3xl max-md:py-[6px] max-2xl:py-[12px]"
            variant="secondary"
            onClick={() => router.back()}
          >
            {t("common.back")}
          </Button>
          <Button
            className="flex-1 w-full font-bold rounded-3xl max-md:py-[6px] max-2xl:py-[12px]"
            variant="secondary"
            disabled={data?.stockNumber === 0}
            onClick={() => {
              console.log("add cart");
            }}
          >
            <div className="flex items-center gap-2 justify-center">
              <Image
                unoptimized
                quality={100}
                src={"/svg/shopping-cart-active.svg"}
                width={24}
                height={24}
                alt="shopping image"
                className="max-md:size-4"
              />
              {t("common.add_to_cart")}
            </div>
          </Button>
          <Button
            onClick={handlePreOrder}
            className="flex-1 w-full font-bold rounded-3xl max-md:py-[6px] max-2xl:py-[12px]"
            disabled={data?.stockNumber === 0}
          >
            {t("mobile_package.sim_normal.pre_order")}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default PreOrderDevice;
