"use client";

import { useLangStore } from "@/_stores/useLang.store";
import { useLoadingStore } from "@/_stores/useLoading,store";
import DeviceItem from "@/app/devices/_components/devices-item";
import BreadCrumbCommon from "@/components/breadcrumb-common";
import NoDataAvailable from "@/components/common/no-data-available/no-data-available";
import { TOption } from "@/components/form";
import Select from "@/components/form/select";
import { getDevice, getDeviceCategories } from "@/lib/repository";
import { ICategories, IDeviceDetail } from "@/schemaValidations/device.schema";
import { ILinks } from "@/types/package";
import { useTranslations } from "next-intl";
import { useSearchParams } from "next/navigation";
import React, { useEffect, useState } from "react";

const DeviceSort = ({ categorySlug }: { categorySlug: string }) => {
  const { lang } = useLangStore();
  const t = useTranslations("");
  const { setIsLoading } = useLoadingStore();
  const searchParams = useSearchParams();

  const options: TOption[] = [
    {
      label: t("phone_device.price_to_high"),
      value: "price_asc",
    },
    {
      label: t("phone_device.price_to_low"),
      value: "price_desc",
    },
    {
      label: t("phone_device.rating_to_high"),
      value: "ratePoint_asc",
    },
    {
      label: t("phone_device.rating_to_low"),
      value: "ratePoint_desc",
    },
  ];

  const [items, setItems] = useState<IDeviceDetail[]>([]);
  const [category, setCategory] = useState<ICategories>();
  const [optionSort, setOptionSort] = useState<string>(options[0].value);

  const breadCrumb: ILinks[] = [
    {
      label: t("personal.home"),
      link: "/",
    },
    {
      label: t("search.device"),
      link: "/devices",
    },
    {
      label: category?.name ?? "",
      link: `/devices/${categorySlug}`,
    },
  ];
  const getData = async (sort: string) => {
    setIsLoading(true);
    try {
      const res = await getDevice({
        categoryId: searchParams.get("id") ?? "",
        page: 1,
        size: 999999,
        sort: sort,
      });
      setItems(res.pagination);
      setIsLoading(false);
    } catch (error) {
      console.log(error);
      throw Error("error");
    }
  };

  const getCategory = async () => {
    setIsLoading(true);
    try {
      const res = await getDeviceCategories();
      const category = res.find((item) => (item.id = items?.[0]?.categoryId));
      setCategory(category);
      setIsLoading(false);
    } catch (error) {
      console.log(error);
      throw Error("error");
    }
  };

  useEffect(() => {
    getData(optionSort);
  }, [lang, optionSort]);

  useEffect(() => {
    getCategory();
  }, [lang]);

  return (
    <>
      <BreadCrumbCommon content={breadCrumb} />
      <div className="mt-10 max-sm:mt-8">
        <div className="md:flex md:justify-end md:items-center">
          <Select
            className="md:min-w-[342px]"
            options={options}
            onValueChange={(value) => {
              setOptionSort(value);
            }}
          />
        </div>
        <div className="mt-6 max-md:mt-3">
          {!!items?.length ? (
            <div className="grid grid-cols-2 lg:grid-cols-3 gap-6 max-sm:gap-x-2 max-sm:gap-y-3">
              {items.map((data: IDeviceDetail) => (
                <DeviceItem
                  slugParent={categorySlug}
                  key={data.id}
                  data={data}
                />
              ))}
            </div>
          ) : (
            <NoDataAvailable />
          )}
        </div>
      </div>
    </>
  );
};

export default DeviceSort;
