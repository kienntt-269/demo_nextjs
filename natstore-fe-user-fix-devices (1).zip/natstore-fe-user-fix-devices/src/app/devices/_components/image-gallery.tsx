"use client";

import ImageCommon from "@/components/common/image-common";
import { getImageUrl } from "@/constants/imageUrl";
import { cx } from "class-variance-authority";
import React, { useState } from "react";
type ImageGalleryProps = {
  images?: { path: string; sort_order: string }[];
};

const ImageGallery = ({ images }: ImageGalleryProps) => {
  const [selected, setSelected] = useState(1);
  console.log(images?.[selected - 1]);
  return (
    <div className="w-full">
      <div className="relative lg:p-4 rounded-lg flex md:flex-col justify-center items-center gap-4 w-full">
        <div className="relative h-[248px] lg:h-[338px] max-w-[235px] sm:max-w-[346px] md:max-w-[457px] xl:max-w-[611px] w-full">
          <ImageCommon
            src={
              images?.[selected - 1]
                ? getImageUrl(images[selected - 1]?.path)
                : "/"
            }
            alt="Preview"
            fill
            className={cx("object-cover rounded-2xl", {
              "object-contain": images?.[selected - 1]?.path != "/",
            })}
          />
        </div>
        <div className="md:w-[calc(100%-170px)] max-md:max-h-[248px] overflow-auto">
          <div className="flex flex-col md:flex-row gap-2 min-w-max justify-center items-center">
            {images
              ?.sort((a, b) =>
                a.sort_order > b.sort_order
                  ? 1
                  : b.sort_order > a.sort_order
                    ? -1
                    : 0
              )
              ?.map((img, index) => (
                <div
                  key={index}
                  className={`cursor-pointer max-md:w-[56px] max-md:h-[56px] md:w-[132px] md:h-[140px] rounded-[8px] overflow-hidden border-2 ${index === selected - 1 ? "border-primary" : "border-transparent"}`}
                  onClick={() => setSelected(index + 1)}
                >
                  <ImageCommon
                    src={img?.path ? getImageUrl(img?.path) : "/"}
                    alt={`Thumbnail ${index}`}
                    width={132}
                    height={140}
                    className={cx("object-cover h-full w-full", {
                      "object-contain": img?.path != "/",
                    })}
                  />
                </div>
              ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ImageGallery;
