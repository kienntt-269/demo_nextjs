import DeviceItem from "@/app/devices/_components/devices-item";
import ButtonSeeMore from "@/components/btn-see-more";
import CarouselData from "@/components/common/carousel-data/carousel-data";
import NoDataAvailable from "@/components/common/no-data-available/no-data-available";
import TitleStyle from "@/components/title-common";
import {
  IDeviceCategories,
  IDeviceDetail,
} from "@/schemaValidations/device.schema";
import React from "react";

type IProp = {
  data?: IDeviceCategories;
};

const TabDeviceList = ({ data }: IProp) => {
  return (
    <div>
      <div className="mt-10 max-lg:mt-8 flex justify-between items-center relative">
        <div className="flex xl:gap-24 md:gap-10 items-center">
          <TitleStyle>{data?.name ?? ""}</TitleStyle>
        </div>
        {!!data?.children?.pagination?.length ? (
          <ButtonSeeMore
            href={`devices/${data.slug}?name=${data?.name}&id=${data?.id}`}
          />
        ) : null}
      </div>
      <div className="mt-4 max-md:mt-2 mb-6 max-md:mb-3 text-sm lg:text-xl text-neutral-dark-04 line-clamp-1 break-words">
        {data?.description ?? ""}
      </div>
      <div className="mb-6">
        {!!data?.children?.pagination?.length ? (
          <CarouselData
            customClass="lg:gap-4 mb-6 lg:mb-9"
            quantity={3}
            quantityMobile={2}
            length={3}
            isShowPaging={false}
          >
            {data?.children?.pagination?.map((item: IDeviceDetail) => (
              <DeviceItem key={item.slug} slugParent={data.slug} data={item} />
            ))}
          </CarouselData>
        ) : (
          <NoDataAvailable />
        )}
      </div>
    </div>
  );
};

export default TabDeviceList;
