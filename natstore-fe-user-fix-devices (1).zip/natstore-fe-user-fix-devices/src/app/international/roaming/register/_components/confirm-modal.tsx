import React, { useRef, useState } from "react";
import { useTranslations } from "next-intl";
import Modal from "@/components/common/modal/Modal";
import { Button } from "@/components/ui/button";
import { Option } from "@/types/common";
import { ConfirmModalProps } from "@/types/mobile-package";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { formatNumber } from "@/app/international/roaming/register/_components/register-item";
import { phoneSchemaFnc } from "@/lib/schema";
import InputCustom from "@/components/custom-ui/input-custom";
import { useLoadingStore } from "@/_stores/useLoading,store";
import { formatPhoneSubmit } from "@/lib/utils";

const ConfirmModal = ({
  data,
  isOpenModal,
  onClose,
  onRegister,
}: ConfirmModalProps) => {
  const t = useTranslations("mobile_package");
  const t2 = useTranslations("");
  const { setIsLoading } = useLoadingStore();
  const [optionRadio, setOptionRadio] = useState<string>();
  const [phoneNumber, setPhoneNumber] = useState<string>("");
  const [error, setError] = useState<string>();

  const inputRef = useRef<HTMLInputElement>(null);

  const optionRadios: Option[] = [
    {
      label: t("roaming.register_option_1"),
      value: "login_phone",
    },
    {
      label: t("roaming.register_option_2"),
      value: "other_phone",
    },
  ];

  const validatePhoneNumber = (value: string) => {
    const cleanedValue = value.replace(/\D/g, ""); // Chỉ giữ số
    if (cleanedValue.length == 0) {
      setError(t2(`common.message.phone.required`));
      return false;
    }
    setPhoneNumber(cleanedValue);

    const result = phoneSchemaFnc({ checkPrefix: true }).safeParse(
      cleanedValue
    );
    if (!result.success) {
      setError(t2(`common.message.${result.error.errors[0].message}`));
      return false;
    } else {
      setError("");
      return true;
    }
  };

  const handleChangeRadio = (value: string) => {
    setOptionRadio(value);
  };

  const handleRegister = () => {
    setIsLoading(true);
    if (optionRadio === "other_phone") {
      if (validatePhoneNumber(phoneNumber)) {
        onRegister(formatPhoneSubmit(phoneNumber));
      } else {
        inputRef.current?.focus();
      }
    } else {
      onRegister();
    }
  };

  return (
    <Modal
      contentClassName="w-[343px] lg:w-[504px] lg:max-w-full pb-[24px] pt-2 px-2 lg:p-6"
      isOpen={isOpenModal}
      title={t("roaming.confirm_phone_number")}
      onClose={onClose}
    >
      <div className="flex flex-col">
        <div className="text-center text-sm lg:text-base mt-4 lg:mt-2">
          {t.rich("roaming.confirm_register", {
            name: data?.name,
            price:
              (data?.price ? formatNumber(Number(data?.price)) : 100) +
              " " +
              t("htg"),
            strong: (chunks) => <strong>{chunks}</strong>,
          })}
        </div>
        <RadioGroup onValueChange={handleChangeRadio} className="mt-4 lg:mt-6">
          {optionRadios.map((item) => (
            <div
              key={item.value}
              className={`border-2 border-solid text-sm lg:text-base p-[14px] lg:p-6 rounded-xl ${optionRadio === item.value ? "bg-[#FFEBD6] border-[#FF8600]" : "text-neutral-dark-04 bg-[#F5F6F7] border-[#E3E4E5]"}`}
            >
              <div className="flex items-center">
                <RadioGroupItem value={item.value} id={item.value} />
                <label
                  className={`ml-[10px] ${optionRadio === item.value ? "text-primary font-bold" : ""}`}
                  htmlFor={item.value}
                >
                  {item.label}
                </label>
              </div>
              {item.value === "other_phone" &&
                optionRadio === "other_phone" && (
                  <div className="mt-2">
                    <InputCustom
                      classNameWrapper={`rounded-xl bg-white text-sm border`}
                      inputProps={{
                        placeholder: t("swap_sim.phone"),
                        autoFocus: true,
                        ref: inputRef,
                      }}
                      formatValueRegex={/[^0-9+]+/g}
                      value={phoneNumber}
                      onChange={(e) => validatePhoneNumber(e.target.value)}
                      prefix="+509"
                    />
                    {error && (
                      <p className="text-red-500 text-sm mt-1">{error}</p>
                    )}
                  </div>
                )}
            </div>
          ))}
        </RadioGroup>
        <div className="mt-6 mb-2 flex justify-center items-center text-base gap-2">
          <Button
            type="button"
            variant="secondary"
            className=" font-bold text-primary border-primary-orange min-w-[150px] lg:min-w-[212px]  rounded-3xl"
            onClick={onClose}
          >
            {t("roaming.cancel")}
          </Button>
          <Button
            className="min-w-[150px] lg:min-w-[212px]"
            disabled={
              !optionRadio || (optionRadio === "other_phone" && error != "")
            }
            onClick={handleRegister}
          >
            {t("roaming.register")}
          </Button>
        </div>
      </div>
    </Modal>
  );
};

export default ConfirmModal;
