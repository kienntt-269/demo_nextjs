import BreadCrumbCommon from "@/components/breadcrumb-common";
import PageContent from "@/components/page-content";
import BannerHomePage from "@/module/home-page/banner-home-page";
import { ILinks } from "@/types/package";
import { useTranslations } from "next-intl";
import React from "react";

const Layout = ({ children }: { children: React.ReactNode }) => {
  const t = useTranslations();
  const breadCrumb: ILinks[] = [
    {
      label: t("common.home"),
      link: "/",
    },
    {
      label: t("order_tracking.title"),
      link: `/order-tracking`,
    },
  ];

  return (
    <PageContent>
      <BannerHomePage />
      <div className="mt-6">
        <BreadCrumbCommon content={breadCrumb} />
      </div>
      {children}
    </PageContent>
  );
};

export default Layout;
