"use client";
import React, { useState } from "react";
import { useTranslations } from "next-intl";
import { Button } from "@/components/ui/button";
import OtpInputCustom from "@/components/custom-ui/input-otp-custom";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { formatPhoneView } from "@/lib/utils";

interface InternetProps {
  searchParams: {
    [key: string]: string | string[] | undefined;
  };
}

function FormInputOtp({ searchParams }: InternetProps) {
  console.log("searchParams", searchParams);
  const t = useTranslations();
  const router = useRouter();
  const [otp, setOtp] = useState("");
  return (
    <div>
      <h1 className="text-xl md:text-size-28 font-bold text-neutral-dark-01 text-center">
        {t("order_tracking.otp_code")}
      </h1>
      <div className="flex justify-center mt-4 md:mt-8">
        <Image
          src="/images/icon/input-otp.png"
          alt="input-otp"
          width={148}
          height={148}
          className="max-sm:size-24 lg:size-[148px] rounded-t-2xl"
        />
      </div>
      <p className="text-sm md:text-base mt-4 md:mt-8 text-center text-neutral-dark-02">
        {t("order_tracking.otp_code_desc", {
          phone: formatPhoneView(searchParams?.phoneNumber as string),
        })}
      </p>
      <div className="mt-6 md:mt-8 max-w-[351px] mx-auto">
        <OtpInputCustom value={otp} onChange={setOtp} />
        <p className="text-center mt-3 md:mt-4 text-[#A2A2A2] text-sm">
          {t("order_tracking.did_not_receive_otp")}{" "}
          <span className="text-primary font-semibold underline cursor-pointer">
            {t("order_tracking.resend_otp_code")}
          </span>
        </p>
        <p
          className="text-center mt-3 md:mt-4 text-sm text-primary underline cursor-pointer"
          onClick={() => router.back()}
        >
          {t("order_tracking.change_phone_number")}
        </p>
        <div className="text-center mt-6 md:mt-8">
          <Button
            className="mx-auto w-full md:max-w-[244px]"
            disabled={otp.length < 6}
          >
            {t("common.confirm")}
          </Button>
        </div>
      </div>
    </div>
  );
}

export default FormInputOtp;
