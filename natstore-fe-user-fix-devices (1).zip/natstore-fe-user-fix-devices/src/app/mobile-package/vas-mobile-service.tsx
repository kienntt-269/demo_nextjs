import TitleStyle from "@/components/title-common";
import CarouselData from "@/components/common/carousel-data/carousel-data";
import React from "react";
import VasItem from "@/app/mobile-package/vas/_components/vas-item";
import ButtonSeeMore from "@/components/btn-see-more";
import { VasListParams } from "@/types/mobile-package";
import mobilePackageApiRequest from "@/services/mobile-package";
import { getTranslations } from "next-intl/server";
import SubTabVas from "@/module/mobile-services/component/sub-tab-vas";
export const dynamic = "force-dynamic";

const getVasCategories = async () => {
  try {
    const res = await mobilePackageApiRequest.getVasCategories();
    return res.payload.data;
  } catch (error) {
    console.log(error);
    throw Error("error");
  }
};

const getListVas = async (data: VasListParams) => {
  try {
    const res = await mobilePackageApiRequest.getListVas(data);
    return res.payload.data;
  } catch (error) {
    console.log(error);
    throw Error("error");
  }
};

const VasMobileService = async ({
  searchParams,
}: {
  searchParams: { [key: string]: string | undefined };
}) => {
  const t = await getTranslations();
  const vasCategories = await getVasCategories();
  const vasListSimilar = await getListVas({
    categorySlug: searchParams?.vasSlug ?? vasCategories?.[0].children[0]?.slug,
    sortBy: "PRICE_DESC",
    promotion: true,
    latest: true,
  });
  return (
    <div className="mt-6 max-lg:mt-4">
      <div className="flex justify-between items-center w-full">
        <TitleStyle classStyle="text-[28px]">{t("common.vas")}</TitleStyle>
        <ButtonSeeMore href={"/mobile-package/vas"} />
      </div>
      <SubTabVas
        name="/mobile-package"
        searchParams={searchParams}
        categoriesRes={vasCategories}
      />
      <div className="mt-6 max-md:mt-3">
        <CarouselData quantity={4} length={vasListSimilar?.length}>
          {vasListSimilar?.map((data) => (
            <VasItem key={data.slug} data={data} />
          ))}
        </CarouselData>
      </div>
    </div>
  );
};

export default VasMobileService;
