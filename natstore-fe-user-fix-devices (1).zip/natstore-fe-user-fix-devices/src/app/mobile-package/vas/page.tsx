import { ILinks } from "@/types/package";
import BreadCrumbCommon from "@/components/breadcrumb-common";
import TabVasList from "@/app/mobile-package/vas/_components/tab-vas-list";
import { getTranslations } from "next-intl/server";
import mobilePackageApiRequest from "@/services/mobile-package";
import PageContent from "@/components/page-content";
import BannerHomePage from "@/module/home-page/banner-home-page";
import TitleStyle from "@/components/title-common";
import SubTabVas from "@/module/mobile-services/component/sub-tab-vas";
export const dynamic = "force-dynamic";
type VasPageProps = {
  params: { slug: string };
  searchParams: { [key: string]: string | undefined };
};

const getVasCategories = async () => {
  try {
    const res = await mobilePackageApiRequest.getVasCategories();
    return res.payload.data;
  } catch (error) {
    console.log(error);
    throw Error("error");
  }
};

export default async function VasPage({ searchParams }: VasPageProps) {
  const vasCategories = await getVasCategories();
  const t = await getTranslations();

  const breadCrumb: ILinks[] = [
    {
      label: t("personal.home"),
      link: "/",
    },
    {
      label: t("mobile_package.roaming.mobile_service"),
      link: "/mobile-package",
    },
    {
      label: t("common.vas"),
      link: "/mobile-packages/vas",
    },
  ];

  return (
    <PageContent>
      <BannerHomePage />
      <BreadCrumbCommon content={breadCrumb} />
      <div className="flex justify-between items-center mt-10 max-md:mt-6">
        <TitleStyle>{t("common.vas")}</TitleStyle>
      </div>
      <SubTabVas
        name="/mobile-package/vas"
        searchParams={searchParams}
        categoriesRes={vasCategories}
      />
      <div className="mt-6 max-md:mt-3">
        <TabVasList
          data={{
            categorySlug:
              searchParams?.vasSlug ?? vasCategories?.[0]?.children[0]?.slug,
            sortBy: "PRICE_DESC",
            promotion: true,
            latest: true,
          }}
        />
      </div>
    </PageContent>
  );
}
