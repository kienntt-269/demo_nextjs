"use client";

import React from "react";
import { Button } from "@/components/ui/button";
import { Ratings } from "@/components/ui/rating";
import { IVasDetail } from "@/schemaValidations/mobile-package.schema";
import { useTranslations } from "next-intl";
import { getImageUrl } from "@/constants/imageUrl";
import ImageCommon from "@/components/common/image-common";
import { cx } from "class-variance-authority";
import ComponentWithTooltip from "@/components/component-with-tooltip";

type VasItemProps = {
  data: IVasDetail;
};

const formatNumber = (num: number) => {
  return num < 1000 ? num.toString() : num.toLocaleString("en-US");
};

const VasItem = ({ data }: VasItemProps) => {
  const t = useTranslations();

  return (
    <div
      className="bg-white shadow hover:shadow-lg transition-shadow rounded-3xl"
      key={data.slug}
    >
      <ImageCommon
        src={data.imagePath ? getImageUrl(data.imagePath) : "/"}
        alt="bon_info"
        width={371}
        height={260}
        className={cx("max-sm:h-[112px] w-full h-[260px] rounded-t-2xl", {
          "object-contain": data.imagePath,
        })}
      />
      <div className="flex flex-col p-3 pb-4 lg:p-6">
        <div className="grow mb-4 lg:mb-6">
          <h2 className="text-sm lg:text-2xl font-bold truncate text-black">
            <ComponentWithTooltip content={data?.name}>
              <div className="text-[24px] max-sm:text-sm max-xl:text-[18px] max-2xl:text-[20px] font-bold overflow-hidden text-ellipsis whitespace-nowrap">
                {data?.name}
              </div>
            </ComponentWithTooltip>
          </h2>
          <p className="text-xs lg:text-sm text-neutral-dark-04 h-8 lg:h-10 my-2 lg:my-3 line-clamp-2 break-words">
            {data.description ?? "-"}
          </p>
          <div className="flex gap-2 mb-1 lg:mb-2">
            <p className="text-sm lg:text-xl font-bold">
              {formatNumber(Number(data.price))}
            </p>
            <p className="text-sm lg:text-xl font-bold text-neutral-mid-01">
              {t("mobile_package.htg")}
            </p>
          </div>
          <div className="">
            <Ratings
              rating={data?.rating ?? 0}
              variant="orange"
              className="max-md:hidden flex"
            />
            <Ratings
              rating={data?.rating ?? 0}
              variant="orange"
              size={12}
              className="hidden max-md:flex"
            />
          </div>
        </div>
        <Button
          navigate={`/mobile-package/vas/${data.slug}`}
          className="w-full grow-0 rounded-3xl font-semibold"
          variant="secondary"
        >
          {t("mobile_package.detail")}
        </Button>
      </div>
    </div>
  );
};

export default VasItem;
