"use client";
import React, { useEffect, useRef, useState } from "react";
import mobileApiRequest from "@/services/mobile-service";
import {
  ICategoriesDataPlant,
  IDataPlan,
} from "@/schemaValidations/mobile-service.schema";
import CarouselData from "@/components/common/carousel-data/carousel-data";
import CardCommon from "@/components/card-common";
import SubTabMobileData from "@/module/mobile-services/component/sub-tab-mobile-data";
import TabCommon from "@/components/tabs-common";
import { IDataServiceCategoriesRes } from "@/schemaValidations/service-categories";
import ButtonSeeMore from "@/components/btn-see-more";
import { Skeleton } from "@/components/ui/skeleton";
import { useIsMobile } from "@/hooks/use-mobile";
import { useLangStore } from "@/_stores/useLang.store";

const DataPlansMobile = () => {
  const [listCategoriesMobile, setListCategoriesMobile] =
    useState<IDataServiceCategoriesRes>();
  const [loading, setLoading] = useState(true);
  const containerRef = useRef<HTMLDivElement>(null);
  const tabRef = useRef<HTMLDivElement>(null);
  const [showSeeMore, setShowSeeMore] = useState<boolean>(true);
  const [activeTab, setActiveTab] = useState(0);
  const [tabActiveChildren, setTabActiveChildren] = useState<number>(0);
  const [listSubCategories, setListSubCategories] = useState<
    ICategoriesDataPlant[]
  >([]);
  const isMobile = useIsMobile();
  const { lang } = useLangStore();
  const [listDataPackage, setListDataPackage] = useState<IDataPlan[]>([]);

  useEffect(() => {
    getListCategoriesMobile();
  }, []);

  useEffect(() => {
    const checkOverflow = () => {
      if (containerRef.current && tabRef.current) {
        const containerWidth = containerRef?.current?.offsetWidth;
        const tabWidth = tabRef?.current?.scrollWidth;
        if (tabWidth + 120 > containerWidth) {
          setShowSeeMore(false);
        } else {
          setShowSeeMore(true);
        }
      }
    };

    checkOverflow();
    window.addEventListener("resize", checkOverflow);
    return () => window.removeEventListener("resize", checkOverflow);
  }, [listCategoriesMobile]);

  const getListCategoriesMobile = async () => {
    try {
      const res = await mobileApiRequest.getListCategoriesMobile();
      setListCategoriesMobile(res.payload);
      setListSubCategories(
        res.payload.data?.[0]?.children?.[0]?.children ?? []
      );
    } catch (error) {
      console.log(error);
      throw Error("error");
    }
  };
  const handleTabChange = (index: number) => {
    setActiveTab(index);
    setTabActiveChildren(0);
    setListDataPackage([]);
    setListSubCategories(
      listCategoriesMobile?.data?.[0]?.children?.[index]?.children ?? []
    );
  };

  useEffect(() => {
    if (listCategoriesMobile) {
      getListData();
    }
  }, [activeTab, tabActiveChildren, listCategoriesMobile, lang]);

  const getListData = async () => {
    setLoading(true);
    try {
      if (listSubCategories?.length === 0) {
        console.log(listCategoriesMobile);
        const res = await mobileApiRequest.getDataMobileService({
          categorySlug:
            listCategoriesMobile?.data[0]?.children[activeTab]?.slug,
        });
        setListDataPackage(res.payload.data);
      } else {
        const res = await mobileApiRequest.getDataMobileService({
          categoryId:
            listCategoriesMobile?.data?.[0]?.children?.[activeTab]?.children[
              tabActiveChildren
            ].id,
        });

        setListDataPackage(res.payload.data);
      }
      setTimeout(() => {
        setLoading(false);
      }, 300);
    } catch (error) {
      console.log(error);
      throw Error("error");
    }
  };

  const tabs =
    listCategoriesMobile?.data?.[0]?.children?.map((item) => ({
      label: item.name,
    })) || [];

  return (
    <div className="mt-10 max-lg:mt-8 max-md:mt-6">
      {!showSeeMore && (
        <div className="flex justify-end">
          {!!listCategoriesMobile?.data?.[0]?.children?.length ? (
            <ButtonSeeMore
              href={`/mobile-package/${listCategoriesMobile?.data?.[0]?.children?.[activeTab]?.slug}`}
            />
          ) : null}
        </div>
      )}
      <div
        className="mt-6 max-md:mt-3 flex items-center justify-between"
        ref={containerRef}
      >
        <div ref={tabRef}>
          <TabCommon tabs={tabs} onChangeTab={handleTabChange} />
        </div>
        {showSeeMore && (
          <ButtonSeeMore
            href={`/mobile-package/${listCategoriesMobile?.data?.[0]?.children?.[activeTab]?.slug}`}
          />
        )}
      </div>
      <SubTabMobileData
        listSubCategories={listSubCategories}
        onChangeTab={(tab) => {
          setTabActiveChildren(tab);
        }}
        activeTab={tabActiveChildren}
      />
      {loading ? (
        <div className="flex">
          {Array(isMobile ? 2 : 4)
            .fill(null)
            .map((_, index) => (
              <Skeleton
                key={index}
                className="md:h-[306px] h-[257px] w-[371px] mt-6 mr-6 rounded-3xl"
              />
            ))}
        </div>
      ) : (
        <div className="mt-6 max-md:mt-3">
          <CarouselData quantity={4} length={listDataPackage.length}>
            {listDataPackage?.map((val: IDataPlan) => {
              return (
                <CardCommon
                  key={val.id}
                  type="medium"
                  data={val}
                  target="data"
                  redirectBuy={`/mobile-package/data/${val.slug}/payment`}
                  redirectLink={`/mobile-package/data/${val.slug}`}
                />
              );
            })}
          </CarouselData>
        </div>
      )}
    </div>
  );
};

export default DataPlansMobile;
