import React from "react";
import { ILinks } from "@/types/package";
import BreadCrumbCommon from "@/components/breadcrumb-common";
import PageContent from "@/components/page-content";
import TitleStyle from "@/components/title-common";
import { getTranslations } from "next-intl/server";
import StepSimComponent from "@/app/mobile-package/buy-sim/step-sim";
import RadioBuySim from "@/app/mobile-package/buy-sim/radio-buy-sim";
// import ListSimPackage from "./list-sim-package";
import TableSIM from "@/components/common/table-sim/table-sim";
import simApiRequest from "@/services/sim-service";
import SelectMainPackageSim from "@/app/mobile-package/buy-sim/select-main-package";
import { Metadata } from "next";
import TabSimChange from "@/app/mobile-package/buy-sim/tab-sim";

export const dynamic = "force-dynamic";

const getDataSim = async (
  page: number | string,
  isdnNumber: string,
  sort: string,
  hotKey: string,
  typeCard: string
) => {
  try {
    const res = await simApiRequest.getListSim({
      page: page ?? 1,
      size: 10,
      isdnNumber: hotKey ? "" : isdnNumber,
      sort,
      hotKey,
      typeCard,
    });
    return res.payload;
  } catch (error) {
    console.log(error);
    throw Error("error");
  }
};

const getInformationSimType = async (type: string) => {
  try {
    const res = await simApiRequest.getSimTypeDetail(type ?? "1");
    return res.payload;
  } catch (error) {
    console.log(error);
    throw Error("error");
  }
};

const BuySIMPage = async ({
  searchParams,
}: {
  searchParams: { [key in string]: string };
}) => {
  const t = await getTranslations();
  const response = await getDataSim(
    searchParams.page,
    searchParams.isdnNumber,
    searchParams.sortBy,
    searchParams.hotKey,
    searchParams.typeCard
  );
  const resInformationSim = await getInformationSimType(searchParams.type);
  const simTypeChange = () => {
    switch (searchParams.type) {
      case "1":
        return t("mobile_package.sim_normal.xchange_sim");
      case "2":
        return t("mobile_package.sim_normal.student_sim");
      case "3":
        return t("mobile_package.sim_normal.dcom_sim");
      default:
        return t("mobile_package.sim_normal.xchange_sim");
    }
  };
  const jsonLd = {
    "@context": "https://schema.org/",
    "@type": "Product",
    name: `${simTypeChange()}`,
    image: [],
    description: `${resInformationSim.data.description}`,
    sku: `${resInformationSim.data.name}`,
    mpn: `${resInformationSim.data.name}`,
    brand: {
      "@type": "Brand",
      name: `${resInformationSim.data.value}`,
    },
    aggregateRating: {
      "@type": "AggregateRating",
    },
    offers: {
      "@type": "Offer",
      url: `https://natcomstore.arabicatech.vn/mobile-package/buy-sim?slug=${searchParams.slug}`,
      priceCurrency: "HTG",
    },
  };

  const breadCrumb: ILinks[] = [
    {
      label: t("personal.home"),
      link: "/",
    },
    {
      label: t("mobile_package.roaming.mobile_service"),
      link: "/mobile-package",
    },
    {
      label: t("mobile_package.swap_sim.buy_sim"),
      link: "/mobile-package/buy-sim",
    },
  ];

  return (
    <PageContent>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />
      <div className="">
        <BreadCrumbCommon content={breadCrumb} />
      </div>
      <div className="mt-10 max-lg:mt-8 max-md:mt-4">
        <TitleStyle classStyle="text-center">
          {t("mobile_package.swap_sim.buy_sim")}
        </TitleStyle>
        <StepSimComponent />
        <TabSimChange searchParams={searchParams} />
        <div className="mt-6 max-lg:mt-4">
          <TableSIM
            searchParams={searchParams}
            simType={resInformationSim.data}
            response={response}
          />
          <div className="mt-10 max-lg:mt-4">
            <RadioBuySim searchParams={searchParams} />
          </div>
        </div>
        <SelectMainPackageSim />
      </div>
    </PageContent>
  );
};

export const generateMetadata = async ({
  searchParams,
}: {
  searchParams: { [key in string]: string };
}): Promise<Metadata> => {
  const resInformationSim = await getInformationSimType(searchParams.type);
  console.log("resInformationSim", resInformationSim);
  const data = resInformationSim.data;
  const url = `https://natcomstore.arabicatech.vn/mobile-package/buy-sim?slug=${searchParams.slug}&isdnNumber=${searchParams.isdnNumber}&hotKey=${searchParams.hotKey}&type=${searchParams.type}`;

  return {
    title: data?.value,
    description: data?.description,
    keywords: [
      `${data.name}`,
      `${data.value}`,
      `sim ${searchParams.slug}`,
      `${searchParams.hotKey}`,
    ],
    alternates: {
      canonical: url,
    },
    generator: "data",
    openGraph: {
      title: `${data?.name}`,
      description: `${data?.description}`,
      images: [
        searchParams?.type === "1"
          ? "https://natcomstore.arabicatech.vn/mobile-package/bg_description_sim.png"
          : searchParams.type === "2"
            ? "https://natcomstore.arabicatech.vn/mobile-package/student-sim.png"
            : "https://natcomstore.arabicatech.vn/mobile-package/d-com-sim.png",
      ],
      type: "website",
      url: url,
    },
    metadataBase: new URL(url),
    twitter: {
      card: "summary_large_image",
      title: `${data?.name}`,
      description: `${data?.description}`,
      images: [
        searchParams?.type === "1"
          ? "https://natcomstore.arabicatech.vn/mobile-package/bg_description_sim.png"
          : searchParams.type === "2"
            ? "https://natcomstore.arabicatech.vn/mobile-package/student-sim.png"
            : "https://natcomstore.arabicatech.vn/mobile-package/d-com-sim.png",
      ],
      site: "Product",
    },
  };
};

export default BuySIMPage;
