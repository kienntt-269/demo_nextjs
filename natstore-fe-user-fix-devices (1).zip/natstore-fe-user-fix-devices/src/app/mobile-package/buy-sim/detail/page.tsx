"use client";
import OrderSimNormal from "@/app/mobile-package/buy-sim/detail/order-sim-normal";
import StepSimComponent from "@/app/mobile-package/buy-sim/step-sim";
import BreadCrumbCommon from "@/components/breadcrumb-common";
import PageContent from "@/components/page-content";
import { Form, InputField, SelectField } from "@/components/form";
import TitleStyle from "@/components/title-common";
import { ILinks } from "@/types/package";
import { useTranslations } from "next-intl";
import React, { useEffect, useMemo, useState } from "react";
import { paymentService } from "@/services/payment-service";
import {
  IAddressDetail,
  SimRegisterInformation,
  SimRegisterInformationType,
} from "@/schemaValidations/sim-card.schema";
import dayjs from "dayjs";
import DatePickerField from "@/components/form/date-picker-field";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import Image from "next/image";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Controller } from "react-hook-form";
import { useRouter, useSearchParams } from "next/navigation";
import { toastError } from "@/hooks/use-toast";
import simApiRequest from "@/services/sim-service";
import { IShowroomSwapSim } from "@/schemaValidations/mobile-package.schema";
import { InputPhoneNumberField } from "@/components/form/input-phone-number-field";
import DateTimePickerField from "@/components/form/date-time-field";
import { ISimCardOrder } from "@/types/mobile-package";
import { useSimCardStore } from "@/_stores/useSimCard.store";
import { useLoadingStore } from "@/_stores/useLoading,store";
import { checkResSuccess, formatPhoneSubmit } from "@/lib/utils";
import OrderSimSuccess from "@/app/mobile-package/buy-sim/detail/order-sim-success";
import OrderSimError from "@/app/mobile-package/buy-sim/detail/order-sim-error";
import { storage } from "@/lib/storage";
import { getTypeOfDocV2 } from "@/constants/variable";
// import { REGEX_INPUT_ID_CARD } from "@/constants/regex";
import UploadFileSingle from "@/components/form/upload-file-single";
import { IShowroomDetail } from "@/types/swap-sim";
import clsx from "clsx";
import { useIsMobile } from "@/hooks/use-mobile";
// import { IPaymentMethod } from "@/types/payment";

function RegisterSimNormal() {
  const router = useRouter();
  const t = useTranslations();
  const searchParams = useSearchParams();
  const isMobile = useIsMobile();
  // const [listPaymentMethod, setListPaymentMethod] = useState<IPaymentMethod[]>(
  //   []
  // );
  const { setIsLoading } = useLoadingStore();
  const [showRooms, setShowRooms] = useState<IShowroomSwapSim>([
    {
      name: t("common.no_data"),
      id: "0",
      location: "",
      order: "",
      active: false,
    },
  ]);
  const [detailShowroom, setDetailShowroom] = useState<IShowroomDetail>({});
  const [provinces, setProvinces] = useState<IAddressDetail[]>([
    { name: t("common.no_data"), id: 0 },
  ]);
  // const [districts, setDistricts] = useState<IAddressDetail[]>([]);
  const { simDetail, packageData } = useSimCardStore();

  const breadCrumb: ILinks[] = [
    {
      label: t("personal.home"),
      link: "/",
    },
    {
      label: t("mobile_package.roaming.mobile_service"),
      link: "/mobile-package",
    },
    {
      label: t("mobile_package.swap_sim.buy_sim"),
      link: "/mobile-package/buy-sim",
    },
  ];

  const getProvince = async () => {
    try {
      const res = await simApiRequest.getAddress({
        type: 1,
      });
      setProvinces(res.payload.data);
    } catch (error) {
      console.log(error);
    }
  };

  const getPaymentMethods = async () => {
    try {
      const res = await paymentService.getPaymentMethods("sim");
      console.log(res);
    } catch (error) {
      console.log(error);
    }
  };

  const getShowRoom = async (id: string) => {
    try {
      const res = await simApiRequest.getShowroomSim(id);
      if (res.payload.data.length > 0) {
        setShowRooms(res.payload.data);
      } else {
        setShowRooms([
          {
            name: t("common.no_data"),
            id: "0",
            location: "",
            order: "",
            active: false,
          },
        ]);
      }
    } catch (error) {
      console.log(error);
    }
  };

  const handleSubmit = async (data: SimRegisterInformationType) => {
    setIsLoading(true);
    registerSimCard(data);
  };

  const registerSimCard = async (data: SimRegisterInformationType) => {
    try {
      storage.setSimRegister(searchParams.get("idSim") ?? "");
      const formmattedTimeReceive = dayjs(data.timeOfReceiving).format(
        "DD/MM/YYYY hh:mm A"
      );
      const formattedDOB = dayjs(data.dob).format("DD/MM/YYYY");
      const newData: ISimCardOrder = {
        request: {
          simNumber: simDetail?.isdn,
          type: Number(data.type),
          price: simDetail?.price,
          packageId: Number(packageData?.id),
          packagePrice: Number(packageData?.price),
          vatPrice: Number(data.vatPrice),
          provinceId: Number(data.provinceId),
          fullName: data.fullName ?? "",
          dob: formattedDOB,
          cardId: data.cardId ?? "",
          vatId: 0,
          mobileNumber: formatPhoneSubmit(data.mobileNumber ?? ""),
          simType: Number(data.simType),
          receivedType: Number(data.receivedType),
          timeOfReceiving: formmattedTimeReceive,
          showroomId: Number(data.showroomId),
          typeDocument: Number(data?.typeDocument),
          email: data.email ?? undefined,
          whatsappNumber: "",
          // paymentMethod: searchParams.get("typeSim") === "1" ? "physical" : "",
        },
      };
      const formData = new FormData();
      formData.append(
        "request",
        new Blob([JSON.stringify(newData.request)], {
          type: "application/json",
        })
        // JSON.stringify(newData.request)
      );
      if (
        data.backIdcard &&
        data.backIdcard.length > 0 &&
        data.frontIdCard &&
        data.frontIdCard.length > 0 &&
        data.faceImage &&
        data.faceImage.length > 0
      ) {
        formData.append("frontIdCard", data.frontIdCard[0]);
        formData.append("backIdCard", data.backIdcard[0]);
        formData.append("faceImage", data.faceImage[0]);
      } else {
        formData.append(
          "frontIdCard",
          new File([], "empty-face.jpg", { type: "image/jpeg" })
        );
        formData.append(
          "backIdCard",
          new File([], "empty-face.jpg", { type: "image/jpeg" })
        );
        formData.append(
          "faceImage",
          new File([], "empty-face.jpg", { type: "image/jpeg" })
        );
      }
      const res = await simApiRequest.orderSimCard(formData);
      if (checkResSuccess(res.payload.code)) {
        if (res?.payload?.data?.paymentUrl) {
          window.open(
            `${res.payload.data.paymentUrl}&simCardOrderId=${res?.payload?.data?.simCardOrderId}&orderId=${res?.payload?.data?.orderId}`,
            "_self"
          );
        } else if (res?.payload?.data?.status === "FAILED") {
          router.push(
            `/mobile-package/buy-sim/detail?idSim=${searchParams.get("idSim")}&statusPayment=error&type=${searchParams.get("type")}&package=${searchParams.get("package")}&orderId=${res.payload.data.simCardOrderId}&esim=true`
          );
        } else {
          router.push(
            `/mobile-package/buy-sim/detail?idSim=${searchParams.get("idSim")}&statusPayment=success&type=${searchParams.get("type")}&package=${searchParams.get("package")}&orderId=${res.payload.data.simCardOrderId}`
          );
        }
      } else if (res.payload.code === "01") {
        const errorsFromBE = res.payload.data;
        const allErrorMessages = Object.values(errorsFromBE);
        toastError(t(`${allErrorMessages}`));
      } else {
        toastError(
          t(`payment.message.${res.payload.code}`) ||
            res?.payload?.message ||
            t(`payment.message.99`)
        );
      }
      setIsLoading(false);
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    getProvince();
    getPaymentMethods();
  }, []);

  const schema = useMemo(() => SimRegisterInformation(), []);

  return (
    <PageContent>
      <BreadCrumbCommon content={breadCrumb} />
      {searchParams.get("statusPayment") === "success" && (
        <OrderSimSuccess searchParams={searchParams} />
      )}
      {searchParams.get("statusPayment") === "error" && (
        <OrderSimError searchParams={searchParams} />
      )}
      {!searchParams.get("statusPayment") && (
        <>
          <div className="mt-10 max-lg:mt-8 max-md:mt-4">
            <TitleStyle classStyle="text-center">
              {t("mobile_package.swap_sim.buy_sim")}
            </TitleStyle>
            <StepSimComponent step={2} />
          </div>
          <Form<SimRegisterInformationType, typeof schema>
            schema={schema}
            onSubmit={handleSubmit}
            options={{
              mode: "all",
            }}
            defaultValue={{
              email: "",
              files: [],
              simNumber: simDetail?.isdn ?? "1",
              simType: searchParams.get("typeSim"),
              type: searchParams.get("type") ?? "",
              receivedType: "1",
              paymentMethod: 1,
              whatsappNumber: "",
              vatPrice: 0,
              showroomId: null,
              provinceId: null,
            }}
          >
            {({
              control,
              formState: { errors, isValid },
              watch,
              setValue,
              trigger,
            }) => {
              const values = watch();
              // console.log(values);
              return (
                <div className="grid grid-cols-7fr-3fr gap-x-6 mt-10 max-lg:mt-8 max-md:mt-4 max-xl:block">
                  <div className="w-full bg-white rounded-3xl p-8 max-md:px-4 max-md:py-6">
                    <div className="text-[28px] max-md:text-[20px] font-bold">
                      {t("mobile_package.sim_normal.customer_information")}
                    </div>
                    <div className="mt-4 text-neutral-dark-04 text-[14px] max-md:text-[12px]">
                      (*) {t("mobile_package.sim_normal.please_fill_in")}
                    </div>
                    <div className="text-[20px] font-bold mt-8 max-md:mt-6 max-md:text-[16px]">
                      {t("mobile_package.sim_normal.personal_information")}
                    </div>
                    <div className="grid grid-cols-3 gap-x-6 gap-y-4 max-lg:gap-2 max-md:grid-cols-1 mt-4 max-md:mt-2">
                      <InputField
                        maxLength={50}
                        name="fullName"
                        label={t("mobile_package.swap_sim.full_name")}
                        classNameLabel="!font-normal text-sm lg:text-base !text-neutral-dark-01"
                        placeholder={t("mobile_package.swap_sim.full_name")}
                        type="text"
                        control={control}
                        errors={errors}
                        required
                      />
                      <InputPhoneNumberField
                        label={t("register.phone_number")}
                        control={control}
                        errors={errors}
                        id="mobileNumber"
                        name="mobileNumber"
                        type="text"
                        classNameLabel="!font-normal text-sm lg:text-base !text-neutral-dark-01"
                        placeholder={t("register.phone_number")}
                        required
                      />
                      <DatePickerField
                        name="dob"
                        label={t("mobile_package.swap_sim.date_placholder")}
                        control={control}
                        errors={errors}
                        placeholder={t(
                          "mobile_package.swap_sim.date_placholder"
                        )}
                        classNameLabel="!font-normal text-sm lg:text-base !text-neutral-dark-01"
                        required
                      />
                      <div>
                        <SelectField
                          control={control}
                          error={errors.typeDocument}
                          placeholder={t("mobile_package.swap_sim.type_of_doc")}
                          name="typeDocument"
                          label={t("mobile_package.swap_sim.type_of_doc")}
                          classNameLabel="!font-normal text-sm lg:text-base !text-neutral-dark-01"
                          trigger={trigger}
                          options={getTypeOfDocV2(t).map((item) => ({
                            label: item.name,
                            value: item.id + "",
                          }))}
                          required
                        />
                      </div>
                      <InputField
                        // formatValueRegex={REGEX_INPUT_ID_CARD}
                        // maxLength={20}
                        name="cardId"
                        label={t("mobile_package.sim_normal.id_card")}
                        placeholder={t("mobile_package.sim_normal.id_card")}
                        classNameLabel="!font-normal text-sm lg:text-base !text-neutral-dark-01"
                        type="text"
                        className=""
                        control={control}
                        errors={errors}
                        required
                        disabled={!values.typeDocument}
                      />
                      <InputField
                        maxLength={255}
                        name="email"
                        label={t("register.email")}
                        classNameLabel="!font-normal text-sm lg:text-base !text-neutral-dark-01"
                        placeholder={t("register.email")}
                        type="text"
                        control={control}
                        errors={errors}
                        required={
                          searchParams.get("typeSim") === "2" ? true : false
                        }
                      />
                    </div>
                    <div className="mt-4 text-neutral-dark-04">
                      <div className="font-bold max-md:text-[14px]">
                        {t("common.note")}:
                      </div>
                      <ul className="list-disc pl-4 text-[14px] max-md:text-[10px]">
                        <li>{t("mobile_package.sim_normal.each_type_of")}</li>
                        <li>
                          {t("mobile_package.sim_normal.for_student_sim_card")}
                        </li>
                      </ul>
                    </div>
                    {searchParams.get("typeSim") === "1" && (
                      <>
                        <div className="text-[20px] font-bold mt-8 mb-4 max-md:text-base max-md:mt-6">
                          {t("mobile_package.sim_normal.service_type")}
                        </div>
                        <Controller
                          name="receivedType"
                          control={control}
                          render={({ field }) => (
                            <RadioGroup
                              {...field}
                              value={values.receivedType}
                              onValueChange={(event) => {
                                setValue("receivedType", event);
                                setValue("showroomId", null);
                                setValue("provinceId", null);
                                setValue("timeOfReceiving", undefined);
                                setValue("email", null);
                                setDetailShowroom({});
                              }}
                            >
                              <div
                                className={`grid grid-cols-3 gap-x-4 max-md:grid-cols-1 max-2xl:grid-cols-2 max-2xl:gap-2`}
                              >
                                <label
                                  htmlFor="in_store"
                                  className={`w-full flex items-center cursor-pointer justify-between ${values.receivedType === "1" ? "bg-primary/20 border-primary text-primary font-bold" : "bg-[#F5F6F7] border-neutral font-normal text-neutral-dark-04"}   border-[2px] border-solio rounded-2xl py-3 px-6`}
                                >
                                  <div className="flex items-center space-x-2 cursor-pointer gap-x-2 max-lg:text-[14px]">
                                    <RadioGroupItem
                                      value="1"
                                      id="in_store"
                                      className={`${values.receivedType === "1" ? "border-primary" : "border-neutral"}  border-[2px]`}
                                    />
                                    {t("mobile_package.sim_normal.in_store")}
                                  </div>
                                  <Image
                                    src={
                                      values.receivedType === "1"
                                        ? "/store_app_active.svg"
                                        : "/store_app.png"
                                    }
                                    width={24}
                                    height={24}
                                    unoptimized
                                    quality={100}
                                    alt="store app"
                                  />
                                </label>
                                {/* {values.simType === "2" && (
                              <label
                                htmlFor="qr_via_whatsapp"
                                className={`w-full cursor-pointer ${values.receivedType === "3" ? "bg-primary/20 border-primary text-primary font-bold" : "bg-[#F5F6F7] border-neutral font-normal text-neutral-dark-04"} border-[2px] border-solio rounded-2xl py-3 px-6`}
                              >
                                <div className="flex items-center space-x-2 cursor-pointer gap-x-2 max-lg:text-[14px]">
                                  <RadioGroupItem
                                    value="3"
                                    id="qr_via_whatsapp"
                                    className={`${values.receivedType === "3" ? "border-primary" : "border-neutral"}  border-[2px]`}
                                  />
                                  {t(
                                    "mobile_package.sim_normal.get_qr_via_whatsapp"
                                  )}
                                </div>
                              </label>
                            )}
                            {values.simType === "2" && (
                              <label
                                htmlFor="qr_via_email"
                                className={`w-full cursor-pointer ${values.receivedType === "2" ? "bg-primary/20 border-primary text-primary font-bold" : "bg-[#F5F6F7] border-neutral font-normal text-neutral-dark-04"} border-[2px] border-solio rounded-2xl py-3 px-6`}
                              >
                                <div className="flex items-center space-x-2 cursor-pointer gap-x-2 max-lg:text-[14px]">
                                  <RadioGroupItem
                                    value="2"
                                    id="qr_via_email"
                                    className={`${values.receivedType === "2" ? "border-primary" : "border-neutral"}  border-[2px]`}
                                  />
                                  {t(
                                    "mobile_package.sim_normal.get_qr_via_email"
                                  )}
                                </div>
                              </label>
                            )} */}
                              </div>
                            </RadioGroup>
                          )}
                        />
                      </>
                    )}

                    {values.simType === "2" && values.receivedType === "2" && (
                      <div className="grid grid-cols-3 gap-x-4 max-md:grid-cols-1 max-md:gap-y-2 mt-4">
                        <InputField
                          maxLength={255}
                          name="email"
                          label={t(
                            "mobile_package.sim_normal.email_to_receive"
                          )}
                          placeholder={t(
                            "mobile_package.swap_sim.email_placholder"
                          )}
                          classNameLabel="!font-normal text-xs lg:text-base !text-neutral-dark-01"
                          type="text"
                          className="col-span-2"
                          control={control}
                          errors={errors}
                          required
                        />
                      </div>
                    )}

                    {(values.simType === "1" ||
                      (values.simType === "2" &&
                        values.receivedType === "1")) && (
                      <>
                        <div className="mt-4 grid grid-cols-2 gap-4 max-md:grid-cols-1 max-md:gap-2">
                          <div>
                            <label
                              htmlFor=""
                              className="text-sm lg:text-base max-md:font-medium"
                            >
                              {t("mobile_package.sim_normal.province_city")}
                            </label>
                            <span className="text-red-500">*</span>
                            <Controller
                              name="provinceId"
                              control={control}
                              render={({
                                field: { onChange },
                                fieldState: { error },
                              }) => {
                                return (
                                  <div className="flex flex-col">
                                    <Select
                                      onValueChange={(value) => {
                                        setValue("showroomId", "");
                                        setDetailShowroom({});
                                        getShowRoom(value);
                                        onChange(value);
                                      }}
                                    >
                                      <SelectTrigger
                                        className={clsx(
                                          "flex-1 py-[12px] px-[16px] h-[48px] rounded-xl mt-2 border-2 data-[placeholder]:text-neutral-mid-01",
                                          {
                                            "border-solid border border-error":
                                              !!error,
                                          }
                                        )}
                                      >
                                        <SelectValue
                                          placeholder={t(
                                            "mobile_package.sim_normal.province_city"
                                          )}
                                        />
                                      </SelectTrigger>
                                      <SelectContent>
                                        {provinces?.map((val) => {
                                          return (
                                            <SelectItem
                                              key={val.id}
                                              value={`${val.id}`}
                                              className=""
                                              disabled={provinces?.[0].id === 0}
                                            >
                                              {val.name}
                                            </SelectItem>
                                          );
                                        })}
                                      </SelectContent>
                                    </Select>
                                    {error && (
                                      <p className="text-red-500 text-sm mt-1">
                                        {error.message}
                                      </p>
                                    )}
                                  </div>
                                );
                              }}
                            />
                          </div>
                          <div>
                            <label
                              htmlFor=""
                              className="text-sm lg:text-base max-md:font-medium"
                            >
                              {t("common.store")}
                            </label>{" "}
                            <span className="text-red-500">*</span>
                            <Controller
                              name="showroomId"
                              control={control}
                              render={({
                                field: { onChange },
                                fieldState: { error },
                              }) => {
                                return (
                                  <div className="flex flex-col">
                                    <Select
                                      onValueChange={(event) => {
                                        const dataShowroom: IShowroomDetail =
                                          showRooms.find(
                                            (val) => val.id === event
                                          ) as IShowroomDetail;
                                        setDetailShowroom(dataShowroom);
                                        onChange(event);
                                      }}
                                    >
                                      <SelectTrigger
                                        className={clsx(
                                          "flex-1 py-[12px] px-[16px] h-[48px] rounded-xl mt-2 data-[placeholder]:text-neutral-mid-01",
                                          {
                                            "border-solid border border-error":
                                              !!error,
                                          }
                                        )}
                                      >
                                        <SelectValue
                                          placeholder={t("common.store")}
                                        />
                                      </SelectTrigger>
                                      <SelectContent>
                                        {showRooms?.map((val) => {
                                          return (
                                            <SelectItem
                                              key={val.id}
                                              value={val.id}
                                              disabled={
                                                showRooms?.[0].id === "0"
                                              }
                                            >
                                              {val.name}
                                            </SelectItem>
                                          );
                                        })}
                                      </SelectContent>
                                    </Select>
                                    {error && (
                                      <p className="text-red-500 text-sm mt-1">
                                        {error.message}
                                      </p>
                                    )}
                                  </div>
                                );
                              }}
                            />
                            {detailShowroom?.id && (
                              <div className="mt-2 text-xs lg:text-base">
                                {t("mobile_package.sim_normal.store_address")}:
                                {detailShowroom?.location}
                                {detailShowroom?.districtName
                                  ? `, ${detailShowroom.districtName}`
                                  : ""}
                              </div>
                            )}
                          </div>
                          <div>
                            <label
                              htmlFor=""
                              className="text-sm lg:text-base max-md:font-medium"
                            >
                              {t("mobile_package.sim_normal.time_of_receiving")}
                            </label>{" "}
                            <span className="text-red-500">*</span>
                            <div className="">
                              <DateTimePickerField
                                name="timeOfReceiving"
                                control={control}
                                errors={errors}
                                placeholder={t(
                                  "mobile_package.sim_normal.time_of_receiving"
                                )}
                                className="h-12"
                              />
                            </div>
                          </div>
                        </div>
                        <div className="mt-4 text-neutral-dark-04 max-md:mt-6">
                          <div className="font-bold max-md:text-[14px]">
                            {t(
                              "mobile_package.sim_normal.sim_registration_procedures"
                            )}
                          </div>
                          <ul className="list-disc pl-4 text-[14px] max-md:text-[10px]">
                            <li>
                              {t(
                                "mobile_package.sim_normal.you_need_subscriber"
                              )}
                              .
                            </li>
                          </ul>
                        </div>
                      </>
                    )}
                    {values.simType === "2" && (
                      <>
                        <div className="mt-8 max-md:mt-6 text-[20px] max-md:text-[16px] font-bold">
                          {t("mobile_package.sim_normal.upload_personal")}
                        </div>
                        <div className="mt-4 text-neutral-dark-04 text-[14px] max-md:text-[12px]">
                          {/* {t("mobile_package.swap_sim.upload_title_desc")} */}
                          {!isMobile
                            ? t("internet.file_upload")
                            : t("mobile_package.swap_sim.upload_title_desc")}
                        </div>
                        <div className="mt-4 flex gap-6 max-md:gap-4">
                          {/* <UploadFileButtonField
                            label={t("common.upload")}
                            name="files"
                            control={control}
                            errors={errors}
                          /> */}
                          <div className="flex flex-col">
                            <UploadFileSingle
                              label={t("common.upload")}
                              name="faceImage"
                              control={control}
                              labelBottom={t(
                                "mobile_package.sim_normal.face_photo"
                              )}
                              className="max-md:h-[72px] max-md:w-[72px]"
                            />
                          </div>
                          <div className="flex flex-col">
                            <UploadFileSingle
                              label={t("common.upload")}
                              name="backIdcard"
                              control={control}
                              className="max-md:h-[72px] max-md:w-[72px]"
                              labelBottom={t("internet.back_photo")}
                            />
                          </div>
                          <div className="flex flex-col">
                            <UploadFileSingle
                              label={t("common.upload")}
                              name="frontIdCard"
                              control={control}
                              className="max-md:h-[72px] max-md:w-[72px]"
                              labelBottom={t("internet.front_photo")}
                            />
                          </div>
                        </div>
                      </>
                    )}
                    <div className="text-[20px] max-md:text-[16px] font-bold mt-8 mb-4 max-md:mt-6">
                      {t("mobile_package.swap_sim.payment_method")}
                    </div>
                    {values.simType === "1" && (
                      <RadioGroup
                        defaultValue={"1"}
                        value={"1"}
                        // onValueChange={(event) => {
                        //   setPaymentMethod(event);
                        // }}
                      >
                        <div className="grid grid-cols-3 gap-x-4 max-md:grid-cols-1 max-md:gap-y-2">
                          <label
                            htmlFor="paymentMethod"
                            className={`w-full flex items-center cursor-pointer justify-between bg-primary/20 border-primary text-primary font-bold border-[2px] border-solio rounded-2xl py-3 px-6`}
                          >
                            <div className="flex items-center space-x-2 cursor-pointer gap-x-2 max-lg:text-[14px]">
                              <RadioGroupItem
                                value="1"
                                id="paymentMethod"
                                className={`border-primary border-[2px]`}
                              />
                              {t("payment.payment_on_delivery")}
                            </div>
                          </label>
                        </div>
                      </RadioGroup>
                    )}
                    {/* SRS đang bảo ẩn phương thức thanh toán đối với trường hợp esim */}
                    {/* {values.simType === "2" && (
                      <RadioGroup
                        defaultValue={paymentMethod}
                        value={paymentMethod}
                        onValueChange={(event) => {
                          setPaymentMethod(event);
                        }}
                      >
                        <div className="grid grid-cols-3 gap-x-4 max-md:grid-cols-1 max-md:gap-y-2">
                          {listPaymentMethod?.map((val) => (
                            <label
                              key={val.code}
                              htmlFor={val.code}
                              className={`w-full flex items-center cursor-pointer justify-between bg-primary/20 border-primary text-primary font-bold border-[2px] border-solio rounded-2xl py-3 px-6`}
                            >
                              <div className="flex items-center space-x-2 cursor-pointer gap-x-2 max-lg:text-[14px]">
                                <RadioGroupItem
                                  value={`${val.code}`}
                                  id={val.code}
                                  className={`border-primary border-[2px]`}
                                />
                                {val.name}
                              </div>
                            </label>
                          ))}
                        </div>
                      </RadioGroup>
                    )} */}
                  </div>
                  <div className="w-full bg-white rounded-3xl p-8 max-md:px-4 max-md:py-6 h-fit max-xl:mt-8 max-md:mt-4">
                    <OrderSimNormal
                      searchParams={searchParams}
                      isFormModified={!isValid}
                    />
                  </div>
                </div>
              );
            }}
          </Form>
        </>
      )}
    </PageContent>
  );
}

export default RegisterSimNormal;
