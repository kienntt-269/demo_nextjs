"use client";
import React, { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import Image from "next/image";
import TitleStyle from "@/components/title-common";
import { useTranslations } from "next-intl";
import { ReadonlyURLSearchParams } from "next/navigation";
import { ISimCard } from "@/schemaValidations/sim-card.schema";
import simApiRequest from "@/services/sim-service";
import mobileApiRequest from "@/services/mobile-service";
import { IDataPlan } from "@/schemaValidations/mobile-service.schema";
import { useLangStore } from "@/_stores/useLang.store";
import ComponentWithTooltip from "@/components/component-with-tooltip";
import { formatTimeWithDay } from "@/lib/utils";

interface IProps {
  searchParams: ReadonlyURLSearchParams;
}

const OrderSimSuccess = ({ searchParams }: IProps) => {
  const [simDetail, setSimDetail] = useState<ISimCard>();
  const [dataPackage, setDataPackage] = useState<IDataPlan>();
  const t = useTranslations();
  const { lang } = useLangStore();
  const getSimDetail = async () => {
    try {
      const res = await simApiRequest.getSimDetail(
        searchParams.get("idSim") ?? ""
      );
      setSimDetail(res.payload.data);
    } catch (error) {
      console.log(error);
    }
  };

  const getDataPackage = async () => {
    try {
      const res = await mobileApiRequest.getDetailData(
        searchParams.get("package") ?? ""
      );
      setDataPackage(res.payload.data);
    } catch (error) {
      console.log(error);
    }
  };

  const simTypeChange = () => {
    switch (searchParams.get("type")) {
      case "1":
        return t("mobile_package.sim_normal.xchange_sim");
      case "2":
        return t("mobile_package.sim_normal.student_sim");
      case "3":
        return t("mobile_package.sim_normal.dcom_sim");
      default:
        return t("mobile_package.sim_normal.xchange_sim");
    }
  };

  useEffect(() => {
    if (searchParams.get("idSim")) {
      getSimDetail();
    }
    if (searchParams.get("package")) {
      getDataPackage();
    }
  }, [searchParams, lang]);

  return (
    <div className="flex justify-center py-10 max-md:py-4 max-md:px-4">
      <div className="max-w-[768px] flex flex-col items-center w-full gap-y-6 max-md:gap-y-3 bg-white shadow-box-custom p-8 max-md:p-4 rounded-3xl">
        <Image
          src={"/images/icon/check-success.svg"}
          quality={100}
          unoptimized
          height={64}
          width={64}
          alt=""
          className="max-md:size-12"
        />
        <div className="">
          <TitleStyle classStyle="max-sm:leading-8 text-center">
            {t("mobile_package.sim_normal.order_created_successfully")}!
          </TitleStyle>
          <div className="text-neutral-dark-04 text-[14px] max-md:text-[12px] font-normal text-center mt-4 max-md:mt-2">
            {formatTimeWithDay(t, new Date())}
          </div>
        </div>

        {searchParams?.get("esim") && (
          <>
            <div className="flex justify-center">
              <Image
                src={"/mobile-package/qr_code.png"}
                alt="qr code"
                width={160}
                height={160}
                unoptimized
                quality={100}
              />
            </div>
            <div className="text-neutral-dark-04 text-center max-md:text-[12px]">
              {t("mobile_package.sim_normal.please_scan_qr_code_esim")}
            </div>
            <div className="flex justify-center gap-x-2 text-primary text-[14px] font-bold">
              <Image
                src={"/mobile-package/infor-icon.svg"}
                alt="qr code"
                width={20}
                height={20}
                unoptimized
                quality={100}
              />
              <div>
                {t("mobile_package.sim_normal.installation_instructions")}
              </div>
            </div>
          </>
        )}

        <div className="w-full">
          <div className="w-full rounded-2xl p-4 bg-[#F5F6F7]">
            <div className="flex items-center justify-between h-9 max-md:text-[12px]">
              <div>{t("payment.order_id")}</div>
              <div className="font-bold text-neutral-dark-02">
                {searchParams?.get("orderId")}
              </div>
            </div>
            <div className="flex items-center justify-between h-9 max-md:text-[12px]">
              <div>{t("mobile_package.sim_normal.sim_release_version")}</div>
              <div className="font-bold text-neutral-dark-02">
                {searchParams?.get("esim")
                  ? t("mobile_package.swap_sim.esim")
                  : t("mobile_package.swap_sim.physical_sim")}
              </div>
            </div>
            {simDetail?.id && (
              <>
                <div className="flex items-center justify-between h-9 max-md:text-[12px]">
                  <div>{t("mobile_package.sim_normal.sim_card")}</div>
                  <div className="font-bold text-neutral-dark-02">
                    {simDetail?.isdn}
                  </div>
                </div>
                <div className="flex items-center justify-between h-9 max-md:text-[12px]">
                  <div>{t("mobile_package.sim_normal.type_sim")}</div>
                  <div className="font-bold text-neutral-dark-02">
                    {simTypeChange()}
                  </div>
                </div>
                <div className="flex items-center justify-between h-9 max-md:text-[12px]">
                  <div>{t("mobile_package.sim_normal.sim_price")}</div>
                  <div className="font-bold text-neutral-dark-02">
                    {simDetail?.price.toLocaleString("en-US")}{" "}
                    {t("mobile_package.htg")}
                  </div>
                </div>
              </>
            )}
            {dataPackage?.id && (
              <>
                <div className="flex items-center justify-between h-9 gap-x-10 lg:gap-x-20 max-md:text-[12px]">
                  <div className="flex-shrink-0">
                    {t("mobile_package.sim_normal.data_plan")}
                  </div>
                  <ComponentWithTooltip content={dataPackage?.name}>
                    <div className="font-bold text-neutral-dark-02 overflow-hidden text-ellipsis whitespace-nowrap max-w-full text-right">
                      {dataPackage?.name}
                    </div>
                  </ComponentWithTooltip>
                </div>
                <div className="flex items-center justify-between h-9 max-md:text-[12px]">
                  <div className="flex-shrink-0">
                    {t("mobile_package.sim_normal.data_plan_price")}
                  </div>
                  <div className="font-bold text-neutral-dark-02">
                    {Number(dataPackage?.price ?? 0).toLocaleString("en-US")}{" "}
                    {t("mobile_package.htg")}
                  </div>
                </div>
              </>
            )}
            <div className="flex items-center justify-between h-9 max-md:text-[12px]">
              <div>{t("common.total")}</div>
              <div className="font-bold text-neutral-dark-02">
                {(
                  Number(simDetail?.price ?? 0) +
                  Number(dataPackage?.price ?? 0)
                ).toLocaleString("en-US")}{" "}
                {t("mobile_package.htg")}
              </div>
            </div>
            <div className="flex items-center justify-between h-9 max-md:text-[12px]">
              <div>{t("payment.payment_method")}</div>
              <div className="font-bold text-neutral-dark-02">
                {searchParams?.get("esim")
                  ? t("payment.natcash")
                  : t("payment.pay_at_store")}
              </div>
            </div>
          </div>
          {/* phải chờ trạng thái payment có nên ẩn hiện đoạn này k */}
          {searchParams?.get("esim") ? (
            <div className="mt-4 max-md:mt-2 text-neutral-dark-04 text-center max-md:text-[12px]">
              {t("mobile_package.sim_normal.you_will_receive_qr_esim")}
            </div>
          ) : (
            <div className="mt-4 max-md:mt-2 text-neutral-dark-04 text-center max-md:text-[12px]">
              {t("mobile_package.sim_normal.please_come_to_the_store")}
            </div>
          )}
        </div>
        <Button navigate="/" className="px-14 max-md:px-8">
          {t("common.back_home_page")}
        </Button>
      </div>
    </div>
  );
};

export default OrderSimSuccess;
