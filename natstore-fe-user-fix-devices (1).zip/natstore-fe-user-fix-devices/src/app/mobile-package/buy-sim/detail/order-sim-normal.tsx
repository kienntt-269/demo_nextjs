"use client";
import { useTranslations } from "next-intl";
import { Button } from "@/components/ui/button";
import React, { useEffect, useState } from "react";
import { ReadonlyURLSearchParams, useRouter } from "next/navigation";
import Image from "next/image";
import mobileApiRequest from "@/services/mobile-service";
import { useSimCardStore } from "@/_stores/useSimCard.store";
import simApiRequest from "@/services/sim-service";
import Modal from "@/components/common/modal/Modal";
import { IDataPlan } from "@/schemaValidations/mobile-service.schema";
import CarouselSimPackage from "@/app/mobile-package/buy-sim/detail/carousel-sim-package";
import { useLangStore } from "@/_stores/useLang.store";
import TextWithTooltip from "@/components/text-width-tooltip";

interface IProps {
  searchParams: ReadonlyURLSearchParams;
  isFormModified: boolean;
}

const OrderSimNormal = ({ searchParams, isFormModified }: IProps) => {
  const [isOpen, setIsOpen] = useState<boolean>(false);
  const [listDataPackage, setListDataPackage] = useState<IDataPlan[]>([]);
  const { setPackageData, setSimDetail, packageData, simDetail } =
    useSimCardStore();
  const t = useTranslations();
  const router = useRouter();
  const lang = useLangStore();

  const getListDataPackage = async () => {
    try {
      const res = await mobileApiRequest.getDataMobileService({
        simCard: true,
      });
      setListDataPackage(res.payload.data);
    } catch (error) {
      console.log(error);
      throw Error("error");
    }
  };

  const getDetailPackage = async () => {
    try {
      const res = await mobileApiRequest.getDetailData(
        searchParams.get("package") ?? ""
      );
      setPackageData(res.payload.data);
    } catch (error) {
      console.log(error);
      throw Error("error");
    }
  };

  const getDetailSimCard = async () => {
    try {
      const res = await simApiRequest.getSimDetail(
        searchParams.get("idSim") ?? ""
      );
      setSimDetail(res.payload.data);
    } catch (error) {
      console.log(error);
      throw Error("error");
    }
  };

  useEffect(() => {
    getListDataPackage();
    if (searchParams.get("package")) {
      getDetailPackage();
    } else {
      setPackageData();
    }
    if (searchParams.get("idSim")) {
      getDetailSimCard();
    }
  }, [lang]);

  const simTypeChange = () => {
    switch (searchParams.get("type")) {
      case "1":
        return t("mobile_package.sim_normal.xchange_sim");
      case "2":
        return t("mobile_package.sim_normal.student_sim");
      case "3":
        return t("mobile_package.sim_normal.dcom_sim");
      default:
        return t("mobile_package.sim_normal.xchange_sim");
    }
  };

  return (
    <div>
      <div className="text-[28px] font-bold max-md:text-[20px]">
        {t("common.order")}
      </div>
      <div className="mt-8 max-md:mt-6 pb-2 text-[16px] font-bold text-neutral-dark-02 border-b border-solid border-[#E3E4E5]">
        <div className="my-4 flex items-center justify-between max-md:text-[14px]">
          <div className="max-md:font-normal">{t("common.sim")}</div>
          <div className="">{simDetail?.isdn}</div>
        </div>
        <div className="my-4 flex items-center justify-between max-md:text-[14px]">
          <div>{t("mobile_package.sim_normal.sim_release_version")}</div>
          <div className="">
            {searchParams?.get("typeSim") === "2"
              ? t("mobile_package.swap_sim.esim")
              : t("mobile_package.swap_sim.physical_sim")}
          </div>
        </div>
        <div className="my-4 flex items-center justify-between max-md:text-[14px]">
          <div className="max-md:font-normal">
            {t("mobile_package.sim_normal.type_sim")}
          </div>
          <div className="">{simTypeChange()}</div>
        </div>
        <div className="my-4 flex items-center justify-between max-md:text-[14px]">
          <div className="max-md:font-normal">
            {t("mobile_package.sim_normal.sim_price")}
          </div>
          <div className="">
            {simDetail?.price.toLocaleString("en-US")} {t("mobile_package.htg")}
          </div>
        </div>
      </div>
      {packageData?.id && (
        <div className="mt-2 pb-2 text-[16px] font-bold text-neutral-dark-02 border-b border-solid border-[#E3E4E5]">
          <div className="my-4 flex items-center justify-between gap-x-6 max-md:gap-x-3 max-md:text-[14px]">
            <div className="max-md:font-normal flex-shrink-0 max-md:text-[14px]">
              {t("mobile_package.sim_normal.data_plan")}
            </div>
            <div className="flex gap-x-2">
              <div className="line-clamp-1">
                <TextWithTooltip content={`${packageData.name}`} />
              </div>
              <Image
                src={"/images/icon/ic_edit.svg"}
                width={24}
                height={24}
                alt=""
                unoptimized
                quality={100}
                className="cursor-pointer"
                onClick={() => {
                  setIsOpen(true);
                }}
              />
              <Modal
                contentClassName="max-w-[1500px] max-md:w-[380px] max-2xl:w-[1200px] max-xl:w-[770px] max-lg:w-[630px] overflow-x-hidden"
                isOpen={isOpen}
                title={t("mobile_package.select_main_package")}
                onClose={(value) => {
                  setIsOpen(value);
                }}
              >
                <div className="px-14 mt-8 max-lg:mt-6 max-md:mt-4 w-[1430px] max-md:w-[345px] max-md:px-2 max-2xl:w-[1130px] max-xl:w-[700px] max-lg:w-[560px]">
                  <CarouselSimPackage
                    length={listDataPackage?.length ?? 0}
                    listDataPackage={listDataPackage}
                    quantityMobile={1}
                    quantity={4}
                  />
                </div>
              </Modal>
            </div>
          </div>
          <div className="my-4 flex items-center justify-between max-md:text-[14px]">
            <div className="max-md:font-normal">
              {t("mobile_package.sim_normal.data_plan_price")}
            </div>
            <div className="">
              {Number(packageData?.price).toLocaleString("en-US")}{" "}
              {t("mobile_package.htg")}
            </div>
          </div>
          <div className="my-4 flex items-center justify-between max-md:text-[14px]">
            <div className="max-md:font-normal">
              {t("payment.estimated_cost")}
            </div>
            <div className="">
              {(
                Number(simDetail?.price ?? 0) + Number(packageData?.price ?? 0)
              ).toLocaleString("en-US")}{" "}
              {t("mobile_package.htg")}
            </div>
          </div>
        </div>
      )}

      <div className="mt-6 max-md:mt-2 flex items-center justify-between">
        <div className="text-neutral-dark-02 font-bold text-[20px] max-md:text-base">
          {" "}
          {t("common.total")}
        </div>
        <div className="flex flex-col items-end">
          <div className="text-neutral-dark-02 font-bold text-[20px] max-md:text-[16px]">
            {(
              Number(simDetail?.price ?? 0) + Number(packageData?.price ?? 0)
            ).toLocaleString("en-US")}{" "}
            {t("mobile_package.htg")}
          </div>
          <div className="text-neutral-dark-04 text-[14px] font-bold max-md:font-normal">
            ( {t("payment.included_vat_if_any")} )
          </div>
        </div>
      </div>
      <div className="mt-6 text-center text-neutral-dark-04 text-[16px] font-normal max-md:text-[14px]">
        {t("payment.please_pay_at_the_store")}.
      </div>
      <Button
        className="mt-6 w-full "
        variant={"default"}
        type="submit"
        disabled={isFormModified}
      >
        {t("mobile_package.sim_normal.pre_order")}
      </Button>
      <Button
        className="mt-4 max-md:mt-2 w-full "
        variant={"secondary"}
        onClick={() => {
          router.back();
        }}
      >
        {t("common.back")}
      </Button>
    </div>
  );
};

export default OrderSimNormal;
