import Modal from "@/components/common/modal/Modal";
import { Dialog } from "@/components/ui/dialog";
import { useTranslations } from "next-intl";
import React from "react";

export type SIMSwapNotSupportedOnlineModalProps = React.ComponentProps<
  typeof Dialog
> & {
  isModal: boolean;
  onClose: () => void;
};

const SIMSwapNotSupportedOnlineModal = ({
  isModal,
  onClose,
}: SIMSwapNotSupportedOnlineModalProps) => {
  const t = useTranslations("mobile_package.swap_sim.sim_not_online");
  return (
    <Modal
      isOpen={isModal}
      onClose={onClose}
      contentClassName="w-[504px] max-w-full p-6"
      title={t("title")}
    >
      <div className="text-base text-neutral-dark-02">
        <p className="text-center mb-6">{t("desc_1")}</p>
        <div className="p-4 rounded-2xl bg-[#F5F6F7]">
          <ul className="px-4 list-disc">
            <li className="mb-8">{t("desc_2")}</li>
            <li className="">{t("desc_3")}</li>
          </ul>
        </div>
      </div>
    </Modal>
  );
};

export default SIMSwapNotSupportedOnlineModal;
