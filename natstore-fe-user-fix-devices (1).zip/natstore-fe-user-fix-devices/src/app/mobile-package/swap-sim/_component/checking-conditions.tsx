"use client";

import Modal from "@/components/common/modal/Modal";
import { Button } from "@/components/ui/button";
import { useTranslations } from "next-intl";
import React, { useState } from "react";

export const CheckingConditions = () => {
  const t = useTranslations("mobile_package.swap_sim");
  const [isOpen, setIsOpen] = useState<boolean>(false);

  const handleClose = () => {
    setIsOpen(false);
  };
  return (
    <>
      <Button
        className="flex items-center justify-center bg-[#ff8600] text-white rounded-3xl min-w-[169px]"
        onClick={() => setIsOpen(true)}
      >
        {t("check")}
      </Button>
      <Modal
        isOpen={isOpen}
        onClose={handleClose}
        contentClassName="w-[504px] max-w-full p-6"
        title={t("condititon_checking")}
      >
        <div className="flex flex-col">
          <div className="mb-4">
            <div className="font-semibold text-neutral-dark-04 text-base">
              {t("hotline")}
            </div>
            <div className="text-xl font-bold">0123 456 789</div>
          </div>
          <div className="mb-4">
            <div className="font-semibold text-neutral-dark-04 text-base">
              {t("ussed_code")}
            </div>
            <div className="text-xl font-bold">*3001#12345#*</div>
          </div>
          <div className="text-center">
            <Button
              className="min-w-[212px] rounded-3xl"
              onClick={handleClose}
            >
              {t("close")}
            </Button>
          </div>
        </div>
      </Modal>
    </>
  );
};

export default CheckingConditions;
