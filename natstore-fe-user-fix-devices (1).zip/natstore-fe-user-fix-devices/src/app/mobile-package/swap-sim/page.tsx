import React from "react";
import { ILinks } from "@/types/package";
import BreadCrumbCommon from "@/components/breadcrumb-common";
import SwapSimMain from "@/app/mobile-package/swap-sim/_component/swap-sim-main";
import mobilePackageApiRequest from "@/services/mobile-package";
import { getTranslations } from "next-intl/server";
import PageContent from "@/components/page-content";
import BannerHomePage from "@/module/home-page/banner-home-page";

export const dynamic = "force-dynamic";

const getBanners = async () => {
  try {
    const res = await mobilePackageApiRequest.getBanners();
    return res.payload.data;
  } catch (error) {
    console.log(error);
    throw Error("error");
  }
};

const getFaqs = async () => {
  try {
    const res = await mobilePackageApiRequest.getFaqs("SWAP_SIM");
    return res.payload.data;
  } catch (error) {
    console.log(error);
    throw Error("error");
  }
};

const SwapSimPage = async () => {
  const banners = await getBanners();
  const faqs = await getFaqs();
  const t = await getTranslations();
  const breadCrumb: ILinks[] = [
    {
      label: t("personal.home"),
      link: "/",
    },
    {
      label: t("mobile_package.roaming.mobile_service"),
      link: "/mobile-package",
    },
    {
      label: t("mobile_package.swap_sim.title"),
      link: "/mobile-packages/swap-sim",
    },
  ];

  return (
    <>
      <PageContent className="pb-0">
        <BannerHomePage />
        <div className="mb-10">
          <BreadCrumbCommon content={breadCrumb} />
        </div>
      </PageContent>
      <SwapSimMain banners={banners} faqs={faqs.slice(-3)} />
      {/* <SwapSimConditions /> */}
    </>
  );
};

export default SwapSimPage;
