"use client";
import { useDialogAuthStore } from "@/_stores/useDialogAuth.store";
import { useProfileStore } from "@/_stores/useProfile.store";
import TextCSRStyle from "@/components/text-csr-style";
import { Button } from "@/components/ui/button";
import { useRouter } from "next/navigation";
import React from "react";

function ButtonRegisterData({ slug }: { slug: string }) {
  const router = useRouter();
  const { user } = useProfileStore();
  const { setIsOpen, setUrlLoginSuccess } = useDialogAuthStore();
  return (
    <div>
      <Button
        className="mt-6 max-md:mt-4 max-md:w-full max-md:text-[14px] max-md:h-8 w-fit"
        onClick={() => {
          if (user?.id) {
            router.push(`/mobile-package/data/${slug}/payment`);
          } else {
            setIsOpen({ isOpen: true, mode: "LOGIN" });
            setUrlLoginSuccess(`/mobile-package/data/${slug}/payment`);
          }
        }}
      >
        <TextCSRStyle>mobile_package.data.buy_now</TextCSRStyle>
      </Button>
    </div>
  );
}

export default ButtonRegisterData;
