"use client";
import React, { useEffect, useRef, useState } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useIsMobile } from "@/hooks/use-mobile";
import { IColumnTable } from "@/types/common";
import { Button } from "@/components/ui/button";
import { useTranslations } from "next-intl";
import simApiRequest from "@/services/sim-service";
import TitleStyle from "@/components/title-common";
import { ChevronLeft, ChevronRight, Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import ButtonSeeMore from "@/components/btn-see-more";
import PaginationCustom from "@/components/pagination-custom";
import { IHotKey, ISimCard } from "@/schemaValidations/sim-card.schema";
import Image from "next/image";
import { useLangStore } from "@/_stores/useLang.store";
import TabCommon from "@/components/tabs-common";

const TableSimService = ({
  isHome,
  pageSize = 10,
}: {
  isHome?: boolean;
  pageSize?: number;
}) => {
  const t = useTranslations();
  const [total, setTotal] = useState<number>(0);
  const [typeSim, setTypeSim] = useState<"esim" | "physical">("physical");
  const [page, setPage] = useState<number>(1);
  const [hotKey, setHotKey] = useState<IHotKey[]>([]);
  const [queryHotKey, setQueryHotKey] = useState<string>("");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [listSim, setListSim] = useState<ISimCard[]>([]);
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const [showPrev, setShowPrev] = useState<boolean>(false);
  const [showNext, setShowNext] = useState<boolean>(false);
  const isMobile = useIsMobile();
  const { lang } = useLangStore();

  const categoriesSim = [
    {
      label: t("mobile_package.swap_sim.physical_sim"),
      // slug: "physical",
    },
    // {
    //   label: t("mobile_package.esim"),
    //   slug: "esim",
    // },
  ];

  const column: IColumnTable<ISimCard>[] = [
    {
      header: t("common.no"),
      key: "id",
      classStyleHeader: "pl-8",
      render: (value, record, i) => {
        return (
          <div className="text-[20px] max-md:w-[20px] max-md:text-[14px] font-bold">
            <div>{page * pageSize - pageSize + i + 1}</div>
          </div>
        );
      },
    },
    {
      header: t("common.sim_number"),
      key: "phone",
      render: (value, record) => {
        return (
          <div className="text-[20px] max-md:text-[14px] max-md:w-[100px] font-bold max-md:font-normal">
            <div>{record?.isdn || ""}</div>
          </div>
        );
      },
    },
    {
      header: t("common.price"),
      key: "price",
      render: (value, record) => {
        return (
          <div className="text-primary font-bold text-[20px] max-md:text-[14px] flex gap-x-1">
            <div> {Number(record.price).toLocaleString("en-US")}</div>
            <div>{t("mobile_package.htg")}</div>
          </div>
        );
      },
      classStyleHeader: "w-[350px] max-xl:w-auto",
    },
    {
      header: t("mobile_package.type_card"),
      key: "typeCard",
      render: (value, record) => {
        return (
          <div className="text-[20px] max-md:text-[14px] max-md:w-[100px] font-bold">
            <div>{record?.typeCard ?? "-"}</div>
          </div>
        );
      },
    },
    {
      header: "",
      key: "id",
      render: (value, record) => {
        return (
          <div className="flex items-center justify-center h-full">
            <Button
              navigate={`/mobile-package/buy-sim?page=${page}&chooseSim=${record.id}&isdnNumber=${searchQuery}&hotKey=${searchQuery === queryHotKey ? queryHotKey : ""}&slug=${typeSim}`}
              className="lg:w-[156px]"
            >
              {t("common.buy")}
            </Button>
          </div>
        );
      },
      classStyleHeader: "w-[156px] max-xl:w-auto",
    },
  ];

  const checkScroll = () => {
    const container = scrollContainerRef.current;
    if (
      container &&
      container.scrollWidth > container.clientWidth &&
      container.scrollLeft + container.clientWidth < container.scrollWidth
    ) {
      setShowPrev(true);
      setShowNext(true);
    }
  };

  useEffect(() => {
    setTimeout(checkScroll, 300);
    window.addEventListener("resize", checkScroll);
    return () => window.removeEventListener("resize", checkScroll);
  }, []);

  const scroll = (direction: "left" | "right") => {
    const container = scrollContainerRef.current;
    if (container) {
      const scrollAmount = container.clientWidth / 2;
      container.scrollBy({
        left: direction === "left" ? -scrollAmount : scrollAmount,
        behavior: "smooth",
      });
    }
  };

  const getSimReq = async (page_number: number) => {
    try {
      const res = await simApiRequest.getListSim({
        page: page_number ?? 1,
        size: pageSize,
        isdnNumber: queryHotKey ? "" : searchQuery,
        hotKey: queryHotKey ?? "",
      });
      setTotal(res?.payload?.data?.total_records ?? 0);
      setListSim(res?.payload?.data?.pagination ?? []);
    } catch (error) {
      console.log(error);
      throw Error("error");
    }
  };

  const handleKeyDown = (event: React.KeyboardEvent<HTMLInputElement>) => {
    if (event.key === "Backspace" || event.key === "Delete") {
      setQueryHotKey("");
    }
  };

  const getHotKey = async () => {
    try {
      const res = await simApiRequest.getHotKey();
      const sortedList = res.payload?.data?.sort((a, b) => {
        if (a.sortOrder === null && b.sortOrder === null) return 0;
        if (a.sortOrder === null) return 1;
        if (b.sortOrder === null) return -1;
        return a.sortOrder - b.sortOrder;
      });
      setHotKey(sortedList ?? []);
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    getHotKey();
  }, []);

  useEffect(() => {
    getSimReq(1);
  }, [lang]);

  return (
    <div className="my-8 max-md:mb-0 max-md:mt-6">
      {!isHome && (
        <div className="flex justify-between items-center max-lg:items-start">
          <div>
            <TitleStyle classStyle="mb-4">
              {t("mobile_package.sim_normal.sim_card")}
            </TitleStyle>
            <TabCommon
              tabs={categoriesSim}
              onChangeTab={(index) => {
                if (index === 0) {
                  setTypeSim("physical");
                } else {
                  setTypeSim("esim");
                }
              }}
            />
          </div>
          <ButtonSeeMore href={`/mobile-package/buy-sim?slug=${typeSim}`} />
        </div>
      )}
      <div className="mt-6 max-md:mt-4 gap-x-12 2xl:flex items-center justify-between">
        <div className="flex gap-x-2">
          <div className="relative xl:max-w-[596px] max-xl:w-full">
            <Input
              className="xl:w-[329px] max-xl:w-full text-normal pl-8 h-[38px] bg-[#E3E4E5] rounded-xl font-normal outline-none border-none"
              placeholder={t("mobile_package.sim_normal.search_sim")}
              onChange={(event) => {
                if (
                  event.target.value === "" ||
                  (/^\d*$/.test(event.target.value) &&
                    Number(event.target.value) >= 0)
                ) {
                  setSearchQuery(event.target.value);
                }
                if (!event.target.value) {
                  setQueryHotKey("");
                  setPage(1);
                  getSimReq(1);
                }
              }}
              onKeyDown={(event) => {
                handleKeyDown(event);
                if (event.key === "Enter") {
                  setPage(1);
                  getSimReq(1);
                }
              }}
              value={searchQuery}
            />
            <Search
              strokeWidth={1}
              className="absolute top-[11px] left-2 size-4"
            />
          </div>
          <button
            onClick={() => {
              setPage(1);
              getSimReq(1);
            }}
            className="h-[40px] max-md:h-[38px] max-md:w-[70px] px-[52px] flex items-center justify-center rounded-2xl bg-primary border-none text-white font-bold text-[14px]"
          >
            {t("common.search")}
          </button>
        </div>
        {hotKey.length > 0 && (
          <div className="flex items-center gap-x-2 max-2xl:mt-4 max-xl:block max-md:mt-2">
            <div className="font-semibold text-neutral-mid-01 max-md:text-[12px] flex-shrink-0">
              {t("common.hot_key")}
            </div>
            <div className="flex items-center gap-x-2">
              {!isMobile && showPrev && (
                <button
                  className="rounded max-md:hidden xl:size-8 size-6 flex items-center justify-center bg-[#E3E4E5] flex-shrink-0 transition-all duration-300 ease-in-out hover:scale-[1.025]"
                  onClick={() => scroll("left")}
                  aria-label="Previous Slide"
                >
                  <ChevronLeft size={isMobile ? 12 : 16} />
                </button>
              )}
              <div
                className="flex items-center gap-x-8 max-md:gap-x-4 text-primary font-bold text-xl max-md:text-[14px] max-w-[653px] overflow-x-scroll no-scrollbar"
                ref={scrollContainerRef}
              >
                {hotKey.length > 0 &&
                  hotKey.map((val, index) => {
                    return (
                      <div
                        key={index}
                        onClick={() => {
                          setSearchQuery(val.hotKey);
                          setQueryHotKey(val.hotKey);
                        }}
                        className="cursor-pointer md:hover:text-[#f8b76d] transition-all duration-300 ease-in-out"
                      >
                        {val.hotKey}
                      </div>
                    );
                  })}
              </div>
              {!isMobile && showNext && (
                <button
                  className="rounded max-md:hidden xl:size-8 size-6 flex items-center justify-center bg-[#E3E4E5] flex-shrink-0 transition-all duration-300 ease-in-out hover:scale-[1.025]"
                  onClick={() => scroll("right")}
                  aria-label="Previous Slide"
                >
                  <ChevronRight size={isMobile ? 12 : 16} />
                </button>
              )}
            </div>
          </div>
        )}
      </div>
      <div className="mt-4 max-md:mt-3 rounded-t-lg md:rounded-t-2xl">
        <Table className="rounded-t-lg md:rounded-t-2xl overflow-hidden">
          <TableHeader className="bg-[#212121] text-white h-14 max-md:h-8 ">
            <TableRow className="hover:bg-[#212121]">
              {column.map((col, index) => (
                <TableHead
                  key={`header-table${index}`}
                  className={`text-white font-bold text-xl max-md:text-[12px] ${col.classStyleHeader}`}
                >
                  {col.header}
                </TableHead>
              ))}
            </TableRow>
          </TableHeader>
          <TableBody className="bg-white">
            {listSim?.length > 0 &&
              listSim?.map((row, indexRow) => (
                <TableRow
                  key={indexRow}
                  className="text-xl h-20 max-md:h-[54px] hover:bg-[#ffebd6]"
                >
                  {column.map((col, i) => (
                    <TableCell
                      className={`font-bold text-neutral-dark-02 ${col.classStyleHeader}`}
                      key={i}
                    >
                      {col?.render
                        ? col.render(
                            row[col.key as keyof typeof row],
                            row,
                            indexRow
                          )
                        : (row as unknown as Record<string, string>)[col.key]}
                    </TableCell>
                  ))}
                </TableRow>
              ))}
          </TableBody>
        </Table>
        {listSim?.length === 0 && pageSize !== 5 && (
          <div className="py-28 max-lg:py-12 max-md:py-4 max-lg:h-auto text-neutral-dark-03 bg-[white] flex flex-col items-center justify-center w-full">
            <Image
              src={"/unavailable.svg"}
              alt=""
              unoptimized
              quality={100}
              className="object-contain max-lg:w-[400px] max-lg:h-[200px]"
              width={600}
              height={600}
            />
            <div className="text-[28px] max-lg:text-[20px] font-bold mt-4 max-lg:mt-2">
              {t("mobile_package.no_sim_found")}
            </div>
            <div className="text-[20px] max-lg:text-[14px] font-normal mt-4 max-lg:mt-2">
              {t("mobile_package.please_try_another_number")}
            </div>
          </div>
        )}
        {listSim?.length === 0 && pageSize === 5 && (
          <div className="py-20 max-lg:py-12 max-md:py-4 max-lg:h-auto text-neutral-dark-03 bg-[white] flex flex-col items-center justify-center w-full">
            <Image
              src={"/unavailable.svg"}
              alt=""
              unoptimized
              quality={100}
              className="object-contain max-lg:w-[400px] max-lg:h-[200px]"
              width={400}
              height={400}
            />
            <div className="text-[28px] max-lg:text-[20px] font-bold mt-4 max-lg:mt-2">
              {t("mobile_package.no_sim_found")}
            </div>
            <div className="text-[20px] max-lg:text-[14px] font-normal mt-4 max-lg:mt-2">
              {t("mobile_package.please_try_another_number")}
            </div>
          </div>
        )}
      </div>
      {total > 0 && (
        <div className="mt-6 max-md:mt-3">
          <PaginationCustom
            totalItems={total}
            itemsPerPage={10}
            current={page}
            onChange={(value) => {
              setPage(value);
              getSimReq(value);
            }}
          />
        </div>
      )}
    </div>
  );
};

export default TableSimService;
