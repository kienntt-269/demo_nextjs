"use client";
import { useProfileStore } from "@/_stores/useProfile.store";
import NoDataAvailable from "@/components/common/no-data-available/no-data-available";
import PaginationCustom from "@/components/pagination-custom";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { FORMAT_TIME_DATE_FULL } from "@/constants/common";
import { formatDate, updateSearchParams } from "@/lib/utils";
import {
  PointHistoryItemType,
  PointHistoryResType,
} from "@/schemaValidations/point.schema";
import { ISimCardListRes } from "@/schemaValidations/sim-card.schema";
import pointApiRequest from "@/services/point-service";
import { IColumnTable } from "@/types/common";
import { useTranslations } from "next-intl";
import { usePathname, useRouter } from "next/navigation";
import React, { useEffect, useState } from "react";

type Props = {
  response?: ISimCardListRes;
  searchParams: { [key in string]: string };
};

const PointTableView = ({ searchParams }: Props) => {
  const { user } = useProfileStore();
  const t = useTranslations();
  const router = useRouter();
  const pathname = usePathname();
  const [response, setResponse] = useState<PointHistoryResType | undefined>();

  const column: IColumnTable<PointHistoryItemType>[] = [
    {
      header: t("common.id"),
      key: "id",
      classStyleHeader: "px-3 w-[37px] text-xs text-center",
      render: (value, record, i) => {
        return (
          <div className="font-bold text-xs">
            <div>{(response?.paging?.currentPage || 1) * 10 - 10 + i + 1}</div>
          </div>
        );
      },
    },

    {
      header: t("common.description"),
      key: "description",
      render: (value, record) => {
        return (
          <div className="font-normal text-start whitespace-nowrap">
            <div>{record?.description}</div>
          </div>
        );
      },
      classStyleHeader: "px-3 text-xs text-center",
    },
    {
      header: t("common.points_earned"),
      key: "points_earned",
      render: (value, record) => {
        return (
          <div className="font-bold text-[#34C759]">
            <div>+{Number(record.pointAdd).toLocaleString("en-US")}</div>
          </div>
        );
      },
      classStyleHeader: "px-3 text-xs text-center",
    },
    {
      header: t("common.points_used"),
      key: "points_used",
      render: (value, record) => {
        return (
          <div className="font-bold text-[#FF3B30]">
            <div>{record?.pointMinus ? `-${record?.pointMinus}` : ""}</div>
          </div>
        );
      },
      classStyleHeader: "px-3 text-xs text-center",
    },
    {
      header: t("common.balance"),
      key: "balance",
      render: (value, record) => {
        return (
          <div className=" max-md:w-[100px] font-bold">
            <div>{record?.pointAdd ?? "-"}</div>
          </div>
        );
      },
      classStyleHeader: "px-3 text-xs text-center",
    },
    {
      header: t("common.time"),
      key: "time",
      render: (value, record) => {
        return (
          <div className="font-normal whitespace-nowrap">
            {formatDate(record?.createdAt, FORMAT_TIME_DATE_FULL) ?? "-"}
          </div>
        );
      },
      classStyleHeader: "px-3 text-xs text-center",
    },
  ];

  const handleUpdateParamsSearch = (param: { [key: string]: string }) => {
    router.push(`${pathname}${updateSearchParams(param, searchParams)}`, {
      scroll: false,
    });
  };

  useEffect(() => {
    if (!user?.id) return;
    pointApiRequest
      .getMyHistory({
        userId: user.id,
        from: searchParams?.from,
        to: searchParams?.to,
        filter: +searchParams?.filter,
        page: +(searchParams?.page || 1),
        searchKey: searchParams?.searchKey || "",
        size: 10,
      })
      .then((res) => {
        setResponse(res.payload);
      });
  }, [searchParams, user?.id]);

  return (
    <div>
      <div className="border border-[#F2F2F2] rounded-xl overflow-hidden">
        <Table className="rounded-t-xl overflow-hidden">
          <TableHeader className="bg-[#E3E4E5] text-white h-14 max-md:h-8">
            <TableRow className="hover:bg-[#E3E4E5]">
              {column.map((col, index) => (
                <TableHead
                  key={`header-table${index}`}
                  className={`text-neutral-dark-02 whitespace-nowrap font-bold max-md: ${col.classStyleHeader}`}
                >
                  {col.header}
                </TableHead>
              ))}
            </TableRow>
          </TableHeader>
          <TableBody className="bg-white">
            {response &&
              response?.data?.length > 0 &&
              response?.data?.map((row, indexRow) => (
                <TableRow
                  key={indexRow}
                  className={`h-10 max-md:h-[54px] hover:bg-[#ffebd6] border-none `}
                >
                  {column.map((col, i) => (
                    <TableCell
                      className={`text-neutral-dark-02 ${col.classStyleHeader}`}
                      key={i}
                    >
                      {col?.render
                        ? col.render(
                            row[col.key as keyof typeof row],
                            row,
                            indexRow
                          )
                        : (row as unknown as Record<string, string>)[col.key]}
                    </TableCell>
                  ))}
                </TableRow>
              ))}
          </TableBody>
        </Table>
      </div>
      {response?.data?.length === 0 && (
        <NoDataAvailable />
      )}
      {!!response?.paging?.totalPages && response?.paging?.totalPages > 1 && (
        <div className="mt-6 max-md:mt-3">
          <PaginationCustom
            totalItems={response?.paging?.totalPages}
            itemsPerPage={response?.paging?.pageSize}
            current={response?.paging?.currentPage}
            onChange={(value) => {
              handleUpdateParamsSearch({ page: value.toString() });
            }}
          />
        </div>
      )}
    </div>
  );
};

export default PointTableView;
