"use client";
import { storage } from "@/lib/storage";
import { checkResSuccess } from "@/lib/utils";
import internetApiRequest from "@/services/internet";
import { paymentService } from "@/services/payment-service";
import { useRouter, useSearchParams } from "next/navigation";
import React, { useEffect } from "react";

const PaymentResponse = () => {
  const searchParams = useSearchParams();
  const code = searchParams.get("code");
  const transId = searchParams.get("transId");
  const signature = searchParams.get("signature");
  const orderNumber = searchParams.get("orderNumber");
  const type = searchParams.get("productType");
  const orderId = searchParams.get("orderId");
  const router = useRouter();

  const handleVerifyDataPackage = ({
    transactionId,
    code,
    ncTransId,
    signature,
  }: {
    transactionId: string;
    code: string;
    ncTransId: string;
    signature: string;
  }) => {
    paymentService
      .dataPlanVerifyNatcashPayment({
        transactionId,
        code,
        ncTransId,
        signature,
      })
      .then((res) => {
        console.log({ res });
        const dataRes = res?.payload?.data;
        const packageData = dataRes?.packageData;
        if (
          res.payload.data.status === "REGISTER_SUCCESS" ||
          res.payload.data.status === "WAITING_PAYMENT" ||
          res.payload.data.status === "NEW"
        ) {
          router.push(
            `/mobile-package/data/${packageData?.slug}/payment?statusPayment=success&paymentMethod=natcash&orderId=${dataRes?.orderId}`
          );
        }
        // navigate to success page or error page
        if (
          res.payload.data.status === "REGISTER_FAILED" ||
          res.payload.data.status === "PAYMENT_ERROR"
        ) {
          router.push(
            `/mobile-package/data/${packageData?.slug}/payment?statusPayment=error&typeError=${res.payload.data.status}&orderId=${dataRes?.orderId}&paymentMethod=natcash`
          );
        }
      });
  };

  const handleVerifySimOrder = ({
    transactionId,
    code,
    ncTransId,
    signature,
  }: {
    transactionId: string;
    code: string;
    ncTransId: string;
    signature: string;
  }) => {
    paymentService
      .simVerifyNatcashPayment({
        transactionId,
        code,
        ncTransId,
        signature,
      })
      .then((res) => {
        console.log({ res });
        const dataRes = res?.payload?.data;
        if (dataRes.status === "PAYMENT_SUCCESS") {
          router.push(
            `/mobile-package/buy-sim/detail?idSim=${dataRes?.simId}&statusPayment=success&orderId=${dataRes?.simOrderId}&package=${dataRes?.packageId}&esim=true`
          );
        }
        if (
          !checkResSuccess(res.payload.code ?? "") ||
          dataRes.status === "PAYMENT_FAILED"
        ) {
          router.push(
            `/mobile-package/buy-sim/detail?idSim=${dataRes?.simId}&statusPayment=error&orderId=${dataRes?.simOrderId}&package=${dataRes?.packageId}&esim=true`
          );
        }
      });
  };

  const handleVerifyRegisterInternet = ({
    transactionId,
    code,
    ncTransId,
    signature,
  }: {
    transactionId: string;
    code: string;
    ncTransId: string;
    signature: string;
  }) => {
    internetApiRequest
      .postVerifyNatcashPayment({
        transactionId,
        code,
        ncTransId,
        signature,
      })
      .then((res) => {
        storage.setResponsePaymentDataInternet(
          JSON.stringify(res.payload.data)
        );
        if (
          res.payload.data.transactionStatus === "REGISTER_SUCCESS" ||
          res.payload.data.transactionStatus === "WAITING_PAYMENT" ||
          res.payload.data.transactionStatus === "PAYMENT_SUCCESS" ||
          res.payload.data.transactionStatus === "NEW"
        ) {
          router.push(
            `/internet/${res.payload.data.productSlug}/register?statusPayment=success`
          );
        }
        // navigate to success page or error page
        if (
          !checkResSuccess(res.payload.code ?? "") ||
          res.payload.data.transactionStatus === "REGISTER_FAILED" ||
          res.payload.data.transactionStatus === "PAYMENT_ERROR"
        ) {
          router.push(
            `/internet/${res.payload.data.productSlug}/register?statusPayment=fail`
          );
        }
      });
  };
  useEffect(() => {
    if (!orderNumber || !signature || !transId || !type) {
      return;
    }
    if (type === "SIMCARD") {
      handleVerifySimOrder({
        transactionId: orderNumber ?? "",
        signature: signature ?? "",
        code: code ?? "",
        ncTransId: transId ?? "",
      });
      return;
    } else if (type === "INTERNET") {
      handleVerifyRegisterInternet({
        transactionId: orderNumber ?? "",
        signature: signature ?? "",
        code: code ?? "",
        ncTransId: transId ?? "",
      });
      return;
    } else if (type === "PACKAGE_DATA") {
      handleVerifyDataPackage({
        transactionId: orderNumber ?? "",
        signature: signature ?? "",
        code: code ?? "",
        ncTransId: transId ?? "",
      });
    }
  }, [type, router, orderId, code, signature, transId, orderNumber]);
  return <div className="min-h-screen"></div>;
};

export default PaymentResponse;
