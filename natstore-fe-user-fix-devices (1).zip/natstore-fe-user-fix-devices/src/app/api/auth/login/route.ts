import envConfig from "@/config";
import {
  XSRF_REFRESH_TOKEN,
  XSRF_TOKEN,
  XSRF_USERID,
} from "@/constants/authority";
import { checkResSuccess, decodeAccessToken } from "@/lib/utils";
import { NextRequest, NextResponse } from "next/server";
const isProd = process.env.NODE_ENV === "production";
export async function POST(req: NextRequest) {
  const res = await fetch(
    `${envConfig.NEXT_PUBLIC_API_ENDPOINT}/v1/public/auth/login`,
    {
      method: "POST",
      headers: req.headers,
      body: req?.body,
      duplex: "half",
    } as RequestInit
  );

  const data = await res.json();
  const headers = new Headers();
  if (checkResSuccess(data.code + "")) {
    const cookieOptions = [
      "Path=/",
      "HttpOnly",
      isProd ? "Secure" : "",
      "SameSite=Lax",
    ]
      .filter(Boolean)
      .join("; ");
    headers.append(
      "Set-Cookie",
      `${XSRF_TOKEN}=${data?.data?.accessToken}; ${cookieOptions} `
    );
    headers.append(
      "Set-Cookie",
      `${XSRF_REFRESH_TOKEN}=${data?.data?.refreshToken}; ${cookieOptions}`
    );
    headers.append(
      "Set-Cookie",
      `${XSRF_USERID}=${decodeAccessToken(data?.data?.accessToken).sub}; ${cookieOptions}`
    );
  }

  return NextResponse.json(data, { status: res.status, headers: headers });
}
