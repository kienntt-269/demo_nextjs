import envConfig from "@/config";
import {
  XSRF_REFRESH_TOKEN,
  XSRF_TOKEN,
  XSRF_USERID,
} from "@/constants/authority";
import { cookies } from "next/headers";
import { NextResponse } from "next/server";

export async function POST() {
  const cookieStore = cookies();
  const token = cookieStore.get(XSRF_TOKEN)?.value;
  const userId = cookieStore.get(XSRF_USERID)?.value;
  fetch(`${envConfig.NEXT_PUBLIC_API_ENDPOINT}/v1/api/auth/logout`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      authorization: `Bearer ${token ?? ""}`,
      "user-id": userId ?? "",
    },
  });
  cookieStore.delete(XSRF_TOKEN);
  cookieStore.delete(XSRF_USERID);
  cookieStore.delete(XSRF_REFRESH_TOKEN);
  return NextResponse.json({});
}
