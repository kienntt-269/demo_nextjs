"use client";
import { useProfileStore } from "@/_stores/useProfile.store";
import LeftSectionItem from "@/app/personal/components/sidebar-left";
import SectionPersonalInformation from "@/app/personal/components/infomation";
import ChangePasswordForm from "@/app/personal/components/change-password-form";
import BreadCrumbCommon from "@/components/breadcrumb-common";
import PasswordIcon from "@/components/icons/password-icon";
import PurchaseIcon from "@/components/icons/purchase-icon";
import UserIcon from "@/components/icons/user-icon";
import WarrantyIcon from "@/components/icons/warranty-icon";
import PageContent from "@/components/page-content";
import { ILinks } from "@/types/package";
import { useTranslations } from "next-intl";
import ErrorPage from "@/components/error";
import CarouselData from "@/components/common/carousel-data/carousel-data";
import { useIsMobile } from "@/hooks/use-mobile";
import NatcomPointIcon from "@/components/icons/natcom-point-icon";
import OrderTrackingIcon from "@/components/icons/order-tracking-icon";
import OrderTracking from "@/app/personal/components/order-tracking";
import WarrantyInfomation from "@/app/personal/components/warranty-infomation";

const PERSONAL_PAGE_TYPE = {
  info: "info",
  change_pass: "change-password",
  order_status: "order-status",
  purchase: "purchase",
  warranty: "warranty",
  affiliate: "affiliate",
  natcom_point: "natcom-point",
  order_tracking: "order-tracking",
};

export default function PersonalPage({
  searchParams,
}: {
  searchParams: { [key: string]: string | string[] | undefined };
}) {
  const isMobile = useIsMobile();
  const type = searchParams["type"] || PERSONAL_PAGE_TYPE.info; // default value is "1"
  const t = useTranslations();
  const { user } = useProfileStore();
  const breadCrumb: ILinks[] = [
    {
      label: t("personal.home"),
      link: "/",
    },

    {
      label: t("personal.title"),
      link: "/personal",
    },
  ];
  const listMenuLeft = [
    {
      icon: <UserIcon />,
      title: t("personal.account_information"),
      url: `?type=${PERSONAL_PAGE_TYPE.info}`,
      isActive: type === PERSONAL_PAGE_TYPE.info,
    },
    {
      icon: <PasswordIcon />,
      title: t("personal.changePassword.title"),
      url: `?type=${PERSONAL_PAGE_TYPE.change_pass}`,
      isActive: type === PERSONAL_PAGE_TYPE.change_pass,
    },
    {
      icon: <NatcomPointIcon />,
      title: t("natcom_points.title"),
      url: `/${PERSONAL_PAGE_TYPE.natcom_point}`,
      isActive: type === PERSONAL_PAGE_TYPE.natcom_point,
    },
    {
      icon: <OrderTrackingIcon />,
      title: t("order_tracking.title"),
      url: `?type=${PERSONAL_PAGE_TYPE.order_tracking}`,
      isActive: type === PERSONAL_PAGE_TYPE.order_tracking,
    },
    // {
    //   icon: <OrderIcon />,
    //   title: t("personal.order_status.title"),
    //   url: `?type=${PERSONAL_PAGE_TYPE.order_status}`,
    //   isActive: type === PERSONAL_PAGE_TYPE.order_status,
    // },
    {
      icon: <PurchaseIcon />,
      title: t("personal.purchase_history.title"),
      url: `?type=${PERSONAL_PAGE_TYPE.purchase}`,
      isActive: type === PERSONAL_PAGE_TYPE.purchase,
    },
    // {
    //   icon: <PurchaseIcon />,
    //   title: t("personal.affiliate.title"),
    //   url: `?type=${PERSONAL_PAGE_TYPE.affiliate}`,
    //   isActive: type === PERSONAL_PAGE_TYPE.affiliate,
    // },
    {
      icon: <WarrantyIcon />,
      title: t("personal.warranty_information.title"),
      url: `?type=${PERSONAL_PAGE_TYPE.warranty}`,
      isActive: type === PERSONAL_PAGE_TYPE.warranty,
    },
  ];

  const renderRightContent = () => {
    switch (type) {
      case PERSONAL_PAGE_TYPE.change_pass:
        return <ChangePasswordForm user={user || undefined} />;
      case PERSONAL_PAGE_TYPE.order_tracking:
        return <OrderTracking />;
      case PERSONAL_PAGE_TYPE.warranty:
        return <WarrantyInfomation />;
      case PERSONAL_PAGE_TYPE.order_status:
        return <ErrorPage />;
      case PERSONAL_PAGE_TYPE.purchase:
        return <ErrorPage />;
      case PERSONAL_PAGE_TYPE.affiliate:
        return <ErrorPage />;
      default:
        return <SectionPersonalInformation user={user || undefined} />;
    }
  };

  return (
    <PageContent className="bg-background-content">
      <div className="max-md:hidden">
        <BreadCrumbCommon content={breadCrumb} />
      </div>
      <div className="mt-10">
        <div className="grid grid-cols-12 gap-4 xl:gap-6">
          <div className="col-span-12 md:col-span-4 xl:col-span-3 rounded-2xl md:rounded-3xl">
            <div className="w-full flex justify-between md:justify-normal md:flex-col md:h-full md:gap-4 h-[72px] gap-2  bg-white p-2 rounded-2xl md:rounded-3xl shadow-box-custom md:shadow-none">
              {isMobile ? (
                <CarouselData
                  quantityMobile={6}
                  quantityXs={6}
                  length={listMenuLeft.length}
                  isShowPaging={false}
                >
                  {listMenuLeft.map((item, index) => (
                    <LeftSectionItem
                      key={index}
                      title={item.title}
                      icon={item.icon}
                      url={item.url}
                      isActive={item.isActive}
                    />
                  ))}
                </CarouselData>
              ) : (
                listMenuLeft.map((item, index) => (
                  <LeftSectionItem
                    key={index}
                    title={item.title}
                    icon={item.icon}
                    url={item.url}
                    isActive={item.isActive}
                  />
                ))
              )}
            </div>
          </div>
          <div className="col-span-12 md:col-span-8 xl:col-span-9 shadow-box-custom md:shadow-none rounded-2xl md:rounded-3xl">
            <div className="w-full h-full bg-white p-4 lg:p-8 rounded-2xl md:rounded-3xl">
              {renderRightContent()}
            </div>
          </div>
        </div>
      </div>
    </PageContent>
  );
}
