import ContentPagePersonal from "@/app/personal/components/content-page";
import WarrantyResult from "@/app/personal/components/warranty-result";
import { Form, InputField } from "@/components/form";
import { Button } from "@/components/ui/button";
import { Typography } from "@/components/ui/typography";
import { IUserProfile } from "@/types/user";
import { useTranslations } from "next-intl";
import React from "react";

type WarrantyFormValues = {
  currentPassword: string;
  otp: string;
  newPassword: string;
  confirmNewPassword: string;
  [key: string]: string;
};

const Warranty = ({ user }: { user?: IUserProfile }) => {
  console.log({ user });
  const t = useTranslations();
  const handleSubmit = async () => {};
  return (
    <ContentPagePersonal title="Warranty Information">
      <Form<WarrantyFormValues>
        onSubmit={handleSubmit}
        options={{
          mode: "onChange",
        }}
        defaultValue={{
          otp: "",
          currentPassword: "",
          newPassword: "",
          confirmPassword: "",
        }}
      >
        {({ control, watch, formState: { errors } }) => {
          return (
            <>
              <div className="flex flex-col gap-6 max-w-[447px]">
                <InputField
                  isShadow
                  control={control}
                  errors={errors}
                  name="serialNumber"
                  required
                  label={"Serial number"}
                  placeholder={"Input your serial number"}
                />
                <InputField
                  isShadow
                  control={control}
                  errors={errors}
                  name="orderId"
                  label={"Order ID"}
                  placeholder={"Input your order ID"}
                />
              </div>
              <div className="mt-6">
                <Button
                  disabled={!watch("serialNumber") || !watch("orderId")}
                  className="w-full max-w-full lg:w-[227px]"
                >
                  {t("common.search")}
                </Button>
              </div>
            </>
          );
        }}
      </Form>
      <div>
        <Typography className="font-bold text-2xl">Result (1)</Typography>
        <div className="mt-4">
          <WarrantyResult />
        </div>
      </div>
    </ContentPagePersonal>
  );
};

export default Warranty;
