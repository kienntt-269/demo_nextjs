import { Typography } from "@/components/ui/typography";
import { cn } from "@/lib/utils";
import React from "react";

type Props = {
  title: string;
  children: React.ReactNode;
  titleClassName?: string;
};

const ContentPagePersonal = ({ title, titleClassName, children }: Props) => {
  return (
    <div className="flex flex-col gap-6 xl:gap-10">
      <Typography variant="title2" className={cn(titleClassName)}>
        {title}
      </Typography>
      {children}
    </div>
  );
};

export default ContentPagePersonal;
