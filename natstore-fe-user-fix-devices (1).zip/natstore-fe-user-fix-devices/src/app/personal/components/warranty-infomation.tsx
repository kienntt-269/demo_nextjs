import ContentPagePersonal from "@/app/personal/components/content-page";
import WarrantyFaqs from "@/app/personal/components/warranty-faqs";
import WarrantyPolicyContent from "@/app/personal/components/warranty-policy-content";
import WarrantyServicePoint from "@/app/personal/components/warranty-service-point";
import TabCommon from "@/components/tabs-common";
import { ITab } from "@/types/package";
import { useTranslations } from "next-intl";
import { useSearchParams } from "next/navigation";
import React from "react";

const WarrantyInfomation = () => {
  const t = useTranslations("personal");
  const searchParam = useSearchParams();
  const slug = searchParam.get("slug") || "policy"; // default to 'policy' if no tab is specified
  const tabs: ITab[] = [
    {
      label: t("warranty_information.warranty_policy"),
      slug: "policy",
    },
    {
      label: t("warranty_information.warranty_service_point"),
      slug: "service-point",
    },
    {
      label: t("warranty_information.faqs"),
      slug: "faqs",
    },
  ];

  const renderTabContent = () => {
    switch (slug) {
      case "policy":
        return <WarrantyPolicyContent />;
      case "service-point":
        return <WarrantyServicePoint />;
      case "faqs":
        return <WarrantyFaqs />;
      default:
        return null;
    }
  };
  return (
    <ContentPagePersonal title={t("warranty_information.title")}>
      <div className="flex justify-between">
        <TabCommon tabs={tabs} tabItemClassName="!text-base" />
      </div>
      <div className="customer-support-page">{renderTabContent()}</div>
    </ContentPagePersonal>
  );
};

export default WarrantyInfomation;
