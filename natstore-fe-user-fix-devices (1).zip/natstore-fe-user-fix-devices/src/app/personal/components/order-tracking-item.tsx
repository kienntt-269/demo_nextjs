import React from "react";
import { Button } from "@/components/ui/button";
import { useTranslations } from "next-intl";

type OrderTrackingItemProps = {
  orderId: string;
  productCount: number;
  customer: string;
  product: string;
  orderDate: string;
  total: string;
  paymentMethod: string;
  status: "delivered" | "pending" | "cancelled" | "processing";
};

// Status styling map
const statusStyleMap: Record<
  string,
  { textColor: string; bgColor: string; labelKey: string }
> = {
  delivered: {
    textColor: "text-[#34C759]",
    bgColor: "bg-[#34C75929]",
    labelKey: "delivered",
  },
  pending: {
    textColor: "text-[#FFA500]",
    bgColor: "bg-[#FFA50029]",
    labelKey: "pending",
  },
  cancelled: {
    textColor: "text-[#FF3B30]",
    bgColor: "bg-[#FF3B3029]",
    labelKey: "cancelled",
  },
  processing: {
    textColor: "text-[#007AFF]",
    bgColor: "bg-[#007AFF29]",
    labelKey: "processing",
  },
};

const OrderTrackingItem = ({
  orderId,
  productCount,
  customer,
  product,
  orderDate,
  total,
  paymentMethod,
  status,
}: OrderTrackingItemProps) => {
  const t = useTranslations();

  const statusStyle = statusStyleMap[status];

  return (
    <div className="py-4 px-6 pr-2 bg-[#F5F6F7] border border-[#DEDEDE] rounded-2xl">
      <div className="flex justify-between">
        <div className="flex-1">
          {/* Header Info */}
          <div className="flex gap-8 items-center">
            <div className="flex gap-2">
              <p className="text-neutral-dark-04">{t("order_tracking.order_id")}:</p>
              <p className="text-neutral-dark-01 font-bold">#{orderId}</p>
            </div>
            <div className="w-[1px] h-[21px] bg-[#C5C5C5]" />
            <div className="flex gap-1">
              <p className="text-neutral-dark-01 font-bold">{productCount}</p>
              <p className="text-neutral-dark-04">{t("order_tracking.products")}</p>
            </div>
          </div>

          {/* Order Details */}
          <div className="mt-6 flex gap-6">
            <InfoBlock label={t("order_tracking.customer")} value={customer} />
            <InfoBlock label={t("order_tracking.product")} value={product} />
            <InfoBlock label={t("order_tracking.successful_order_date")} value={orderDate} />
            <InfoBlock label={t("order_tracking.total")} value={total} valueClass="text-primary" />
            <InfoBlock label={t("order_tracking.payment_method")} value={paymentMethod} />
            <div className="flex flex-col gap-2 flex-1">
              <p className="text-sm text-neutral-dark-04">{t("order_tracking.order_status")}</p>
              <p
                className={`font-bold py-1 px-4 w-fit rounded-[34px] 
                ${statusStyle.textColor} ${statusStyle.bgColor}`}
              >
                {t(statusStyle.labelKey)}
              </p>
            </div>
          </div>
        </div>

        {/* Action Button */}
        <div>
          <Button variant="outline" size="sm">
            {t("order_tracking.see_detail")}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default OrderTrackingItem;

// Reusable info block
const InfoBlock = ({
  label,
  value,
  valueClass = "text-neutral-dark-02",
}: {
  label: string;
  value: string;
  valueClass?: string;
}) => (
  <div className="flex flex-col gap-2 flex-1">
    <p className="text-sm text-neutral-dark-04">{label}</p>
    <p className={`font-bold ${valueClass}`}>{value}</p>
  </div>
);
