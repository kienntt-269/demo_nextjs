import { IStepStore } from "@/types/stores";
import { create } from "zustand";

export const useStepsStore = create<IStepStore>((set) => ({
  currentStep: 0,
  setCurrentStep: (step) => set({ currentStep: step }),
  nextStep: () => set((state) => ({ currentStep: state.currentStep + 1 })),
  nextStepWithNumber: (number: number) => set(() => ({ currentStep: number })),
  prevStep: () =>
    set((state) => ({ currentStep: Math.max(0, state.currentStep - 1) })),
  resetSteps: () => set({ currentStep: 0 }), // Định nghĩa resetSteps
}));
