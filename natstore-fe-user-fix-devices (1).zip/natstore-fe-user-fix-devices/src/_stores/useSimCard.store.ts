import { create } from "zustand";
import { IDataPlan } from "@/schemaValidations/mobile-service.schema";
import { ISimCard } from "@/schemaValidations/sim-card.schema";

interface ISimCardStore {
  simDetail?: ISimCard;
  packageData?: IDataPlan;
  setSimDetail: (data?: ISimCard) => void;
  setPackageData: (data?: IDataPlan) => void;
}

export const useSimCardStore = create<ISimCardStore>((set) => ({
  simDetail: undefined,
  packageData: undefined,
  setSimDetail: (data) =>
    set((state) => ({
      ...state,
      simDetail: data,
    })),
  setPackageData: (data) =>
    set((state) => ({
      ...state,
      packageData: data,
    })),
}));
