import { create } from "zustand";

export const useLoadingStore = create<{
  isLoading: boolean;
  setIsLoading: (isLoading: boolean) => void;
}>((set) => ({
  isLoading: false,
  setIsLoading: (isLoading: boolean) =>
    set((state) => ({ ...state, isLoading })),
}));
