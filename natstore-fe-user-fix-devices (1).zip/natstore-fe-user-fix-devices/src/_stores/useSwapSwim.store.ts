import { SwapSimForm } from "@/schemaValidations/swap-sim.schema";
import { ISwapSimStore } from "@/types/stores";
import { create } from "zustand";

export const useSwapSimStore = create<ISwapSimStore>((set) => ({
  data: undefined,
  requestId: undefined,
  setData: (data: SwapSimForm, requestId: string) =>
    set({ data: data, requestId: requestId }),
}));
