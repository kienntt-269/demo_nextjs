"use client";
import { create } from "zustand";

export const useChatOnline = create<{
  isOpen: boolean;
  isStart: boolean;
  roomIsExist: boolean;
  roomData: {
    roomId: string;
    status: string;
  } | null;
  mode: "CHAT" | "FORM";
  phoneSupporting: string;
  serviceChoosedId: string;
  nameSupporting: string;
  setStateChatOnline: ({
    isStart,
    isOpen,
    roomIsExist,
    mode,
    roomData,
    phoneSupporting,
    serviceChoosedId,
    nameSupporting,
  }: {
    isStart?: boolean;
    isOpen?: boolean;
    roomIsExist?: boolean;
    mode?: "CHAT" | "FORM";
    roomData?: {
      roomId: string;
      status: string;
    } | null;
    phoneSupporting?: string;
    serviceChoosedId?: string;
    nameSupporting?: string;
  }) => void;
}>((set) => ({
  isOpen: false,
  isStart: false,
  roomIsExist: true,
  phoneSupporting: "",
  serviceChoosedId: "",
  nameSupporting: "",
  roomData: null,
  mode: "FORM",
  setStateChatOnline: (newState) =>
    set((state) => ({ ...state, isStart: false, ...newState })),
}));
