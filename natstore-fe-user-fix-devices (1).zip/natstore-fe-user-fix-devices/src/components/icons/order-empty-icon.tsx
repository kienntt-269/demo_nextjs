import React from "react";

const OrderEmptyIcon = () => {
  return (
    <svg
      width="480"
      height="216"
      viewBox="0 0 480 216"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <g clip-path="url(#clip0_18020_119613)">
        <path
          d="M321.428 44.2524C264.863 29.096 221.189 108.813 152.012 74.2931C101.899 49.2866 66.7826 115.74 136.113 160.556C180.67 189.357 192.935 154.135 251.065 179.55C346.03 221.07 419.963 70.6549 321.428 44.2524Z"
          fill="#F5F6F7"
        />
        <path
          d="M275.93 44.3018L278.514 32.9033"
          stroke="#7C7C7C"
          strokeWidth="1.5593"
          strokeLinecap="round"
        />
        <path
          d="M279.371 48.1726L296.168 38.9248"
          stroke="#7C7C7C"
          strokeWidth="1.5593"
          strokeLinecap="round"
        />
        <path
          d="M280.883 53.335H291.865"
          stroke="#7C7C7C"
          strokeWidth="1.5593"
          strokeLinecap="round"
        />
        <path
          d="M163.289 51.2654C162.065 37.2872 137.138 28.4845 125.617 29.9354C102.604 32.8334 118.98 52.2954 132.06 57.4187C148.321 63.7877 164.165 61.2674 163.289 51.2654Z"
          fill="#F5F6F7"
        />
        <path
          d="M168.451 85.3961L208.489 96.1243C210.623 96.6961 212.816 95.4298 213.388 93.2959L225.84 46.8256C226.412 44.6917 225.145 42.4984 223.011 41.9266L182.973 31.1984C180.839 30.6266 178.646 31.8929 178.074 34.0268L165.622 80.4971C165.051 82.631 166.317 84.8243 168.451 85.3961Z"
          fill="#A2A2A2"
        />
        <path
          d="M185.066 36.761L218.418 45.6976C220.018 46.1265 220.968 47.7714 220.539 49.3718L210.215 87.9013C209.786 89.5016 208.141 90.4513 206.541 90.0226L173.189 81.086C171.589 80.6572 170.639 79.0122 171.068 77.4118L181.392 38.8823C181.82 37.2819 183.465 36.3321 185.066 36.761Z"
          fill="white"
          stroke="black"
          strokeWidth="2"
        />
        <rect
          x="188.949"
          y="47.2852"
          width="26.3808"
          height="3.03772"
          rx="1.51886"
          transform="rotate(15 188.949 47.2852)"
          fill="#C5C5C5"
        />
        <rect
          x="184.301"
          y="46.041"
          width="3.03331"
          height="3.03772"
          rx="1.51665"
          transform="rotate(15 184.301 46.041)"
          fill="#616161"
        />
        <rect
          x="187.035"
          y="54.4346"
          width="26.3808"
          height="3.03772"
          rx="1.51886"
          transform="rotate(15 187.035 54.4346)"
          fill="#C5C5C5"
        />
        <rect
          x="182.387"
          y="53.1885"
          width="3.03331"
          height="3.03772"
          rx="1.51665"
          transform="rotate(15 182.387 53.1885)"
          fill="#616161"
        />
        <rect
          x="185.117"
          y="61.5801"
          width="26.3808"
          height="3.03772"
          rx="1.51886"
          transform="rotate(15 185.117 61.5801)"
          fill="#C5C5C5"
        />
        <rect
          x="180.469"
          y="60.3359"
          width="3.03331"
          height="3.03772"
          rx="1.51665"
          transform="rotate(15 180.469 60.3359)"
          fill="#616161"
        />
        <rect
          x="183.199"
          y="68.7295"
          width="26.3808"
          height="3.03772"
          rx="1.51886"
          transform="rotate(15 183.199 68.7295)"
          fill="#C5C5C5"
        />
        <rect
          x="178.551"
          y="67.4834"
          width="3.03331"
          height="3.03772"
          rx="1.51665"
          transform="rotate(15 178.551 67.4834)"
          fill="#616161"
        />
        <path
          d="M204.978 31.2047C207.553 31.8946 209.266 34.1934 209.327 36.7295L214.939 38.2331L212.513 47.2858L190.41 41.3633L192.836 32.3106L198.45 33.815C199.772 31.6496 202.404 30.5149 204.978 31.2047Z"
          fill="#333333"
        />
        <path
          d="M313.221 193.468C311.195 187.205 229.589 185.617 191.063 187.404C114.11 190.973 165.717 198.262 208.466 199.325C261.61 200.647 314.67 197.95 313.221 193.468Z"
          fill="#E3E4E5"
        />
        <g filter="url(#filter0_i_18020_119613)">
          <path
            d="M177.255 140.213L199.776 134.179L222.297 128.144L249.971 120.729L267.34 116.075C270.024 115.365 272.372 113.731 273.971 111.46C275.57 109.19 276.318 106.429 276.082 103.662L275.817 100.412L274.722 86.9925L273.362 70.323L271.976 53.3345L237.107 62.6775L202.239 72.0205L176.86 78.8208L151.48 85.6211"
            fill="#DADADA"
          />
        </g>
        <path
          d="M177.255 140.213L199.776 134.179M151.48 85.6211L176.86 78.8208M222.297 128.144L202.239 72.0205M222.297 128.144L249.971 120.729M222.297 128.144L199.776 134.179M202.239 72.0205L237.107 62.6775M202.239 72.0205L176.86 78.8208M237.107 62.6775L271.976 53.3345L273.362 70.323M237.107 62.6775L249.971 120.729M249.971 120.729L267.34 116.075C270.024 115.365 272.372 113.731 273.971 111.46C275.57 109.19 276.318 106.429 276.082 103.662L275.817 100.412M176.86 78.8208L199.776 134.179M273.362 70.323L158.548 100.412M273.362 70.323L274.722 86.9925M274.722 86.9925L165.34 114.965M274.722 86.9925L275.817 100.412M275.817 100.412L170.967 126.803"
          stroke="black"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <path
          d="M272.088 145.552L190.18 167.499L140.689 62.8373C140.101 61.5824 139.094 60.5723 137.841 59.9816C136.588 59.3909 135.167 59.2568 133.826 59.6026L120.844 63.0811"
          stroke="black"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <g filter="url(#filter1_i_18020_119613)">
          <path
            d="M205.184 194.229C213.107 192.106 217.808 183.963 215.685 176.04C213.563 168.118 205.419 163.416 197.497 165.539C189.575 167.662 184.873 175.805 186.996 183.727C189.119 191.65 197.262 196.351 205.184 194.229Z"
            fill="#616161"
          />
        </g>
        <path
          d="M205.184 194.229C213.107 192.106 217.808 183.963 215.685 176.04C213.563 168.118 205.419 163.416 197.497 165.539C189.575 167.662 184.873 175.805 186.996 183.727C189.119 191.65 197.262 196.351 205.184 194.229Z"
          stroke="black"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <path
          d="M202.786 185.273C205.763 184.475 207.529 181.416 206.732 178.439C205.934 175.462 202.874 173.696 199.898 174.493C196.921 175.291 195.154 178.351 195.952 181.327C196.75 184.304 199.809 186.07 202.786 185.273Z"
          fill="#D9D9D9"
        />
        <g filter="url(#filter2_i_18020_119613)">
          <path
            d="M279.774 174.241C287.696 172.118 292.398 163.975 290.275 156.053C288.152 148.131 280.009 143.429 272.087 145.552C264.165 147.675 259.463 155.818 261.586 163.74C263.709 171.663 271.852 176.364 279.774 174.241Z"
            fill="#616161"
          />
        </g>
        <path
          d="M279.774 174.241C287.696 172.118 292.398 163.975 290.275 156.053C288.152 148.131 280.009 143.429 272.087 145.552C264.165 147.675 259.463 155.818 261.586 163.74C263.709 171.663 271.852 176.364 279.774 174.241Z"
          stroke="black"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <path
          d="M277.38 165.286C280.356 164.488 282.123 161.428 281.325 158.452C280.528 155.475 277.468 153.708 274.491 154.506C271.515 155.304 269.748 158.363 270.546 161.34C271.343 164.317 274.403 166.083 277.38 165.286Z"
          fill="#D9D9D9"
        />
      </g>
      <defs>
        <filter
          id="filter0_i_18020_119613"
          x="150.48"
          y="52.334"
          width="126.645"
          height="88.8799"
          filterUnits="userSpaceOnUse"
          color-interpolation-filters="sRGB"
        >
          <feFlood flood-opacity="0" result="BackgroundImageFix" />
          <feBlend
            mode="normal"
            in="SourceGraphic"
            in2="BackgroundImageFix"
            result="shape"
          />
          <feColorMatrix
            in="SourceAlpha"
            type="matrix"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dx="7" dy="3" />
          <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
          <feColorMatrix
            type="matrix"
            values="0 0 0 0 0.858333 0 0 0 0 0.858333 0 0 0 0 0.858333 0 0 0 1 0"
          />
          <feBlend
            mode="normal"
            in2="shape"
            result="effect1_innerShadow_18020_119613"
          />
        </filter>
        <filter
          id="filter1_i_18020_119613"
          x="185.484"
          y="164.029"
          width="31.7109"
          height="31.709"
          filterUnits="userSpaceOnUse"
          color-interpolation-filters="sRGB"
        >
          <feFlood flood-opacity="0" result="BackgroundImageFix" />
          <feBlend
            mode="normal"
            in="SourceGraphic"
            in2="BackgroundImageFix"
            result="shape"
          />
          <feColorMatrix
            in="SourceAlpha"
            type="matrix"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dx="-3" dy="4" />
          <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
          <feColorMatrix
            type="matrix"
            values="0 0 0 0 0.858333 0 0 0 0 0.858333 0 0 0 0 0.858333 0 0 0 1 0"
          />
          <feBlend
            mode="normal"
            in2="shape"
            result="effect1_innerShadow_18020_119613"
          />
        </filter>
        <filter
          id="filter2_i_18020_119613"
          x="260.074"
          y="144.042"
          width="31.7109"
          height="31.709"
          filterUnits="userSpaceOnUse"
          color-interpolation-filters="sRGB"
        >
          <feFlood flood-opacity="0" result="BackgroundImageFix" />
          <feBlend
            mode="normal"
            in="SourceGraphic"
            in2="BackgroundImageFix"
            result="shape"
          />
          <feColorMatrix
            in="SourceAlpha"
            type="matrix"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dx="-3" dy="4" />
          <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
          <feColorMatrix
            type="matrix"
            values="0 0 0 0 0.858333 0 0 0 0 0.858333 0 0 0 0 0.858333 0 0 0 1 0"
          />
          <feBlend
            mode="normal"
            in2="shape"
            result="effect1_innerShadow_18020_119613"
          />
        </filter>
        <clipPath id="clip0_18020_119613">
          <rect width="480" height="216" fill="white" />
        </clipPath>
      </defs>
    </svg>
  );
};

export default OrderEmptyIcon;
