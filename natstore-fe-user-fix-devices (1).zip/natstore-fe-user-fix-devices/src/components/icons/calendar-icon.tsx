import React from "react";

const CalendarIcon = () => {
  return (
    <svg
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M20.6667 4.6665H3.33333C2.59695 4.6665 2 5.26346 2 5.99984V20.6665C2 21.4029 2.59695 21.9998 3.33333 21.9998H20.6667C21.403 21.9998 22 21.4029 22 20.6665V5.99984C22 5.26346 21.403 4.6665 20.6667 4.6665Z"
        stroke="#A2A2A2"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M2 10H22"
        stroke="#A2A2A2"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M7.33203 6.66667V2"
        stroke="#A2A2A2"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M16.668 6.66667V2"
        stroke="#A2A2A2"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
};

export default CalendarIcon;
