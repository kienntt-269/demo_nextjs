import React from "react";

const PasswordIcon = () => {
  return (
    <svg
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M17 9.14062H7C5.61929 9.14062 4.5 10.2599 4.5 11.6406V19.1406C4.5 20.5213 5.61929 21.6406 7 21.6406H17C18.3807 21.6406 19.5 20.5213 19.5 19.1406V11.6406C19.5 10.2599 18.3807 9.14062 17 9.14062Z"
        stroke="black"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M12 1.64062C10.6739 1.64063 9.40215 2.16741 8.46447 3.10509C7.52678 4.04277 7 5.31454 7 6.64062V9.14062H17V6.64062C17 5.31454 16.4732 4.04277 15.5355 3.10509C14.5979 2.16741 13.3261 1.64063 12 1.64062V1.64062Z"
        stroke="black"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
};

export default PasswordIcon;
