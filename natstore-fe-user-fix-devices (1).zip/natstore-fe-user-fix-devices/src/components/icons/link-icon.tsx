import React from "react";

const LinkIcon = () => {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width={24} height={24} fill="none">
      <path
        stroke="#000"
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth={1.5}
        d="M8.599 11.251a4.37 4.37 0 0 0-3.341 1.267L4.22 13.555a4.4 4.4 0 0 0 6.222 6.222l1.037-1.037a4.376 4.376 0 0 0 1.267-3.34M11.252 8.6a4.37 4.37 0 0 1 1.267-3.341l1.037-1.037a4.4 4.4 0 1 1 6.222 6.222l-1.037 1.037a4.373 4.373 0 0 1-3.34 1.267M8.367 15.629l7.26-7.26"
      />
    </svg>
  );
};

export default LinkIcon;
