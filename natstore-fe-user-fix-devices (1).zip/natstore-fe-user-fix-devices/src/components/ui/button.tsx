"use client";

import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";

import { cn } from "@/lib/utils";
import { useRouter } from "next/navigation";

const buttonVariants = cva(
  " inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 relative overflow-hidden transition-all duration-300 before:absolute before:top-0 before:left-[-100%] before:w-full before:h-full before:transition-all before:duration-300 before:z-0 hover:before:left-0",
  {
    variants: {
      variant: {
        default:
          "bg-primary font-bold text-white hover:bg-primary/60 before:bg-primary/60 active:bg-primary/60 disabled:bg-neutral-light disabled:text-neutral",
        destructive:
          "bg-destructive text-destructive-foreground shadow-sm hover:bg-destructive/90 before:bg-destructive/90",
        outline:
          "border border-primary bg-background text-primary shadow-sm hover:bg-black focus:bg-primary/60 before:bg-black",
        secondary:
          "border border-primary font-bold text-primary hover:bg-primary/10 before:bg-primary/10 active:bg-primary/16 active:border-transparent disabled:border-transparent disabled:bg-neutral-light2 disabled:text-neutral2",
        ghost:
          "font-bold text-primary hover:opacity-80 active:text-[#CA6A00] disabled:text-neutral",
        link: "text-primary underline-offset-4 hover:underline",
      },
      size: {
        default: "h-8 md:h-12 text-sm lg:text-base px-5 rounded-full",
        sm: "h-8 rounded-full px-3 text-sm",
        lg: "h-10 rounded-md px-5",
        xl: "h-12 text-md px-5 rounded-full",
        icon: "h-9 w-9",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  },
);

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean;
  navigate?: string;
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  (
    { navigate, className, variant, size, asChild = false, children, ...props },
    ref,
  ) => {
    const Comp = asChild ? Slot : "button";
    const router = useRouter();
    const navigateNew = navigate?.startsWith("/") ? navigate : `/${navigate}`;
    return (
      <Comp
        className={cn(buttonVariants({ variant, size, className }))}
        ref={ref}
        onClick={() => navigate && router.push(navigateNew)}
        {...props}
      >
        <span className="relative z-10 flex-1">{children}</span>
      </Comp>
    );
  },
);
Button.displayName = "Button";

export { Button, buttonVariants };
