"use client";

import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

const typographyVariants = cva(
  "font-inter", // Base styles for the typography
  {
    variants: {
      variant: {
        title2:
          "text-xl sm:text-2xl xl:text-[28px] xl:leading-[34px] font-bold",
        h1: "text-4xl font-bold leading-tight",
        h2: "text-3xl font-semibold leading-tight",
        title: "text-2xl font-medium",
        content: "text-base",
        subtitle: "text-lg font-medium leading-relaxed",
        caption: "text-sm font-light leading-relaxed",
        bodyEmphasize:
          "text-neutral-dark-01 text-sm lg:text-base tracking-[-0.41px]",
        bodyRegular:
          "text-neutral-dark2 text-sm lg:text-base tracking-[-0.41px]",
      },
      weight: {
        regular: "font-normal",
        medium: "font-medium",
        bold: "font-bold",
      },
      //   color: {
      //     default: "text-neutral-800",
      //     primary: "text-primary",
      //     secondary: "text-secondary",
      //     error: "text-destructive",
      //   },
      align: {
        left: "text-left",
        center: "text-center",
        right: "text-right",
        justify: "text-justify",
      },
    },
    defaultVariants: {
      variant: "content",
      //   weight: "regular",
      //   color: "default",
      //   align: "left",
    },
  }
);

export interface TypographyProps
  extends React.HTMLAttributes<HTMLElement>,
    VariantProps<typeof typographyVariants> {
  asChild?: boolean;
}

const Typography = React.forwardRef<HTMLElement, TypographyProps>(
  ({ variant, weight, align, className, asChild = false, ...props }, ref) => {
    const Component = asChild ? "span" : "p"; // Default to <p> but can be a span if needed
    return (
      <Component
        className={cn(
          typographyVariants({ variant, weight, align, className })
        )}
        ref={ref as React.LegacyRef<HTMLParagraphElement>}
        {...props}
      />
    );
  }
);

Typography.displayName = "Typography";

export { Typography, typographyVariants };
