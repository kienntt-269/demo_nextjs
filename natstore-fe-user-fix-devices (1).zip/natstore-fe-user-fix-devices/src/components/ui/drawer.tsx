import React from "react";
import * as Dialog from "@radix-ui/react-dialog";
import Image from "next/image";

const Drawer: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  return (
    <Dialog.Root>
      <Dialog.Trigger className=" text-white rounded-md">
        <Image
          unoptimized
          quality={100}
          src={"/hamburger.png"}
          width={24}
          height={24}
          alt="hamburger image"
        />
      </Dialog.Trigger>
      <Dialog.Portal>
        <Dialog.Overlay className="fixed inset-0 bg-black/50 z-40 transition-opacity duration-300 data-[state=open]:opacity-100 data-[state=closed]:opacity-0" />

        <Dialog.Content className="fixed top-0 left-0 h-full w-3/4 max-w-xs bg-white z-50 shadow-lg transform data-[state=open]:animate-in data-[state=closed]:animate-out">
          {/* <Dialog.Close asChild>
            <button className="absolute top-4 right-4 p-2 text-gray-500">
              
            </button>
          </Dialog.Close> */}

          <div>{children}</div>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  );
};

export default Drawer;
