"use client";
import React from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useTranslations } from "next-intl";
import { IDataInternet } from "@/schemaValidations/internet.shema";
import { useRouter } from "next/navigation";
import Image from "next/image";
import TextCSRStyle from "@/components/text-csr-style";
import ComponentWithTooltip from "@/components/component-with-tooltip";

type IPropsCard = {
  data?: IDataInternet;
  action?: () => void;
  onRegister?: () => void;
  type: "large" | "medium";
};

const CardInfo: React.FC<IPropsCard> = ({
  data,
  type = "medium",
  action,
  // onRegister,
}) => {
  const t = useTranslations();
  const router = useRouter();

  return (
    <Card
      className="rounded-3xl max-md:rounded-2xl overflow-hidden border-none"
      style={{
        boxShadow: "0px 3.09px 12.37px 0px #00000014",
      }}
      onClick={() => {
        if (action) action();
      }}
    >
      <CardHeader
        className={`p-0 px-3 text-center space-y-0  ${
          type === "large"
            ? ""
            : "bg-[url('/card-header-infor.png')] bg-cover py-[15px] max-md:py-3"
        }`}
      >
        {type === "medium" ? (
          <ComponentWithTooltip content={data?.name ?? "ASWÈ NÈT"}>
            <div className="text-white text-card text-base md:text-[24px] hover:scale-105 transition-all max-md:text-[16px] max-md:font-semibold leading-[34px] max-md:leading-5 font-bold truncate text-ellipsis text-nowrap overflow-hidden">
              {data?.name ?? "ASWÈ NÈT"}
            </div>
          </ComponentWithTooltip>
        ) : (
          <Image
            unoptimized
            quality={100}
            width={368}
            height={260}
            src={"./pic-card.png"}
            className="object-cover w-full"
            alt=""
          />
        )}
      </CardHeader>

      <CardContent className="md:p-6 p-2">
        <div className=" border-b-[1px] border-b-[#E3E4E5] border-solid pb-6 ">
          <div className="flex justify-between items-center">
            <div className="max-md:text-[14px] text-neutral-dark-02">
              {t("internet.access_speed")}
            </div>
            <div className="max-w-24 lg:max-w-40 2xl:max-w-48 text-base  flex items-center md:text-xl font-bold max-md:mt-1 text-primary ">
              <ComponentWithTooltip
                content={`${Number(data?.speed).toLocaleString("en-US")} ${t("internet.mbps")}`}
              >
                <div className="overflow-hidden text-ellipsis whitespace-nowrap ">
                  {Number(data?.speed).toLocaleString("en-US")}
                </div>
              </ComponentWithTooltip>
              <span className="ml-1 ">{t("internet.mbps")}</span>
            </div>
          </div>
          <div className="flex justify-between items-center">
            <div className="max-md:text-[14px] text-neutral-dark-02">
              {t("internet.price")}
            </div>
            <div className="max-w-32 md:max-w-48 text-base flex items-center md:text-xl font-bold max-md:mt-1 text-neutral-dark-02">
              <ComponentWithTooltip
                content={`${Number(data?.price).toLocaleString("en-US")} $`}
              >
                <div className="overflow-hidden text-ellipsis whitespace-nowrap">
                  {Number(data?.price).toLocaleString("en-US")}
                </div>
              </ComponentWithTooltip>
              <span className="ml-1 text-neutral-mid-01">$</span>
            </div>
          </div>
        </div>
        <div className="border-b-[1px] border-b-[#E3E4E5] border-solid pb-4">
          <div className="pt-4 pb-2">
            <div className="text-neutral-dark-01 font-bold text-xl max-md:text-base">
              {t("internet.promotion")}
            </div>
          </div>
          <div>
            <ul className="h-14 md:h-16 list-disc text-sm text-neutral-dark-04 leading-relaxed font-normal px-4 max-md:pl-4 max-md:line-clamp-2">
              <li>
                {" "}
                <div className="line-clamp-3 font-normal text-[14px] text-neutral3 max-md:text-[12px] max-md:leading-[15px] whitespace-pre-line">
                  {data?.promotion}
                </div>
              </li>
            </ul>
          </div>
        </div>
        <div className="pt-4 pb-2">
          <div className="font-bold text-neutral-dark-01 text-xl max-md:text-base">
            {t("internet.note")}
          </div>
        </div>
        <div>
          <ul className="h-10 list-disc text-sm text-neutral-dark-04 leading-relaxed font-normal px-4 max-md:pl-4 max-md:line-clamp-2">
            <li>
              <div className="line-clamp-2 font-normal text-[14px] text-neutral-dark-04 max-md:text-[12px] max-md:leading-[15px] whitespace-pre-line">
                {data?.note}
              </div>
            </li>
          </ul>
        </div>
        <div className="flex max-md:flex-col max-md:gap-y-2 items-center gap-x-3 max-md:mt-3 mt-6">
          <Button
            className="flex-1 py-[13.5px] max-md:h-8 font-bold max-md:w-full max-lg:text-[14px] max-lg:py-2 max-lg:px-4 max-md:py-[6px] max-md:leading-5 "
            onClick={() => {
              router.push(`/internet/${data?.slug}/register`);
            }}
          >
            <TextCSRStyle>common.register</TextCSRStyle>
          </Button>
          <Button
            className="flex-1 py-[13.5px] max-md:h-8 font-bold max-md:w-full max-lg:text-[14px] max-lg:py-2 max-lg:px-4 max-md:py-[6px] max-md:leading-5 "
            variant={"secondary"}
            onClick={() => {
              router.push(`/internet/${data?.slug}`);
            }}
          >
            {t("mobile_package.detail")}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default CardInfo;
