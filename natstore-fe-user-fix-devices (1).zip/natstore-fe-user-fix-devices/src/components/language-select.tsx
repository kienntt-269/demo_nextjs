import { useLangStore } from "@/_stores/useLang.store";
import { useLoadingStore } from "@/_stores/useLoading,store";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useIsMobile } from "@/hooks/use-mobile";
import { Locale } from "@/i18n/config";
import { ILanguage } from "@/schemaValidations/list-menu.chema";
// import listMenuApiRequest from "@/services/list-menu";
import { getUserLocale, setUserLocale } from "@/services/locale";
import { Check } from "lucide-react";
import { useTranslations } from "next-intl";
import Image from "next/image";
import { useRouter } from "next/navigation";
import React, { useEffect, useMemo, useState } from "react";

const LANGUAGE_LIST: ILanguage[] = [
  {
    locale: "fr",
    name: "France",
    image: "/images/icon/french.svg",
  },
  {
    locale: "en",
    name: "English",
    image: "/images/icon/english.svg",
  },
  {
    locale: "ht",
    name: "Haitian Creole",
    image: "/images/icon/haitian.svg",
  },
];

const LanguageSelect = ({ defaultLocale }: { defaultLocale: Locale }) => {
  const t = useTranslations();
  const { setIsLoading } = useLoadingStore();
  // const [languageList, setLanguageList] = useState<ILanguage[]>([
  //   {
  //     locale: "en",
  //     name: "English",
  //     image: "/images/icon/english.svg",
  //   },
  // ]);
  const [locale, setLocale] = useState<Locale>(defaultLocale);
  const isMobile = useIsMobile();
  const { setLang } = useLangStore();
  const router = useRouter();
  const iconLangActive = useMemo(() => {
    return LANGUAGE_LIST.find((item) => item.locale === locale)?.image;
  }, [locale]);

  const handleSelect = (lang: Locale) => {
    setIsLoading(true);
    setTimeout(() => {
      setLang(lang);
      setLocale(lang);
      setUserLocale(lang);
      router.refresh();
      setIsLoading(false);
    }, 200);
  };

  // const getLanguage = async () => {
  //   try {
  //     const res = await listMenuApiRequest.getLanguage();
  //     if (res?.payload?.data) setLanguageList(res.payload.data);
  //     return res.payload.data;
  //   } catch (error) {
  //     console.log(error);
  //     throw Error("error");
  //   }
  // };

  // useEffect(() => {
  //   getLanguage();
  // }, []);

  useEffect(() => {
    const getLocale = async () => {
      const cookieLocal = await getUserLocale();
      if (cookieLocal) {
        setLocale(cookieLocal as Locale);
        setLang(cookieLocal as Locale);
      } else {
        const browserLocale = navigator.language.slice(0, 2);
        setLang(browserLocale as Locale);
        setLocale(browserLocale as Locale);
        setUserLocale(browserLocale as Locale);
        // router.refresh();
      }
    };
    getLocale();
  }, []);

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <span>
          <Image
            unoptimized
            quality={100}
            src={iconLangActive ?? "/images/icon/english.svg"}
            width={isMobile ? 24 : 32}
            height={isMobile ? 24 : 32}
            alt="lang image"
            className="max-sm:size-6 lg:size-8 cursor-pointer"
          />
        </span>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-[240px] p-4 rounded-xl">
        <div className="font-bold text-base mb-3 text-black">
          {t("common.select_language")}
        </div>
        <div className="flex flex-col gap-[10px]">
          {LANGUAGE_LIST.map((language) => (
            <DropdownMenuItem
              key={language.locale}
              className="cursor-pointer flex justify-between"
              onClick={() => handleSelect(language.locale as Locale)}
            >
              <div className="flex justify-center items-center gap-4">
                <Image
                  src={language.image as string}
                  alt="img content"
                  width={24}
                  height={24}
                  className="object-contain"
                />
                <div className="text-neutral-dark-04 text-sm lg:text-base">
                  {language.name}
                </div>
              </div>
              <span className="flex items-center gap-2">
                {locale === language.locale ? (
                  <Check className="w-4 h-4 text-primary" />
                ) : null}
              </span>
            </DropdownMenuItem>
          ))}
        </div>
      </DropdownMenuContent>
    </DropdownMenu>
  );
};

export default LanguageSelect;
