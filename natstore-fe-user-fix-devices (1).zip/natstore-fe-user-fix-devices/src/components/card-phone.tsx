"use client";
import React from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import Image from "next/image";
import { ICard } from "@/types/package";
import { cn } from "@/lib/utils";

type IPropsCard = {
  data?: ICard;
  action?: () => void;
  onRegister?: () => void;
  type?: string;
};

const CardPhone: React.FC<IPropsCard> = ({
  data,
  type = "medium",
  action,
  // onRegister,
}) => {
  return (
    <Card
      className={cn(
        "rounded-3xl max-md:rounded-2xl overflow-hidden border-none",
        type,
      )}
      style={{
        boxShadow: "0px 3.09px 12.37px 0px #00000014",
      }}
      onClick={() => {
        if (action) action();
      }}
    >
      <CardHeader>
        <Image
          src="/unavailable.svg"
          alt="illustration roaming"
          width={504}
          height={290}
          className="md:h-[290px] h-[142px]"
        />
      </CardHeader>
      <CardContent className="md:p-6 p-4">
        <div className="md:text-2xl text-base font-bold md:pb-3 pb-1 md:pt-6">
          {data?.title}
        </div>
        <div className="text-primary md:text-2xl text-base font-bold">
          {data?.price} HTG
        </div>
      </CardContent>
    </Card>
  );
};

export default CardPhone;
