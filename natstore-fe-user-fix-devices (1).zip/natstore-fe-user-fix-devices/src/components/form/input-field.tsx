import {
  Control,
  Controller,
  FieldError,
  FieldErrors,
  FieldValues,
  Path,
} from "react-hook-form";

import { FieldWrapper, TFieldWrapperPassThroughProps } from "./field-wrapper";
import InputCustom from "@/components/custom-ui/input-custom";

type TInputFieldProps<TFormValues extends FieldValues> =
  React.InputHTMLAttributes<HTMLInputElement> &
    TFieldWrapperPassThroughProps & {
      ref?: React.Ref<HTMLInputElement>;
      isShadow?: boolean;
      isPassValue?: boolean;
      name: Path<TFormValues>;
      formatValueRegex?: RegExp;
      type?: "text" | "email" | "password" | "file" | "number";
      className?: string;
      required?: boolean;
      errors?: FieldErrors<FieldValues>;
      control: Control<TFormValues>;
      label2?: React.ReactNode;
    };

export const InputField = <
  TFormValues extends Record<string, unknown> = Record<string, unknown>,
>(
  props: TInputFieldProps<TFormValues>,
) => {
  const {
    name,
    isShadow,
    type = "text",
    label,
    className,
    classNameLabel,
    required,
    errors,
    control,
    formatValueRegex,
    isPassValue,
    label2,
    ...rest
  } = props;
  return (
    <Controller
      name={name}
      control={control}
      render={({ field }) => {
        return (
          <FieldWrapper
            label={label}
            label2={label2}
            error={errors?.[name] as FieldError}
            required={required}
            className={className}
            classNameLabel={classNameLabel}
          >
            <InputCustom
              isPassValue={isPassValue}
              isShadow={isShadow}
              isError={!!errors?.[name]}
              formatValueRegex={formatValueRegex}
              value={field.value as string}
              onChange={field.onChange}
              variant={type}
              inputProps={{
                ...rest,
              }}
            />
          </FieldWrapper>
        );
      }}
    />
  );
};
