import { forwardRef, useCallback, useEffect, useState, useRef } from "react";
import { NumericFormat, NumericFormatProps } from "react-number-format";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cx } from "class-variance-authority";

export interface NumberInputProps
  extends Omit<NumericFormatProps, "value" | "onValueChange"> {
  stepper?: number;
  thousandSeparator?: string;
  placeholder?: string;
  defaultValue: number;
  min?: number;
  max?: number;
  value?: number; // Controlled value
  suffix?: string;
  prefix?: string;
  onValueChange?: (value: number) => void;
  fixedDecimalScale?: boolean;
  decimalScale?: number;
  customClassName?: string;
  error: string | null;
  setError: (error: string | null) => void;
}

const NumberInput = forwardRef<HTMLInputElement, NumberInputProps>(
  (
    {
      stepper,
      thousandSeparator,
      placeholder,
      defaultValue,
      min = -Infinity,
      max = Infinity,
      onValueChange,
      fixedDecimalScale = false,
      decimalScale = 0,
      suffix,
      prefix,
      value: controlledValue,
      error,
      // setError,
      ...props
    },
    ref
  ) => {
    const internalRef = useRef<HTMLInputElement>(null);
    const combinedRef =
      (ref as React.RefObject<HTMLInputElement>) || internalRef;
    const [value, setValue] = useState<number>(controlledValue ?? defaultValue);

    const handleIncrement = useCallback(() => {
      const next = (value || 0) + (stepper ?? 1);
      if (next <= max) {
        setValue(next);
        if (onValueChange) onValueChange(next);
      } else {
        setValue(max);
        if (onValueChange) onValueChange(max);
      }
    }, [value, stepper, max, onValueChange]);

    const handleDecrement = useCallback(() => {
      const next = (value || 0) - (stepper ?? 1);
      if (next >= min) {
        setValue(next);
        if (onValueChange) onValueChange(next);
      } else {
        setValue(min);
        if (onValueChange) onValueChange(min);
      }
    }, [value, stepper, min, onValueChange]);

    useEffect(() => {
      const handleKeyDown = (e: KeyboardEvent) => {
        if (document.activeElement === combinedRef.current) {
          if (e.key === "ArrowUp") handleIncrement();
          if (e.key === "ArrowDown") handleDecrement();
        }
      };
      window.addEventListener("keydown", handleKeyDown);
      return () => window.removeEventListener("keydown", handleKeyDown);
    }, [handleIncrement, handleDecrement, combinedRef]);

    useEffect(() => {
      if (controlledValue !== undefined) {
        setValue(controlledValue);
      }
    }, [controlledValue]);

    const handleChange = (values: {
      value: string;
      floatValue: number | undefined;
    }) => {
      const newValue = values.floatValue ?? defaultValue;
      setValue(newValue);
      if (onValueChange) onValueChange(newValue);
    };

    const handleBlur = () => {
      if (value < min) {
        setValue(min);
        combinedRef.current!.value = String(min);
        if (onValueChange) onValueChange(min);
      } else if (value > max) {
        setValue(max);
        combinedRef.current!.value = String(max);
        if (onValueChange) onValueChange(max);
      }
    };

    return (
      <div className="flex flex-col gap-1">
        <div className="flex gap-2 items-center">
          <Button
            aria-label="Decrease value"
            className="p-[6px] !h-6 !w-6 border-input text-black bg-[#E3E4E5] focus-visible:relative hover:text-white"
            onClick={handleDecrement}
            disabled={value === min}
          >
            -
          </Button>
          <NumericFormat
            value={value}
            onValueChange={handleChange}
            thousandSeparator={thousandSeparator}
            decimalScale={decimalScale}
            fixedDecimalScale={fixedDecimalScale}
            allowNegative={min < 0}
            valueIsNumericString
            onBlur={handleBlur}
            suffix={suffix}
            prefix={prefix}
            customInput={Input}
            placeholder={placeholder}
            className={cx(
              "text-base [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none rounded-r-none relative rounded-sm border-transparent focus:border focus:border-ring focus:outline-none max-w-[32px] p-0 text-center",
              props.customClassName
            )}
            getInputRef={combinedRef}
            {...props}
          />
          <Button
            aria-label="Increase value"
            className="p-[6px] !h-6 !w-6 border-input text-black bg-[#E3E4E5] focus-visible:relative hover:text-white"
            onClick={handleIncrement}
            disabled={value === max}
          >
            +
          </Button>
        </div>
        {error && <div className="text-sm text-red-500">{error}</div>}
      </div>
    );
  }
);

NumberInput.displayName = "NumberInput";
export default NumberInput;
