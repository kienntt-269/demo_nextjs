import {
  Control,
  Controller,
  FieldError,
  FieldErrors,
  FieldValues,
  Path,
} from "react-hook-form";

import { FieldWrapper, TFieldWrapperPassThroughProps } from "./field-wrapper";
import InputCustom from "@/components/custom-ui/input-custom";

type TInputFieldProps<TFormValues extends FieldValues> =
  React.InputHTMLAttributes<HTMLInputElement> &
    TFieldWrapperPassThroughProps & {
      name: Path<TFormValues>;
      type?: "text" | "email" | "password" | "file";
      className?: string;
      isPrefix?: boolean;
      required?: boolean;
      errors: FieldErrors<FieldValues>;
      control: Control<TFormValues>;
    };

export const InputPhoneNumberField = <
  TFormValues extends Record<string, unknown> = Record<string, unknown>,
>(
  props: TInputFieldProps<TFormValues>,
) => {
  const {
    name,
    type = "text",
    label,
    className,
    isPrefix = true,
    required,
    errors,
    control,
    classNameLabel,
    ...rest
  } = props;
  return (
    <Controller
      name={name}
      control={control}
      render={({ field }) => {
        return (
          <FieldWrapper
            label={label}
            error={errors?.[name] as FieldError}
            required={required}
            className={className}
            classNameLabel={classNameLabel}
          >
            <InputCustom
              isError={!!errors?.[name]}
              formatValueRegex={/[^0-9+]+/g}
              prefix={isPrefix ? "+509" : ""}
              isPassValue
              value={field.value as string}
              onChange={field.onChange}
              variant={type}
              inputProps={{
                maxLength: 8,
                ...rest,
              }}
            />
          </FieldWrapper>
        );
      }}
    />
  );
};
