import React from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import {
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationLink,
} from "@/components/ui/pagination";

type PaginationProps = {
  totalItems: number;
  itemsPerPage: number;
  current: number;
  onChange: (page: number) => void;
};

const generatePages = (current: number, total: number) => {
  const pages = [];
  if (total <= 7) {
    return Array.from({ length: total }, (_, i) => i + 1);
  }

  pages.push(1);
  if (current > 4) pages.push("...");

  const start = Math.max(2, current - 1);
  const end = Math.min(total - 1, current + 1);
  for (let i = start; i <= end; i++) {
    pages.push(i);
  }

  if (current < total - 3) pages.push("...");
  pages.push(total);

  return pages;
};

const PaginationCustom: React.FC<PaginationProps> = ({
  totalItems,
  itemsPerPage,
  current,
  onChange,
}) => {
  const total = Math.max(1, Math.ceil(totalItems / itemsPerPage));
  const pages = generatePages(current, total);

  return (
    <Pagination className="flex items-center gap-2">
      <PaginationContent>
        <PaginationItem
          className="mr-7"
          onClick={() => {
            if (current > 1) {
              onChange(current - 1);
            }
          }}
        >
          <PaginationLink
            className={`rounded-[2px] font-semibold size-8 cursor-pointer bg-[#E3E4E5] text-neutral-mid-01`}
          >
            <ChevronLeft />
          </PaginationLink>
        </PaginationItem>
        {pages.map((page, index) => (
          <PaginationItem
            key={`pagination-${index}`}
            onClick={() => typeof page === "number" && onChange(page)}
          >
            <PaginationLink
              className={`rounded-[2px] font-semibold size-8 cursor-pointer ${
                page === current
                  ? "bg-primary text-white"
                  : "bg-[#E3E4E5] text-neutral-mid-01 border-none"
              }`}
              isActive={page === index + 1 ? true : false}
            >
              {page}
            </PaginationLink>
          </PaginationItem>
        ))}
        <PaginationItem
          className="ml-7"
          onClick={() => {
            if (current < pages.length) {
              onChange(current + 1);
            }
          }}
        >
          <PaginationLink
            className={`rounded-[2px] font-semibold size-8 cursor-pointer bg-[#E3E4E5] text-neutral-mid-01`}
          >
            <ChevronRight />
          </PaginationLink>
        </PaginationItem>
      </PaginationContent>
    </Pagination>
  );
};

export default PaginationCustom;
