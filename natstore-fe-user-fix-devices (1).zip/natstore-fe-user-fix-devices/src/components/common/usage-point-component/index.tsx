"use client";
import { useProfileStore } from "@/_stores/useProfile.store";
import InputCustom from "@/components/custom-ui/input-custom";
import { FieldWrapper } from "@/components/form";
import { Switch2 } from "@/components/ui/switch2";
import pointApiRequest from "@/services/point-service";
import { StateUsePointType } from "@/types/common";
import { useTranslations } from "next-intl";
import React, { useEffect, useState } from "react";
import { FieldError } from "react-hook-form";

const MIN_AMOUNT_LIMIT = 10;
type UsagePointComponentProps = {
  totalAmount: number;
  onChangeState?: (data: StateUsePointType) => void;
};

const UsagePointComponent = ({
  totalAmount,
  onChangeState,
}: UsagePointComponentProps) => {
  const t = useTranslations();
  const { user } = useProfileStore();
  const [isUsePoint, setIsUsePoint] = useState<boolean>(false);
  const [point, setPoint] = useState<number>(0);
  const [redeemPoint, setRedeemPoint] = useState<string>("");
  const [error, setError] = useState<string | null>(null);

  const handleChange = (value: string) => {
    const numericValue = parseFloat(value);
    setRedeemPoint(value);
    if (!value) {
      setError("redeem_point.required");
    } else if (numericValue > point) {
      setError("redeem_point.redeem_exceed_balance");
    } else if (numericValue > totalAmount - MIN_AMOUNT_LIMIT) {
      setError("redeem_point.redeem_exceed_limit");
    } else {
      setError(null);
    }
  };

  const handleBlur = () => {
    const [int, dec] = redeemPoint.split(".");

    if (dec) {
      setRedeemPoint(`${int}.${dec[0]}`);
    } else {
      setRedeemPoint(redeemPoint);
    }
  };

  useEffect(() => {
    const numericValue = parseFloat(redeemPoint);
    onChangeState?.({
      redeemPoint: isNaN(numericValue) ? 0 : numericValue,
      isUsedPoint: isUsePoint,
      error: error ? error : undefined,
    });
  }, [isUsePoint, redeemPoint, point]);

  useEffect(() => {
    if (!user?.id) return;
    pointApiRequest.getMyBalance(user.id).then((res) => {
      setPoint(res.payload.data);
    });
  }, [user?.id]);

  if (!user) return null;

  return (
    <div>
      <div className="flex justify-between h-[56px] items-center">
        <p className="text-neutral-dark-02">
          {t("natcom_points.redeem_point")}
        </p>
        <Switch2
          checked={isUsePoint}
          onCheckedChange={(checked) => {
            setIsUsePoint(checked);
            if (!checked) {
              setRedeemPoint("");
              setError(null);
            }
          }}
        />
      </div>
      <div className="bg-[#F5F6F7] p-4 rounded-xl">
        <div className=" flex justify-between items-center">
          <p className="text-neutral-dark-04">
            {t("natcom_points.number_of_points")}
          </p>
          <p className="text-neutral-dark-04 font-bold">
            {point} {t("common.points")}
          </p>
        </div>
        <div>
          {!!isUsePoint ? (
            <FieldWrapper
              error={
                error
                  ? ({
                      message: error,
                      data: { limit: `${totalAmount - MIN_AMOUNT_LIMIT}`},
                    } as unknown as FieldError)
                  : undefined
              }
            >
              <InputCustom
                isShadow={true}
                isError={!!error}
                value={redeemPoint}
                isPassValue
                onChange={(event) => handleChange(event.target.value)}
                variant="number"
                inputProps={{
                  onBlur: handleBlur,
                  placeholder: t("natcom_points.input_points"),
                }}
              />
            </FieldWrapper>
          ) : null}
        </div>
      </div>
    </div>
  );
};

export default UsagePointComponent;
