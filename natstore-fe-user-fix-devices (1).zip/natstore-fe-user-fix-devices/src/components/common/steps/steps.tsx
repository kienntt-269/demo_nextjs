"use client";

import { useStepsStore } from "@/_stores/useSteps.store";
import React from "react";

interface Step {
  id: number;
  title: string;
  content: React.ReactNode;
}

interface StepsProps {
  steps: Step[];
}

export default function Steps({ steps }: StepsProps) {
  const currentStep = useStepsStore((state) => state.currentStep);
  const setCurrentStep = useStepsStore((state) => state.setCurrentStep);

  return (
    <div className="">
      <div className="mb-10 flex justify-center gap-4 lg:gap-[60px] rounded-3xl steps-header-bg px-4 py-[22px] lg:pt-[74px] lg:px-[90px] lg:pb-[50px]">
        {steps.map((step, index) => (
          <button
            key={step.id}
            onClick={() => setCurrentStep(index)}
            className="relative w-[99px] lg:w-[168px] flex flex-col justify-start items-center"
            disabled={currentStep < index}
          >
            <div
              className={`h-6 w-6 lg:h-10 lg:w-10 flex items-center justify-center text-xs lg:text-2xl rounded-t-2xl rounded-br-2xl border transition-all ${
                currentStep >= index
                  ? "bg-white text-primary"
                  : "border-2 border-solid border-white text-white"
              }`}
            >
              {index + 1}
              {index !== steps.length - 1 && (
                <div
                  className={`absolute -right-[56%] w-[88%] lg:-right-[84%] lg:w-[120%] 2xl:-right-[74%] h-1 2xl:w-[113%] bg-white z-10 transition-all ${currentStep < index ? "opacity-[24%]" : ""}`}
                ></div>
              )}
            </div>
            <div
              className={`text-xs lg:text-xl text-white mt-4 ${currentStep < index ? "" : "font-bold"}`}
            >
              {step.title}
            </div>
          </button>
        ))}
      </div>

      {/* Step Content */}
      <div className="px-4 py-6 lg:p-8 border rounded-3xl form-box-shadow">
        {steps[currentStep]?.content ?? <p>LOADING...</p>}
      </div>
    </div>
  );
}
