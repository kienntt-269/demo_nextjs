import { useTranslations } from "next-intl";
import Image from "next/image";
import React from "react";

const NotFound = () => {
  const t = useTranslations("");
  return (
    <div className="flex justify-center flex-col items-center">
      <Image
        src="/unavailable.svg"
        alt="no package found"
        width={480}
        height={216}
        className="md:h-[216px] h-[142px]"
      />
      <p className="mt-8 mb-4 lg:mb-0 text-sm lg:text-xl text-neutral-dark-03">
        {t("common.not_content")}
      </p>
    </div>
  );
};

export default NotFound;
