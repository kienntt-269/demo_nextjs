"use client";
import React, { useCallback, useRef, useState } from "react";
import { Swiper, SwiperSlide, SwiperRef } from "swiper/react";
import { Navigation, Pagination, Autoplay } from "swiper/modules";
import "swiper/css";
import "swiper/css/navigation";
import "swiper/css/pagination";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { useIsMobile } from "@/hooks/use-mobile";
import { cn } from "@/lib/utils";
import NoDataAvailable from "@/components/common/no-data-available/no-data-available";

type ICarousel = {
  quantity?: number;
  children: React.ReactNode;
  length?: number;
  quantityMobile?: number;
  loop?: boolean;
  autoplay?: object;
  customClass?: string;
  isShowPaging?: boolean;
  spaceBeetween?: number;
  speed?: number;
  isInfiniteLoop?: boolean;
  quantityXs?: number;
  quantitySm?: number;
  quantityMd?: number;
  quantityLg?: number;
  quantityXl?: number;
  swipperClassName?: string;
};

const CarouselData: React.FC<ICarousel> = ({
  quantity = 4,
  children,
  length = 0,
  quantityMobile = 2,
  quantityXs,
  quantitySm,
  quantityMd,
  quantityLg,
  quantityXl,
  loop = false,
  autoplay = false,
  customClass = "",
  isShowPaging = true,
  spaceBeetween,
  speed = 1000,
  isInfiniteLoop = false,
  swipperClassName = "",
}) => {
  const [activeIndex, setActiveIndex] = useState(0);
  const sliderRef = useRef<SwiperRef>(null);

  const handlePrev = useCallback(() => {
    if (!sliderRef.current) return;
    sliderRef.current.swiper.slidePrev();
  }, []);

  const handleNext = useCallback(() => {
    if (!sliderRef.current) return;
    sliderRef.current.swiper.slideNext();
  }, []);
  const isMobile = useIsMobile();
  return (
    <div
      className={`${customClass} relative w-full overflow-visible rounded-lg`}
    >
      <Swiper
        ref={sliderRef}
        modules={[Navigation, Pagination, Autoplay]}
        slidesPerView={quantity}
        spaceBetween={
          spaceBeetween !== undefined ? spaceBeetween : isMobile ? 8 : 24
        }
        onSlideChange={(swiper) => {
          setActiveIndex(swiper.activeIndex);
        }}
        autoplay={autoplay}
        loop={loop}
        speed={speed}
        pagination={{
          clickable: true,
          renderBullet: (index, className) =>
            `<span class="${className} custom-bullet"></span>`,
        }}
        breakpoints={{
          0: { slidesPerView: quantityMobile },
          480: { slidesPerView: quantityXs ?? quantityMobile },
          640: {
            slidesPerView: quantitySm
              ? quantitySm
              : !!(quantity - 2)
                ? quantity - 2
                : 1,
          },
          768: {
            slidesPerView: quantityMd
              ? quantityMd
              : !!(quantity - 1)
                ? quantity - 1
                : 1,
          },
          1024: {
            slidesPerView: quantityLg
              ? quantityLg
              : !!(quantity - 1)
                ? quantity - 1
                : 1,
          },
          1280: {
            slidesPerView: quantityXl ? quantityXl : !!quantity ? quantity : 1,
          },
          1440: { slidesPerView: quantity },
        }}
        className={cn(
          `${length > quantity - 2 ? "md:!pb-8 !pb-4 custom-swiper" : "!pb-3 "} ${!isShowPaging ? "hide-paging" : ""} !z-0`,
          swipperClassName
        )}
      >
        {/* sau có design no data thì gắn vào đây */}
        {React.Children.toArray(children).length > 0 ? (
          React.Children.toArray(children).map((item, index) => (
            <SwiperSlide key={index}>{item}</SwiperSlide>
          ))
        ) : (
          <NoDataAvailable />
        )}
      </Swiper>
      {length > quantity && (
        <div>
          <button
            className={cn(
              "cursor-pointer hidden absolute top-[43%] -left-16 max-xl:-left-12 max-lg:-left-10 transform -translate-y-1/2 z-0 xl:size-14 size-9 md:flex items-center justify-center bg-[#E3E4E5] rounded-full",
              {
                "cursor-default opacity-45":
                  activeIndex === 0 && !isInfiniteLoop,
              }
            )}
            onClick={handlePrev}
            aria-label="Previous Slide"
          >
            <ChevronLeft />
          </button>
          <button
            className={cn(
              "cursor-pointer hidden absolute top-[43%] -right-16 max-xl:-right-12 max-lg:-right-10 transform -translate-y-1/2 z-0 xl:size-14 size-9 md:flex items-center justify-center bg-[#E3E4E5] rounded-full",
              {
                "cursor-default opacity-45":
                  activeIndex === length - quantity && !isInfiniteLoop,
              }
            )}
            onClick={handleNext}
            aria-label="Next Slide"
          >
            <ChevronRight />
          </button>
        </div>
      )}
      <style>{`
      
        .custom-swiper .swiper-pagination {
          bottom: 0px !important;
          height: 18px !important;
        }

        .custom-swiper .swiper-slide {
          border-radius: 16px !important;
        }

        .custom-swiper.hide-paging {
          padding-bottom: 0 !important;
        }

        .custom-swiper.hide-paging .swiper-pagination {
          display: none !important;
        }

        .custom-bullet {
          width: 8px;
          height: 8px;
          background: gray;
          margin: 0 5px;
          border-radius: 50%;
          transition: all 0.3s ease;
        }

        .custom-swiper .swiper-pagination-bullet-active {
          width: 24px;
          height: 8px;
          background: #ff8600;
          border-radius: 5px;
        }

        @media (max-width: 640px) {
          .custom-swiper .swiper-pagination {
            height: 18px !important;
          }
          .custom-swiper .swiper-pagination-bullet-active {
            height: 6px;
          }
          .custom-bullet {
            width: 6px;
            height: 6px;
          }
        }
      `}</style>
    </div>
  );
};

export default CarouselData;
