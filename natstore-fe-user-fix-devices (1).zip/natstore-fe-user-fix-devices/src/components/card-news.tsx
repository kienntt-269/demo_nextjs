"use client";
import Image from "next/image";
import React from "react";

const CardNews = () => {
  return (
    <div className="overflow-hidden rounded-3xl form-box-shadow">
      <Image
        src={"/mobile-package/pic-card.png"}
        alt=""
        quality={100}
        unoptimized
        width={316}
        height={316}
        className="h-[316px] w-full object-cover"
      />
      <div className="bg-white p-6 w-full">
        <div className="text-neutral-mid-01 font-bold">
          Monday, December 23, 2024
        </div>
        <div className="mt-3 text-[20px] font-bold">
          25% discount when buying packages on My Natcom app and website
        </div>
        <div className="mt-3 text-[14px] font-normal">
          25% discount when buying packages on My Natcom app and website
        </div>
      </div>
    </div>
  );
};

export default CardNews;
