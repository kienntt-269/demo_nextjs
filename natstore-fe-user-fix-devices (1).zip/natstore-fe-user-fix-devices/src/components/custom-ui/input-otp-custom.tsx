"use client";
import {
  InputOTP,
  InputOTPGroup,
  InputOTPSlot,
} from "@/components/ui/input-otp";
import React from "react";

type OtpInputProps = {
  value: string;
  onChange: (value: string) => void;
  length?: number;
};

const OtpInputCustom = ({ value, onChange, length = 6 }: OtpInputProps) => {
  const handleOtpChange = (val: string) => {
    const numericValue = val.replace(/[^0-9]/g, "");
    onChange(numericValue);
  };

  return (
    <div className="w-full flex justify-center">
      <InputOTP
        autoFocus
        maxLength={length}
        value={value}
        onChange={handleOtpChange}
        type="text"
        inputMode="numeric"
        pattern="[0-9]*"
      >
        {Array.from({ length }).map((_, index) => (
          <InputOTPGroup key={index}>
            <InputOTPSlot
              className="max-sm:size-[42px] lg:size-[52px] bg-[#F2F2F2]"
              index={index}
            />
          </InputOTPGroup>
        ))}
      </InputOTP>
    </div>
  );
};

export default OtpInputCustom;
