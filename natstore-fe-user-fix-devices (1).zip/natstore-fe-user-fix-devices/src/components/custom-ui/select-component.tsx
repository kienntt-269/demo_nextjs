import { Label } from "@/components/ui/label";
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from "@/components/ui/select"; // cập nhật theo thư viện bạn dùng
import clsx from "clsx";

type Option = {
  label: string;
  value: string;
};

type SelectComponentProps = {
  label?: string;
  value?: string;
  onChange: (value: string) => void;
  options: Option[];
  placeholder?: string;
  className?: string;
  required?: boolean;
};

const SelectComponent = ({
  label,
  value,
  onChange,
  options,
  placeholder = "Select...",
  className,
  required,
}: SelectComponentProps) => {
  return (
    <div className={clsx(className)}>
      {label && (
        <div className="flex justify-between mb-2 items-center">
          {label && (
            <Label className="text-neutral-dark-01 text-sm md:text-base">
              {label}
              {required && <span className="text-red-500">*</span>}
            </Label>
          )}
        </div>
      )}

      <Select onValueChange={onChange} value={value}>
        <SelectTrigger className="w-full">
          <div
            className={clsx({
              "text-neutral": !value,
              "truncate block w-full text-left": !!value,
            })}
          >
            <SelectValue placeholder={placeholder} />
          </div>
        </SelectTrigger>

        <SelectContent>
          {options.map((option) => (
            <SelectItem key={option.value} value={option.value}>
              {option.label}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
};

export default SelectComponent;
