import TextWithTooltip from "@/components/text-width-tooltip";
import React from "react";

type IProps = {
  name: string;
  isActive: boolean;
};

const SubCategoriesMobile = ({ isActive, name }: IProps) => {
  return (
    <div
      className={`${isActive ? "text-primary bg-[#FF860029] flex items-center gap-x-2" : "bg-[#E3E4E599] text-neutral-dark-04 transition-all duration-300 ease-in-out hover:scale-[1.025]"} px-5 py-2 cursor-pointer rounded-3xl  font-bold text-[20px] max-xl:text-[16px] max-md:text-[14px] leading-6 whitespace-nowrap`}
    >
      {isActive && <div className="bg-primary size-2 rounded-full"></div>}{" "}
      <TextWithTooltip
        content={name}
        limit={20}
        className="block text-xl max-xl:text-[18px] max-md:text-[14px] max-2xl:text-[20px] font-bold overflow-hidden text-ellipsis whitespace-nowrap"
      />
    </div>
  );
};

export default SubCategoriesMobile;
