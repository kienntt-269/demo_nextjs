"use client";
import ErrorPage from "@/components/error";
import { usePathname } from "next/navigation";
import React, { Component, ReactNode } from "react";

// Định nghĩa state và props của Error Boundary
interface ErrorBoundaryState {
  hasError: boolean;
  contentHeight?: number;
}

interface ErrorBoundaryProps {
  children: ReactNode;
}

class ErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false, contentHeight: undefined };
  }

  static getDerivedStateFromError(): ErrorBoundaryState {
    // Cập nhật state để hiển thị UI lỗi
    return { hasError: true };
  }

  componentDidMount() {
    this.updateContentHeight();
    window.addEventListener("resize", this.updateContentHeight);
  }

  componentWillUnmount() {
    window.removeEventListener("resize", this.updateContentHeight);
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo): void {
    // Log lỗi nếu cần
    console.error("Error caught:", error, errorInfo);
  }

  updateContentHeight = () => {
    const headerHeight = document.querySelector("header")?.offsetHeight || 0;
    const footerHeight = document.querySelector("footer")?.offsetHeight || 0;
    const windowHeight = window.innerHeight;
    const contentHeight = windowHeight - headerHeight - footerHeight;
    this.setState({ contentHeight });
  };

  render() {
    if (this.state.hasError) {
      return (
        <div
          className="flex justify-center items-center"
          style={{ minHeight: this.state.contentHeight || "100vh" }}
        >
          <ErrorPage />
        </div>
      );
    }

    return this.props.children;
  }
}

const ErrorBoundaryWrapper = ({ children }: { children: ReactNode }) => {
  const pathname = usePathname();

  return <ErrorBoundary key={pathname}>{children}</ErrorBoundary>;
};

export default ErrorBoundaryWrapper;
