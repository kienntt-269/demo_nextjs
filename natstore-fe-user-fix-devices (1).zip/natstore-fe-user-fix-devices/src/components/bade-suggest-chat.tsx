import React from "react";

type Props = {
  content: string;
  onClick: (content: string) => void;
};

export const BadeSuggestChat = ({ content, onClick }: Props) => {
  return (
    <div
      onClick={() => onClick(content)}
      className="h-8 whitespace-nowrap border flex items-center justify-center cursor-pointer px-4 rounded-xl text-center text-sm bg-white border-input shadow-badge-suggest-chat text-neutral-dark-04"
    >
      {content}
    </div>
  );
};
