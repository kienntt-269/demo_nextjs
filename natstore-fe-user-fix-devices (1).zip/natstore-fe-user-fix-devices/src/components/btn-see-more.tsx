"use client";
import React from "react";
import Link from "next/link";
import { useTranslations } from "next-intl";

type IProps = {
  href: string;
  classes?: string;
};

const ButtonSeeMore = ({ href, classes }: IProps) => {
  const t = useTranslations();
  return (
    <Link
      href={href || "#"}
      className={`text-primary text-[32px] relative see-more-link group transition-all duration-300 max-2xl:text-[28px] max-xl:text-[24px] max-md:text-[14px] font-bold ${classes}`}
    >
      {t("common.see_all")}
    </Link>
  );
};

export default ButtonSeeMore;
