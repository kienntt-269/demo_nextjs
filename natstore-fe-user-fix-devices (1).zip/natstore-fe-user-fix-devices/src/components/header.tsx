"use client";
import React, { useEffect, useState } from "react";
import { ChevronDownIcon } from "lucide-react";
import Image from "next/image";
import { useIsMobile } from "@/hooks/use-mobile";
import { useDialogAuthStore } from "@/_stores/useDialogAuth.store";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useTranslations } from "next-intl";
import { useRouter } from "next/navigation";
import Link from "next/link";
import MobileMenu from "@/components/mobile-menu";
import listMenuApiRequest from "@/services/list-menu";
import { IDataListMenu } from "@/schemaValidations/list-menu.chema";
import Search from "@/components/search";
import LanguageSelect from "@/components/language-select";
import { Locale } from "@/i18n/config";
import OrderTrackingIcon from "@/components/icons/order-tracking-icon";
// import { urlMapping } from "@/constants/url-mapping";
export default function HeaderComponent({
  isLogin,
  locale,
}: {
  isLogin: boolean;
  locale: Locale;
}) {
  const router = useRouter();
  const isMobile = useIsMobile();
  const t = useTranslations();

  const { setIsOpen } = useDialogAuthStore();

  const [listMenu, setListMenu] = useState<IDataListMenu[]>();
  // const updateMenuUrls = (menuItems: IDataListMenu[]): IDataListMenu[] => {
  //   return menuItems.map((item) => ({
  //     ...item,
  //     url: urlMapping[item.label] || "#",
  //     children: item.children ? updateMenuUrls(item.children) : item.children,
  //   }));
  // };
  const getData = async () => {
    try {
      const res = await listMenuApiRequest.getDataMenu();
      // const valueUpdate = updateMenuUrls(res.payload.data);
      setListMenu(res.payload.data);
    } catch (error) {
      console.log("error", error);
      throw error;
    }
  };
  useEffect(() => {
    getData();
  }, [locale]);

  return (
    <header className="z-50 px-16 max-lg:px-10 max-md:px-4 w-full max-w-[1689px] mx-auto h-auto bg-background-content overflow-visible">
      <div className="flex items-center justify-between">
        <div className="xl:mr-[77px] hidden md:flex">
          <Link href={"/"} className="text-primary text-[28px] font-bold">
            <Image
              unoptimized
              quality={100}
              src={"/natcom.svg"}
              width={isMobile ? 71 : 94}
              height={isMobile ? 15 : 45}
              alt="natcom image"
              className={`md:w-[91px] w-[71px]`}
            />
          </Link>
        </div>
        <div className=" justify-end items-center  h-[72px] overflow-visible hidden md:flex">
          <div className="flex items-center gap-6">
            <div className="relative">
              <Search />
            </div>
            <Link href={"/order-tracking"}>
              <OrderTrackingIcon />
            </Link>
            {/* Todo: Tạm ẩn phase 1
           <button>
            <Image
              unoptimized
              quality={100}
              src={"/svg/shopping-cart.svg"}
              width={24}
              height={24}
              alt="shopping image"
              className="max-md:size-4"
            />
          </button> */}
            <LanguageSelect defaultLocale={locale} />
            {isLogin ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Avatar className="w-12 h-12">
                    <AvatarImage src="https://github.com/shadcn.png" />
                    <AvatarFallback>CN</AvatarFallback>
                  </Avatar>
                </DropdownMenuTrigger>
                <DropdownMenuContent
                  align="end"
                  className="w-[226px] p-4 flex flex-col gap-2.5 rounded-2xl"
                >
                  <DropdownMenuItem
                    className="font-bold text-neutral-dark-02 cursor-pointer "
                    onClick={() => {
                      router.push("/personal");
                    }}
                  >
                    {t("homePage.accountInformation")}
                  </DropdownMenuItem>
                  <DropdownMenuItem
                    className="font-bold text-neutral-dark-02 cursor-pointer "
                    onClick={() => {
                      router.push("/personal?type=change-password");
                    }}
                  >
                    {t("homePage.changePassword")}
                  </DropdownMenuItem>
                  <DropdownMenuItem
                    className="font-bold text-neutral-dark-02 cursor-pointer "
                    onClick={() => setIsOpen({ isOpen: true, mode: "LOGOUT" })}
                  >
                    {t("homePage.logout")}
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <div className="gap-4 flex justify-between items-center">
                <button
                  className=" rounded-full text-base text-neutral-dark-01 font-bold"
                  onClick={() => setIsOpen({ isOpen: true, mode: "REGISTER" })}
                >
                  {t("common.sign_up")}
                </button>
                <button
                  className=" rounded-full bg-[#FF8600] text-white w-[97px] h-8 font-bold text-base"
                  onClick={() => setIsOpen({ isOpen: true, mode: "LOGIN" })}
                >
                  {t("common.login")}
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className=" flex items-center overflow-visible h-auto justify-between ">
        <div className="md:hidden w-full">
          <MobileMenu isLogin={isLogin} listMenu={listMenu} locale={locale} />
        </div>
        <div className="hidden md:flex gap-4 w-full justify-center flex-1 relative overflow-visible z-[49]">
          {listMenu?.map((menuItem: IDataListMenu) => (
            <div
              className="relative group flex items-center pl-3 py-6 overflow-visible hover:text-primary "
              key={menuItem.label}
            >
              <Link href={menuItem?.url || "#"}>
                <div className="flex justify-center items-center ">
                  {menuItem.label === "Promotion" && (
                    <Image
                      src="/svg/gift-header.svg"
                      alt="img content"
                      width={20}
                      height={20}
                      className="mr-1"
                    />
                  )}
                  <div className="font-bold lg:text-base text-sm ">
                    {menuItem.label}
                  </div>
                  {!!menuItem.children.length && (
                    <ChevronDownIcon
                      className="ml-2 size-4"
                      aria-hidden="true"
                    />
                  )}
                </div>
              </Link>

              {!!menuItem.children.length && (
                <div className="absolute left-[-5%] overflow-visible z-[999999] top-[90%] hidden  group-hover:flex flex-col bg-white text-black shadow-lg p-2 rounded-md w-max">
                  {menuItem?.children?.map((item) => (
                    <Link
                      href={item?.url || "#"}
                      key={item.label}
                      className=" py-3 overflow-visible pl-4 pr-10 hover:bg-gray-100 hover:text-primary rounded-md"
                    >
                      {item.label}
                    </Link>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </header>
  );
}
