import envConfig from "@/config";

export const getImageUrl = (path: string) => {
  if (!path) return "";
  if (path && path.startsWith("https")) return path;
  return path.startsWith("/")
    ? `${envConfig.NEXT_PUBLIC_CMS_URL}${path}`
    : `${envConfig.NEXT_PUBLIC_CMS_URL}/${path}`;
};
