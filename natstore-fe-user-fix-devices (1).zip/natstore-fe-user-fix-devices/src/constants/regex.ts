export const REGEX_VALIDATE_PHONE_NUMBER = /^\+?[0-9]+$/;
export const REGEX_VALIDATE_PHONE_NUMBER_ON_NET =
  /^(32|33|35|40|41|42|43|55)\d{6}$/;
export const REGEX_INPUT_OTP = /[^0-9]/g;
export const REGEX_INPUT_ID_CARD = /[^a-zA-Z0-9]/g;
export const REGEX_INPUT_ID_CARD_NUMBER = /[^0-9]/g;
export const REGEX_INPUT_PASSWORD =
  /[^a-zA-Z0-9!@#$%^&*()_+=\-[\]{}|;:'",.<>?/~]/g;

export const REGEX_VALIDATE_EMAIL =
  /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
export const REGEX_VALIDATE_PASSWORD =
  /^(?=.*[a-zA-Z])(?=.*\d)[a-zA-Z0-9!@#$%^&*()_+=\-[\]{}|;:'",.<>?/~]{6,20}$/;

export const REGEX_VALIDATE_ID_CARD = /^[a-zA-Z0-9]{10,20}$/;
export const REGEX_VALIDATE_NAME = /^[a-zA-Z\s]+$/;
export const REGEX_VALIDATE_ADDRESS = /^[a-z0-9]{1,100}$/;
export const REGEX_VALIDATE_LICENSE_DRIVER = /^[a-zA-Z0-9]+$/;
