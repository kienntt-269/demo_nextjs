export const convertSecondsToMonths = (seconds: number) => {
  const secondsPerMonth = 30 * 24 * 60 * 60;
  return Math.round((seconds / secondsPerMonth) * 10) / 10;
};
