export const FORMAT_DATE = "DD/MM/YYYY";
export const FORMAT_TIME_CHAT_SERVER = "YYYY-MM-DD HH:mm:ss";
export const FORMAT_DATE_YYYYMMDD = "YYYY-MM-DD";
export const FORMAT_DATE_TIME_ORDER = "MM/DD/YYYY HH:mm";
export const FORMAT_TIME_PAYMENT = "HH:mm:ss dddd MM/DD/YYYY";
export const FORMAT_TIME_DATE_FULL = "hh:mm:ss A, DD/MM/YYYY";
export const FORMAT_HHMM = "HH:mm";
export const PAYMENT_METHOD = {
  NATCASH: "natcash",
  NATCOM: "natcom",
};

export const PAYMENT_INTERNET_PACKAGE_SLUG = "payment-the-package";
export const EXCHANGE_RATE_HTG_USD = 0.00765;

export const LIST_PHONE_HAITI_PREFIX = [32, 33, 35, 40, 41, 42, 43, 55];
export const SEARCH_TYPE_PAYMENT_PACKAGE = {
  NUMBER_ACCOUNT: "numberAccount",
  ID_CARD_NUMBER: "idCardNumber",
};
