import CarouselData from "@/components/common/carousel-data/carousel-data";
import { getImageUrl } from "@/constants/imageUrl";
import bannerApiRequest from "@/services/banner";
import Image from "next/image";
import Link from "next/link";
import React from "react";

const getData = async () => {
  try {
    const res = await bannerApiRequest.getDataBanner();
    return res.payload?.data || [];
  } catch (error) {
    console.error("Error fetching banner data:", error);
    return [];
  }
};

const BannerHomePage = async () => {
  const data = await getData();
  
  return (
    <div>
      <CarouselData
        quantity={1}
        quantityMobile={1}
        length={data.length}
        loop
        speed={1200}
        autoplay={{ delay: 10000, disableOnInteraction: false }}
        isInfiniteLoop
      >
        {data.map((item) => (
          <Link href={item?.bannerLink || "#"} key={item.bannerName}>
            <Image
              key={item.imagePath}
              src={getImageUrl(item.imagePath)}
              alt="illustration roaming"
              width={1524}
              height={313}
              className="w-full h-[136px] md:h-[313px] md:rounded-3xl rounded-2xl hidden md:block"
              unoptimized
            />
            <Image
              key={item.imageWapPath}
              src={getImageUrl(item.imageWapPath)}
              alt="illustration roaming"
              width={1524}
              height={313}
              className="w-full h-[136px] md:h-[313px] md:rounded-3xl rounded-2xl block md:hidden"
              unoptimized
            />
          </Link>
        ))}
      </CarouselData>
    </div>
  );
};

export default BannerHomePage;
