import RegisterItem from "@/app/international/roaming/register/_components/register-item";
import VasItem from "@/app/mobile-package/vas/_components/vas-item";
import CardCommon from "@/components/card-common";
import { ITypePackage } from "@/schemaValidations/search-home.schema";

export const getCardComponent = (
  TypeCategory: string | null,
  val: ITypePackage
) => {
  switch (TypeCategory) {
    case "1":
      return (
        <CardCommon
          key={val.id}
          type="medium"
          target="data"
          data={val}
          redirectBuy={`/mobile-package/data/${val.slug}/payment`}
          redirectLink={`/mobile-package/data/${val.slug}`}
        />
      );
    case "4":
      return <VasItem data={val} />;
    case "7":
      return <RegisterItem data={val} />;
    default:
      return (
        <CardCommon
          key={val.id}
          type="medium"
          target="data"
          data={val}
          redirectBuy={`/mobile-package/data/${val.slug}/payment`}
          redirectLink={`/mobile-package/data/${val.slug}`}
        />
      );
  }
};
