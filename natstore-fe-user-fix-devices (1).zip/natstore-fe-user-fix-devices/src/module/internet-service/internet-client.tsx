"use client";
import ButtonSeeMore from "@/components/btn-see-more";
import CardInfo from "@/components/card-info";
import CarouselData from "@/components/common/carousel-data/carousel-data";
import NoDataAvailable from "@/components/common/no-data-available/no-data-available";
import TabCommon from "@/components/tabs-common";
import TitleStyle from "@/components/title-common";
import { PAYMENT_INTERNET_PACKAGE_SLUG } from "@/constants/common";
import PaymentPackageInternet from "@/module/payment-package-internet";
import {
  IDataInternet,
  IDataInternetCategories,
} from "@/schemaValidations/internet.shema";
import { useTranslations } from "next-intl";
import { useRouter, useSearchParams } from "next/navigation";

const InternetClient = ({
  dataInternet,
  serviceCategoriesList,
  isList,
}: {
  dataInternet: IDataInternet[];
  serviceCategoriesList: IDataInternetCategories[];
  isList?: boolean;
}) => {
  const router = useRouter();
  const searchParams = useSearchParams();
  const type = searchParams.get("internet-view") || "buy-internet-package";
  const t = useTranslations();
  const categoryChildren = serviceCategoriesList[0]?.children;
  const findIndexByType = (type: string) => {
    const index = categoryChildren?.findIndex(
      (item: IDataInternetCategories) => item.slug === type
    );
    return index !== undefined ? index : 0;
  };

  const handleChangeTab = (value: number) => {
    const itemSelected = categoryChildren[value];
    const updatedParams = new URLSearchParams(searchParams);
    updatedParams.set("internet-view", itemSelected.slug);
    router.push(`?${updatedParams.toString()}`, { scroll: false });
  };

  const renderContent = () => {
    switch (type) {
      case "buy-internet-package":
        return (
          <div className="mt-6 max-md:mt-3">
            <CarouselData
              quantity={4}
              length={dataInternet.length}
              quantityMobile={1.5}
              quantityLg={2.5}
              quantityMd={2}
              quantitySm={2}
              quantityXs={2}
              quantityXl={3}
            >
              {dataInternet.map((item: IDataInternet) => (
                <CardInfo
                  key={item.id}
                  type="medium"
                  data={{
                    id: item.id,
                    name: item.name,
                    price: item.price,
                    speed: item.speed,
                    promotion: item.promotion,
                    note: item.note,
                    slug: item.slug,
                  }}
                />
              ))}
            </CarouselData>
          </div>
        );
      case PAYMENT_INTERNET_PACKAGE_SLUG:
        return <PaymentPackageInternet />;
      default:
        return <NoDataAvailable />;
    }
  };

  return (
    <div>
      {!isList && (
        <div className="md:mt-7 mt-8 flex justify-between items-center">
          <div className=" flex xl:gap-24 md:gap-10 items-center">
            <TitleStyle>{t("internet.internet_services")}</TitleStyle>
          </div>
          <ButtonSeeMore href={"/internet"} />
        </div>
      )}
      <div className="flex justify-start w-full mt-4">
        <TabCommon
          isApplyDefaultTab
          defaultTab={findIndexByType(type)}
          tabs={categoryChildren?.map((item: IDataInternetCategories) => ({
            label: item.name,
          }))}
          onChangeTab={handleChangeTab}
        />
      </div>
      {renderContent()}
    </div>
  );
};

export default InternetClient;
