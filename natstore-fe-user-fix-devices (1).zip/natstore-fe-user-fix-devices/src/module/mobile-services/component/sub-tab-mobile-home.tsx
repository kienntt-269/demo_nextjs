"use client";
import TextWithTooltip from "@/components/text-width-tooltip";
import { ChevronLeft, ChevronRight } from "lucide-react";
import React, { useEffect, useRef, useState } from "react";
type IsubTabs = { label: string; id: string; type: string };
type IProp = {
  dataServiceDetail: IsubTabs[];
  onChangeTab?: (index: number, type: number) => void;
  setTabActiveChildren?: (index: number) => void;
  tabActiveChildren?: number;
};
const SubTabMobileHome = ({
  dataServiceDetail,
  onChangeTab = () => {},
  setTabActiveChildren = () => {},
  tabActiveChildren,
}: IProp) => {
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const [showPrev, setShowPrev] = useState<boolean>(false);
  const [showNext, setShowNext] = useState<boolean>(false);

  const handleScroll = () => {
    if (!scrollContainerRef.current) return;
    const { scrollLeft, scrollWidth, clientWidth } = scrollContainerRef.current;
    setShowPrev(scrollLeft > 0);
    setShowNext(scrollLeft + clientWidth < scrollWidth);
  };

  const scroll = (direction: "left" | "right") => {
    if (!scrollContainerRef.current) return;
    const { clientWidth } = scrollContainerRef.current;
    const scrollAmount = clientWidth * 0.8;

    if (direction === "left") {
      scrollContainerRef.current.scrollBy({
        left: -scrollAmount,
        behavior: "smooth",
      });
    } else {
      scrollContainerRef.current.scrollBy({
        left: scrollAmount,
        behavior: "smooth",
      });
    }
  };

  useEffect(() => {
    const container = scrollContainerRef.current;
    if (container) {
      container.addEventListener("scroll", handleScroll);
      handleScroll();
    }
    return () => container?.removeEventListener("scroll", handleScroll);
  }, []);
  return (
    <div className="w-full relative">
      {showPrev && (
        <button
          className="hidden absolute top-[43%] -left-16 max-xl:-left-12 max-lg:-left-10 transform -translate-y-1/2 z-0 xl:size-14 size-9 md:flex items-center justify-center bg-[#E3E4E5] rounded-full"
          onClick={() => scroll("left")}
          aria-label="Previous Slide"
        >
          <ChevronLeft />
        </button>
      )}
      {showNext && (
        <button
          className="hidden absolute top-[43%] -right-16 max-xl:-right-12 max-lg:-right-10 transform -translate-y-1/2 z-0 xl:size-14 size-9 md:flex items-center justify-center bg-[#E3E4E5] rounded-full"
          onClick={() => scroll("right")}
          aria-label="Next Slide"
        >
          <ChevronRight />
        </button>
      )}
      <div
        ref={scrollContainerRef}
        className="flex items-center gap-x-4 mt-6 max-md:gap-x-2 max-md:mt-2 w-full overflow-x-scroll no-scrollbar"
      >
        {dataServiceDetail?.map((val: IsubTabs, i: number) => {
          return (
            <div
              key={val.id}
              onClick={() => {
                setTabActiveChildren(i);
                onChangeTab(Number(val.id), Number(val.type));
              }}
              className={` ${!val.label ? "hidden" : ""} ${tabActiveChildren === i ? "text-primary bg-[#FF860029] flex items-center gap-x-2" : "text-neutral-dark-04 bg-[#E3E4E599] transition-all duration-300 ease-in-out hover:scale-[1.02]"} w-max px-5 py-2 cursor-pointer rounded-3xl  font-bold md:text-xl text-sm leading-6`}
            >
              {tabActiveChildren === i && (
                <div className="h-2 w-2 bg-primary rounded-full"></div>
              )}
              <div className="w-max">
                <TextWithTooltip limit={20} content={val.label} />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default SubTabMobileHome;
