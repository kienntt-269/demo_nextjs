import { IDataPlan } from "@/schemaValidations/mobile-service.schema";
import { useTranslations } from "next-intl";
import React from "react";

type ITag = {
  data?: IDataPlan;
};

const TagServiceMobile: React.FC<ITag> = ({ data }) => {
  const t = useTranslations();
  return (
    <div className="h-7 flex gap-x-2 overflow-x-scroll no-scrollbar">
      {data?.hot === "1" && (
        <div className="text-center flex flex-shrink-0 items-center px-3 w-fit py-1 max-md:py-[2px] text-[12px] max-lg:text-[10px] max-2xl:text-[8px] max-md:text-[10px] font-bold text-error bg-[#FF3B301A] rounded-3xl max-md:rounded-3xl max-md:px-2">
          {t("common.hot_plan")}
        </div>
      )}
      {data?.recommend === "1" && (
        <div className="text-center flex flex-shrink-0 items-center px-3 w-fit py-1 max-md:py-[2px] text-[12px] max-lg:text-[10px] max-2xl:text-[8px] max-md:text-[10px] font-bold text-[#5FBD98] bg-[#10B1711A] rounded-3xl max-md:rounded-3xl max-md:px-2">
          {t("common.recomended")}
        </div>
      )}
      {data?.bestSeller === "1" && (
        <div className="text-center flex flex-shrink-0 items-center px-3 w-fit py-1 max-md:py-[2px] text-[12px] max-lg:text-[10px] max-2xl:text-[8px] max-md:text-[10px] font-bold text-[#3DBDF4] bg-[#3DBDF41A] rounded-3xl max-md:rounded-3xl max-md:px-2">
          {t("common.best_sellers")}
        </div>
      )}
    </div>
  );
};

export default TagServiceMobile;
