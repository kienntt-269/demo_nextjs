"use client";
import ComponentWithTooltip from "@/components/component-with-tooltip";
import TextCSRStyle from "@/components/text-csr-style";
import { Ratings } from "@/components/ui/rating";
import { IDataInternetDetail } from "@/schemaValidations/internet.shema";
import { IDataPlan } from "@/schemaValidations/mobile-service.schema";
import { useTranslations } from "next-intl";
import Image from "next/image";
import React from "react";

interface IProps {
  data: IDataPlan | IDataInternetDetail;
  isInternet?: boolean;
}

const PlanSummary = ({ data, isInternet }: IProps) => {
  const t = useTranslations();
  return (
    <div className="grid grid-cols-4 gap-x-6 max-lg:grid-cols-1 max-lg:gap-2">
      <div className="px-6 py-[16px] max-xl:p-4 flex items-center gap-x-4 max-md:gap-x-2 bg-white border-[0.46px] border-solid border-[#DEDEDE] rounded-2xl">
        <div className="size-12 max-xl:size-10 max-lg:size-8 flex-shrink-0">
          {isInternet ? (
            <Image
              src={"/svg/internetDetail.svg"}
              width={48}
              height={48}
              unoptimized
              quality={100}
              alt="phone"
              className="object-cover w-full h-full"
            />
          ) : (
            <Image
              src={"/mobile-package/phone_mobile.png"}
              width={48}
              height={48}
              unoptimized
              quality={100}
              alt="phone"
              className="object-contain w-full h-full"
            />
          )}
        </div>
        <div className="min-w-0 flex-1 line-clamp-2">
          <TextCSRStyle classStyle="text-[14px] max-md:text-[12px] font-normal text-[#333333]">
            payment.plan_name
          </TextCSRStyle>
          <ComponentWithTooltip content={data?.name ?? ""}>
            <div className="text-[24px] max-2xl:text-[20px] font-bold max-md:mt-1 text-neutral-dark-03 line-clamp-1 break-all">
              {data?.name}
            </div>
          </ComponentWithTooltip>
        </div>
      </div>
      <div className="px-6 py-[18px] max-xl:p-4 flex items-center gap-x-4 max-md:gap-x-2 bg-white border-[0.46px] border-solid border-[#DEDEDE] rounded-2xl">
        <div className="size-12 max-xl:size-10 max-lg:size-8 flex-shrink-0">
          <Image
            src={"/mobile-package/coin-cover.svg"}
            width={48}
            height={48}
            unoptimized
            quality={100}
            alt="phone"
            className="object-contain w-full h-full"
          />
        </div>
        <div className="min-w-0 flex-1">
          <TextCSRStyle classStyle="text-[14px] max-md:text-[12px] font-normal text-[#333333]">
            common.price
          </TextCSRStyle>

          <div className="text-[24px] flex items-center max-2xl:text-[20px] font-bold max-md:mt-1 text-neutral-dark-03 ">
            <ComponentWithTooltip
              content={
                <>
                  {Number(data?.price).toLocaleString("en-US")}{" "}
                  {isInternet ? "$" : t("mobile_package.htg")}
                </>
              }
            >
              <div className="overflow-hidden text-ellipsis whitespace-nowrap">
                {Number(data?.price).toLocaleString("en-US")}
              </div>
            </ComponentWithTooltip>
            <span className="ml-1 ">
              {isInternet ? "$" : t("mobile_package.htg")}
            </span>
          </div>
          <div className="text-[24px] flex items-center max-xl:text-[18px] max-2xl:text-[20px] font-bold max-md:mt-1 text-neutral-dark-03 "></div>
        </div>
      </div>
      <div className="px-6 py-[18px] max-xl:p-4 flex items-center gap-x-4 max-md:gap-x-2 bg-white border-[0.46px] border-solid border-[#DEDEDE] rounded-2xl">
        <div className="size-12 max-xl:size-10 max-lg:size-8 flex-shrink-0">
          {isInternet ? (
            <Image
              src={"/svg/speed.svg"}
              width={48}
              height={48}
              unoptimized
              quality={100}
              alt="phone"
              className="object-contain w-full h-full"
            />
          ) : (
            <Image
              src={"/mobile-package/calendar.svg"}
              width={48}
              height={48}
              unoptimized
              quality={100}
              alt="phone"
              className="object-contain w-full h-full"
            />
          )}
        </div>
        {isInternet ? (
          <div className="min-w-0 flex-1">
            <TextCSRStyle classStyle="text-[14px] max-md:text-[12px] font-normal text-[#333333]">
              internet.speed
            </TextCSRStyle>

            <div className="text-[24px] flex items-center max-2xl:text-[20px] font-bold max-md:mt-1 text-neutral-dark-03 ">
              <ComponentWithTooltip
                content={`${data?.speed} ${t("internet.mbps")}`}
              >
                <div className="overflow-hidden text-ellipsis whitespace-nowrap">
                  {data?.speed}
                </div>
              </ComponentWithTooltip>

              <span className="ml-1">{t("internet.mbps")}</span>
            </div>
          </div>
        ) : (
          <div className="min-w-0 flex-1">
            <TextCSRStyle classStyle="text-[14px] max-md:text-[12px] font-normal text-[#333333]">
              common.period
            </TextCSRStyle>
            <div className="text-[24px] max-2xl:text-[20px] font-bold max-md:mt-1 text-neutral-dark-03 overflow-hidden text-ellipsis whitespace-nowrap">
              {data?.useTimeUnit === "day" ? `${data?.useTimeValue} ` : null}
              {data?.useTimeUnit === "midnight"
                ? t("common.midnight")
                : data?.useTimeUnit
                  ? t(`common.${data?.useTimeUnit}`)
                  : "-"}
            </div>
          </div>
        )}
      </div>
      <div className="px-6 py-[18px] max-xl:p-4 flex items-center gap-x-4 max-md:gap-x-2 bg-white border-[0.46px] border-solid border-[#DEDEDE] rounded-2xl">
        <div className="size-12 max-xl:size-10 max-lg:size-8 flex-shrink-0">
          <Image
            src={"/mobile-package/like-up.svg"}
            width={48}
            height={48}
            unoptimized
            quality={100}
            alt="phone"
            className="object-contain w-full h-full"
          />
        </div>
        <div className="min-w-0 flex-1">
          <div className="flex gap-x-1 items-center">
            <TextCSRStyle classStyle="text-[14px] max-md:text-[12px] font-normal text-[#333333]">
              mobile_package.rating
            </TextCSRStyle>
            <span className="text-neutral-dark-04 text-sm md:hidden">
              ({data?.ratingCount ?? 0})
            </span>
          </div>
          <div className="flex items-center mt-2 max-md:mt-1 gap-2">
            <div className="text-[24px] max-2xl:text-[20px] font-bold max-md:mt-0 text-neutral-dark-03">
              <Ratings
                rating={data?.rating ?? 0}
                size={20}
                className="flex max-lg:hidden"
                variant="orange"
              />
              <Ratings
                rating={data?.rating ?? 0}
                variant="orange"
                size={12}
                className="max-lg:flex hidden"
              />
            </div>
            <span className="text-neutral-dark-04 text-base leading-[21px] max-xl:hidden max-lg:text-sm max-lg:block max-md:hidden">
              ({data?.ratingCount ?? 0})
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PlanSummary;
