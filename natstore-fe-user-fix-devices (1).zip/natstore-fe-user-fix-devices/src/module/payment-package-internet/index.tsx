"use client";
import React from "react";
import SearchResult from "@/module/payment-package-internet/components/search-result";
import SearchForm from "@/module/payment-package-internet/components/search-form";
import { paymentInternetFormValue } from "@/types/common";
import ContractInfomation from "@/module/payment-package-internet/components/contract-infomation";
import internetApiRequest from "@/services/internet";
import { IDataDebtDetail } from "@/schemaValidations/internet.shema";
import { toastError } from "@/hooks/use-toast";
import { useTranslations } from "next-intl";
import { useSearchParams } from "next/navigation";
import { useRouter } from "next/navigation";
import { useInternetDebtStore } from "@/_stores/useInternetDebt.store";
import { storage } from "@/lib/storage";
import { SEARCH_TYPE_PAYMENT_PACKAGE } from "@/constants/common";

const PaymentPackageInternet = () => {
  const t = useTranslations();
  const { setInternetDebt, internetDebt } = useInternetDebtStore();
  const searchParams = useSearchParams();
  const contractNumber = searchParams.get("contractNumber");
  const router = useRouter();

  const handleContinue = (data?: IDataDebtDetail) => {
    const updatedParams = new URLSearchParams(searchParams);
    updatedParams.set("contractNumber", data?.contractNumber || "");
    router.push(`?${updatedParams.toString()}`, { scroll: false });
  };

  const handleSearch = (values: paymentInternetFormValue) => {
    internetApiRequest
      .getDebtInfo({
        numberAccount:
          values.searchType === SEARCH_TYPE_PAYMENT_PACKAGE.NUMBER_ACCOUNT
            ? values.valueSearch
            : undefined,
        idCardNumber:
          values.searchType === SEARCH_TYPE_PAYMENT_PACKAGE.ID_CARD_NUMBER
            ? values.valueSearch
            : undefined,
      })
      .then((res) => {
        if (res?.payload.code + "" === "03") {
          toastError(t("common.message.MSG0049"));
        } else {
          const data = res?.payload.data ?? [];
          setInternetDebt({
            data,
            searchType: values.searchType,
            searchKey: values.valueSearch,
          });
          storage.setDataPaymentPackage(data);
        }
      })
      .catch((err) => {
        setInternetDebt({ data: [] });
        storage.setDataPaymentPackage([]);
        console.error(err);
      });
  };

  return (
    <div className="flex flex-col gap-10 mt-10">
      {contractNumber ? (
        <ContractInfomation />
      ) : (
        <>
          <SearchForm onSearch={handleSearch} />
          {internetDebt !== undefined && (
            <SearchResult data={internetDebt} onContinue={handleContinue} />
          )}
        </>
      )}
    </div>
  );
};

export default PaymentPackageInternet;
