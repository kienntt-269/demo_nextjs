"use client";
import { RadioComponent } from "@/components/radio-compoent";
import { formatMoney } from "@/lib/utils";
import { IDataDebtDetail } from "@/schemaValidations/internet.shema";
import clsx from "clsx";
import { useTranslations } from "next-intl";
import React from "react";

type Props = {
  data: IDataDebtDetail;
  isSelected?: boolean;
  onSelected: (id: IDataDebtDetail) => void;
};

const SearchResultItem = ({ data, isSelected, onSelected }: Props) => {
  const t = useTranslations();
  return (
    <div
      className={clsx(
        "p-6 flex flex-col gap-4 rounded-2xl border-2 ",
        isSelected
          ? "bg-primary/16 border-primary"
          : "bg-[#F5F6F7] border-[#DEDEDE]"
      )}
    >
      <div className="flex justify-between">
        <div className="flex flex-col gap-2">
          <span className="text-neutral-dark-02 text-xs lg:text-sm">
            {t("payment_package_internet.contact_id")}
          </span>
          <span className="text-neutral-dark-02 font-bold text-sm lg:text-base">
            {data?.contractNumber}
          </span>
        </div>
        <RadioComponent
          checked={!!isSelected}
          onChange={() => onSelected(data)}
        />
      </div>
      <div className="flex flex-col gap-2">
        <span className="text-neutral-dark-02 text-xs lg:text-sm">
          {t("payment_package_internet.account")}:
        </span>
        <span className="text-neutral-dark-02 font-bold text-sm lg:text-base">
          {data?.account}
        </span>
      </div>
      <div className="flex flex-col gap-2">
        <span className="text-neutral-dark-02 text-xs lg:text-sm">
          {t("payment_package_internet.total_debt")}:
        </span>
        <span className="text-neutral-dark-02 font-bold text-sm lg:text-base">
          {formatMoney(data?.totalDebit)} HTG
        </span>
      </div>
      <div className="flex flex-col gap-2">
        <span className="text-neutral-dark-02 text-xs lg:text-sm">
          {" "}
          {t("payment_package_internet.status")}:
        </span>
        <div className="py-1 px-4 text-[#34C759] text-xs lg:text-sm rounded-[34px] bg-[#34C75929] w-fit">
          {data?.status}
        </div>
      </div>
    </div>
  );
};
export default SearchResultItem;
