import { useTranslations } from "next-intl";
import Image from "next/image";
import React from "react";

const EmptySearch = ({ searchKey }: { searchKey: string }) => {
  const t = useTranslations();
  return (
    <div className="w-full mb-8">
      <div className="text-[32px] text-center font-bold mb-6">
        {t("search.search_result")}
      </div>
      <div className="bg-white h-auto max-w-[1032px] w-full mx-auto rounded-3xl py-8">
        <Image
          src="/unavailable.svg"
          alt="illustration roaming"
          width={480}
          height={216}
          quality={100}
          className="md:h-[216px] w-[480px] h-[216px] mx-auto"
        ></Image>
        <div
          className="text-center leading-6 text-xl  mt-10 px-4"
          style={{ wordBreak: "break-word" }}
        >
          {`${t("search.keyword")} '${searchKey}'`}
        </div>
        <div className="text-center leading-6 text-xl">
          {t("search.another_keyword")}
        </div>
      </div>
    </div>
  );
};

export default EmptySearch;
