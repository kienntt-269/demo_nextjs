"use client";
import Modal from "@/components/common/modal/Modal";
import { Button } from "@/components/ui/button";
import { useTranslations } from "next-intl";
import { useState } from "react";
import { Rating } from "react-simple-star-rating";

export function DialogRatingCOnversation({
  onSubmit,
  onClose,
  isOpen,
}: {
  onSubmit: (rate: number) => void;
  onClose: (open: boolean) => void;
  isOpen: boolean;
}) {
  const t = useTranslations();
  const [rating, setRating] = useState(0);
  const [error, setError] = useState(false);

  const handleRating = (rate: number) => {
    setError(false);
    setRating(rate);
  };

  const handleSubmit = async () => {
    if (!rating || error) {
      setError(true);
      return;
    }
    handleClose(false);
    await onSubmit(rating);
  };

  const handleClose = (isOpen: boolean) => {
    onClose?.(isOpen);
    setRating(0);
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={handleClose}
      title={"Rating this conversation"}
      contentChildWrapper="px-0 lg:px-4"
    >
      <div className=" mt-6 flex flex-col gap-6 justify-center items-center">
        <div>
          <div className="flex gap-4 items-center">
            <div>
              <Rating
                size={32}
                SVGclassName="inline primary"
                fillColor="#FF8600"
                onClick={handleRating}
              />
            </div>
            <span className="text-neutral-dark-04">{`(${rating}/5)`}</span>
          </div>
          {error && (
            <div
              role="alert"
              className="mt-1 font-normal lg:mt-2 text-xs lg:text-sm text-error"
            >
              {t("chat_online.message.select_rate")}
            </div>
          )}
        </div>
        <Button onClick={handleSubmit} className="w-full max-w-[212px]">
          {t("common.submit")}
        </Button>
      </div>
    </Modal>
  );
}
