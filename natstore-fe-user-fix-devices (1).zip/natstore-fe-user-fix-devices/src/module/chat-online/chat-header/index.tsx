import { useChatOnline } from "@/_stores/useChatOnline";
import CloseIcon from "@/components/icons/close-icon";
import { isCustomerSupportOnline } from "@/lib/utils";
import clsx from "clsx";
import { useTranslations } from "next-intl";
import Image from "next/image";
import React from "react";
type Props = {
  isProcessing?: boolean;
};

const ChatHeader = ({ isProcessing = false }: Props) => {
  const t = useTranslations();
  const { setStateChatOnline } = useChatOnline();
  const isSupportOnline = isCustomerSupportOnline();
  return (
    <div className="w-full flex justify-between items-center gap-4 bg-gradient-chat-header h-[64px] md:rounded-ss-3xl md:rounded-se-3xl px-4">
      <div className="flex items-center gap-4">
        {isProcessing ? (
          <div className="flex items-center gap-3">
            <div>
              <Image
                src="/images/avatar_supporting.svg"
                alt="Avatar"
                width={40}
                height={40}
                className="rounded-full"
              />
            </div>
            <div>
              <div className="text-white text-xl font-bold">
                {t("chat_online.natcom_live_chat")}
              </div>
              <div className="flex gap-1.5 items-center">
                <div
                  className={clsx(
                    "w-2 h-2 rounded-full",
                    isSupportOnline ? "bg-online" : "bg-neutral",
                  )}
                ></div>
                <div className="text-white text-sm">
                  {isSupportOnline
                    ? t("chat_online.online")
                    : t("chat_online.offline")}
                </div>
              </div>
            </div>
          </div>
        ) : (
          <>
            <div
              className={clsx(
                "w-4 h-4 rounded-full",
                isSupportOnline ? "bg-online" : "bg-neutral",
              )}
            ></div>
            <div className="text-white text-2xl font-bold">
              {t("chat_online.natcom_live_chat")}
            </div>
          </>
        )}
      </div>
      <div
        className="cursor-pointer"
        onClick={() => setStateChatOnline({ isOpen: false })}
      >
        <CloseIcon color="#fff" />
      </div>
    </div>
  );
};

export default ChatHeader;
