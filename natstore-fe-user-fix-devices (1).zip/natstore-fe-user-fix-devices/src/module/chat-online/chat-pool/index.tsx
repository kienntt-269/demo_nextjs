"use client";
import { FORMAT_TIME_CHAT_SERVER } from "@/constants/common";
import dayjsLib from "@/lib/dayjs";
import { convertUrlImageChat } from "@/lib/utils";
import MessageItem from "@/module/chat-online/message-item";
import { MessageDataType } from "@/types/common";
import React from "react";
import InfiniteScroll from "react-infinite-scroll-component";

type Props = {
  messages: MessageDataType[];
  hasMore: boolean;
  onLoadMore: () => void;
};
const TIME_MESSAGE_CONSECUTIVE = 60; //seconds
export const ChatPoolContainer = ({ messages, hasMore, onLoadMore }: Props) => {
  const handleRenderMessage = () => {
    const listData: Array<React.ReactNode> = [];
    let prevItem: MessageDataType | null = null;
    let nextItem: MessageDataType | null = null;
    let isHeaderMessage = false;
    let isFinalMessage = false;
    messages?.forEach((message: MessageDataType, index: number) => {
      const isOwner = !message.isSupporter;
      prevItem = messages?.[index - 1];
      nextItem = messages?.[index + 1];
      // check message gui lien tiep
      if (!prevItem) {
        isHeaderMessage = true;
      }

      if (!nextItem) {
        isFinalMessage = true;
      }
      if (prevItem) {
        if (
          (prevItem?.senderId ?? prevItem?.senderId) ===
            (message?.senderId ?? message?.senderId) &&
          dayjsLib(prevItem.createdTime).diff(
            dayjsLib(message.createdTime),
            "seconds",
          ) < TIME_MESSAGE_CONSECUTIVE &&
          dayjsLib(prevItem.createdTime).format(FORMAT_TIME_CHAT_SERVER) ===
            dayjsLib(message.createdTime).format(FORMAT_TIME_CHAT_SERVER)
        ) {
          isHeaderMessage = false;
        } else {
          isHeaderMessage = true;
        }
      }

      if (nextItem) {
        if (
          (nextItem?.senderId ?? nextItem?.senderId) ===
            (message?.senderId ?? message?.senderId) &&
          dayjsLib(message.createdTime).diff(
            dayjsLib(nextItem.createdTime),
            "seconds",
          ) < TIME_MESSAGE_CONSECUTIVE &&
          dayjsLib(nextItem.createdTime).format(FORMAT_TIME_CHAT_SERVER) ===
            dayjsLib(message.createdTime).format(FORMAT_TIME_CHAT_SERVER)
        ) {
          isFinalMessage = false;
        } else {
          isFinalMessage = true;
        }
      }

      const itemMessage = (
        <MessageItem
          isHeaderMessage={isHeaderMessage}
          isFinalMessage={isFinalMessage}
          key={message.id}
          text={message.message || ""}
          imagePath={message.imagePath
            ?.split(",")
            .map((item) => convertUrlImageChat(item))}
          isOwnerMessage={isOwner}
          createdTime={message.createdTime ?? ""}
        />
      );
      listData.push(itemMessage);
    });
    return listData;
  };

  return (
    <div
      className="flex flex-col-reverse flex-1 p-4 overflow-auto"
      id="scrollableDivChat"
    >
      <div id="sroll-bottom-chat-pool" />
      <InfiniteScroll
        style={{ display: "flex", flexDirection: "column-reverse" }}
        dataLength={messages?.length}
        inverse={true}
        hasMore={hasMore}
        next={onLoadMore}
        loader={<p></p>}
        scrollableTarget="scrollableDivChat"
        scrollThreshold={0.9}
      >
        {handleRenderMessage()}
      </InfiniteScroll>
    </div>
  );
};
