import { formatTimeMessage } from "@/lib/utils";
import MessageImage from "@/module/chat-online/message-item/message-image";
import MessageImageText from "@/module/chat-online/message-item/message-image-text";
import MessageText from "@/module/chat-online/message-item/message-text";
import React from "react";

type Props = {
  text: string;
  createdTime: string;
  isOwnerMessage: boolean;
  isHeaderMessage: boolean;
  isFinalMessage: boolean;
  imagePath?: string[];
};

const MessageItem = ({
  text,
  imagePath,
  createdTime,
  isOwnerMessage,
  isFinalMessage,
  isHeaderMessage,
}: Props) => {
  const renderItem = () => {
    if (imagePath?.length && text) {
      return (
        <MessageImageText
          images={imagePath}
          text={text}
          isFinalMessage={isFinalMessage}
          isHeaderMessage={isHeaderMessage}
          avatar="/images/avatar_supporting.svg"
          time={formatTimeMessage(createdTime)}
          // createdTime={formatTimeChatLocal(createdTime)}
          isOwnMessage={isOwnerMessage}
        />
      );
    }
    if (imagePath?.length) {
      return (
        <MessageImage
          images={imagePath}
          isFinalMessage={isFinalMessage}
          isHeaderMessage={isHeaderMessage}
          avatar="/images/avatar_supporting.svg"
          text={text}
          time={formatTimeMessage(createdTime)}
          // createdTime={formatTimeChatLocal(createdTime)}
          isOwnMessage={isOwnerMessage}
        />
      );
    }
    return (
      <MessageText
        isFinalMessage={isFinalMessage}
        isHeaderMessage={isHeaderMessage}
        avatar="/images/avatar_supporting.svg"
        text={text}
        time={formatTimeMessage(createdTime)}
        isOwnMessage={isOwnerMessage}
      />
    );
  };
  return <div>{renderItem()}</div>;
};

export default MessageItem;
