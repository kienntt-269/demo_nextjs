import { LegacyRef, useCallback, useEffect, useRef, useState } from "react";
import SendMessageIcon from "@/components/icons/send-mesage-icon";
import SendImageIcon from "@/components/icons/send-image-icon";
import Image from "next/image";
import { Button } from "@/components/ui/button";
import { useChatOnline } from "@/_stores/useChatOnline";
import { useTranslations } from "next-intl";
import { BadeSuggestChat } from "@/components/bade-suggest-chat";
import CloseCircleIcon from "@/components/icons/close-circle-icon";
import { toastError } from "@/hooks/use-toast";
import clsx from "clsx";
import { useDialogAuthStore } from "@/_stores/useDialogAuth.store";
import { useProfileStore } from "@/_stores/useProfile.store";
import { debounce } from "lodash";

const MAX_LENGTH = 200;
export default function ChatInput({
  handleSubmit,
  handleSendImage,
  isShowSuggestion,
}: {
  handleSendImage: ({
    files,
    message,
  }: {
    files?: File[];
    message?: string;
    type?: "1" | "2" | "3";
  }) => void;
  handleSubmit: ({
    message,
    imagePath,
  }: {
    message?: string;
    imagePath?: string;
    type?: "1" | "2" | "3";
  }) => void;
  isShowSuggestion?: boolean;
}) {
  const t = useTranslations();
  const { user } = useProfileStore();
  const { setIsOpen, setUrlLoginSuccess } = useDialogAuthStore();
  const [message, setMessage] = useState("");
  const [images, setImages] = useState<File[]>([]);
  const { serviceChoosedId, roomData, setStateChatOnline } = useChatOnline();
  const divInputRef = useRef<HTMLDivElement>();
  const inputRef = useRef<HTMLInputElement>();
  const inputFileRef = useRef<HTMLInputElement>();

  const handleShowLogin = () => {
    setIsOpen({ isOpen: true, mode: "LOGIN" });
    setUrlLoginSuccess(location.pathname);
  };

  const handleImageChange = (files: File[]) => {
    const allowedExtensions = ["image/png", "image/jpeg", "image/jpg"];
    if (files.length + images.length > 20) {
      toastError(t("common.message.MSG0018"));
      if (inputFileRef.current) inputFileRef.current.value = "";
      return;
    }
    for (let i = 0; i < files.length; i++) {
      const file = files[i];

      if (!allowedExtensions.includes(file.type)) {
        toastError(t("chat_online.file_upload_type"));
        if (inputFileRef.current) inputFileRef.current.value = "";
        return;
      }
      // Check if the file size is less than or equal to 3MB
      if (file.size > 3 * 1024 * 1024) {
        toastError(t("common.message.MSG0019"));
        if (inputFileRef.current) inputFileRef.current.value = "";
        return;
      }
    }
    if (files) {
      setImages([...images, ...files]);
      if (inputFileRef.current) inputFileRef.current.value = "";
    }
  };

  const removeImage = (index: number) => {
    setImages(images.filter((_, i) => i !== index));
  };

  const handleSend = useCallback(
    debounce(async () => {
      if (!divInputRef.current?.textContent?.trim().length && !images.length)
        return;

      if (message && !images.length) {
        handleSubmit({ message });
      } else if (images.length && !message) {
        handleSendImage({ files: images });
      } else if (images.length && message) {
        handleSendImage({ files: images, message });
      }

      setImages([]);
      setMessage("");
      if (inputRef.current) inputRef.current.value = "";
      if (divInputRef.current) divInputRef.current.innerHTML = "";
    }, 500),
    [
      message,
      images,
      inputRef,
      divInputRef,
      handleSendImage,
      handleSubmit,
      setImages,
      setMessage,
    ]
  );
  const onKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    const element = e.currentTarget;
    const selection = window.getSelection();
    const innerText = element.innerText;

    if (selection && selection.rangeCount > 0) {
      const range = selection.getRangeAt(0);
      const selectedText = range.toString();
      const remainingLength =
        MAX_LENGTH - (innerText.length - selectedText.length);
      if (
        remainingLength < 0 &&
        e.key !== "Backspace" &&
        e.key !== "Delete" &&
        e.key !== "ArrowLeft" &&
        e.key !== "ArrowRight"
      ) {
        e.preventDefault();
        return;
      }
    } else if (
      innerText.length > MAX_LENGTH &&
      e.key !== "Backspace" &&
      e.key !== "Delete" &&
      e.key !== "ArrowLeft" &&
      e.key !== "ArrowRight"
    ) {
      e.preventDefault();
      return;
    }
    if (e.key === "Enter") {
      if (e.shiftKey) {
        return;
      }
      e.preventDefault(); // Ngăn form bị submit mặc định
      handleSend();
    }
  };

  const handleInput = (element: HTMLElement) => {
    if (element.innerHTML === "<br>") {
      element.innerHTML = "";
      element.innerText = "";
    }
    setMessage(element.innerHTML);
  };

  const renderFooterPool = () => {
    if (isShowSuggestion) {
      return (
        <div className="grid grid-cols-2 gap-2 px-4 pb-3">
          <BadeSuggestChat
            content={t("chat_online.package_plans")}
            onClick={(content) => handleSubmit({ message: content })}
          />
          <BadeSuggestChat
            content={t("chat_online.currently_promotions")}
            onClick={(content) => handleSubmit({ message: content })}
          />
          <BadeSuggestChat
            content={t("chat_online.best_seller_products")}
            onClick={(content) => handleSubmit({ message: content })}
          />
          <BadeSuggestChat
            content={t("chat_online.purchase_method")}
            onClick={(content) => handleSubmit({ message: content })}
          />
        </div>
      );
    }
    if (roomData?.status === "3") {
      return (
        <div className="flex justify-center pt-2 pb-1">
          <Button
            size="sm"
            onClick={() => {
              handleSubmit({ message: t("chat_online.start"), type: "1" });
              setStateChatOnline({ roomData: { ...roomData, status: "1" } });
            }}
          >
            {t("chat_online.start_new_chat")}
          </Button>
        </div>
      );
    }

    return (
      <div className="flex justify-center pt-2 pb-1">
        <Button
          size="sm"
          onClick={() => {
            handleSubmit({ message: t("chat_online.end"), type: "3" });
            setStateChatOnline({
              roomData: {
                ...roomData,
                status: "3",
                roomId: roomData?.roomId ?? "",
              },
            });
          }}
        >
          {t("chat_online.end")}
        </Button>
      </div>
    );
  };

  useEffect(() => {
    if (serviceChoosedId) {
      // chatApiRequest.getListServiceSuggestion(serviceChoosedId).then((res) => {
      //   setServiceSuggestions(res?.payload?.data);
      // });
    }
  }, [serviceChoosedId]);

  return (
    <div
      className={clsx(
        "w-full md:rounded-ee-3xl md:rounded-es-3xl overflow-hidden"
      )}
    >
      {renderFooterPool()}

      <div
        className={clsx("w-full mx-auto bg-white py-2 px-3 rounded-lg ", {
          "pointer-events-none": roomData?.status == "3",
        })}
      >
        {images.length > 0 && (
          <div className="pb-4">
            <div
              className="flex gap-2 overflow-x-auto pb-2"
              style={{ scrollbarWidth: "thin" }}
            >
              {images.map((image, index) => (
                <div
                  key={index}
                  className="relative w-[72px] h-[72px] shrink-0 flex items-center"
                >
                  <Image
                    width={72}
                    height={72}
                    src={URL.createObjectURL(image)}
                    alt="Preview"
                    className="rounded-[8px] object-cover max-h-full h-full"
                  />
                  <button
                    className="absolute top-1 right-1 rounded-full"
                    onClick={() => removeImage(index)}
                  >
                    <CloseCircleIcon />
                  </button>
                </div>
              ))}
            </div>
            <div className="text-neutral text-xs">
              {t("chat_online.text_max_upload")}
            </div>
          </div>
        )}
        {/* input */}
        <div className="flex items-center gap-3 w-full">
          <label
            className="cursor-pointer self-end mb-3"
            onClick={(e) => {
              if (!user) {
                e.preventDefault();
                handleShowLogin();
              }
            }}
          >
            <input
              ref={inputFileRef as LegacyRef<HTMLInputElement>}
              type="file"
              className="hidden"
              accept="image/png,image/jpeg,image/jpg"
              multiple
              onChange={(e) =>
                e.target.files
                  ? handleImageChange(Array.from(e.target.files))
                  : null
              }
            />
            <SendImageIcon />
          </label>
          <div
            className={clsx(
              "flex items-center gap-2 py-3 pl-3 pr-4  rounded-[32px] min-h-[56px] bg-[#F5F6F7] flex-1 overflow-auto"
            )}
          >
            <div className="w-full max-h-[160px] overflow-y-auto relative">
              <div
                ref={divInputRef as LegacyRef<HTMLDivElement>}
                className="w-full outline-none border-none max-w-full pr-1"
                contentEditable="true"
                title={t("chat_online.input_placeholder")}
                onInput={(e: React.ChangeEvent<HTMLInputElement>) =>
                  handleInput(e.target as HTMLElement)
                }
                onPaste={(event) => {
                  event.preventDefault();
                  const files = event.clipboardData.files;
                  let textPlain = event.clipboardData.getData("text/plain");
                  if (files.length > 0) {
                    if (!user) {
                      handleShowLogin();
                    } else {
                      handleImageChange(Array.from(files));
                    }
                  }
                  if (
                    textPlain.replace(/\n/g, "").length +
                      message.replace(/<br>/g, "").length >
                    MAX_LENGTH
                  ) {
                    textPlain = textPlain.substring(
                      0,
                      MAX_LENGTH - message.replace(/<br>/g, "").length
                    );
                  }
                  document.execCommand(
                    "insertHTML",
                    false,
                    textPlain.replace(/\n/g, "<br>")
                  );
                }}
                onKeyDown={onKeyDown}
              />
              {!divInputRef?.current?.innerText && (
                <span className="w-full placeholder bottom-0 absolute pointer-events-none text-neutral truncate">
                  {t("chat_online.input_placeholder")}
                </span>
              )}
            </div>
            {/* <input
              id="input-chat-online"
              autoFocus
              ref={inputRef as LegacyRef<HTMLInputElement>}
              type="text"
              placeholder={t("chat_online.input_placeholder")}
              className="flex-1 outline-none bg-transparent"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              onKeyDown={onKeyDown}
              maxLength={200}
            /> */}
            <span className="cursor-pointer self-end" onClick={handleSend}>
              <SendMessageIcon />
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
