import { MessageDataType } from "@/types/common";

export interface IResponse {
  success: boolean;
  message: string;
  data?: object | string;
}

export interface IQueryParam {
  page: number;
  name?: string;
  limit?: string | number;
}

export type GetRoomResponseType = {
  data: {
    roomId: string;
    status: string;
  };
};

export type GetMessageResponseType = {
  data: {
    messages: MessageDataType[];
  };
};

export type CheckRoomIsExistResponseType = {
  data: {
    roomId: string;
    status: string;
  };
};
