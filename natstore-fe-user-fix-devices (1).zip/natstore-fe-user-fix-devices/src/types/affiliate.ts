export interface IAffiliateFAQ {
  id?: string;
  question?: string;
  answer?: string;
  sortOrder?: string;
  faqCategoryId?: string;
  createdAt?: string;
}

export interface IAffiliateFAQRes {
  code: string;
  data: IAffiliateFAQ[];
  message: string;
}

export interface IBannerAffiliate {
  imagePath: string;
  imageWapPath: string;
  bannerLink: string | number;
  bannerName: string;
}

export interface IBannerAffiliateRes {
  code: string;
  data: IBannerAffiliate;
  message: string;
}
