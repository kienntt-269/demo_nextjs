declare module "react-simple-captcha";
