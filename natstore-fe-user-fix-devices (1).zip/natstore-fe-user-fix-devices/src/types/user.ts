export interface IUserProfile {
  id: number;
  phoneNumber: string;
  userName: string;
  isdn: string;
  email: string;
  address: string;
  loyaltyPoint?: string;
  lastModifiedBy?: string;
  lastModifiedDate?: Date | null;
}
