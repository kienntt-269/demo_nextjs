import { XSRF_REFRESH_TOKEN, XSRF_TOKEN } from "@/constants/authority";
import { request } from "@/lib/http";
import { CustomOptions } from "@/types/http";
import { cookies } from "next/headers";

class HttpServer {
  public async get<Response>(
    url: string,
    options?: Omit<CustomOptions, "body"> | undefined,
  ) {
    const cookieStore = await cookies();
    const refreshToken = await cookieStore.get(XSRF_REFRESH_TOKEN)?.value;
    const token = cookieStore.get(XSRF_TOKEN)?.value;
    const headers: { [key: string]: string } = {};
    if (token) headers.Authorization = `Bearer ${token}`;
    const optionsExtend = {
      ...(options ?? {}),
      headers: { ...headers, ...(options?.headers ?? {}) },
    };
    if (refreshToken) optionsExtend.refreshToken = refreshToken;
    return request<Response>("GET", url, optionsExtend);
  }
  public async post<Response>(
    url: string,
    body: BodyInit,
    options?: Omit<CustomOptions, "body"> | undefined,
  ) {
    const cookieStore = await cookies();
    const token = cookieStore.get(XSRF_TOKEN);
    const headers: { [key: string]: string } = {};
    if (token) headers.Authorization = `Bearer ${token}`;
    const optionsExtend = {
      ...(options ?? {}),
      headers: { ...headers, ...(options?.headers ?? {}) },
    };
    return request<Response>("POST", url, { ...optionsExtend, body });
  }
  public async put<Response>(
    url: string,
    body: BodyInit,
    options?: Omit<CustomOptions, "body"> | undefined,
  ) {
    const cookieStore = await cookies();
    const token = cookieStore.get(XSRF_TOKEN);
    const headers: { [key: string]: string } = {};
    if (token) headers.Authorization = `Bearer ${token}`;
    const optionsExtend = {
      ...(options ?? {}),
      headers: { ...headers, ...(options?.headers ?? {}) },
    };

    return request<Response>("PUT", url, { ...optionsExtend, body });
  }
  public async delete<Response>(
    url: string,
    options?: Omit<CustomOptions, "body"> | undefined,
  ) {
    const cookieStore = await cookies();
    const token = cookieStore.get(XSRF_TOKEN);
    const headers: { [key: string]: string } = {};
    if (token) headers.Authorization = `Bearer ${token}`;
    const optionsExtend = {
      ...(options ?? {}),
      headers: { ...headers, ...(options?.headers ?? {}) },
    };

    return request<Response>("DELETE", url, { ...optionsExtend });
  }
}
const httpServer = new HttpServer();
export { httpServer };
