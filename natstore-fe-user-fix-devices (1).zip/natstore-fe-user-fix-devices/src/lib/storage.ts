"use client";

import {
  DATA_PACKAGE_REGISTER_KEY,
  DATA_PAYMENT_PACKAGE_INTERNET,
  INTERNET_REGISTER_KEY,
  IS_SHOW_SUGGESTION_KEY,
  PHONE_SUPPORTING_KEY,
  RESPONSE_PAYMENT_INTERNET,
  SIM_REGISTER_KEY,
  SIM_TYPE_REGISTER_KEY,
} from "@/constants/storage";
import {
  decryptPhoneChatSupporting,
  encryptPhoneChatSupporting,
} from "@/lib/utils";
import { IDataDebtDetail } from "@/schemaValidations/internet.shema";

const safeStorage = {
  setItem: (key: string, value: string) => {
    if (typeof window !== "undefined") {
      localStorage.setItem(key, value);
    }
  },
  getItem: (key: string): string | null => {
    if (typeof window !== "undefined") {
      return localStorage.getItem(key);
    }
    return null;
  },
  removeItem: (key: string) => {
    if (typeof window !== "undefined") {
      localStorage.removeItem(key);
    }
  },
  clear: () => {
    if (typeof window !== "undefined") {
      localStorage.clear();
    }
  },
};

export const storage = {
  setPhoneSupporting: (phone: string) =>
    safeStorage.setItem(
      PHONE_SUPPORTING_KEY,
      encryptPhoneChatSupporting(phone)
    ),

  getPhoneSupporting: () =>
    decryptPhoneChatSupporting(safeStorage.getItem(PHONE_SUPPORTING_KEY) || ""),

  removePhoneSupporting: () => safeStorage.removeItem(PHONE_SUPPORTING_KEY),

  setDataPackageRegister: (data: string) =>
    safeStorage.setItem(DATA_PACKAGE_REGISTER_KEY, data),

  getDataPackageRegister: () => {
    try {
      return JSON.parse(safeStorage.getItem(DATA_PACKAGE_REGISTER_KEY) || "{}");
    } catch {
      return {};
    }
  },

  removeDataPackageRegister: () =>
    safeStorage.removeItem(DATA_PACKAGE_REGISTER_KEY),

  setSimRegister: (phone: string) =>
    safeStorage.setItem(SIM_REGISTER_KEY, phone),

  setTypeSimRegister: (type: string) =>
    safeStorage.setItem(SIM_TYPE_REGISTER_KEY, type),

  getSimTypeRegister: () => safeStorage.getItem(SIM_TYPE_REGISTER_KEY || ""),

  getSimRegister: () => safeStorage.getItem(SIM_REGISTER_KEY) || "",

  removeSimRegister: () => safeStorage.removeItem(SIM_REGISTER_KEY),

  setInternetRegister: (phone: string) =>
    safeStorage.setItem(INTERNET_REGISTER_KEY, phone),

  getInternetRegister: () => safeStorage.getItem(INTERNET_REGISTER_KEY) || "",

  removeInternetRegister: () => safeStorage.removeItem(INTERNET_REGISTER_KEY),

  setIsShowSuggestionChat: (isShow: boolean) =>
    safeStorage.setItem(IS_SHOW_SUGGESTION_KEY, JSON.stringify(isShow)),

  getIsShowSuggestionChat: () => {
    try {
      return JSON.parse(safeStorage.getItem(IS_SHOW_SUGGESTION_KEY) || "false");
    } catch {
      return false;
    }
  },

  removeIsShowSuggestionChat: () =>
    safeStorage.removeItem(IS_SHOW_SUGGESTION_KEY),

  setDataPaymentPackage: (data: IDataDebtDetail[]) =>
    safeStorage.setItem(DATA_PAYMENT_PACKAGE_INTERNET, JSON.stringify(data)),

  getDataPaymentPackage: (): IDataDebtDetail[] => {
    try {
      return JSON.parse(
        safeStorage.getItem(DATA_PAYMENT_PACKAGE_INTERNET) || "[]"
      );
    } catch {
      return [];
    }
  },
  removeDataPaymentPackage: () =>
    safeStorage.removeItem(DATA_PAYMENT_PACKAGE_INTERNET),

  setResponsePaymentDataInternet: (data: string) =>
    safeStorage.setItem(RESPONSE_PAYMENT_INTERNET, data),

  getResponsePaymentDataInternet: () => {
    try {
      return JSON.parse(safeStorage.getItem(RESPONSE_PAYMENT_INTERNET) || "{}");
    } catch {
      return [];
    }
  },
  removeResponsePaymentDataInternet: () =>
    safeStorage.removeItem(RESPONSE_PAYMENT_INTERNET),

  removeAll: () => safeStorage.clear(),
};
