import envConfig from "@/config";
import { storage } from "@/lib/storage";
import { checkResSuccess } from "@/lib/utils";
import { getUserLocale } from "@/services/locale";
import { CustomOptions, EntityErrorPayload, PayloadType } from "@/types/http";

const ENTITY_ERROR_STATUS = 422;
const AUTHENTICATION_ERROR_STATUS = 401;
const AUTHENTICATION_ERROR_STATUS2 = 412;

class HttpError extends Error {
  status: number | string;
  payload: PayloadType;

  constructor({
    status,
    payload,
  }: {
    status: number | string;
    payload: PayloadType;
  }) {
    super("Http Error");
    this.status = status;
    this.payload = payload;
  }
}

class EntityError extends HttpError {
  constructor(payload: EntityErrorPayload) {
    super({ status: ENTITY_ERROR_STATUS, payload });
  }
}

let refreshTokenRequest: Promise<{
  code: number | string;
  data: { refreshToken: string; accessToken: string };
}> | null = null;

const handleRefreshToken = async ({
  url,
  requestOrigin,
}: {
  url: string;
  requestOrigin: RequestInit;
}) => {
  if (!refreshTokenRequest) {
    refreshTokenRequest = fetch(`/api/auth/refresh-token`, {
      method: "POST",
    })
      .then(async (res) => {
        return await res.json();
      })
      .finally(() => {
        refreshTokenRequest = null; // Reset after the request is completed
      });
  }
  const dataRes = await refreshTokenRequest;
  if (!checkResSuccess(dataRes.code + "")) {
    storage.removePhoneSupporting();
    throw new HttpError({
      status: dataRes.code,
      payload: dataRes as unknown as PayloadType,
    });
  }
  const { accessToken } = dataRes.data;
  const retryResponse = await fetch(url, {
    ...requestOrigin,
    headers: {
      ...requestOrigin.headers,
      Authorization: `Bearer ${accessToken}`,
    },
  });
  if (!retryResponse.ok) {
    throw new HttpError({
      status: retryResponse.status,
      payload: await retryResponse.json(),
    });
  }

  return {
    status: retryResponse.status,
    payload: await retryResponse.json(),
  };
};

export const request = async <Response>(
  method: "GET" | "POST" | "PUT" | "DELETE",
  url: string,
  options?: CustomOptions
): Promise<{ status?: number | string; payload: Response }> => {
  const body =
    options?.body instanceof FormData
      ? options.body
      : options?.body
        ? JSON.stringify(options.body)
        : undefined;

  const baseHeaders =
    body instanceof FormData ? {} : { "Content-Type": "application/json" };

  const baseUrl = options?.baseUrl ?? envConfig.NEXT_PUBLIC_API_ENDPOINT;
  const fullUrl = url.startsWith("/")
    ? `${baseUrl}${url}`
    : `${baseUrl}/${url}`;
  const locale = await getUserLocale();
  const requestOrigin: RequestInit = {
    ...options,
    headers: {
      ...baseHeaders,
      ...(options?.headers ?? {}),
      lang: locale,
    } as HeadersInit,
    credentials: "include",
    body,
    method,
  };
  const res = await fetch(fullUrl, requestOrigin);
  const payload: Response & EntityErrorPayload & { code?: number | string } =
    await res.json();
  if (!res.ok || (payload?.code && !checkResSuccess(payload?.code + ""))) {
    if (
      payload?.code == AUTHENTICATION_ERROR_STATUS ||
      payload?.code == AUTHENTICATION_ERROR_STATUS2
    ) {
      const isClient = typeof window !== "undefined";
      if (isClient) return handleRefreshToken({ url: fullUrl, requestOrigin });
      throw new HttpError({
        status: payload.code,
        payload: payload as PayloadType,
      });
    } else {
      return { status: payload.code, payload };
      // throw new HttpError({
      //   status: payload.code ?? res.status,
      //   payload: payload as PayloadType,
      // });
    }
  }

  return { status: res.status, payload };
};

const http = {
  get<Response>(url: string, options?: Omit<CustomOptions, "body">) {
    return request<Response>("GET", url, options);
  },
  post<Response>(
    url: string,
    body: BodyInit,
    options?: Omit<CustomOptions, "body">
  ) {
    return request<Response>("POST", url, { ...options, body });
  },
  put<Response>(
    url: string,
    body: BodyInit,
    options?: Omit<CustomOptions, "body">
  ) {
    return request<Response>("PUT", url, { ...options, body: body });
  },
  delete<Response>(url: string, options?: Omit<CustomOptions, "body">) {
    return request<Response>("DELETE", url, options);
  },
};

export { HttpError, EntityError };
export default http;
