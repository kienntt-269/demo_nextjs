import devicesApiRequest from "@/services/devices";

type GetDeviceType = {
  categoryId?: number | string;
  page?: number;
  size?: number;
  sort?: string;
};

export const getDeviceCategories = async () => {
  try {
    const res = await devicesApiRequest.getCategoryProduct();
    return res.payload.data;
  } catch (error) {
    console.log(error);
    throw Error("error");
  }
};

export const getDevice = async ({
  categoryId,
  page,
  size,
  sort,
}: GetDeviceType) => {
  try {
    const res = await devicesApiRequest.getProduct({
      category: categoryId ?? "",
      page: page ?? 1,
      size: size ?? 3,
      sort: `${sort ?? "ratePoint"}_desc`,
    });
    return res.payload.data;
  } catch (error) {
    console.log(error);
    throw Error("error");
  }
};

export const getDetailDevice = async (idOrSlug: string) => {
  try {
    const res = await devicesApiRequest.getDetailProduct(idOrSlug);
    return res.payload.data;
  } catch (error) {
    console.log(error);
    throw Error("error");
  }
};
