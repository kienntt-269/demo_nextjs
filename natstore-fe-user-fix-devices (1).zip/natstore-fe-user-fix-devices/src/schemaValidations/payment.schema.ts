import z from "zod";

export const PaymentDataPlanRes = z.object({
  code: z.string().nullable(),
  message: z.string().nullable(),
  data: z.object({
    status: z.string(),
    simId: z.string(),
    simOrderId: z.string(),
    packageId: z.string(),
    orderId: z.string(),
    packageData: z.object({
      slug: z.string(),
    }),
  }),
});

export const PaymentMethodRes = z.object({
  code: z.string().nullable(),
  message: z.string().nullable(),
  data: z.array(
    z.object({
      code: z.string(),
      name: z.string(),
      active: z.boolean(),
    })
  ),
});

export type IPaymentMethodRes = z.TypeOf<typeof PaymentMethodRes>;

export type IPaymentDataPlanRes = z.TypeOf<typeof PaymentDataPlanRes>;
