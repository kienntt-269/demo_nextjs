import {
  checkPaymentPhoneFnc,
  phoneSchemaFnc,
  validateAndAddIssue,
} from "@/lib/schema";
import { ICategoryDataPlans } from "@/types/mobile-package";
import z from "zod";

export const MobileServiceRes = z.object({
  data: z.object({
    id: z.number(),
    name: z.string(),
    email: z.string(),
  }),
  message: z.string(),
});

export const CategoriesDataPlans = z.object({
  id: z.string(),
  name: z.string(),
  description: z.string(),
  active: z.boolean(),
  home: z.boolean(),
  icon: z.string(),
  order: z.string(),
  type: z.string(),
  parentId: z.string(),
  createdAt: z.string(),
  updatedAt: z.string(),
  createdBy: z.string(),
  updatedBy: z.string(),
  slug: z.string(),
  categoryId: z.string().nullable(),
  children: z.array(
    z.lazy((): z.ZodType<ICategoryDataPlans> => CategoriesDataPlans)
  ),
});

export const DataPlans = z.object({
  id: z.string().nullable(),
  name: z.string().nullable(),
  description: z.string().nullable(),
  shortDescription: z.string().nullable(),
  categoryId: z.string().nullable(),
  hot: z.string().nullable(),
  home: z.string().nullable(),
  active: z.boolean().nullable(),
  displayFrontend: z.string().nullable(),
  bestSeller: z.string().nullable(),
  recommend: z.string().nullable(),
  rating: z.number().nullable(),
  ratingCount: z.string().nullable(),
  price: z.string().nullable(),
  useTime: z.string().nullable(),
  useTimeValue: z.string().nullable(),
  useTimeUnit: z.string().nullable().optional(),
  packageValue: z.string().nullable(),
  packageUnit: z.string().nullable(),
  type: z.string().nullable(),
  promotionType: z.string().nullable(),
  promotionPrice: z.string().nullable(),
  promotionTime: z.string().nullable(),
  promotionStartTime: z.string().nullable(),
  promotionEndTime: z.string().nullable(),
  createdAt: z.string().nullable(),
  createdBy: z.string().nullable(),
  updatedAt: z.string().nullable(),
  updatedBy: z.string().nullable(),
  slug: z.string().nullable(),
  imagePath: z.string().nullable(),
  speed: z.string().nullable(),
  categories: z.array(CategoriesDataPlans),
  vote: z.number().nullable(),
  imageUrl: z.string().nullable(),
  note: z.string().nullable(),
  detail: z.string().nullable(),
  code: z.string().nullable(),
});

export const CategoriesDataPlansRes = z.object({
  data: z.array(CategoriesDataPlans),
  message: z.string(),
  code: z.number(),
});

export const DataPlansRes = z.object({
  data: z.array(DataPlans),
  message: z.string(),
  code: z.number(),
});

export const DataPlanDetail = z.object({
  data: DataPlans,
  message: z.string(),
  code: z.number(),
});

export const PaymentDataPackage = (
  t: (key: string, values?: Record<string, string>) => string = (key: string) =>
    key
) =>
  z
    .object({
      orderId: z.string(),
      registrationType: z.string(),
      sharePhoneNumber: z.string().optional().nullable(),
      paymentPhoneNumber: z.string().optional(),
      method: z.string(),
    })
    .superRefine((data, ctx) => {
      if (data.registrationType === "SHARE_PLAN") {
        if (data.sharePhoneNumber === null) {
          ctx.addIssue({
            code: z.ZodIssueCode.custom,
            message: t("common.message.phone.required"),
            path: ["sharePhoneNumber"],
          });
        }

        const phoneSchema = phoneSchemaFnc();
        const result = phoneSchema.safeParse(data.sharePhoneNumber);
        if (!result.success) {
          result.error.issues.forEach((issue) => {
            ctx.addIssue({
              code: z.ZodIssueCode.custom,
              message: issue.message,
              path: ["sharePhoneNumber"],
            });
          });
        }
        validateAndAddIssue(
          ctx,
          checkPaymentPhoneFnc(),
          data.sharePhoneNumber,
          ["sharePhoneNumber"]
        );
      }
      if (data.method === "natcom") {
        const phoneSchema = phoneSchemaFnc();
        const result = phoneSchema.safeParse(data.paymentPhoneNumber);
        if (!result.success) {
          result.error.issues.forEach((issue) => {
            ctx.addIssue({
              code: z.ZodIssueCode.custom,
              message: issue.message,
              path: ["paymentPhoneNumber"],
            });
          });
        }
        validateAndAddIssue(
          ctx,
          checkPaymentPhoneFnc(),
          data.paymentPhoneNumber,
          ["paymentPhoneNumber"]
        );
      }
    });

export type MobileResType = z.TypeOf<typeof MobileServiceRes>;

export type DataPlansTypeList = z.TypeOf<typeof DataPlansRes>;

export type IDataPlanRes = z.TypeOf<typeof DataPlanDetail>;

export type IDataPlan = z.TypeOf<typeof DataPlans>;

export type ICategoryDataRes = z.TypeOf<typeof CategoriesDataPlansRes>;

export type ICategoriesDataPlant = z.TypeOf<typeof CategoriesDataPlans>;
