import z from "zod";

export const ServiceTab = z.object({
  id: z.string(),
  name: z.string(),
  description: z.string(),
  icon: z.string(),
  slug: z.string(),
});

export const ServiceTabRes = z.object({
  data: z.array(ServiceTab),
  message: z.string(),
  code: z.number(),
});

export type IServiceTabRes = z.TypeOf<typeof ServiceTabRes>;

export type IServiceTab = z.TypeOf<typeof ServiceTab>;
