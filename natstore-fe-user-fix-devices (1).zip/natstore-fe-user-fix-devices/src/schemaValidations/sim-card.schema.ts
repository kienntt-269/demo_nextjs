import {
  dateSchemaFnc,
  driverLicenseSchemaFnc,
  emailSchemaFnc,
  identityNewCardSchemaFnc,
  identityOldCardSchemaFnc,
  passportSchemaFnc,
  phoneSchemaFnc,
  validateAndAddIssue,
} from "@/lib/schema";
import { fileSchemaFnc } from "@/lib/schema";
import z from "zod";

export const SimCardDetail = z.object({
  id: z.string().nullable(),
  isdn: z.string(),
  categoryId: z.number().nullable(),
  type: z.number().nullable(),
  payType: z.number().nullable(),
  status: z.number().nullable(),
  price: z.number(),
  promotionPrice: z.string().nullable(),
  description: z.string().nullable(),
  shortDescription: z.string().nullable(),
  cycle: z.number().nullable(),
  cycleUnit: z.string().nullable(),
  createdAt: z.string().nullable(),
  createdBy: z.string().nullable(),
  updatedAt: z.string().nullable(),
  updatedBy: z.string().nullable(),
  isActive: z.number().nullable(),
  typeCard: z.string().nullable(),
});

export const HotKeyDetail = z.object({
  id: z.string(),
  hotKey: z.string(),
  isActive: z.number().nullable(),
  isDelete: z.number().nullable(),
  sortOrder: z.number().nullable(),
});

export const SimRegisterInformation = (
  t: (key: string, values?: Record<string, string>) => string = (key: string) =>
    key
) =>
  z
    .object({
      email: z.string().optional().nullable(),
      simType: z.enum(["1", "2"]),
      provinceId: z.string().optional().nullable(),
      timeOfReceiving: z.date().optional().nullable(),
      showroomId: z.string().optional().nullable(),
      files: z.any().optional().nullable(),
      frontIdCard: z.any().optional().nullable(),
      backIdcard: z.any().optional().nullable(),
      faceImage: z.any().optional().nullable(),
      fullName: z.string().optional().nullable(),
      cardId: z.string().optional().nullable(),
      vatPrice: z.number().optional().nullable(),
      mobileNumber: z.string().optional().nullable(),
      type: z.string().nullable(),
      typeDocument: z.string().optional().nullable(),
      dob: z.date().optional().nullable(),
      receivedType: z.string(),
      simNumber: z.string().optional().nullable(),
      whatsappNumber: z.string().optional().nullable(),
      paymentMethod: z.number().optional().nullable(),
    })
    .superRefine((data, ctx) => {
      if (!data.fullName) {
        ctx.addIssue({
          code: "custom",
          message: t("name.required"),
          path: ["fullName"],
        });
      }
      if (!data.cardId) {
        ctx.addIssue({
          code: "custom",
          message: t("id_card_internet.required"),
          path: ["cardId"],
        });
      }
      if (!data.typeDocument) {
        ctx.addIssue({
          code: "custom",
          message: t("type_of_doc.required"),
          path: ["typeDocument"],
        });
      } else if (data.typeDocument === "1") {
        validateAndAddIssue(ctx, identityNewCardSchemaFnc(), data.cardId, [
          "cardId",
        ]);
      } else if (data.typeDocument === "2") {
        validateAndAddIssue(ctx, identityOldCardSchemaFnc(), data.cardId, [
          "cardId",
        ]);
      } else if (data.typeDocument === "3") {
        validateAndAddIssue(ctx, driverLicenseSchemaFnc(), data.cardId, [
          "cardId",
        ]);
      } else if (data.typeDocument === "4") {
        validateAndAddIssue(ctx, passportSchemaFnc(), data.cardId, ["cardId"]);
      }

      validateAndAddIssue(ctx, phoneSchemaFnc(), data.mobileNumber, [
        "mobileNumber",
      ]);
      validateAndAddIssue(ctx, dateSchemaFnc(), data.dob, ["dob"]);
      if (data.simType === "1") {
        if (!data.provinceId)
          ctx.addIssue({
            code: "custom",
            message: t("province.required"),
            path: ["provinceId"],
          });
        if (!data.timeOfReceiving)
          ctx.addIssue({
            code: "custom",
            message: t("time_of_receving.required"),
            path: ["timeOfReceiving"],
          });
        if (!data.showroomId)
          ctx.addIssue({
            code: "custom",
            message: t("store.required"),
            path: ["showroomId"],
          });
        if (data.email) {
          validateAndAddIssue(ctx, emailSchemaFnc(), data.email, ["email"]);
        }
      }

      if (data.simType === "2") {
        validateAndAddIssue(ctx, emailSchemaFnc(), data.email, ["email"]);
        if (data.receivedType === "1") {
          if (!data.provinceId)
            ctx.addIssue({
              code: "custom",
              message: t("province.required"),
              path: ["provinceId"],
            });
          if (!data.timeOfReceiving)
            ctx.addIssue({
              code: "custom",
              message: t("time_of_receving.required"),
              path: ["timeOfReceiving"],
            });
          if (!data.showroomId)
            ctx.addIssue({
              code: "custom",
              message: t("store.required"),
              path: ["showroomId"],
            });
        }

        // Validate faceImage
        if (!data.faceImage || data?.faceImage?.length === 0) {
          ctx.addIssue({
            code: "custom",
            message: "file.face_photo",
            path: ["faceImage"],
          });
        } else {
          validateAndAddIssue(
            ctx,
            fileSchemaFnc({ fileSizeLimit: 15 }),
            data.faceImage,
            ["faceImage"]
          );
        }

        // Validate frontIdCard
        if (!data.frontIdCard || data?.frontIdCard?.length === 0) {
          ctx.addIssue({
            code: "custom",
            message: "file.front_photo",
            path: ["frontIdCard"],
          });
        } else {
          validateAndAddIssue(
            ctx,
            fileSchemaFnc({ fileSizeLimit: 15 }),
            data.frontIdCard,
            ["frontIdCard"]
          );
        }

        // Validate backIdcard
        if (!data.backIdcard || data?.backIdcard?.length === 0) {
          ctx.addIssue({
            code: "custom",
            message: "file.back_photo",
            path: ["backIdcard"],
          });
        } else {
          validateAndAddIssue(
            ctx,
            fileSchemaFnc({ fileSizeLimit: 15 }),
            data.backIdcard,
            ["backIdcard"]
          );
        }
      }
    });

export const OrderSimCard = z.object({
  request: z.object({
    simNumber: z.string().nullable(),
    type: z.number().nullable(),
    price: z.number().nullable(),
    packageId: z.number().nullable(),
    packagePrice: z.number().nullable(),
    isIncludedVat: z.number().nullable(),
    vatPrice: z.number().nullable(),
    provinceId: z.string().nullable(),
    districtId: z.string().nullable(),
    fullName: z.string().nullable(),
    dob: z.string().nullable(),
    cardId: z.string().nullable(),
    vatId: z.number().nullable(),
    mobileNumber: z.string().nullable(),
    simType: z.number().nullable(),
    receivedType: z.number().nullable(),
    timeOfReceiving: z.string().nullable(),
    showroomId: z.string().nullable(),
    email: z.string().nullable(),
    whatsappNumber: z.string().nullable(),
    paymentMethod: z.number().nullable(),
  }),
  files: z.array(z.string()),
});

export const SimCardRes = z.object({
  message: z.string(),
  code: z.number(),
  data: z.object({
    pagination: z.array(SimCardDetail),
    total_records: z.number(),
    current_page: z.number(),
    next_page: z.number(),
    prev_page: z.number(),
    page_size: z.number(),
    total_pages: z.number(),
    last: z.boolean(),
  }),
});

export const AddressDetail = z.object({
  id: z.number().nullable().optional(),
  name: z.string().nullable().optional(),
  type: z.number().nullable().optional(),
  parentId: z.number().nullable().optional(),
  sortOrder: z.number().nullable().optional(),
  isActive: z.boolean().nullable().optional(),
  isDelete: z.boolean().nullable().optional(),
});

export const SimType = z.object({
  id: z.number(),
  name: z.string(),
  description: z.string(),
  isActive: z.number(),
  value: z.string(),
});

export const SimTypeRes = z.object({
  message: z.string(),
  code: z.string(),
  data: SimType,
});

export const AddressDetailRes = z.object({
  message: z.string(),
  code: z.string(),
  data: z.array(AddressDetail),
});

export const HotKeyRes = z.object({
  message: z.string(),
  code: z.number(),
  data: z.array(HotKeyDetail),
});

export const SimDetailRes = z.object({
  message: z.string(),
  code: z.number(),
  data: SimCardDetail,
});

export const SimCardOrderRes = z.object({
  message: z.string(),
  code: z.string(),
  data: z.object({
    simCardOrderId: z.number(),
    paymentUrl: z.string(),
    orderId: z.number(),
    status: z.string(),
  }),
});

export const SimCardVerifyPayment = z.object({
  message: z.string(),
  code: z.string(),
  data: z.object({
    status: z.string(),
  }),
});

export type ISimCardListRes = z.TypeOf<typeof SimCardRes>;

export type ISimCard = z.TypeOf<typeof SimCardDetail>;

export type IHotKey = z.TypeOf<typeof HotKeyDetail>;

export type IHotKeyListRes = z.TypeOf<typeof HotKeyRes>;
export const schemaSimRegisterInformation = SimRegisterInformation();
export type SimRegisterInformationType = z.TypeOf<
  typeof schemaSimRegisterInformation
>;

export type ISimCardOrderRes = z.TypeOf<typeof SimCardOrderRes>;

export type SimDetailRes = z.TypeOf<typeof SimDetailRes>;

export type ISimType = z.TypeOf<typeof SimType>;

export type ISimTypeRes = z.TypeOf<typeof SimTypeRes>;

export type ISimCardOrder = z.TypeOf<typeof OrderSimCard>;

export type IAddressDetail = z.TypeOf<typeof AddressDetail>;

export type IAddressRes = z.TypeOf<typeof AddressDetailRes>;

export type IVerifyPaymentSimCardRes = z.TypeOf<typeof SimCardVerifyPayment>;
