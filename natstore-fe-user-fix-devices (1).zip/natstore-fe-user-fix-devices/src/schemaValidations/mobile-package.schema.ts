import z from "zod";

export const RoamingStatus = z.object({
  activationStatus: z.string(),
});

export const Roaming = z.object({
  id: z.string().nullable(),
  name: z.string().nullable(),
  vote: z.number().nullable(),
  price: z.string().nullable(),
  note: z.string().nullable(),
  detail: z.string().nullable(),
  imageUrl: z.string().nullable(),
});

export const RoamingMetadata = z.object({
  id: z.number(),
  descriptionAndPricing: z.object({
    productPricingDes: z.string(),
    price: z.string(),
  }),
  promotion: z.object({
    promotionDes: z.string(),
    promotionType: z.string(),
    promotionPrice: z.string(),
    promotionTime: z.string(),
    promotionStartTime: z.string(),
    promotionEndTime: z.string(),
  }),
  changePackageDes: z.string(),
  faqDes: z.string(),
});

export const ActivateStatusUser = z.object({
  id: z.number(),
  name: z.string(),
  transactionId: z.string(),
  registerAt: z.string(),
  expireAt: z.date(),
  registerStatus: z.string(),
  activationStatus: z.string(),
  usageStatus: z.object({
    remainingDataInByte: z.number(),
    usingDataInByte: z.number(),
  }),
  installationInstruction: z.string().optional(),
});

//roaming
export const RoamingListRes = z.object({
  data: z.array(Roaming),
  message: z.string(),
  code: z.string(),
});

export const RoamingDetailRes = z.object({
  data: Roaming,
  message: z.string(),
  code: z.string(),
});

export const RoamingMetadataRes = z.object({
  data: RoamingMetadata,
  message: z.string(),
  code: z.string(),
});

export const RoamingRegisterRes = z.object({
  data: ActivateStatusUser,
  message: z.string(),
  code: z.string(),
});

export const RoamingStatusRes = z.object({
  data: RoamingStatus,
  message: z.string(),
  code: z.string(),
});

export const ActivateStatusUserRes = z.object({
  data: ActivateStatusUser,
  message: z.string(),
  code: z.string(),
});

//vas
export const Vas = z.object({
  id: z.string().nullable(),
  name: z.string().nullable(),
  description: z.string().nullable(),
  shortDescription: z.string().nullable(),
  categoryId: z.string().nullable(),
  hot: z.string().nullable(),
  home: z.string().nullable(),
  active: z.boolean().nullable(),
  displayFrontend: z.string().nullable(),
  bestSeller: z.string().nullable(),
  recommend: z.string().nullable(),
  rating: z.number().nullable(),
  ratingCount: z.string().nullable(),
  price: z.string().nullable(),
  useTime: z.string().nullable(),
  useTimeUnit: z.string().nullable().optional(),
  packageValue: z.string().nullable(),
  packageUnit: z.string().nullable(),
  type: z.string().nullable(),
  promotionType: z.string().nullable(),
  promotionPrice: z.string().nullable(),
  promotionTime: z.string().nullable(),
  promotionStartTime: z.string().nullable(),
  promotionEndTime: z.string().nullable(),
  createdAt: z.string().nullable(),
  createdBy: z.string().nullable(),
  updatedAt: z.string().nullable(),
  updatedBy: z.string().nullable(),
  slug: z.string().nullable(),
  imagePath: z.string().nullable(),
});

export type VasCategoryType = {
  id: string;
  name: string;
  description: string;
  active: boolean;
  home: boolean;
  icon: string;
  order: string;
  type: string;
  parentId: string;
  createdAt: Date;
  updatedAt: Date;
  createdBy: string;
  updatedBy: string;
  slug: string;
  children: VasCategoryType[];
};

export const VasCategory: z.ZodType<VasCategoryType> = z.lazy(() =>
  z.object({
    id: z.string(),
    name: z.string(),
    description: z.string(),
    active: z.boolean(),
    home: z.boolean(),
    icon: z.string(),
    order: z.string(),
    type: z.string(),
    parentId: z.string(),
    createdAt: z.date(),
    updatedAt: z.date(),
    createdBy: z.string(),
    updatedBy: z.string(),
    slug: z.string(),
    children: z.array(VasCategory),
  })
);

export const Faqs = z.array(
  z.object({
    id: z.string(),
    question: z.string(),
    answer: z.string(),
  })
);

export const ShowroomSwapSim = z.array(
  z.object({
    id: z.string(),
    name: z.string(),
    location: z.string(),
    order: z.string(),
    active: z.boolean(),
  })
);

export const BannerSwapSim = z.array(
  z.object({
    id: z.string(),
    featureText: z.string(),
    bannerImageWeb: z.string(),
    bannerImageWap: z.string(),
    hotline: z.string(),
    fee: z.number(),
    feeDiscount: z.number(),
    features: z.array(
      z.object({
        id: z.string(),
        swapSimBannerId: z.string(),
        title: z.string(),
        content: z.string(),
        order: z.string(),
      })
    ),
  })
);

export const FormsSwapSim = z.object({
  id: z.string(),
  swapSimRequestId: z.string(),
  fullname: z.string(),
  gender: z.string(),
  dob: z.date(),
  identityNumber: z.string(),
  issueDate: z.date(),
  phoneNumber: z.string(),
  contactNumber1: z.string(),
  contactNumber2: z.string(),
  contactNumber3: z.string(),
  contactNumber4: z.string(),
  contactNumber5: z.string(),
  newSubName: z.string(),
  newSubGender: z.string(),
  newSubIdentityNumber: z.string(),
  newSubIssueDate: z.date(),
  newSubExpireDate: z.date(),
  newSubAddress: z.string(),
  newSubEmail: z.string(),
});

export const DeviceDetail = z.object({
  id: z.string(),
  brandId: z.string(),
  deviceName: z.string(),
  deviceImage: z.string(),
});

export const DeviceDetailArray = z.array(DeviceDetail);

export const DevicesSwapSim = z.object({
  id: z.string(),
  brandName: z.string(),
  displayType: z.string(),
  image: z.string(),
  devices: DeviceDetailArray,
});

export const VasListRes = z.object({
  data: z.array(Vas),
  message: z.string(),
  code: z.string(),
});

export const VasDetailRes = z.object({
  data: Vas,
  message: z.string(),
  code: z.string(),
});

export const VasCategoriesRes = z.object({
  data: z.array(VasCategory),
  message: z.string(),
  code: z.string(),
});

export const ShowroomSwapSimRes = z.object({
  data: ShowroomSwapSim,
  message: z.string(),
  code: z.string(),
});

export const FaqsRes = z.object({
  data: Faqs,
  message: z.string(),
  code: z.string(),
});

export const BannerSwapSimRes = z.object({
  data: BannerSwapSim,
  message: z.string(),
  code: z.string(),
});

export const DevicesSwapSimRes = z.object({
  data: z.array(DevicesSwapSim),
  message: z.string(),
  code: z.string(),
});

export const FormsSwapSimRes = z.object({
  data: FormsSwapSim,
  message: z.string(),
  code: z.string(),
});

export const ReceivingMethodFormRes = z.object({
  data: z.object({
    id: z.string(),
    phoneNumber: z.string(),
    fullname: z.string(),
    dob: z.date(),
    identityNumber: z.string(),
    identityDocs: z.string(),
    typeOfSim: z.string(),
    simInfoMatched: z.boolean(),
    receiveMethod: z.number(),
    showroomId: z.number(),
    receiveEmail: z.string(),
    fee: z.string(),
    paymentMethod: z.number(),
    paymentStatus: z.string(),
    swapStatus: z.string(),
    createdAt: z.date(),
    createdBy: z.string(),
    updatedAt: z.date(),
    updatedBy: z.string(),
  }),
  message: z.string(),
  code: z.string(),
});

export const EnterInfoFormRes = z.object({
  data: z.object({
    requestId: z.string(),
    matched: z.boolean(),
  }),
  message: z.string(),
  code: z.string(),
});

export const RequestOtpFormRes = z.object({
  data: z.object({
    otpSent: z.boolean(),
  }),
  message: z.string(),
  code: z.string(),
});

export const SwapApproveRes = z.object({
  data: Vas,
  message: z.string(),
  code: z.string(),
});

//roaming
export type IRoamingListRes = z.TypeOf<typeof RoamingListRes>;
export type IRoamingDetailRes = z.TypeOf<typeof RoamingDetailRes>;
export type IRoamingMetadata = z.TypeOf<typeof RoamingMetadata>;
export type IRoamingMetadataRes = z.TypeOf<typeof RoamingMetadataRes>;
export type IRoamingRegisterRes = z.TypeOf<typeof RoamingRegisterRes>;
export type IRoamingStatusRes = z.TypeOf<typeof RoamingStatusRes>;
export type IActivateStatusUserRes = z.TypeOf<typeof ActivateStatusUserRes>;

//vas
export type IVasListRes = z.TypeOf<typeof VasListRes>;
export type IVasDetailRes = z.TypeOf<typeof VasDetailRes>;
export type IVasCategoriesRes = z.TypeOf<typeof VasCategoriesRes>;
export type IVasDetail = z.TypeOf<typeof Vas>;

//swap-sim
export type IShowroomSwapSim = z.TypeOf<typeof ShowroomSwapSim>;
export type IBannerSwapSim = z.TypeOf<typeof BannerSwapSim>;
export type IBannerSwapSimRes = z.TypeOf<typeof BannerSwapSimRes>;
export type IFaqs = z.TypeOf<typeof Faqs>;
export type IFaqsRes = z.TypeOf<typeof FaqsRes>;
export type IShowroomSwapSimRes = z.TypeOf<typeof ShowroomSwapSimRes>;
export type IDevicesSwapSimRes = z.TypeOf<typeof DevicesSwapSimRes>;
export type IDeviceDetail = z.TypeOf<typeof DeviceDetail>;
export type ISwapApproveRes = z.TypeOf<typeof SwapApproveRes>;
export type IEnterInfoFormRes = z.TypeOf<typeof EnterInfoFormRes>;
export type IRequestOtpFormRes = z.TypeOf<typeof RequestOtpFormRes>;
export type IReceivingMethodFormRes = z.TypeOf<typeof ReceivingMethodFormRes>;
export type IFormsSwapSimRes = z.TypeOf<typeof FormsSwapSimRes>;
export type IFormsSwapSim = z.TypeOf<typeof FormsSwapSim>;
export type ActivateStatusUser = z.TypeOf<typeof ActivateStatusUser>;
