#!/usr/bin/env bash
set -Ex

function apply_path {

    echo "Check that we have ENVIROMENT_VAR vars"
    test -n "$NEXT_PUBLIC_API_ENDPOINT"
    test -n "$NEXT_PUBLIC_URL_ENV"
    find /usr/src/app/.next \( -type d -name .git -prune \) -o -type f -print0 | xargs -0 sed -i "s#NEXT_PUBLIC_API_ENDPOINT_ENV#$NEXT_PUBLIC_API_ENDPOINT#g"
    find /usr/src/app/.next \( -type d -name .git -prune \) -o -type f -print0 | xargs -0 sed -i "s#NEXT_PUBLIC_URL_ENV#$NEXT_PUBLIC_URL#g"
    find /usr/src/app/.next \( -type d -name .git -prune \) -o -type f -print0 | xargs -0 sed -i "s#NEXT_PUBLIC_CMS_URL_ENV#$NEXT_PUBLIC_CMS_URL#g"
    find /usr/src/app/.next \( -type d -name .git -prune \) -o -type f -print0 | xargs -0 sed -i "s#MINIO_ACCESS_KEY_ENV#$MINIO_ACCESS_KEY#g"
    find /usr/src/app/.next \( -type d -name .git -prune \) -o -type f -print0 | xargs -0 sed -i "s#MINIO_SECRET_KEY_ENV#$MINIO_SECRET_KEY#g"
}

apply_path
echo "Starting Nextjs"
exec "$@"