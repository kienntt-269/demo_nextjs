import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: ["class"],
  content: [
    "./src/module/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      opacity: {
        "16": "0.16",
        "35": "0.35",
        "65": "0.65",
      },
      colors: {
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",
        card: {
          DEFAULT: "hsl(var(--card))",
          foreground: "hsl(var(--card-foreground))",
        },
        popover: {
          DEFAULT: "hsl(var(--popover))",
          foreground: "hsl(var(--popover-foreground))",
        },
        neutral: {
          DEFAULT: "hsl(var(--neutral))",
          900: "#000000",
        },
        "neutral-dark": {
          "01": "#000000",
          "02": "#212121",
          "03": "#333333",
          "04": "#616161",
        },
        "neutral-mid": {
          "01": "#A2A2A2",
        },
        neutral2: {
          DEFAULT: "hsl(var(--neutral2))",
        },
        neutral3: {
          DEFAULT: "hsl(var(--neutral3))",
        },
        "neutral-light": {
          DEFAULT: "hsl(var(--neutral-light))",
        },
        "neutral-light2": {
          DEFAULT: "hsl(var(--neutral-light2))",
        },
        "neutral-dark3": {
          DEFAULT: "hsl(var(--neutral-dark3))",
        },
        "neutral-dark2": {
          DEFAULT: "hsl(var(--neutral-dark2))",
        },
        "background-content": {
          DEFAULT: "hsl(var(--background-content))",
        },
        "text-primary": {
          DEFAULT: "hsl(var(--text-primary))",
        },
        "viettel-red": {
          DEFAULT: "hsl(var(--viettel-red))",
        },
        online: {
          DEFAULT: "hsl(var(--online))",
        },
        error: {
          DEFAULT: "hsl(var(--error))",
          foreground: "hsl(var(--error-foreground))",
        },
        primary: {
          DEFAULT: "hsl(var(--primary))",
          foreground: "hsl(var(--primary-foreground))",
        },
        secondary: {
          DEFAULT: "hsl(var(--secondary))",
          foreground: "hsl(var(--secondary-foreground))",
        },
        muted: {
          DEFAULT: "hsl(var(--muted))",
          foreground: "hsl(var(--muted-foreground))",
        },
        accent: {
          DEFAULT: "hsl(var(--accent))",
          foreground: "hsl(var(--accent-foreground))",
        },
        destructive: {
          DEFAULT: "hsl(var(--destructive))",
          foreground: "hsl(var(--destructive-foreground))",
        },
        border: "hsl(var(--border))",
        input: "hsl(var(--input))",
        ring: "hsl(var(--ring))",
        chart: {
          "1": "hsl(var(--chart-1))",
          "2": "hsl(var(--chart-2))",
          "3": "hsl(var(--chart-3))",
          "4": "hsl(var(--chart-4))",
          "5": "hsl(var(--chart-5))",
        },
      },
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
      },
      boxShadow: {
        filterPopover: "0px 4px 16px 0px #00000029",
        "input-custom": "0px 3.09px 12.37px 0px #00000014",
        "box-custom": "0px 3.09px 12.37px 0px #00000014",
      },
      keyframes: {
        "accordion-down": {
          from: {
            height: "0",
          },
          to: {
            height: "var(--radix-accordion-content-height)",
          },
        },
        "accordion-up": {
          from: {
            height: "var(--radix-accordion-content-height)",
          },
          to: {
            height: "0",
          },
        },
        "caret-blink": {
          "0%,70%,100%": { opacity: "1" },
          "20%,50%": { opacity: "0" },
        },
      },
      animation: {
        "accordion-down": "accordion-down 0.2s ease-out",
        "accordion-up": "accordion-up 0.2s ease-out",
        "caret-blink": "caret-blink 1.25s ease-out infinite",
      },
      backgroundImage: {
        "exclusive-benefits":
          "url('/mobile-package/exclusive_benefits_natcom.png')",
      },
      gridTemplateColumns: {
        "7fr-3fr": "7fr 3fr",
        "1fr-3fr": "1fr 3fr",
      },
    },
  },
  // eslint-disable-next-line @typescript-eslint/no-require-imports
  plugins: [require("tailwindcss-animate")],
};
export default config;
