"use client";
import TitleStyle from "@/components/title-common";
import { Button } from "@/components/ui/button";
import { useTranslations } from "next-intl";
import Image from "next/image";
import React, { useEffect, useState } from "react";
import mobileApiRequest from "@/services/mobile-service";
import { IDataPlan } from "@/schemaValidations/mobile-service.schema";
import { ISimCard } from "@/schemaValidations/sim-card.schema";
import simApiRequest from "@/services/sim-service";
import { useLangStore } from "@/_stores/useLang.store";
import ComponentWithTooltip from "@/components/component-with-tooltip";
import { formatTimeWithDay } from "@/lib/utils";

interface IProps {
  idSim?: string;
  idPackage?: string;
  typeError?: string | null;
  paymentMethod?: string;
  paymentTarget?: "data" | "sim";
  orderId?: string;
}

const PaymentError = ({
  idPackage,
  idSim,
  typeError,
  paymentTarget = "sim",
  paymentMethod,
  orderId,
}: IProps) => {
  const t = useTranslations();
  const { lang } = useLangStore();
  const formattedTime = formatTimeWithDay(t, new Date());
  const [dataPackage, setDataPackage] = useState<IDataPlan>();
  const [simDetail, setSimDetail] = useState<ISimCard>();

  const renderTextError = () => {
    switch (typeError) {
      case "REGISTER_FAILED":
        return t("mobile_package.sim_normal.payment_success_register_fail");
      default:
        return t("mobile_package.sim_normal.you_will_receive_qr_esim");
    }
  };

  const getDataPackage = async () => {
    try {
      const res = await mobileApiRequest.getDetailData(idPackage ?? "");
      setDataPackage(res.payload.data);
    } catch (error) {
      console.log(error);
    }
  };

  const getSimCard = async () => {
    try {
      const res = await simApiRequest.getSimDetail(idSim ?? "");
      setSimDetail(res.payload.data);
    } catch (error) {
      console.log(error);
    }
  };

  const simTypeChange = (type: number) => {
    switch (type) {
      case 1:
        return t("mobile_package.sim_normal.xchange_sim");
      case 2:
        return t("mobile_package.sim_normal.student_sim");
      case 3:
        return t("mobile_package.sim_normal.dcom_sim");
      default:
        return t("mobile_package.sim_normal.xchange_sim");
    }
  };

  useEffect(() => {
    if (idPackage) {
      getDataPackage();
    }
    if (idSim) getSimCard();
  }, [lang]);

  const renderPaymentMethod = () => {
    switch (paymentMethod) {
      case "in_store":
        return t("payment.pay_at_store");
      case "natcash":
        return t("payment.natcash");
      case "natcom":
        return t("payment.main_account");
      default:
        return "";
    }
  };

  return (
    <div className="flex w-full justify-center py-10">
      <div className="max-w-[768px] flex flex-col items-center w-full gap-y-6 bg-white shadow-box-custom p-8 rounded-3xl">
        <Image
          src={"/images/icon/check-error.svg"}
          quality={100}
          unoptimized
          height={64}
          width={64}
          alt=""
        />
        <div className="">
          <TitleStyle classStyle="max-sm:leading-8 text-center">
            {t("mobile_package.sim_normal.order_creation_failed")}
          </TitleStyle>
          <div className="text-neutral-dark-04 text-[14px] font-normal text-center mt-4">
            {/* 21:22:05 Monday 03/22/2025 */}
            {formattedTime}
          </div>
        </div>
        <div className="w-full">
          <div className="w-full rounded-2xl p-4 bg-[#F5F6F7]">
            {idSim && (
              <>
                <div className="flex items-center justify-between h-9">
                  <div>{t("mobile_package.sim_normal.sim_card")}</div>
                  <div className="font-bold text-neutral-dark-02">
                    {simDetail?.isdn}
                  </div>
                </div>
                <div className="flex items-center justify-between h-9">
                  <div>{t("mobile_package.sim_normal.sim_type")}</div>
                  <div className="font-bold text-neutral-dark-02">
                    {simTypeChange(simDetail?.type ?? 1)}
                  </div>
                </div>
              </>
            )}
            {idPackage && (
              <>
                <div className="flex items-center justify-between h-9 gap-x-4">
                  <div className="whitespace-nowrap w-40">
                    {t("payment.plan_name")}
                  </div>
                  <ComponentWithTooltip content={dataPackage?.name}>
                    <div className="font-bold text-neutral-dark-02 overflow-hidden text-ellipsis whitespace-nowrap max-w-full text-right">
                      {dataPackage?.name}
                    </div>
                  </ComponentWithTooltip>
                </div>
                <div className="flex items-center justify-between h-9">
                  <div>{t("payment.order_id")}</div>
                  <div className="font-bold text-neutral-dark-02">
                    {orderId}
                  </div>
                </div>
              </>
            )}
            <div className="flex items-center justify-between h-9">
              <div>{t("common.price")}</div>
              <div className="font-bold text-neutral-dark-02">
                {Number(dataPackage?.price ?? 0).toLocaleString("en-US")}{" "}
                {t("mobile_package.htg")}
              </div>
            </div>
            <div className="flex items-center justify-between h-9">
              <div>{t("payment.payment_method")}</div>
              <div className="font-bold text-neutral-dark-02">
                {renderPaymentMethod()}
              </div>
            </div>
          </div>
          {paymentTarget === "sim" && (
            <div className="mt-4 text-neutral-dark-04 text-center">
              {renderTextError()}
            </div>
          )}
        </div>
        <Button className="px-14" navigate="/">
          {t("mobile_package.sim_normal.back_to_homepage")}
        </Button>
      </div>
    </div>
  );
};

export default PaymentError;
