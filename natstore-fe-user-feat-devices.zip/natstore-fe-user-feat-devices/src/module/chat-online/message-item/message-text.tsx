import { setURL } from "@/lib/utils";
import Image from "next/image";

interface MessageProps {
  avatar: string;
  text?: string;
  image?: string;
  time: string;
  isOwnMessage: boolean;
  isHeaderMessage?: boolean;
  isFinalMessage?: boolean;
}

export default function MessageText({
  avatar,
  text,
  image,
  time,
  isOwnMessage,
  // isFinalMessage,
  // isHeaderMessage,
}: MessageProps) {
  // const links = getUrlLinks(text ?? "");
  // let classStyle = "";
  // if (isOwnMessage) {
  //   classStyle = " rounded-l-2xl ";
  //   if (isHeaderMessage) {
  //     classStyle += " rounded-br-2xl ";
  //   }

  //   if (isFinalMessage) {
  //     classStyle += " rounded-tr-2xl ";
  //   }
  // } else {
  //   classStyle = " rounded-r-2xl ";
  //   if (isHeaderMessage) {
  //     classStyle += " rounded-bl-2xl ";
  //   }

  //   if (isFinalMessage) {
  //     classStyle += " rounded-tl-2xl ";
  //   }
  // }
  return (
    <div
      className={`flex ${isOwnMessage ? "justify-end" : "justify-start"} my-2 items-start`}
    >
      {!isOwnMessage && (
        <div className="relative w-10 h-10 mr-2">
          <Image
            src={avatar}
            alt="Avatar"
            fill
            className="rounded-full object-cover"
          />
        </div>
      )}

      <div>
        <div
          className={`py-2 px-3 rounded-xl max-w-[270px] ${
            !isOwnMessage
              ? "bg-[#f5f5f5] text-black rounded-es-none"
              : "bg-gradient-content-chat text-white rounded-ee-none"
          }`}
        >
          {text && (
            <div>
              <span
                style={{ wordBreak: "break-word" }}
                className="text-sm inline-block whitespace-pre-wrap tracking-[-0.3px] break-words"
                dangerouslySetInnerHTML={{ __html: setURL(text || "") }}
              />
            </div>
          )}

          {image && (
            <div className="mt-1 relative w-48 h-48">
              <Image
                src={image}
                alt="Image"
                fill
                className="rounded-lg object-cover"
              />
            </div>
          )}
        </div>
        <div
          className={`text-xs text-neutral mt-1 ${isOwnMessage ? "text-right" : "text-left"}`}
        >
          {time}
        </div>
      </div>
    </div>
  );
}
