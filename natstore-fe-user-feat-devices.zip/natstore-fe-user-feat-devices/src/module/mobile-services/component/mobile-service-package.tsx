"use client";
import React, { useEffect, useState } from "react";
import CarouselData from "@/components/common/carousel-data/carousel-data";
import { Skeleton } from "@/components/ui/skeleton";
import {
  DataPlansTypeList,
  IDataPlan,
} from "@/schemaValidations/mobile-service.schema";
import mobileCategoriesApiRequest from "@/services/mobile-service-categories";
import { useIsMobile } from "@/hooks/use-mobile";
import { getCardComponent } from "@/module/getCardComponent";
import NoDataAvailable from "@/components/common/no-data-available/no-data-available";
import { useLangStore } from "@/_stores/useLang.store";

type IProp = {
  getId: number;
  type: number;
};

const MobileServicesPackage = ({ getId, type }: IProp) => {
  const { lang } = useLangStore();
  const [listDataMobileService, setListDataMobileService] =
    useState<DataPlansTypeList>();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const getData = async () => {
    setLoading(true);
    setError(false);
    try {
      const res = await mobileCategoriesApiRequest.getDataChildren(getId);
      setListDataMobileService(res.payload);
      setTimeout(() => {
        setLoading(false);
      }, 300);
    } catch (error) {
      console.error("Failed to fetch data:", error);
      setError(true);
      setLoading(false);
    }
  };
  useEffect(() => {
    getData();
  }, [getId, lang]);
  const isMobile = useIsMobile();
  if (loading) {
    return (
      <div className="flex">
        {Array(isMobile ? 2 : 4)
          .fill(null)
          .map((_, index) => (
            <Skeleton
              key={index}
              className="md:h-[306px] h-[257px] w-[371px] mt-6 mr-6 rounded-3xl"
            />
          ))}
      </div>
    );
  }

  if (error || !listDataMobileService?.data?.length) {
    return <NoDataAvailable />;
  }

  return (
    <div className="mt-6 max-md:mt-3">
      <CarouselData
        quantity={4}
        length={listDataMobileService?.data?.length || 0}
        quantityMobile={2}
      >
        {listDataMobileService?.data?.map((val: IDataPlan) =>
          getCardComponent(type.toString(), val),
        )}
      </CarouselData>
    </div>
  );
};

export default MobileServicesPackage;
