import { XSRF_TOKEN } from "@/constants/authority";
import { NextRequest, NextResponse } from "next/server";
// This function can be marked `async` if using `await` inside
const privatePaths = ["/personal"];
export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;
  const sessionToken = request.cookies.get(XSRF_TOKEN)?.value;

  if (pathname.startsWith("/mobile-package/swap-sim")) {
    return NextResponse.redirect(new URL("/", request.url));
  }

  // Chưa đăng nhập thì không cho vào private paths
  if (privatePaths.some((path) => pathname.startsWith(path)) && !sessionToken) {
    return NextResponse.redirect(new URL("/", request.url));
  }

  const paymentRouteRegex = /^\/mobile-package\/data\/[^/]+\/payment$/;

  if (paymentRouteRegex.test(pathname)) {
    if (!sessionToken) {
      return NextResponse.redirect(new URL("/", request.url));
    } else {
      return NextResponse.next();
    }
  }

  // if (authPaths.some((path) => pathname.startsWith(path)) && sessionToken) {
  //   return NextResponse.redirect(new URL('/me', request.url))
  // }
  // if (pathname.match(productEditRegex) && !sessionToken) {
  //   return NextResponse.redirect(new URL('/', request.url))
  // }
  return NextResponse.next();
}

// See "Matching Paths" below to learn more
export const config = {
  matcher: [
    "/",
    "/personal",
    "/mobile-package/data/:slug/payment",
    "/mobile-package/swap-sim/:path*",
  ],
};
