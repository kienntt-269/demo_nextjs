import { create } from "zustand";

export const useDialogAuthStore = create<{
  mode: "LOGIN" | "REGISTER" | "FORGOT" | "LOGOUT";
  isOpen: boolean;
  urlLoginSuccess: string;
  setIsOpen: ({
    isOpen,
    mode,
  }: {
    isOpen?: boolean;
    mode?: "LOGIN" | "REGISTER" | "FORGOT" | "LOGOUT";
  }) => void;
  setUrlLoginSuccess: (endpoint: string) => void;
}>((set) => ({
  mode: "LOGIN",
  isOpen: false,
  urlLoginSuccess: "/",
  setIsOpen: (newState) => set((state) => ({ ...state, ...newState })),
  setUrlLoginSuccess: (endpoint) =>
    set((state) => ({ ...state, urlLoginSuccess: endpoint })),
}));
