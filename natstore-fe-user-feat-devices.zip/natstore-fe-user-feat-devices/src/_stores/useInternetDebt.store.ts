import { SEARCH_TYPE_PAYMENT_PACKAGE } from "@/constants/common";
import { IDataDebtDetail } from "@/schemaValidations/internet.shema";
import { create } from "zustand";

export const useInternetDebtStore = create<{
  internetDebt: IDataDebtDetail[] | undefined;
  searchKey: string;
  searchType: string;
  clear: () => void;
  setInternetDebt: ({
    data,
    searchType,
    searchKey,
  }: {
    data?: IDataDebtDetail[] | undefined;
    searchType?: string;
    searchKey?: string;
  }) => void;
}>((set) => ({
  internetDebt: undefined,
  searchType: SEARCH_TYPE_PAYMENT_PACKAGE.NUMBER_ACCOUNT,
  searchKey: "",
  clear: () =>
    set(() => ({
      internetDebt: undefined,
      searchType: SEARCH_TYPE_PAYMENT_PACKAGE.NUMBER_ACCOUNT,
      searchKey: "",
    })),
  setInternetDebt: ({
    data,
    searchType,
    searchKey,
  }: {
    data?: IDataDebtDetail[] | undefined;
    searchType?: string;
    searchKey?: string;
  }) =>
    set((state) => ({
      internetDebt: data || state.internetDebt,
      searchType: searchType || state.searchType,
      searchKey: searchKey || state.searchKey,
    })),
}));
