import { IDevicePreOrder } from "@/schemaValidations/device.schema";
import { IDeviceStore } from "@/types/stores";
import { create } from "zustand";

export const useDeviceStore = create<IDeviceStore>((set) => ({
  data: undefined,
  setData: (data: IDevicePreOrder) => set({ data: data }),
}));
