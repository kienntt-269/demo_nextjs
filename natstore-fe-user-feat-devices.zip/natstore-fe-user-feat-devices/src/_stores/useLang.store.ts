import { defaultLocale, Locale } from "@/i18n/config";
import { create } from "zustand";

export const useLangStore = create<{
  lang: Locale;
  setLang: (lang: Locale) => void;
}>((set) => ({
  lang: defaultLocale,
  setLang: (lang: Locale) => set((state) => ({ ...state, lang })),
}));
