import * as React from "react";
import PageContent from "@/components/page-content";
import HomePageContent from "@/module/home-page/home-page-content";
import ModalCatalog from "@/components/modal-catalog";
import BannerHomePage from "@/module/home-page/banner-home-page";

export const dynamic = "force-dynamic";

export default function HomePage() {
  return (
    <div>
      <PageContent>
        <BannerHomePage />
        <HomePageContent />
      </PageContent>
      <ModalCatalog />
    </div>
  );
}
