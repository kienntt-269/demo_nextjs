import React from "react";

export default function Custom500() {
  return <h1>Oops! Something went wrong on the server.</h1>;
}
