import CarouselData from "@/components/common/carousel-data/carousel-data";
import { getImageUrl } from "@/constants/imageUrl";
import { truncateText } from "@/lib/utils";
import { ICustomerSupportStatic } from "@/schemaValidations/customer-support.schema";
import Image from "next/image";
import Link from "next/link";
import React from "react";

type FaqsTabsProps = {
  classProps?: string;
  serviceTab: ICustomerSupportStatic[];
  active?: string;
};

const FaqsTabs = ({
  classProps = "",
  serviceTab,
  active = serviceTab[0]?.name,
}: FaqsTabsProps) => {
  return (
    <div
      className={`${classProps} w-full md:gap-4 gap-2 mt-4 lg:mt-8 bg-white rounded-3xl`}
    >
      <CarouselData
        customClass="p-4"
        quantity={6}
        quantityMobile={3}
        length={serviceTab.length}
        isShowPaging={false}
      >
        {serviceTab.map((item) => {
          return (
            <Link
              href={`?name=frequently_asked_questions&tabFaqs=${item.name}`}
              key={item.id}
              scroll={false}
            >
              <div
                className={`${active === item.name || (!active && item.id === serviceTab[0].id) ? "bg-[#FF860029]" : ""} flex flex-col justify-center group h-full items-center gap-2 lg:gap-4 pt-4 pb-4 lg:pb-[22px] w-full rounded-2xl`}
              >
                <Image
                  src={item?.imagePath ? getImageUrl(item.imagePath) : "/"}
                  alt="img content"
                  width={48}
                  height={48}
                  className="group-hover:scale-105 md:h-12 md:w-12 w-6 h-6 object-contain"
                />
                <div className="font-bold text-xs md:text-lg text-center xl:text-xl ">
                  {truncateText(item.name ?? "", 30)}
                </div>
              </div>
            </Link>
          );
        })}
      </CarouselData>
    </div>
  );
};

export default FaqsTabs;
