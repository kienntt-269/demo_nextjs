import { NextRequest, NextResponse } from "next/server";
import envConfig from "@/config";
import { cookies } from "next/headers";
import { XSRF_TOKEN } from "@/constants/authority";

export async function GET(
  req: NextRequest,
  { params }: { params: { endpoint: string[] } }
) {
  const cookieStore = cookies();
  const accessToken = cookieStore.get(XSRF_TOKEN)?.value;
  const query = req.nextUrl.searchParams.toString();
  const endpointPath = params.endpoint.join("/");
  const url = `${envConfig.NEXT_PUBLIC_API_ENDPOINT}/${endpointPath}${query ? `?${query}` : ""}`;
  const headers = req.headers;
  if (accessToken && !endpointPath.includes("/public")) {
    headers.set("Authorization", `Bearer ${accessToken}`);
  }
  try {
    const res = await fetch(url, {
      method: "GET",
      headers: headers,
    });
    const data = await res.json();
    return NextResponse.json(data, { status: res.status });
  } catch (error) {
    console.error("Proxy GET error:", error);
    return NextResponse.json(
      { error: "Internal Server Error" },
      { status: 500 }
    );
  }
}

export async function POST(
  req: NextRequest,
  { params }: { params: { endpoint: string[] } }
) {
  const cookieStore = cookies();
  const accessToken = cookieStore.get(XSRF_TOKEN)?.value;
  const query = req.nextUrl.searchParams.toString();
  const endpointPath = params.endpoint.join("/");
  const url = `${envConfig.NEXT_PUBLIC_API_ENDPOINT}/${endpointPath}${query ? `?${query}` : ""}`;
  const headers = req.headers;
  if (accessToken) {
    headers.set("Authorization", `Bearer ${accessToken}`);
  }

  try {
    const res = await fetch(url, {
      method: "POST",
      headers: headers,
      body: req.body ? req.body : undefined,
      duplex: "half",
    } as RequestInit);

    const data = await res.json();
    return NextResponse.json(data, { status: res.status });
  } catch (error) {
    console.error("Proxy POST error:", error);
    return NextResponse.json(
      { error: "Internal Server Error" },
      { status: 500 }
    );
  }
}

export async function PUT(
  req: NextRequest,
  { params }: { params: { endpoint: string[] } }
) {
  const cookieStore = cookies();
  const accessToken = cookieStore.get(XSRF_TOKEN)?.value;
  const query = req.nextUrl.searchParams.toString();
  const endpointPath = params.endpoint.join("/");
  const url = `${envConfig.NEXT_PUBLIC_API_ENDPOINT}/${endpointPath}${query ? `?${query}` : ""}`;
  const headers = req.headers;
  if (accessToken) {
    headers.set("Authorization", `Bearer ${accessToken}`);
  }

  try {
    const res = await fetch(url, {
      method: "PUT",
      headers: headers,
      body: req.body ? req.body : undefined,
      duplex: "half",
    } as RequestInit);

    const data = await res.json();
    return NextResponse.json(data, { status: res.status });
  } catch (error) {
    console.error("Proxy PUT error:", error);
    return NextResponse.json(
      { error: "Internal Server Error" },
      { status: 500 }
    );
  }
}

export async function DELETE(
  req: NextRequest,
  { params }: { params: { endpoint: string[] } }
) {
  const cookieStore = cookies();
  const accessToken = cookieStore.get(XSRF_TOKEN)?.value;
  const query = req.nextUrl.searchParams.toString();
  const endpointPath = params.endpoint.join("/");
  const url = `${envConfig.NEXT_PUBLIC_API_ENDPOINT}/${endpointPath}${query ? `?${query}` : ""}`;
  const headers = req.headers;
  if (accessToken) {
    headers.set("Authorization", `Bearer ${accessToken}`);
  }

  try {
    const res = await fetch(url, {
      method: "DELETE",
      headers: headers,
      body: req.body ? req.body : undefined,
    } as RequestInit);

    const data = await res.json();
    return NextResponse.json(data, { status: res.status });
  } catch (error) {
    console.error("Proxy DELETE error:", error);
    return NextResponse.json(
      { error: "Internal Server Error" },
      { status: 500 }
    );
  }
}
