"use client";
import _ from "lodash";
import CarouselData from "@/components/common/carousel-data/carousel-data";
import PageContent from "@/components/page-content";
import EmptySearch from "@/module/search/empty-search";
import FilterSearch from "@/module/search/filter-search";
import {
  ISearchHome,
  ITypePackage,
  ITypeSearchInternet,
  ITypeSearchMobiles,
} from "@/schemaValidations/search-home.schema";
import searchHomeApiRequest from "@/services/search-home";
import { useTranslations } from "next-intl";
import { useRouter, useSearchParams } from "next/navigation";
import React, { useEffect, useState } from "react";
import { getCardComponent } from "@/module/getCardComponent";
import { Skeleton } from "@/components/ui/skeleton";
import NoDataAvailable from "@/components/common/no-data-available/no-data-available";
import { useLangStore } from "@/_stores/useLang.store";
import CardInfo from "@/components/card-info";
import { IDataInternet } from "@/schemaValidations/internet.shema";
const SearchPage = () => {
  const searchParams = useSearchParams();
  const { lang } = useLangStore();
  const name = searchParams.get("key") || "";
  const [listDataResult, setListDataResult] = useState<ISearchHome>();
  const [listDataFilter, setListDataFilter] = useState<ISearchHome>();
  const [totalParent, setTotalParent] = useState([0, 0, 0]);
  const [loading, setLoading] = useState(true);
  const t = useTranslations();
  const router = useRouter();
  const newParams = new URLSearchParams(searchParams);

  const listParent = [
    {
      params: "packages",
      name: t("search.packages"),
    },
    {
      params: "device",
      name: t("search.device"),
    },
    {
      params: "news",
      name: t("search.news"),
    },
  ];

  const handleClickParent = (value: string) => {
    newParams.set("parent", value);
    router.push(`/search?${newParams.toString()}`, { scroll: false });
  };

  const getData = async () => {
    try {
      setLoading(true);
      const res = await searchHomeApiRequest.getDataSearchHome(
        encodeURIComponent(name.trim())
      );
      setListDataResult(res.payload.data);
      const totalInternet =
        res.payload.data.searchPackages.searchInternets.reduce(
          (sum, category) => sum + category.internets.length,
          0
        );

      const totalMobile = res.payload.data.searchPackages.searchMobiles.reduce(
        (sum, category) => sum + category.mobiles.length,
        0
      );
      setTotalParent([totalInternet + totalMobile, 0, 0]);
      setTimeout(() => {
        setLoading(false);
      }, 300);
    } catch (error) {
      console.log(error);
      throw Error("error");
    }
  };
  useEffect(() => {
    getData();
    if (!searchParams.get("parent")) {
      newParams.set("parent", "packages");
      router.push(`/search?${newParams.toString()}`, { scroll: false });
    }
  }, [name, lang]);

  useEffect(() => {
    const categorizeKey = searchParams.get("categorize");
    const sortBy = searchParams.get("sort_by");

    if (!listDataResult) return;

    const newData = _.cloneDeep(listDataResult);

    if (categorizeKey === "lastest") {
      newData.searchPackages.searchInternets =
        newData.searchPackages.searchInternets.map((category) => ({
          ...category,
          internets: [...category.internets].sort((a, b) => {
            const dateA = a.updatedAt ? new Date(a.updatedAt).getTime() : 0;
            const dateB = b.updatedAt ? new Date(b.updatedAt).getTime() : 0;
            return dateB - dateA;
          }),
        }));

      newData.searchPackages.searchMobiles =
        newData.searchPackages.searchMobiles.map((category) => ({
          ...category,
          mobiles: [...category.mobiles].sort((a, b) => {
            const dateA = a.updatedAt ? new Date(a.updatedAt).getTime() : 0;
            const dateB = b.updatedAt ? new Date(b.updatedAt).getTime() : 0;
            return dateB - dateA;
          }),
        }));
    }

    if (sortBy) {
      newData.searchPackages.searchInternets =
        newData.searchPackages.searchInternets.map((category) => ({
          ...category,
          internets: [...category.internets].sort((a, b) => {
            const priceA = Number(a.price);
            const priceB = Number(b.price);
            return sortBy === "PRICE_ASC" ? priceA - priceB : priceB - priceA;
          }),
        }));

      newData.searchPackages.searchMobiles =
        newData.searchPackages.searchMobiles.map((category) => ({
          ...category,
          mobiles: [...category.mobiles].sort((a, b) => {
            const priceA = Number(a.price);
            const priceB = Number(b.price);
            return sortBy === "PRICE_ASC" ? priceA - priceB : priceB - priceA;
          }),
        }));
    }

    setListDataFilter(newData);
  }, [searchParams.toString(), listDataResult]);

  if (loading) {
    return (
      <>
        <div className="text-[32px] text-center font-bold m-6">
          {t("search.search_result")}
        </div>
        <div className="flex">
          <Skeleton className="h-[413px] max-w-[1032px] w-full mx-auto rounded-3xl pt-8 mb-20" />
        </div>
      </>
    );
  }

  return (
    <div>
      <PageContent>
        {!listDataResult?.searchPackages.searchInternets.length &&
        !listDataResult?.searchPackages.searchMobiles.length ? (
          <div>
            <EmptySearch searchKey={name || ""} />
          </div>
        ) : (
          <div className="w-full relative">
            {" "}
            <div className="hidden md:block">
              <div className="text-[32px] text-center font-bold mb-6">
                {t("search.search_result")}
              </div>
              <div className="sm:absolute top-0 right-0 flex justify-center mb-6">
                <FilterSearch />
              </div>
            </div>
            <div className="md:hidden gap-4 flex justify-between items-center mb-2 md:mb-6">
              <div className="text-xl flex-1 text-start font-bold  ">
                {t("search.search_result")}
              </div>
              <div className=" justify-center">
                <FilterSearch />
              </div>
            </div>
            <div className="md:mb-10 flex items-center gap-x-4 md:justify-center md:mt-6 max-md:gap-x-2 max-md:mt-2 w-full overflow-x-scroll no-scrollbar">
              {listParent.map((item, index) => (
                <div
                  key={item.name}
                  onClick={() => handleClickParent(item.params)}
                  className={`${item.params === searchParams.get("parent") ? "text-primary bg-[#FF860029] flex items-center gap-x-2" : "bg-[#E3E4E599] text-neutral-dark-04"} px-5 py-2 cursor-pointer rounded-3xl  font-bold text-[20px] max-xl:text-[16px] max-md:text-[14px] leading-6 whitespace-nowrap`}
                >
                  {item.params === searchParams.get("parent") && (
                    <div className="bg-primary size-2 rounded-full"></div>
                  )}{" "}
                  {item.name} ({totalParent?.[index] || 0})
                </div>
              ))}
            </div>
            {searchParams.get("parent") === "packages" ? (
              <div>
                {listDataFilter?.searchPackages.searchMobiles.map(
                  (item: ITypeSearchMobiles, index: number) =>
                    item.mobiles.length !== 0 && (
                      <div key={`${index}_mobiles`}>
                        <div className="font-bold text-base md:text-2xl mb-3 md:mb-6 mt-6 md:mt-10">
                          {item.category.name} ({item.mobiles.length})
                        </div>
                        <CarouselData
                          quantity={4}
                          length={item.mobiles?.length || 0}
                          quantityMobile={2}
                        >
                          {item.mobiles.map((val: ITypePackage) => (
                            <div key={val.id}>
                              {getCardComponent(item.category.type, val)}
                            </div>
                          ))}
                        </CarouselData>
                      </div>
                    )
                )}
                {listDataFilter?.searchPackages?.searchInternets.map(
                  (item: ITypeSearchInternet, index: number) =>
                    item.internets.length !== 0 && (
                      <div key={`${index}_internets`}>
                        <div className="font-bold text-base md:text-2xl mb-3 md:mb-6 mt-6 md:mt-10">
                          {item.category.name} ({item.internets.length})
                        </div>
                        <CarouselData
                          quantity={4}
                          length={item.internets?.length || 0}
                          quantityMobile={1.5}
                          quantityLg={2.5}
                          quantityMd={2}
                          quantitySm={2}
                          quantityXs={2}
                          quantityXl={3}
                        >
                          {item.internets.map((val: IDataInternet) => (
                            <CardInfo
                              key={val.id}
                              type="medium"
                              data={{
                                id: val.id,
                                name: val.name,
                                price: val.price,
                                speed: val.speed,
                                promotion: val.promotion,
                                note: val.note,
                                slug: val.slug,
                              }}
                            />
                          ))}
                        </CarouselData>
                      </div>
                    )
                )}
              </div>
            ) : (
              <NoDataAvailable />
            )}
          </div>
        )}
      </PageContent>
    </div>
  );
};

export default SearchPage;
