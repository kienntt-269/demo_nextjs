import React from "react";
import { useTranslations } from "next-intl";
import { getImageUrl } from "@/constants/imageUrl";
import ImageCommon from "@/components/common/image-common";
import { cx } from "class-variance-authority";
import ComponentWithTooltip from "@/components/component-with-tooltip";
import { IDeviceDetail } from "@/schemaValidations/device.schema";
import Link from "next/link";

type DeviceProps = {
  data: IDeviceDetail;
};

const formatNumber = (num: number) => {
  return num < 1000 ? num.toString() : num.toLocaleString("en-US");
};

const DeviceItem = ({ data }: DeviceProps) => {
  const t = useTranslations();

  return (
    <Link key={data.slug} href={`/device/${data.categoryId}/${data.slug}`}>
      <div className="bg-white shadow hover:shadow-lg transition-shadow rounded-3xl h-full">
        <ImageCommon
          src={data?.imagePath ? getImageUrl(data.imagePath) : "/"}
          alt="bon_info"
          width={504}
          height={290}
          className={cx("max-sm:h-[175px] w-full h-[290px] rounded-t-2xl", {
            "object-contain": data?.imagePath != "/",
          })}
        />
        <div className="flex flex-col p-4 lg:p-6">
          <div className="grow">
            <h2 className="text-sm lg:text-2xl font-bold truncate text-black">
              <ComponentWithTooltip content={data?.name}>
                <div className="text-[24px] leading-[24px] max-sm:text-base max-xl:text-[18px] max-2xl:text-[20px] font-bold overflow-hidden text-ellipsis whitespace-nowrap">
                  {data?.name}
                </div>
              </ComponentWithTooltip>
            </h2>
            <div className="flex gap-2 mt-3 max-md:mt-1 mb-4 text-primary">
              <p className="text-base lg:text-2xl font-bold">
                {formatNumber(Number(data.price))}
              </p>
              <p className="text-base lg:text-2xl font-bold">
                {t("mobile_package.htg")}
              </p>
            </div>
            <p className="text-sm lg:text-sm text-neutral-dark-04 line-clamp-2 break-words">
              {data.description ?? ""}
            </p>
          </div>
        </div>
      </div>
    </Link>
  );
};

export default DeviceItem;
