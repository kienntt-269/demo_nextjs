import ImageCommon from "@/components/common/image-common";
import { Button } from "@/components/ui/button";
import { getImageUrl } from "@/constants/imageUrl";
import { IDevicePreOrder } from "@/schemaValidations/device.schema";
import { cx } from "class-variance-authority";
import { useTranslations } from "next-intl";
import { useRouter } from "next/navigation";
import React from "react";

type OrderDeviceType = {
  searchParams: { [key: string]: string | undefined };
  data?: IDevicePreOrder;
};

const OrderDevice = ({ data, searchParams }: OrderDeviceType) => {
  console.log("🚀 ~ OrderDevice ~ searchParams:", searchParams);
  const t = useTranslations("");
  const router = useRouter();
  return (
    <div>
      <div className="text-[28px] font-bold max-md:text-[20px]">
        {t("common.order")}
      </div>
      <div className="mt-8 max-md:mt-6 pb-6 text-[16px] text-neutral-dark-02">
        <div className="flex items-center border-b border-solid border-[#E3E4E5]">
          <div className="relative w-[80px] h-[80px] py-[17px]">
            <ImageCommon
              src={data?.imagePath ? getImageUrl(data.imagePath) : "/"}
              alt="Preview"
              fill
              className={cx("object-cover rounded-2xl", {
                "object-contain": data?.imagePath != "/",
              })}
            />
          </div>
          <div className="ml-4 flex-1">
            <div className="text-base md:text-xl font-bold text-black py-2">
              {data?.name}
            </div>
            <div className="py-2 flex justify-between items-center text-sm md:text-base text-[#212121]">
              <div>{t("common.color")}</div>
              <div className="text-base font-bold">{data?.color}</div>
            </div>
            <div className="py-2 flex justify-between items-center text-sm md:text-base text-[#212121]">
              <div>{t("common.quantity")}</div>
              <div className="text-base font-bold">{data?.quantity}</div>
            </div>
          </div>
        </div>
        <div className="list-item list-disc ml-5 text-sm lg:text-base text-[#212121] py-[17.5px]">
          {t("search.device")}: SUMO Phone
        </div>
        <div className="pt-8 pb-4 my-4 flex justify-between items-center text-base text-[#212121] border-t border-solid border-[#E3E4E5]">
          <div>{t("common.shipping_fee")}</div>
          <div className="font-bold">0</div>
        </div>
        <div className="py-4 flex justify-between items-center text-base text-end text-[#212121]">
          <div>{t("common.total")}</div>
          <div className="">
            <div className="max-md:text-xl max-md:text-black font-bold mb-[2px]">
              {data?.price} {t("internet.htg")}
            </div>
            <div className="font-normal text-[#A2A2A2] text-sm">
              ( {t("internet.included_VAT")} )
            </div>
          </div>
        </div>
      </div>
      <div className="flex flex-col items-center gap-2 lg:gap-4">
        <Button
          className="w-full font-bold rounded-3xl py-[12px]"
          type="submit"
        >
          {t("mobile_package.sim_normal.pre_order")}
        </Button>
        <Button
          className="w-full font-bold rounded-3xl py-[12px]"
          variant="secondary"
          onClick={() => router.back()}
        >
          {t("common.back")}
        </Button>
      </div>
    </div>
  );
};

export default OrderDevice;
