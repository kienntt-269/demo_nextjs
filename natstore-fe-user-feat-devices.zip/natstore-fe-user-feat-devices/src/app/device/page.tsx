import { ILinks } from "@/types/package";
import BreadCrumbCommon from "@/components/breadcrumb-common";
import { getTranslations } from "next-intl/server";
import PageContent from "@/components/page-content";
import BannerHomePage from "@/module/home-page/banner-home-page";
import TabDeviceList from "@/app/device/_components/tab-device-list";
import { IDeviceCategories } from "@/schemaValidations/device.schema";
import devicesApiRequest from "@/services/devices";
export const dynamic = "force-dynamic";
type DeviceProps = {
  params: { slug: string };
  searchParams: { [key: string]: string | undefined };
};

const getDeviceCategories = async () => {
  try {
    const res = await devicesApiRequest.getCategoryProduct();
    return res.payload.data;
  } catch (error) {
    console.log(error);
    throw Error("error");
  }
};

const getDevice = async (slug: string) => {
  try {
    const res = await devicesApiRequest.getProduct({
      category: slug,
      page: 1,
      size: 100,
      // sort: "ratePoint_desc",
    });
    return res.payload.data;
  } catch (error) {
    console.log(error);
    throw Error("error");
  }
};

export default async function Device({ searchParams }: DeviceProps) {
  console.log("🚀 ~ Device ~ searchParams:", searchParams);
  const categories = await getDeviceCategories();
  const deviceCategories: IDeviceCategories[] = await Promise.all(
    categories.map(async (category) => {
      const deviceTop3Rate = await getDevice(category.id);
      return {
        ...category,
        children: deviceTop3Rate,
      };
    })
  );

  const t = await getTranslations();

  const breadCrumb: ILinks[] = [
    {
      label: t("personal.home"),
      link: "/",
    },
    {
      label: t("search.device"),
      link: "/device",
    },
  ];

  return (
    <PageContent>
      <BannerHomePage />
      <BreadCrumbCommon content={breadCrumb} />
      {deviceCategories.map((deviceCategory) => (
        <div key={deviceCategory.id}>
          <TabDeviceList data={deviceCategory} />
        </div>
      ))}
    </PageContent>
  );
}
