import PageContent from "@/components/page-content";
import BannerHomePage from "@/module/home-page/banner-home-page";
import DeviceSort from "@/app/device/_components/device-sort";
export const dynamic = "force-dynamic";
type DeviceSlugPageProps = {
  params: { deviceSlug: string };
  searchParams: { [key: string]: string | undefined };
};

export default function DeviceSlugPage({ params }: DeviceSlugPageProps) {
  return (
    <PageContent>
      <BannerHomePage />
      <DeviceSort categorySlug={params.deviceSlug} />
    </PageContent>
  );
}
