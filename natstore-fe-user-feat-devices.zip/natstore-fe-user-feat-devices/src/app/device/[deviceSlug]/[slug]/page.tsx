import ImageGallery from "@/app/device/_components/image-gallery";
import PreOrderDevice from "@/app/device/_components/pre-oder-device";
import BreadCrumbCommon from "@/components/breadcrumb-common";
import PageContent from "@/components/page-content";
import { Button } from "@/components/ui/button";
import BannerHomePage from "@/module/home-page/banner-home-page";
import { IDeviceDetail } from "@/schemaValidations/device.schema";
import devicesApiRequest from "@/services/devices";
import { ILinks } from "@/types/package";
import { getTranslations } from "next-intl/server";
import React from "react";

const getDetailDevice = async (idOrSlug: string) => {
  try {
    const res = await devicesApiRequest.getDetailProduct(idOrSlug);
    return res.payload.data;
  } catch (error) {
    console.log(error);
    throw Error("error");
  }
};

const DevicesDetailPage = async ({
  params,
  searchParams,
}: {
  params: { slug: string };
  searchParams: { [key: string]: string | undefined };
}) => {
  const t = await getTranslations();
  // const deviceDetail: IDeviceDetail = await getDetailDevice(params.slug);
  const deviceDetail: IDeviceDetail = await getDetailDevice(String(7));
  const breadCrumb: ILinks[] = [
    {
      label: t("personal.home"),
      link: "/",
    },
    {
      label: t("search.device"),
      link: "/device",
    },
    {
      label: `${searchParams}`,
      link: `/device/${params.slug}/${searchParams}`,
    },
  ];

  return (
    <PageContent>
      <BannerHomePage />
      <BreadCrumbCommon content={breadCrumb} />
      <div className="mt-10 mb-14">
        <div className="flex flex-col xl:flex-row justify-center gap-4 lg:gap-6 p-4 lg:pt-12 lg:pb-8 bg-white shadow hover:shadow-lg transition-shadow rounded-3xl">
          <div className="flex-1 2xl:py-9">
            <ImageGallery images={JSON.parse(deviceDetail?.listImagePath)} />
          </div>
          <div className="flex-1">
            <PreOrderDevice data={deviceDetail} />
          </div>
        </div>
        <div className="p-4 my-8 lg:p-8 bg-white shadow hover:shadow-lg transition-shadow rounded-3xl">
          <h2 className="text-base lg:text-2xl font-bold text-black">
            {t("phone_device.product_highlights")}
          </h2>
          <div className="my-4">
            {deviceDetail?.productHighlights?.map((item) => (
              <div
                key={item}
                className="list-item list-disc ml-5 text-[#616161] text-sm lg:text-base"
              >
                {item}
              </div>
            ))}
          </div>
          <div className="w-full flex-1">
            <div className="flex justify-end">
              <Button
                className="flex-1 font-bold rounded-3xl text-sm lg:text-base max-w-[125px] lg:max-w-[212px] ml-auto"
                variant="secondary"
              >
                {t("common.see_more_detail")}
              </Button>
            </div>
          </div>
        </div>
        <div className="mb-2.5 bg-[#f5f6f7]">
          <h3 className="text-size-32 font-bold mb-3 lg:mb-6">
            {t("phone_device.similar_products")}
          </h3>
          {/* <CarouselData quantity={4} length={deviceListSimila?.length}>
            {deviceListSimila?.map((data) => (
              <DeviceItem key={data.slug} data={data} />
            ))}
          </CarouselData> */}
        </div>
      </div>
    </PageContent>
  );
};

export default DevicesDetailPage;
