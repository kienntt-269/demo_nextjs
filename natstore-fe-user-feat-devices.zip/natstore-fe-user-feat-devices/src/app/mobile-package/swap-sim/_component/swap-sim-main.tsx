import React from "react";
import { useTranslations } from "next-intl";
import Image from "next/image";
import PageContent from "@/components/page-content";
import { Button } from "@/components/ui/button";
import {
  IBannerSwapSim,
  IFaqs,
} from "@/schemaValidations/mobile-package.schema";
import Link from "next/link";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { getImageUrl } from "@/constants/imageUrl";
import ImageCommon from "@/components/common/image-common";
import NoDataAvailable from "@/components/common/no-data-available/no-data-available";

export type ProtabitityType = {
  id: number;
  icon: string;
  title: string;
  button: string;
  navigate: string;
};

type SwapSimMainProps = {
  banners: IBannerSwapSim;
  faqs: IFaqs;
};

const SwapSimMain = ({ banners, faqs }: SwapSimMainProps) => {
  const t = useTranslations("mobile_package.swap_sim");
  const protabitityList: ProtabitityType[] = [
    {
      id: 1,
      icon: "/mobile-package/store_front.png",
      title: t("the_nearset_transaction"),
      button: "",
      navigate: "",
    },
    {
      id: 2,
      icon: "/mobile-package/store_front.png",
      title: t("register_on_website"),
      button: t("go_registration"),
      navigate: "/mobile-package/swap-sim/register",
    },
    {
      id: 3,
      icon: "/mobile-package/phone_transfer.png",
      title: t("register_my_natcom"),
      button: t("click_download"),
      navigate:
        "https://play.google.com/store/apps/details?id=com.vtg.app.mynatcom&hl=vi",
    },
    {
      id: 4,
      icon: "/mobile-package/phone.png",
      title: t("call_hotline"),
      button: t("22228888"),
      navigate: "tel:+" + t("22228888"),
    },
  ];

  const conversionProcesss = [
    {
      id: 1,
      icon: "/mobile-package/email.png",
      desc: t("sim_conversion_1"),
    },
    {
      id: 2,
      icon: "/mobile-package/data-package.png",
      desc: t("sim_conversion_2"),
    },
    {
      id: 3,
      icon: "/mobile-package/data-package.png",
      desc: t("sim_conversion_3"),
    },
    {
      id: 4,
      icon: "/mobile-package/data-package.png",
      desc: t("sim_conversion_4"),
    },
    {
      id: 5,
      icon: "/mobile-package/data-package.png",
      desc: t("sim_conversion_5"),
    },
  ];

  return (
    <div className="bg-[#F5F6F7]">
      <PageContent className="pb-6 lg:pb-10">
        <div className="flex flex-col justify-center items-center bg-white rounded-3xl py-8 max-md:pb-0">
          <div className="grid grid-cols-1 px-4">
            <h2 className="font-bold text-xl lg:text-size-32 text-black text-center">
              {t("title_number_protabitity")}
            </h2>
            <div className="text-dark my-6 text-center max-w-[907px]">
              {t("desc_number_protabitity")}
            </div>
          </div>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 px-4">
            {protabitityList.map((protabitity: ProtabitityType) => (
              <div
                key={protabitity.id}
                className="bg-[#F5F6F7] flex flex-col py-6 px-4 lg:px-6 lg:max-w-[288px] rounded-2xl"
              >
                <Image
                  unoptimized
                  quality={100}
                  src={protabitity.icon}
                  width={32}
                  height={32}
                  alt="price image"
                  className=""
                />
                <p className="mt-4 mb-2 text-base font-bold text-black">
                  {protabitity.title}
                </p>
                <Link
                  href={protabitity?.navigate || "#"}
                  className="text-primary whitespace-normal block text-sm font-bold underline-offset-1 underline justify-start"
                  target={
                    protabitity?.navigate.startsWith("https://")
                      ? "_blank"
                      : "_self"
                  }
                >
                  {protabitity.button}
                </Link>
              </div>
            ))}
          </div>
          <div className="flex flex-wrap lg:flex-nowrap lg:flex-row-reverse justify-center lg:justify-between items-center gap-2 lg:gap-8 mt-6 max-lg:my-4">
            <Button
              className="min-w-[244px] rounded-3xl"
              navigate="/mobile-package/swap-sim/register"
              variant="default"
            >
              {t("swap_sim_now")}
            </Button>
            <Button
              className="min-w-[244px] rounded-3xl"
              navigate="/mobile-package/swap-sim/compatible-equipment"
              variant="secondary"
            >
              {t("compatible_equipment")}
            </Button>
          </div>
        </div>
      </PageContent>
      <div className="block md:hidden">
        <ImageCommon
          src={
            banners[0].bannerImageWap
              ? getImageUrl(banners[0].bannerImageWap)
              : "url(/mobile-package/exclusive_benefits_natcom.png)"
          }
          alt="banner image"
          unoptimized
          quality={100}
          width={450}
          height={702}
          className="w-full h-[702px]"
        />
      </div>
      <div className="hidden md:block">
        <ImageCommon
          src={
            banners[0].bannerImageWeb
              ? getImageUrl(banners[0].bannerImageWeb)
              : "url(/mobile-package/exclusive_benefits_natcom.png)"
          }
          alt="banner image"
          unoptimized
          quality={100}
          width={1920}
          height={540}
          className="h-[540px] max-md:h-auto"
        />
      </div>
      <PageContent className="py-0">
        <div className="flex flex-col justify-center items-center mt-6 lg:mt-4 bg-[linear-gradient(185.98deg,#E8632A_-67.53%,#252120_133.47%)] rounded-3xl">
          <h2 className="font-bold text-xl lg:text-size-32 py-6 text-white">
            {t("sim_conversion")}
          </h2>
          <div className="relative flex justify-between flex-col lg:flex-row gap-[29px] px-8 md:px-0">
            {conversionProcesss.map((conversionProcess) => (
              <div
                key={conversionProcess.id}
                className="flex justify-between items-center flex-row lg:flex-col 2xl:w-[193px] gap-4"
              >
                <div className=" bg-[#F5F6F7] w-[56px] h-[56px] lg:w-[84px] lg:h-[84px] rounded-[50%] flex justify-center items-center z-10">
                  <Image
                    src={conversionProcess.icon}
                    width={24}
                    height={24}
                    alt={conversionProcess.desc}
                  />
                </div>
                <p className="flex-1 text-xs font-bold text-white lg:text-center">
                  {conversionProcess.desc}
                </p>
              </div>
            ))}
            <div className="hidden sm:block absolute right-0">
              <Image
                src="/images/icon/Flag.svg"
                alt="flag"
                width={62}
                height={43}
              />
            </div>
            <div className="block sm:hidden absolute bottom-0 left-[60px] w-[2px] h-[100%] z-5 bg-white"></div>
            <div className="hidden sm:block absolute left-16 top-[42px] w-[84%] h-[2px] z-5 bg-white"></div>
          </div>
          <Button
            className="w-[244px] my-6 border-none bg-white"
            navigate="/mobile-package/swap-sim/register"
            variant="secondary"
          >
            {t("register_now")}
          </Button>
        </div>
        <div className="flex flex-col justify-center items-center bg-white mt-6 lg:mt-10 lg:mb-[28px] p-4 rounded-3xl">
          <h2 className="font-bold text-xl lg:text-size-32 mb-4">{t("faq")}</h2>
          <div className="flex flex-col w-full">
            {!!faqs.length ? (
              faqs.map((faq, index) => (
                <div
                  key={faq.id}
                  className="border-solid border-[1px] border-[#C5C5C5] rounded-lg mb-4 "
                >
                  <Accordion type="single" collapsible>
                    <AccordionItem value={faq.id}>
                      <AccordionTrigger className="!no-underline px-6 py-3 text-xs md:text-[14px] font-bold">
                        {index + 1}. {faq.question}
                      </AccordionTrigger>
                      <AccordionContent className="px-6 text-xs md:text-[14px] font-bold whitespace-pre-line">
                        {faq.answer}
                      </AccordionContent>
                    </AccordionItem>
                  </Accordion>
                </div>
              ))
            ) : (
              <NoDataAvailable />
            )}
          </div>
        </div>
      </PageContent>
    </div>
  );
};

export default SwapSimMain;
