import RequestForm from "@/app/mobile-package/swap-sim/sim-change-request-form/_components/request-form";
import BreadCrumbCommon from "@/components/breadcrumb-common";
import PageContent from "@/components/page-content";
import BannerHomePage from "@/module/home-page/banner-home-page";
import { ILinks } from "@/types/package";
import { useTranslations } from "next-intl";

export const dynamic = "force-dynamic";

export default function SimChangeRequestSimPage() {
  const t = useTranslations();
  const breadCrumb: ILinks[] = [
    {
      label: t("personal.home"),
      link: "/",
    },
    {
      label: t("mobile_package.roaming.mobile_service"),
      link: "/mobile-package",
    },
    {
      label: t("mobile_package.swap_sim.title"),
      link: "/mobile-packages/swap-sim",
    },
    {
      label: t("mobile_package.swap_sim.sim_change"),
      link: "/mobile-packages/swap-sim/sim-change-request-form",
    },
  ];
  return (
    <PageContent className="!pb-0">
      <BannerHomePage />
      <BreadCrumbCommon content={breadCrumb} />
      <div className="mt-6">
        <RequestForm />
      </div>
    </PageContent>
  );
}
