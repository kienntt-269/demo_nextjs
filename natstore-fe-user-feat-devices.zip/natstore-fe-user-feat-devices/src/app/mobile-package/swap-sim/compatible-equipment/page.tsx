import RenderContent from "@/app/mobile-package/swap-sim/compatible-equipment/_component/render-content";
import BreadCrumbCommon from "@/components/breadcrumb-common";
import TabsCommon from "@/components/common/tabs/tabs";
import mobilePackageApiRequest from "@/services/mobile-package";
import { ILinks, ITabs } from "@/types/package";
import { getTranslations } from "next-intl/server";
import React from "react";

export const dynamic = "force-dynamic";

type CompatibleEquipmentProps = {
  params: { slug: string };
  searchParams: { [key: string]: string | undefined };
};

const getDevices = async () => {
  try {
    const res = await mobilePackageApiRequest.getDevices();
    return res.payload.data;
  } catch (error) {
    console.log(error);
    throw Error("error");
  }
};

const CompatibleEquipment = async ({
  searchParams,
}: CompatibleEquipmentProps) => {
  const t = await getTranslations();
  const devices = await getDevices();
  const breadCrumb: ILinks[] = [
    {
      label: t("personal.home"),
      link: "/",
    },
    {
      label: t("mobile_package.roaming.mobile_service"),
      link: "/mobile-package",
    },
    {
      label: t("mobile_package.swap_sim.title"),
      link: "/mobile-packages/swap-sim",
    },
  ];

  const tabs: ITabs[] = devices?.map((device) => ({
    id: device.brandName,
    label: device.brandName,
    content: <RenderContent data={device.devices} />,
    params: `/mobile-package/swap-sim/compatible-equipment?name=${device.brandName}`,
  }));

  return (
    <div className="px-4 w-full max-w-[1604px] mx-auto bg-[#F5F6F7]">
      <div className="mb-8">
        <BreadCrumbCommon content={breadCrumb} />
      </div>
      <div className="bg-[#FFFFFF] rounded-3xl max-sm:min-h-[896px] min-h-[812px] mb-8">
        <div className="flex flex-col justify-center items-center">
          <h2 className="font-bold text-xl lg:text-size-32 mt-8 text-black">
            {t("mobile_package.swap_sim.compatible_equipment")}
          </h2>
          <div className="text-sm lg:text-base text-neutral-dark-03 py-6 text-center">
            <div className="">
              {t("mobile_package.swap_sim.compatible_equipment_desc_1")}
            </div>
            <div className="">
              {t("mobile_package.swap_sim.compatible_equipment_desc_2")}
            </div>
          </div>
        </div>
        <TabsCommon
          data={tabs}
          defaultTab={searchParams.name as string}
          textLength={20}
        />
      </div>
    </div>
  );
};

export default CompatibleEquipment;
