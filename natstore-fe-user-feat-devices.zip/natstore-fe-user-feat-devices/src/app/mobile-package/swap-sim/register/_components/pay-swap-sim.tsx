import { useLoadingStore } from "@/_stores/useLoading,store";
import { useStepsStore } from "@/_stores/useSteps.store";
import { useSwapSimStore } from "@/_stores/useSwapSwim.store";
import TitleStyle from "@/components/title-common";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { FAIL_CODE7, SUCCESS_CODE3 } from "@/constants/http-response";
import { toastError } from "@/hooks/use-toast";
import mobilePackageApiRequest from "@/services/mobile-package";
import { PaymentMethodOption } from "@/types/swap-sim";
import { useTranslations } from "next-intl";
import React, { useState } from "react";

export default function PaySwapSim() {
  const t = useTranslations("mobile_package.swap_sim");
  const { setIsLoading } = useLoadingStore();
  const nextStep = useStepsStore((state) => state.nextStep);
  const dataFormSwapSim = useSwapSimStore((state) => state.data);
  const requestId = useSwapSimStore((state) => state.requestId);

  const optionRadios: PaymentMethodOption[] = [
    {
      label: t("natcom_payment"),
      value: "0",
    },
    {
      label: t("natcash"),
      value: "1",
    },
  ];
  const [optionRadio, setOptionRadio] = useState<string>(optionRadios[0].value);

  const handleSubmit = async () => {
    try {
      if (requestId) {
        setIsLoading(true);
        const res = await mobilePackageApiRequest.paySwapSim(requestId, {
          paymentMethod: Number(optionRadio),
        });
        if (res.payload.code === FAIL_CODE7) {
          toastError(res.payload.message);
          return;
        }
        if (res.payload.code === SUCCESS_CODE3) {
          nextStep();
        }
      }
    } catch (error) {
      console.log("🚀 ~ handleSubmit ~ error:", error);
      toastError(t("common.error"));
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="">
      <TitleStyle classStyle="!text-[28px]">
        {t("sim_conversion_fee")}
      </TitleStyle>
      <div className="flex flex-col gap-2 lg:flex-row lg:justify-between lg:items-center py-3">
        <div className="text-sm lg:text-xl flex-1">{t("phone")}</div>
        <div className="flex-1 font-bold text-sm lg:text-xl">
          {dataFormSwapSim?.phoneNumber}
        </div>
      </div>
      <div className="flex flex-col gap-2 lg:flex-row lg:justify-between lg:items-center py-3">
        <div className="text-sm lg:text-xl flex-1">{t("service")}</div>
        <div className="flex-1 font-bold text-sm lg:text-xl">{t("title")}</div>
      </div>
      <div className="flex flex-col gap-2 lg:flex-row lg:justify-between lg:items-center py-3">
        <div className="text-sm lg:text-xl flex-1">{t("total_amount")}</div>
        <div className="flex-1 font-bold text-sm lg:text-xl">
          100 {t("htg")}
        </div>
      </div>
      <div className="bg-[#E3E4E5] h-[1px] w-full"></div>
      <div className="my-6">
        <div className="text-sm lg:text-xl font-bold text-black">
          {t("payment_method")}
        </div>
        <RadioGroup
          onValueChange={(value) => setOptionRadio(value)}
          className="mt-4 flex flex-col lg:flex-row gap-2 lg:gap-4"
          defaultValue={optionRadios[0].value}
        >
          {optionRadios.map((item) => (
            <div
              key={item.value}
              className={`flex-1 cursor-pointer border-2 border-solid text-base py-3 px-6 rounded-xl ${optionRadio === item.value ? "bg-[#FFEBD6] border-[#FF8600]" : "text-neutral-dark-04 bg-[#F5F6F7] border-[#E3E4E5]"}`}
            >
              <div className="flex items-center">
                <RadioGroupItem value={item.value} id={item.value} />
                <label
                  className={`ml-2 ${optionRadio === item.value ? "text-primary font-bold" : ""}`}
                  htmlFor={item.value}
                >
                  {item.label}
                </label>
              </div>
            </div>
          ))}
        </RadioGroup>
      </div>
      <div className="flex justify-center mt-2">
        <Button
          onClick={handleSubmit}
          className="w-[100%] lg:w-[212px] rounded-3xl"
        >
          {t("pay")}
        </Button>
      </div>
    </div>
  );
}
