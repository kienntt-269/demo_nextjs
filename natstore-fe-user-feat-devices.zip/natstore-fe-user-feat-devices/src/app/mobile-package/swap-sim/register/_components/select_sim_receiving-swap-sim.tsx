"use client";

import { useLoadingStore } from "@/_stores/useLoading,store";
import { useStepsStore } from "@/_stores/useSteps.store";
import { useSwapSimStore } from "@/_stores/useSwapSwim.store";
import { Form, InputField, TOption } from "@/components/form";
import RadioButtonField from "@/components/form/radio-button-field";
import TitleStyle from "@/components/title-common";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { FAIL_CODE6, SUCCESS_CODE3 } from "@/constants/http-response";
import { toastError } from "@/hooks/use-toast";
import { HttpError } from "@/lib/http";
import {
  SelectSimReceiving,
  SelectSimReceivingType,
} from "@/schemaValidations/swap-sim.schema";
import mobilePackageApiRequest from "@/services/mobile-package";
import { AddressReceiveOption } from "@/types/swap-sim";
import { useTranslations } from "next-intl";
import React, { useEffect, useState } from "react";
import { Controller } from "react-hook-form";

const getShowroom = async () => {
  try {
    const res = await mobilePackageApiRequest.getShowrooms();
    return res.payload.data;
  } catch (error: unknown) {
    console.log(error);
    throw Error("error: " + error);
  }
};

export default function SelectSimReceivingSwapSim() {
  const t = useTranslations("mobile_package.swap_sim");
  const { setIsLoading } = useLoadingStore();
  const [showroom, setShowroom] = useState<TOption[]>([]);
  const nextStep = useStepsStore((state) => state.nextStep);
  const nextStepWithNumber = useStepsStore((state) => state.nextStepWithNumber);
  const dataFormSwapSim = useSwapSimStore((state) => state.data);
  console.log(
    "🚀 ~ SelectSimReceivingSwapSim ~ dataFormSwapSim:",
    dataFormSwapSim
  );
  const requestId = useSwapSimStore((state) => state.requestId);

  const optionRadios: AddressReceiveOption[] = [
    {
      label: t("showroom"),
      value: "showroom",
    },
    {
      label: t("email"),
      value: "email",
    },
  ];

  const handleSubmit = async (data: SelectSimReceivingType) => {
    if (data.type !== "eSIM") {
      nextStepWithNumber(3);
    } else {
      nextStep();
    }
    try {
      if (requestId) {
        setIsLoading(true);
        const _data = {
          phoneNumber: dataFormSwapSim?.phoneNumber || "",
          emailAddress: data.email || "",
          showroomId: Number(data.showroom),
        };
        const res = await mobilePackageApiRequest.receivingMethodSwapSim(
          requestId,
          _data
        );
        if (res.payload.code === FAIL_CODE6) {
          toastError(res.payload.message);
          return;
        }
        if (res.payload.code === SUCCESS_CODE3) {
          if (data.type !== "eSIM") {
            nextStepWithNumber(3);
          } else {
            nextStep();
          }
        }
      }
    } catch (error) {
      console.log({ error });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    getShowroom()
      .then((res) => {
        setShowroom(res.map((item) => ({ label: item.name, value: item.id })));
      })
      .catch((err: HttpError) => {
        console.log("🚀 ~ getShowroom ~ err:", err);
      });
  }, []);

  return (
    <div className="">
      <TitleStyle classStyle="!text-[28px]">{t("how_get_sim")}</TitleStyle>

      <Form<SelectSimReceivingType, typeof SelectSimReceiving>
        schema={SelectSimReceiving}
        onSubmit={handleSubmit}
        options={{
          mode: "onChange",
        }}
        defaultValue={{
          type:
            dataFormSwapSim?.typeOfSim === "0" ? t("physical_sim") : t("esim"),
          // type: "",
          address_receive: "showroom",
          showroom: showroom?.[0]?.value,
          email: "",
        }}
      >
        {({ control, formState: { errors }, watch, setValue }) => {
          if (watch("address_receive") == "showroom") {
            setValue("showroom", showroom?.[0]?.value);
            setValue("email", "");
          } else {
            setValue("showroom", "");
          }

          return (
            <>
              <div className="flex flex-col gap-2 lg:gap-0 lg:flex-row lg:justify-between lg:items-center lg:mb-6 py-3">
                <div className="text-sm lg:text-xl flex-1 text-neutral-dark-01">
                  {t("type_of_sim")}
                </div>
                <div className="flex-1 font-bold text-sm lg:text-xl">
                  {dataFormSwapSim?.typeOfSim === "0"
                    ? t("physical_sim")
                    : t("esim")}
                </div>
              </div>
              {dataFormSwapSim?.typeOfSim === "1" && (
                <div className="flex flex-col lg:flex-row lg:justify-between lg:items-center lg:mb-6 py-3">
                  <div className="text-sm lg:text-xl flex-1 mb-2 lg:mb-0">
                    {t("address_receive")}
                  </div>
                  <RadioButtonField
                    name="address_receive"
                    control={control}
                    options={optionRadios}
                    className="mt-2 lg:mt-0 flex-1 flex items-center"
                  />
                </div>
              )}
              {watch("address_receive") === "email" ? (
                <div className="flex justify-between items-center mb-6 py-3">
                  <div className="text-sm lg:text-xl flex-1">{t("email")}</div>
                  <div className="flex-1">
                    <InputField
                      name="email"
                      maxLength={255}
                      placeholder={t("email_placholder")}
                      type="text"
                      className=""
                      control={control}
                      errors={errors}
                    />
                  </div>
                </div>
              ) : (
                <>
                  {showroom.length ? (
                    <div className="flex flex-col gap-2 lg:gap-0 lg:flex-row lg:justify-between lg:items-center mb-6 py-3">
                      <div className="text-sm lg:text-xl flex-1">
                        {t("select_nearest_showroom")}
                      </div>
                      <div className="flex-1">
                        {/* <SelectField
                          options={showroom}
                          defaultValue={showroom?.[0]?.value}
                          registration={register("showroom")}
                          setValue={(value) => setValue("showroom", value)}
                          error={errors.showroom}
                        /> */}
                        <Controller
                          name="showroom"
                          control={control}
                          render={({ field: { value, onChange } }) => {
                            return (
                              <Select
                                onValueChange={onChange}
                                defaultValue={value}
                              >
                                <SelectTrigger className="flex-1 py-[12px] px-[16px] h-[48px]">
                                  <SelectValue placeholder="Select a showroom" />
                                </SelectTrigger>
                                <SelectContent>
                                  {showroom.map((optionSelect) => (
                                    <SelectItem
                                      key={optionSelect.value}
                                      value={optionSelect.value}
                                    >
                                      {optionSelect.label}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                            );
                          }}
                        />
                      </div>
                    </div>
                  ) : null}
                </>
              )}
              <div className="flex justify-center mt-2">
                <Button
                  type="submit"
                  className="w-[100%] lg:w-[212px] rounded-3xl"
                >
                  {t("next")}
                </Button>
              </div>
            </>
          );
        }}
      </Form>
    </div>
  );
}
