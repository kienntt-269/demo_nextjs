"use client";

import { useStepsStore } from "@/_stores/useSteps.store";
import ConfirmSwapSim from "@/app/mobile-package/swap-sim/register/_components/confirm-swap-sim";
import EnterInfoSwapSim from "@/app/mobile-package/swap-sim/register/_components/enter-info-swap-sim";
import PaySwapSim from "@/app/mobile-package/swap-sim/register/_components/pay-swap-sim";
import SelectSimReceivingSwapSim from "@/app/mobile-package/swap-sim/register/_components/select_sim_receiving-swap-sim";
import BreadCrumbCommon from "@/components/breadcrumb-common";
import Steps from "@/components/common/steps/steps";
import { ILinks } from "@/types/package";
import { useTranslations } from "next-intl";
import React, { useEffect } from "react";

const RegisterSwapSimPage = () => {
  const t = useTranslations();
  const resetSteps = useStepsStore((state) => state.resetSteps);

  const steps = [
    {
      id: 0,
      title: t("mobile_package.swap_sim.enter_info"),
      content: <EnterInfoSwapSim />,
    },
    {
      id: 1,
      title: t("mobile_package.swap_sim.select_sim"),
      content: <SelectSimReceivingSwapSim />,
    },
    { id: 2, title: t("mobile_package.swap_sim.pay"), content: <PaySwapSim /> },
    {
      id: 3,
      title: t("mobile_package.swap_sim.confirm"),
      content: <ConfirmSwapSim />,
    },
  ];

  const breadCrumb: ILinks[] = [
    {
      label: t("personal.home"),
      link: "/",
    },
    {
      label: t("mobile_package.roaming.mobile_service"),
      link: "/mobile-package",
    },
    {
      label: t("mobile_package.swap_sim.title"),
      link: "/mobile-packages/swap-sim",
    },
  ];

  useEffect(() => {
    resetSteps();
  }, [resetSteps]);
  return (
    <div className="mx-auto p-4 lg:p-6">
      <BreadCrumbCommon content={breadCrumb} />
      <h2 className="font-bold text-size-32 text-center mb-10">
        {t("mobile_package.swap_sim.title")}
      </h2>
      <Steps steps={steps} />
    </div>
  );
};

export default RegisterSwapSimPage;
