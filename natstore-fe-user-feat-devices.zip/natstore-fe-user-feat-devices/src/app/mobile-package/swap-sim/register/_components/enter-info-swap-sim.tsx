import { useLoadingStore } from "@/_stores/useLoading,store";
import { useStepsStore } from "@/_stores/useSteps.store";
import { useSwapSimStore } from "@/_stores/useSwapSwim.store";
import OtpModal from "@/app/mobile-package/swap-sim/_component/otp-modal";
import SIMSwapNotSupportedOnlineModal from "@/app/mobile-package/swap-sim/register/_components/sim-swap-not-supported-online-modal";
import { Form, InputField } from "@/components/form";
import DatePickerField from "@/components/form/date-picker-field";
import { InputPhoneNumberField } from "@/components/form/input-phone-number-field";
import RadioButtonField from "@/components/form/radio-button-field";
import UploadFileButtonField from "@/components/form/upload-file-button-field";
import TitleStyle from "@/components/title-common";
import { Button } from "@/components/ui/button";
import {
  FAIL_CODE,
  FAIL_CODE2,
  FAIL_CODE3,
  FAIL_CODE4,
  FAIL_CODE5,
  SUCCESS_CODE3,
} from "@/constants/http-response";
import { toastError } from "@/hooks/use-toast";
import { formatPhoneSubmit } from "@/lib/utils";
import {
  EnterInformationBody,
  EnterInformationType,
  SwapSimForm,
} from "@/schemaValidations/swap-sim.schema";
import mobilePackageApiRequest from "@/services/mobile-package";
import { format } from "date-fns";
import { useTranslations } from "next-intl";
import { useRouter } from "next/navigation";
import React, { useState } from "react";

export default function EnterInfoSwapSim() {
  const t = useTranslations("mobile_package.swap_sim");
  const t2 = useTranslations("");
  const navigate = useRouter();
  const { setIsLoading } = useLoadingStore();
  const nextStep = useStepsStore((state) => state.nextStep);
  const setData = useSwapSimStore((state) => state.setData);
  const dataFormSwapSim = useSwapSimStore((state) => state.data);
  const [isOtpModal, setIsOtpModal] = useState(false);
  const [isNotSupportedOnline, setIsNotSupportedOnline] = useState(false);
  const [error, setError] = useState<string>("");

  const optionRadios = [
    {
      label: t("physical_sim"),
      value: "0",
    },
    {
      label: t("esim"),
      value: "1",
    },
  ];

  const handleSubmit = async (data: EnterInformationType) => {
    data.phoneNumber = formatPhoneSubmit(data.phoneNumber);
    try {
      const res = await mobilePackageApiRequest.requestsOtpSwapSim({
        phoneNumber: data.phoneNumber,
      });
      if (res.payload.code === FAIL_CODE2) {
        setError(t("otp_error_2"));
        toastError(t("otp_error_2"));
        return;
      }
      if (res.payload.code === FAIL_CODE) {
        toastError(t2("common.message.phone.required"));
        return;
      }
      if (res.payload.code === SUCCESS_CODE3) {
        setIsOtpModal(true);
        setData(
          {
            ...data,
          } as SwapSimForm,
          "",
        );
      }
    } catch (error) {
      console.log("🚀 ~ handleSubmit ~ error:", error);
    }
  };

  const handleSubmitWithOtp = async (otp: string) => {
    const data = dataFormSwapSim;
    try {
      setIsLoading(true);
      const formData = new FormData();
      formData.append(
        "request",
        new Blob(
          [
            JSON.stringify({
              phoneNumber: data?.phoneNumber,
              fullname: data?.fullname,
              dob: data?.dob ? format(data.dob, "dd/MM/yyyy") : "",
              identityNumber: data?.identityNumber,
              typeOfSim: Number(data?.typeOfSim),
              otp: otp,
            }),
            // JSON.stringify({
            //   phoneNumber: "912345678",
            //   fullname: "John Doe",
            //   dob: "01/01/1990",
            //   identityNumber: "A123456789",
            //   typeOfSim: 1,
            //   otp: otp,
            // }),
          ],
          { type: "application/json" },
        ),
      );
      data?.files.forEach((file) => {
        formData.append("files", file as File);
      });
      const res = await mobilePackageApiRequest.requestsSwapSim(formData);
      //otp not matched
      if (res.payload.code === FAIL_CODE2) {
        setError(t("otp_error_1"));
        toastError(t("otp_error_1"));
        return;
      }
      //not supported online
      if (res.payload.code === FAIL_CODE3) {
        setIsNotSupportedOnline(true);
        return;
      }
      if (res.payload.code === FAIL_CODE4) {
        setIsOtpModal(false);
        toastError(res.payload.message);
        return;
      }
      //otp not matched
      if (res.payload.code === FAIL_CODE5) {
        setError(res.payload.message);
        toastError(res.payload.message);
        return;
      }
      if (res.payload.code === SUCCESS_CODE3) {
        toastError(res.payload.message);
        if (res.payload.data.matched) {
          setData(
            {
              ...data,
            } as SwapSimForm,
            res.payload.data.requestId,
          );

          nextStep();
        } else {
          // info not match
          navigate.push("/mobile-package/swap-sim/sim-change-request-form");
        }
      }
    } catch (error) {
      console.log({ error });
      toastError(t2("common.error"));
    } finally {
      setIsLoading(false);
    }
  };

  const handleCloseOtp = () => {
    setError("");
    setIsOtpModal(false);
  };

  return (
    <div className="">
      <TitleStyle classStyle="!text-[28px]">{t("enter_info")}</TitleStyle>
      <Form<EnterInformationType, typeof EnterInformationBody>
        schema={EnterInformationBody}
        onSubmit={handleSubmit}
        options={{
          mode: "onChange",
        }}
        defaultValue={
          dataFormSwapSim
            ? {
                ...(dataFormSwapSim as EnterInformationType),
                dob: "",
                files: [],
              }
            : {
                phoneNumber: "",
                fullname: "",
                dob: "",
                identityNumber: "",
                typeOfSim: optionRadios[0]?.value,
                files: [],
              }
        }
      >
        {({ control, formState: { errors } }) => {
          return (
            <div className="flex-shrink-0 w-full">
              <div className="flex flex-col lg:flex-row items-start lg:justify-between lg:items-center py-3">
                <div className="text-sm lg:text-xl flex-1">{t("phone")}</div>
                <div className="flex-1 w-[100%]">
                  <InputPhoneNumberField
                    autoFocus
                    name="phoneNumber"
                    placeholder={t("phone_placholder")}
                    type="text"
                    className="text-sm lg:text-xl"
                    control={control}
                    errors={errors}
                  />
                </div>
              </div>
              <div className="flex flex-col lg:flex-row items-start lg:justify-between lg:items-center py-3">
                <div className="text-sm lg:text-xl flex-1">{t("name")}</div>
                <div className="flex-1 w-[100%]">
                  <InputField
                    name="fullname"
                    placeholder={t("name_placholder")}
                    type="text"
                    className=""
                    control={control}
                    errors={errors}
                  />
                </div>
              </div>
              <div className="flex flex-col lg:flex-row items-start lg:justify-between lg:items-center py-3">
                <div className="text-sm lg:text-xl flex-1 mb-2">
                  {t("date")}
                </div>
                <div className="flex-1 w-[100%]">
                  <DatePickerField
                    name="dob"
                    control={control}
                    errors={errors}
                    placeholder={t("date_placholder")}
                    // className="h-12"
                  />
                </div>
              </div>
              <div className="flex flex-col lg:flex-row items-start lg:justify-between lg:items-center py-3">
                <div className="text-sm lg:text-xl flex-1">{t("passport")}</div>
                <div className="flex-1 w-[100%]">
                  <InputField
                    name="identityNumber"
                    placeholder={t("passport_placholder")}
                    type="text"
                    className=""
                    control={control}
                    errors={errors}
                  />
                </div>
              </div>
              <div className="flex flex-col lg:flex-row items-start lg:justify-between lg:items-center py-3">
                <div className="flex-1">
                  <div className="text-sm lg:text-xl">{t("upload_title")}</div>
                  <div className="text-sm text-neutral-dark-04 mt-2">
                    {t("upload_title_desc")}
                  </div>
                </div>
                <div className="flex-1 w-[100%]">
                  <UploadFileButtonField
                    label={t("upload")}
                    name="files"
                    control={control}
                    errors={errors}
                  />
                </div>
              </div>
              <div className="flex flex-col lg:flex-row items-start lg:justify-between lg:items-center py-3">
                <div className="text-sm lg:text-xl flex-1">
                  {t("type_of_sim")}
                </div>

                <RadioButtonField
                  name="typeOfSim"
                  control={control}
                  options={optionRadios}
                  className="flex-1 flex items-center max-md:mt-2"
                />
              </div>
              <div className="flex justify-center mt-8">
                <Button
                  // onClick={nextStep}
                  type="submit"
                  className="min-w-[212px] rounded-3xl"
                >
                  {t("next")}
                </Button>
              </div>
            </div>
          );
        }}
      </Form>
      {isNotSupportedOnline && (
        <SIMSwapNotSupportedOnlineModal
          isModal={isNotSupportedOnline}
          onClose={() => setIsNotSupportedOnline(false)}
        />
      )}
      {isOtpModal && (
        <OtpModal
          isModal={isOtpModal}
          onSubmit={handleSubmitWithOtp}
          onClose={handleCloseOtp}
          error={error}
          setError={setError}
        />
      )}
    </div>
  );
}
