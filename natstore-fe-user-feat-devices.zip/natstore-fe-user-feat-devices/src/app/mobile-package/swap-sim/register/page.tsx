import RegisterSwapSimPage from "@/app/mobile-package/swap-sim/register/_components/register-page";
import PageContent from "@/components/page-content";
import BannerHomePage from "@/module/home-page/banner-home-page";

export const dynamic = "force-dynamic";

export default function SwapSimPage() {
  return (
    <PageContent>
      <BannerHomePage />
      <RegisterSwapSimPage />
    </PageContent>
  );
}
