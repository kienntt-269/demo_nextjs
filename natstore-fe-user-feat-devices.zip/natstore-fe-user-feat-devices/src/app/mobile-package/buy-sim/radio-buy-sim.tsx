"use client";
import React, { useEffect } from "react";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useTranslations } from "next-intl";
import { useRouter } from "next/navigation";
import TabCommon from "@/components/tabs-common";

const RadioBuySim = ({
  searchParams,
}: {
  searchParams: { [key in string]: string };
}) => {
  const router = useRouter();
  const t = useTranslations();
  const updateSearchParams = (
    newParams: Record<string, string | null> | { [x: string]: boolean }
  ) => {
    const params = new URLSearchParams(searchParams);

    Object.entries(newParams).forEach(([key, value]) => {
      if (value === null) {
        params.delete(key);
      } else {
        params.set(key, value);
      }
    });
    return `?${params.toString()}`;
  };

  const categoriesSim = [
    {
      label: t("mobile_package.swap_sim.physical_sim"),
      type: "physical",
    },
    // {
    //   label: t("mobile_package.esim"),
    //   type: "esim",
    // },
  ];

  useEffect(() => {
    if (!searchParams?.slug) {
      router.replace(`/mobile-package/buy-sim?slug=physical`);
    }
  }, [searchParams]);

  return (
    <div className="flex justify-between items-end max-md:w-full max-lg:flex-col max-lg:items-center">
      <TabCommon
        tabs={categoriesSim}
        // defaultTab={categoriesSim.findIndex(
        //   (item) => item.type === searchParams?.slug
        // )}
        defaultTab={0}
        onChangeTab={(index) => {
          const newparams = updateSearchParams({
            type: "1",
            slug: index === 1 ? "esim" : "physical",
          });
          router.push(newparams, {
            scroll: false,
          });
        }}
      />
      <div className="flex items-end gap-x-8 max-md:gap-x-2 ">
        <div className="text-neutral-mid-01 text-[20px] font-bold max-lg:hidden">
          {t("mobile_package.sim_normal.type_sim")}
        </div>
        <RadioGroup
          defaultValue="register_normal"
          value={searchParams.type ?? "1"}
          className="flex gap-x-8 max-md:gap-x-2 max-md:justify-between max-md:flex-wrap mt-3 max-md:w-full"
          onValueChange={(event) => {
            const newparams = updateSearchParams({
              type: event,
            });
            router.push(newparams, {
              scroll: false,
            });
          }}
        >
          <label
            htmlFor="r1"
            className="flex font-bold text-[20px] items-center space-x-2 cursor-pointer gap-x-2 max-md:gap-x-1 hover:text-primary"
          >
            <RadioGroupItem value="1" id="r1" className="max-md:text-[18px]" />
            <div className="max-md:text-[12px]">
              {t("mobile_package.sim_normal.xchange_sim")}
            </div>
          </label>
          {searchParams.slug === "physical" && (
            <>
              <label
                htmlFor="r2"
                className="flex font-bold text-[20px] items-center space-x-2 cursor-pointer gap-x-2 max-md:gap-x-1 hover:text-primary"
              >
                <RadioGroupItem
                  value="2"
                  id="r2"
                  className="max-md:text-[18px]"
                />
                <div className="max-md:text-[12px]">
                  {t("mobile_package.sim_normal.student_sim")}
                </div>
              </label>
              <label
                htmlFor="r3"
                className="flex font-bold text-[20px] items-center space-x-2 cursor-pointer gap-x-2 max-md:gap-x-1 hover:text-primary"
              >
                <RadioGroupItem
                  value="3"
                  id="r3"
                  className="max-md:text-[18px]"
                />
                <div className="max-md:text-[12px]">
                  {t("mobile_package.sim_normal.dcom_sim")}
                </div>
              </label>
            </>
          )}
        </RadioGroup>
      </div>
    </div>
  );
};

export default RadioBuySim;
