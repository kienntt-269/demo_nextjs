"use client";
import React from "react";
import Modal from "@/components/common/modal/Modal";
import Image from "next/image";
import { Ratings } from "@/components/ui/rating";
import { Button } from "@/components/ui/button";
import { useTranslations } from "next-intl";
import { IDataPlan } from "@/schemaValidations/mobile-service.schema";
import { useSimCardStore } from "@/_stores/useSimCard.store";
import { Check } from "lucide-react";
import ComponentWithTooltip from "@/components/component-with-tooltip";

type ISimDetail = {
  isVisible: boolean;
  onClose: (data: boolean) => void;
  dataPlant?: IDataPlan;
};

const SimDetailModal: React.FC<ISimDetail> = ({
  isVisible,
  onClose,
  dataPlant,
}) => {
  const t = useTranslations();
  const { setPackageData, packageData } = useSimCardStore();
  return (
    <Modal
      isOpen={isVisible}
      onClose={(open) => {
        console.log(open);
        onClose(open);
      }}
      contentClassName="max-w-[1026px] max-md:max-h-3/4 max-h-[962px] px-4 py-4"
      title={t("mobile_package.package_detail")}
    >
      <div>
        <div className="max-h-[560px] overflow-y-auto mt-4 max-md:mt-2">
          <div className="grid grid-cols-4 gap-x-4 max-lg:grid-cols-1 max-lg:gap-2">
            <div className="border-[0.46px] border-solid border-[#DEDEDE] bg-[#F5F6F7] rounded-2xl max-md:rounded-[8px] p-4 max-md:p-[10px] max-md:gap-x-2 flex items-center gap-x-4">
              <div className="size-8 max-md:size-6 flex-shrink-0">
                <Image
                  src={"/mobile-package/phone_mobile.png"}
                  width={32}
                  height={32}
                  unoptimized
                  quality={100}
                  alt="phone"
                  className="object-contain w-full h-full"
                />
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-[12px] max-md:text-[10px] font-normal ">
                  {t("payment.plan_name")}
                </div>
                <ComponentWithTooltip content={dataPlant?.name}>
                  <div className="font-bold text-[16px] max-md:text-[14px] text-neutral-dark-03 overflow-hidden text-ellipsis whitespace-nowrap leading-[21px] cursor-pointer">
                    {dataPlant?.name}
                  </div>
                </ComponentWithTooltip>
              </div>
            </div>
            <div className="border-[0.46px] border-solid border-[#DEDEDE] bg-[#F5F6F7] rounded-2xl max-md:rounded-[8px] p-4 max-md:p-[10px] max-md:gap-x-2 flex items-center gap-x-4">
              <div className="size-8 max-md:size-6 flex-shrink-0">
                <Image
                  src={"/mobile-package/coin-cover.svg"}
                  width={32}
                  height={32}
                  unoptimized
                  quality={100}
                  alt="coin"
                  className="object-contain w-full h-full"
                />
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-[12px] max-md:text-[10px] font-normal">
                  {t("common.price")}
                </div>
                <div className="font-bold flex items-center text-[16px] max-md:text-[14px] text-neutral-dark-03 overflow-hidden text-ellipsis whitespace-nowrap leading-[21px]">
                  <div className="overflow-hidden text-ellipsis whitespace-nowrap">
                    {Number(dataPlant?.price).toLocaleString("en-US")}
                  </div>
                  <span className="ml-1 text-neutral-dark-03">
                    {t("mobile_package.htg")}
                  </span>
                </div>
              </div>
            </div>
            <div className="border-[0.46px] border-solid border-[#DEDEDE] bg-[#F5F6F7] rounded-2xl max-md:rounded-[8px] p-4 max-md:p-[10px] max-md:gap-x-2 flex items-center gap-x-4">
              <div className="size-8 max-md:size-6 flex-shrink-0">
                <Image
                  src={"/mobile-package/calendar.svg"}
                  width={32}
                  height={32}
                  unoptimized
                  quality={100}
                  alt="calendar"
                  className="object-contain w-full h-full"
                />
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-[12px] max-md:text-[10px] font-normal">
                  {t("common.period")}
                </div>
                <div className="font-bold text-[16px] max-md:text-[14px] text-neutral-dark-03 overflow-hidden text-ellipsis whitespace-nowrap leading-[21px]">
                  {dataPlant?.useTimeUnit === "day"
                    ? `${dataPlant.useTimeValue} `
                    : null}
                  {dataPlant?.useTimeUnit === "midnight"
                    ? t("common.midnight")
                    : (dataPlant?.useTimeUnit ? t(`common.${dataPlant?.useTimeUnit}`) : "-")}
                </div>
              </div>
            </div>
            <div className="border-[0.46px] border-solid border-[#DEDEDE] bg-[#F5F6F7] rounded-2xl max-md:rounded-[8px] p-4 max-md:p-[10px] max-md:gap-x-2 flex items-center gap-x-4">
              <div className="size-8 max-md:size-6 flex-shrink-0">
                <Image
                  src={"/mobile-package/like-up.svg"}
                  width={32}
                  height={32}
                  unoptimized
                  quality={100}
                  alt="like"
                  className="object-contain w-full h-full"
                />
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-[12px] max-md:text-[10px] font-normal">
                  {t("mobile_package.rating")}
                </div>
                <div className="flex gap-x-2 max-md:gap-x-1 items-center">
                  <div className="font-bold text-[16px] max-md:text-[14px] text-neutral-dark-03 overflow-hidden text-ellipsis whitespace-nowrap leading-[21px]">
                    <Ratings
                      rating={dataPlant?.rating ?? 0}
                      variant="orange"
                      size={16}
                      className="max-md:hidden flex"
                    />
                    <Ratings
                      rating={dataPlant?.rating ?? 0}
                      variant="orange"
                      size={14}
                      className="max-md:flex hidden"
                    />
                  </div>
                  <span className="text-neutral-dark-04 mt-1 text-[12px] font-normal">
                    ({dataPlant?.ratingCount ?? 0})
                  </span>
                </div>
              </div>
            </div>
          </div>
          {dataPlant?.description && (
            <div className="mt-6 max-md:mt-4">
              <div className="font-bold text-[16px] max-md:text-[14px]">
                {t("personal.information")}
              </div>
              <div className="mt-1 text-[14px] font-normal text-neutral-dark-04 break-all whitespace-pre-line">
                {dataPlant?.description}
              </div>
            </div>
          )}
        </div>

        <div className="flex justify-center">
          <Button
            className={`mt-6 max-w-[420px] w-full rounded-3xl font-semibold ${packageData?.id === dataPlant?.id ? "opacity-50" : "opacity-100"}`}
            onClick={() => {
              setPackageData(dataPlant);
              // if (packageData?.id === dataPlant?.id) {
              //   setPackageData();
              // } else {

              // }
              onClose(false);
            }}
          >
            <div className="flex items-center justify-center gap-x-2">
              {packageData?.id === dataPlant?.id ? <Check /> : <></>}
              {t("personal.select_this_plan")}
            </div>
          </Button>
        </div>
      </div>
    </Modal>
  );
};

export default SimDetailModal;
