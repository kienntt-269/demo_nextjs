import React from "react";
import { ILinks } from "@/types/package";
import BreadCrumbCommon from "@/components/breadcrumb-common";
import PageContent from "@/components/page-content";
import TitleStyle from "@/components/title-common";
import { getTranslations } from "next-intl/server";
import StepSimComponent from "@/app/mobile-package/buy-sim/step-sim";
import RadioBuySim from "@/app/mobile-package/buy-sim/radio-buy-sim";
// import ListSimPackage from "./list-sim-package";
import TableSIM from "@/components/common/table-sim/table-sim";
import simApiRequest from "@/services/sim-service";
import SelectMainPackageSim from "@/app/mobile-package/buy-sim/select-main-package";

export const dynamic = "force-dynamic";

const getDataSim = async (
  page: number | string,
  isdnNumber: string,
  sort: string,
  hotKey: string,
  typeCard: string,
) => {
  try {
    const res = await simApiRequest.getListSim({
      page: page ?? 1,
      size: 10,
      isdnNumber: hotKey ? "" : isdnNumber,
      sort,
      hotKey,
      typeCard,
    });
    return res.payload;
  } catch (error) {
    console.log(error);
    throw Error("error");
  }
};

const getInformationSimType = async (type: string) => {
  try {
    const res = await simApiRequest.getSimTypeDetail(type ?? "1");
    return res.payload;
  } catch (error) {
    console.log(error);
    throw Error("error");
  }
};

const BuySIMPage = async ({
  searchParams,
}: {
  searchParams: { [key in string]: string };
}) => {
  const t = await getTranslations();
  const response = await getDataSim(
    searchParams.page,
    searchParams.isdnNumber,
    searchParams.sortBy,
    searchParams.hotKey,
    searchParams.typeCard,
  );
  const resInformationSim = await getInformationSimType(searchParams.type);

  const breadCrumb: ILinks[] = [
    {
      label: t("personal.home"),
      link: "/",
    },
    {
      label: t("mobile_package.roaming.mobile_service"),
      link: "/mobile-package",
    },
    {
      label: t("mobile_package.swap_sim.buy_sim"),
      link: "/mobile-package/buy-sim",
    },
  ];

  return (
    <PageContent>
      <div className="">
        <BreadCrumbCommon content={breadCrumb} />
      </div>
      <div className="mt-10 max-lg:mt-8 max-md:mt-4">
        <TitleStyle classStyle="text-center">
          {t("mobile_package.swap_sim.buy_sim")}
        </TitleStyle>
        <StepSimComponent />
        <div className="mt-10 max-lg:mt-8 max-md:mt-4">
          <RadioBuySim searchParams={searchParams} />
        </div>
        <div className="mt-10 max-lg:mt-8 max-md:mt-4">
          <TableSIM
            searchParams={searchParams}
            simType={resInformationSim.data}
            response={response}
          />
        </div>
        <SelectMainPackageSim />
      </div>
    </PageContent>
  );
};

export default BuySIMPage;
