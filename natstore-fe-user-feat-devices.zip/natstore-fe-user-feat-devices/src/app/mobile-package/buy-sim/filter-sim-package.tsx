"use client";
import React, { useEffect, useState } from "react";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  ArrowDownRight,
  ArrowUpRight,
  ChevronDown,
  ChevronUp,
} from "lucide-react";
import { useTranslations } from "next-intl";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { usePathname, useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";

interface IProps {
  searchParams: { [key in string]: string };
}

const FilterSimPackage: React.FC<IProps> = ({ searchParams }) => {
  const [isOpen, setIsOpen] = useState<boolean>(false);
  const router = useRouter();
  const t = useTranslations();
  const pathname = usePathname();
  const updateSearchParams = (
    newParams: Record<string, string | null> | { [x: string]: boolean },
  ) => {
    const params = new URLSearchParams(searchParams);

    Object.entries(newParams).forEach(([key, value]) => {
      if (value === null) {
        params.delete(key);
      } else {
        params.set(key, value);
      }
    });
    return `?${params.toString()}`;
  };
  useEffect(() => {
    setIsOpen(false);
  }, [searchParams]);
  return (
    <Popover
      open={isOpen}
      onOpenChange={() => {
        setIsOpen(!isOpen);
      }}
    >
      <PopoverTrigger asChild>
        <button
          className={`py-3 px-5 max-xl:py-2 max-md:px-3 max-md:py-[6px] rounded-3xl ${searchParams.sortBy || searchParams.typeCard ? "bg-[#FF860029]" : "border-[#333333] text-neutral-dark-03 border-solid border"}  flex items-center gap-x-2 max-md:mt-2`}
        >
          {searchParams.sortBy || searchParams.typeCard ? (
            <ChevronUp className="text-[24px] max-xl:size-5 max-md:size-4" />
          ) : (
            <ChevronDown className="text-[24px] max-xl:size-5 max-md:size-4" />
          )}
          <div className="font-semibold max-xl:text-[14px] max-md:text-[12px]">
            {t("common.sort_by")}
          </div>
        </button>
      </PopoverTrigger>
      <PopoverContent className="w-60 rounded-xl border-white shadow-md">
        <div>
          <div className="font-semibold">{t("common.price")}</div>
          <div
            onClick={() => {
              router.push(
                searchParams.sortBy === "price_asc"
                  ? `${pathname}${updateSearchParams({
                      sortBy: "",
                    })}`
                  : `${pathname}${updateSearchParams({
                      sortBy: "price_asc",
                    })}`,
                {
                  scroll: false,
                },
              );
            }}
            className="flex gap-x-[10px] max-md:gap-x-2 text-neutral-dark-04 items-center mt-3 cursor-pointer group"
          >
            <ArrowUpRight
              strokeWidth={1.5}
              className={`group-hover:text-primary ${searchParams.sortBy === "price_asc" ? "text-primary" : ""}`}
            />
            <div
              className={`group-hover:text-primary ${searchParams.sortBy === "price_asc" ? "text-primary" : ""}`}
            >
              {t("mobile_package.low_to_high")}
            </div>
          </div>
          <div
            onClick={() => {
              router.push(
                searchParams.sortBy === "price_desc"
                  ? `${pathname}${updateSearchParams({
                      sortBy: "",
                    })}`
                  : `${pathname}${updateSearchParams({
                      sortBy: "price_desc",
                    })}`,
                {
                  scroll: false,
                },
              );
            }}
            className="flex gap-x-[10px] max-md:gap-x-2 text-neutral-dark-04 items-center mt-4 cursor-pointer group"
          >
            <ArrowDownRight
              strokeWidth={1.5}
              className={`group-hover:text-primary ${searchParams.sortBy === "price_desc" ? "text-primary" : ""}`}
            />
            <div
              className={`group-hover:text-primary ${searchParams.sortBy === "price_desc" ? "text-primary" : ""}`}
            >
              {t("mobile_package.high_to_low")}
            </div>
          </div>
        </div>
        <div className="mt-4">
          <div className="font-semibold">
            {t("mobile_package.sim_normal.sim_type")}
          </div>
          <RadioGroup
            defaultValue="register_normal"
            value={searchParams.typeCard}
            className="flex flex-col gap-y-4 mt-3"
            onValueChange={(event) => {
              const newparams = updateSearchParams({
                typeCard: event,
              });
              router.push(newparams, { scroll: false });
            }}
          >
            <div className="flex items-center space-x-2 cursor-pointer gap-x-2 text-neutral-dark-04 hover:text-primary">
              <RadioGroupItem
                value="Normal"
                id="normal"
                className="max-md:size-[18px]"
              />
              <label htmlFor="normal"> {t("common.normal")}</label>
            </div>
            <div className="flex items-center space-x-2 cursor-pointer gap-x-2 text-neutral-dark-04 hover:text-primary">
              <RadioGroupItem
                value="Special"
                id="special"
                className="max-md:size-[18px]"
              />
              <label htmlFor="special">{t("common.special")}</label>
            </div>
          </RadioGroup>
        </div>
        <div className="mt-2 flex justify-end">
          <Button
            variant={"ghost"}
            onClick={() => {
              router.push(pathname, {
                scroll: false,
              });
            }}
          >
            {t("common.clear")}
          </Button>
        </div>
      </PopoverContent>
    </Popover>
  );
};

export default FilterSimPackage;
