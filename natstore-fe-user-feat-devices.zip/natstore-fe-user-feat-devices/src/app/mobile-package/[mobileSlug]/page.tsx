import FilterDataPackage from "@/app/mobile-package/[mobileSlug]/filter-data";
import BreadCrumbCommon from "@/components/breadcrumb-common";
import CardCommon from "@/components/card-common";
import NoDataAvailable from "@/components/common/no-data-available/no-data-available";
import PageContent from "@/components/page-content";
import TextWithTooltip from "@/components/text-width-tooltip";
import TitleStyle from "@/components/title-common";
import BannerHomePage from "@/module/home-page/banner-home-page";
import SubTabMobile from "@/module/mobile-services/component/sub-tab-mobile";
import { IDataPlan } from "@/schemaValidations/mobile-service.schema";
import mobileApiRequest from "@/services/mobile-service";
import mobileCategoriesApiRequest from "@/services/mobile-service-categories";
import { ILinks } from "@/types/package";
import { getTranslations } from "next-intl/server";
import React from "react";

const getListData = async (
  param: { [key in string]: string },
  searchParams: { [key in string]: string }
) => {
  try {
    const categorize = { [`${searchParams?.categorize}`]: true };
    const res = await mobileApiRequest.getDataMobileService({
      ...searchParams,
      ...categorize,
      ...param,
    });
    return res.payload || [];
  } catch (error) {
    console.log(error);
    throw Error("error");
  }
};

const getDetailMobileService = async (slug: string) => {
  try {
    const res = await mobileCategoriesApiRequest.getMobileServiceDetail(slug);
    return res.payload || [];
  } catch (error) {
    console.log(error);
    throw Error("error");
  }
};

const MobileSlugPage = async ({
  params,
  searchParams,
}: {
  params: { mobileSlug: string };
  searchParams: { [key in string]: string };
}) => {
  const t = await getTranslations();
  const detailCategories = await getDetailMobileService(params.mobileSlug);
  console.log("detailCategories", detailCategories);

  const breadCrumb: ILinks[] = [
    {
      label: t("personal.home"),
      link: "/",
    },
    {
      label: t("mobile_package.roaming.mobile_service"),
      link: "/mobile-package",
    },
    {
      label: (
        <TextWithTooltip content={detailCategories?.data[0]?.name || ""} />
      ),
      link: "/mobile-package/data",
    },
  ];
  const categoryId =
    searchParams.categoryId || detailCategories?.data[0]?.children?.[0]?.id;
  const categorySlug = detailCategories?.data[0]?.slug;
  const response = await getListData(
    categoryId ? { categoryId: categoryId } : { categorySlug: categorySlug },
    { ...searchParams, latest: searchParams?.latest || "true" }
  );
  console.log({ response });
  return (
    <PageContent>
      <BannerHomePage />
      <div className="mt-6">
        <BreadCrumbCommon content={breadCrumb} />
      </div>
      <div className="flex justify-between items-center mt-10 max-md:mt-6">
        <TitleStyle>{detailCategories.data[0]?.name}</TitleStyle>
        <FilterDataPackage searchParams={searchParams} />
      </div>
      <SubTabMobile
        categoriesRes={detailCategories}
        searchParams={searchParams}
      />
      {response?.data.length > 0 ? (
        <div className="mt-6 max-md:mt-3 grid gap-x-6 gap-y-8 grid-cols-4 max-xl:grid-cols-3 max-lg:grid-cols-2 max-md:gap-x-2 max-md:gap-y-3">
          {response?.data?.map((val: IDataPlan) => {
            return (
              <CardCommon
                key={val.id}
                target="data"
                type="medium"
                data={val}
                redirectBuy={`/mobile-package/data/${val.slug}/payment`}
                redirectLink={`/mobile-package/data/${val.slug}`}
              />
            );
          })}
        </div>
      ) : (
        <NoDataAvailable />
      )}
    </PageContent>
  );
};

export default MobileSlugPage;
