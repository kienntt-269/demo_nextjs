"use client";
import { useTranslations } from "next-intl";
import React from "react";
import Image from "next/image";
import { Button } from "@/components/ui/button";
import { IDataPlan } from "@/schemaValidations/mobile-service.schema";
import { useRouter } from "next/navigation";
import TextWithTooltip from "@/components/text-width-tooltip";
import { formatMoney } from "@/lib/utils";
type Props = {
  orderId: string;
  planInfo?: IDataPlan;
  onPay: () => void;
  disable: boolean;
};

const InformationPayment = ({ orderId, planInfo, onPay, disable }: Props) => {
  const t = useTranslations();
  const router = useRouter();
  return (
    <div className="w-full bg-white rounded-3xl p-8 max-xl:p-6 max-lg:mt-4">
      <div className="text-[28px] leading-[34px] max-xl:text-[22px] max-xl:leading-6 max-lg:text-[20px] font-bold">
        {t("payment.payment_detail")}
      </div>
      <Image
        src={"/mobile-package/natcom.svg"}
        width={144}
        height={144}
        unoptimized
        quality={100}
        alt="phone"
        className="object-contain my-8 max-md:mb-6 m-auto max-lg:size-20"
      />
      <div className="flex items-center justify-between h-[53px] w-full gap-x-4">
        <div className="text-[16px] whitespace-nowrap font-normal">
          {t("payment.plan_name")}
        </div>
        <div className="font-bold max-xl:text-[14px] line-clamp-1">
          <TextWithTooltip content={`${planInfo?.name}`} />
        </div>
      </div>
      <div className="flex items-center justify-between h-[53px] w-full">
        <div className="text-[16px] font-normal">{t("payment.order_id")}</div>
        <div className="font-bold max-xl:text-[14px]">{orderId}</div>
      </div>
      <div className="flex items-center justify-between h-[53px] w-full">
        <div className="text-[16px] font-normal">{t("common.price")}</div>
        <div className="font-bold max-xl:text-[14px]">
          {formatMoney(Number(planInfo?.price ?? 0))} {t("mobile_package.htg")}
        </div>
      </div>
      <div className="h-20 max-md:h-20 max-xl:h-12 flex items-center justify-between border-t border-solid border-[#E3E4E5]">
        <div className="font-bold text-[20px] max-xl:text-[18px] max-lg:text-[20px]">
          {t("common.total")}
        </div>
        <div className="flex flex-col items-end">
          <div className="text-black font-bold text-[20px] max-xl:text-[18px] max-lg:text-[16px] leading-6 ">
            {formatMoney(Number(planInfo?.price ?? 0))}{" "}
            {t("mobile_package.htg")}
          </div>
          <div className="text-neutral-dark-04 mt-1 font-bold text-[14px] leading-5">
            ( {t("payment.included_vat_if_any")} )
          </div>
        </div>
      </div>
      <button
        type="submit"
        className={`mt-6 w-full h-8 md:h-12 rounded-3xl font-bold  ${!disable ? "bg-[#E3E4E5] hover:bg-[#E3E4E5] text-neutral-mid-01" : "bg-primary text-white"}`}
        onClick={() => {
          if (disable) onPay();
        }}
      >
        {t("payment.pay")}
      </button>
      <Button
        className="mt-4 max-md:mt-2 w-full "
        variant={"secondary"}
        onClick={() => {
          router.back();
        }}
      >
        {t("common.back")}
      </Button>
    </div>
  );
};

export default InformationPayment;
