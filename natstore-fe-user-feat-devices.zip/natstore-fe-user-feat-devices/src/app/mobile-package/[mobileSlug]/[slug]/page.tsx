import React from "react";
import PageContent from "@/components/page-content";
import mobileApiRequest from "@/services/mobile-service";
import BreadCrumbCommon from "@/components/breadcrumb-common";
import SimilarInternetPackage from "@/app/mobile-package/[mobileSlug]/[slug]/similar-internet-package";
import TextCSRStyle from "@/components/text-csr-style";
import { getTranslations } from "next-intl/server";
// import CardCommon from "@/components/card-common";
// import CarouselData from "@/components/common/carousel-data/carousel-data";
import { ILinks } from "@/types/package";
import ButtonRegisterData from "@/app/mobile-package/[mobileSlug]/[slug]/btn-register-data";

import PlanSummary from "@/module/mobile-services/component/plan-summary";
import TextWithTooltip from "@/components/text-width-tooltip";

export const dynamic = "force-dynamic";

const getData = async (slug: string) => {
  try {
    const res = await mobileApiRequest.getDetailData(slug);
    return res.payload;
  } catch (error) {
    console.log(error);
    throw Error("error");
  }
};

const DataPlansDetailPage = async ({
  params,
}: {
  params: { slug: string };
}) => {
  const t = await getTranslations();
  const response = await getData(params.slug);
  // const categoriesRes = await getListCategoryData();
  // const categoryDetail = categoriesRes.data[0].children.find(
  //   (val) => val.id === response.data.categoryId
  // );

  const breadCrumb: ILinks[] = [
    {
      label: t("personal.home"),
      link: "/",
    },
    {
      label: t("mobile_package.roaming.mobile_service"),
      link: "/mobile-package",
    },
    {
      label: (
        <TextWithTooltip content={`${response.data.categories[1].name}`} />
      ),
      link: `/mobile-package/${response.data.categories[1].slug}`,
    },
    {
      label: (
        <TextWithTooltip content={`${response.data.categories[2].name}`} />
      ),
      link: `/mobile-package/${response.data.categories[1].slug}?categoryId=${response.data.categories[2]?.id}`,
    },
    {
      label: (
        <TextWithTooltip
          content={response.data.name || ""}
          textSuffix={t("mobile_package.detail")}
        />
      ),
      link: `/mobile-package/${response.data.categories[1].slug}/${params.slug}`,
    },
  ];

  return (
    <PageContent className="bg-background-content">
      <BreadCrumbCommon content={breadCrumb} />
      <div className="my-10 px-28 max-md:my-6 max-2xl:px-16 max-lg:px-8 max-md:px-0">
        <PlanSummary data={response.data} />
        <div className="mt-6 w-full rounded-3xl p-8 max-md:p-4 max-md:mt-4 bg-white">
          {response?.data?.description && (
            <>
              <TextCSRStyle classStyle="font-bold text-[20px] max-xl:text-[18px] block max-md:text-[16px] leading-6">
                mobile_package.data.bonus_information
              </TextCSRStyle>
              <div className="mt-4 max-md:mt-3 max-md:text-[14px] text-neutral-dark-04 font-normal break-all whitespace-pre-line">
                {response.data.description}
              </div>
            </>
          )}
          {response?.data?.shortDescription && (
            <>
              <TextCSRStyle classStyle="mt-6 max-md:mt-4 block font-bold text-[20px] max-xl:text-[18px] max-md:text-[16px] leading-6">
                mobile_package.data.benefit
              </TextCSRStyle>
              <div className="mt-4 max-md:mt-3 max-md:text-[14px] text-neutral-dark-04 font-normal break-all whitespace-pre-line">
                {response.data.shortDescription}
              </div>
            </>
          )}
          <ButtonRegisterData slug={params.slug} />
        </div>
      </div>
      <SimilarInternetPackage slug={params.slug} />
    </PageContent>
  );
};

export default DataPlansDetailPage;
