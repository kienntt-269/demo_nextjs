"use client";
import { useLangStore } from "@/_stores/useLang.store";
import TextCSRStyle from "@/components/text-csr-style";
import TextWithTooltip from "@/components/text-width-tooltip";
import { Button } from "@/components/ui/button";
import { convertSecondsToMonths } from "@/constants/locale";
import { formatMoney } from "@/lib/utils";
import {
  IDataInternetDetailPayment,
  IDataInternetDetailPaymentTotal,
} from "@/schemaValidations/internet.shema";
import internetApiRequest from "@/services/internet";
import { useTranslations } from "next-intl";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { forwardRef, useEffect, useImperativeHandle, useState } from "react";

const OrderInternet = forwardRef(
  (
    {
      id,
      price,
      speed,
      name,
      isFormModified,
    }: {
      id: string;
      price: number;
      speed: string;
      name: string;
      isFormModified: boolean;
    },
    ref
  ) => {
    const [paymentPlans, setPaymentPlans] =
      useState<IDataInternetDetailPayment[]>();
    const { lang } = useLangStore();
    const t = useTranslations();
    const [selectedPlan, setSelectedPlan] = useState<number | null>(null);
    const [paymentTotal, setPaymentTotal] =
      useState<IDataInternetDetailPaymentTotal>();
    const [bonus, setBonus] = useState<number>(0);
    const [totalMonth, setTotalMonth] = useState<number>(0);
    const [installationFee, setInstallationFee] = useState<number>(0);
    const router = useRouter();
    const getDataPaymentPlan = async () => {
      const res = await internetApiRequest.getDetailDataPayment(id);
      setSelectedPlan(res.payload.data?.[0]?.id);
      getDataPaymentTotalPlan(res.payload.data[0].id.toString());
      setPaymentPlans(res.payload.data);
    };
    const getDataPaymentTotalPlan = async (idPayment: string) => {
      const res = await internetApiRequest.getDetailDataTotalPayment(
        id,
        idPayment
      );
      setPaymentTotal(res.payload.data);
      setTotalMonth(
        res.payload.data.monthNumberPayment +
        res.payload.data.monthNumberBonus
      );
      setBonus(res.payload.data.monthNumberBonus);
      setInstallationFee(res.payload.data.installationFee);
    };

    useEffect(() => {
      if (id) {
        getDataPaymentPlan();
      }
    }, [id, lang]);

    useImperativeHandle(ref, () => ({
      getData: () => selectedPlan,
    }));

    return (
      <div className="flex flex-col gap-6">
        <div className="w-full bg-white rounded-3xl p-8 max-md:px-4 max-md:py-6 h-fit max-xl:mt-8 max-md:mt-4">
          <div className="md:text-[28px] text-xl font-bold mb-4">
            {t("internet.choose_a_payment_plan")}
          </div>
          <div className="flex flex-col gap-2">
            {paymentPlans?.map((plan) => (
              <div
                key={plan.id}
                onClick={() => {
                  setSelectedPlan(plan.id);
                  getDataPaymentTotalPlan(plan.id.toString());
                  setInstallationFee(plan.installationFee);
                }}
                className={` px-6 py-3 rounded-2xl cursor-pointer transition-all border-[2px]  ${selectedPlan === plan.id
                  ? "border-[#FF8600] bg-[#FF860029] "
                  : "border-[#E3E4E5] bg-[#F5F6F7]"
                  }`}
              >
                <div className="flex justify-between items-center md:block">
                  <div
                    className={`${selectedPlan === plan.id ? "text-primary" : "text-neutral-dark-04"} flex md:flex-row flex-col md:justify-normal justify-between  items-center`}
                  >
                    <div className="flex md:flex-row flex-row-reverse md:justify-normal justify-end gap-3 w-full">
                      <Image
                        width={24}
                        height={24}
                        src={`${selectedPlan === plan.id ? "/svg/radioChecked.svg" : "/svg/radio.svg"}`}
                        alt=""
                        className="md:block hidden"
                      ></Image>
                      <div>
                        <div className={`font-semibold text-sm md:text-base`}>
                          {convertSecondsToMonths(plan.timeInSeconds) === 1
                            ? t("internet.pay_month", {
                              time: convertSecondsToMonths(
                                plan.timeInSeconds
                              ),
                            })
                            : t("internet.pay_months", {
                              time: convertSecondsToMonths(
                                plan.timeInSeconds
                              ),
                            })}
                        </div>
                        <div className="flex lg:gap-4 mt-2 flex-col lg:flex-row ">
                          <div className=" text-xs md:text-sm">
                            {t("internet.installation_fee")}
                            <span className="font-semibold ml-1">
                              {plan.installationFee === 0
                                ? t("common.free")
                                : `${plan.installationFee} $`} 
                            </span>
                          </div>
                          {convertSecondsToMonths(plan.bonusTimeInSeconds) !==
                            0 && (
                              <div className=" text-xs md:text-sm">
                                {convertSecondsToMonths(
                                  plan.bonusTimeInSeconds
                                ) === 1
                                  ? t("internet.bonus", {
                                    months: convertSecondsToMonths(
                                      plan.bonusTimeInSeconds
                                    ),
                                  })
                                  : t("internet.bonus_s", {
                                    months: convertSecondsToMonths(
                                      plan.bonusTimeInSeconds
                                    ),
                                  })}
                              </div>
                            )}
                        </div>
                      </div>
                    </div>
                    <div className="w-full md:mt-0 mt-2 flex items-center gap-2 md:block">
                      <div
                        className={`md:text-lg text-sm font-bold md:text-end`}
                      >
                        {formatMoney(
                          convertSecondsToMonths(plan.timeInSeconds) * price
                        )}{" "}
                        $
                      </div>
                      <div className="md:text-end md:text-sm  text-xs">
                        ( {t("internet.The_price_not_TCA")} ){" "}
                      </div>
                    </div>
                  </div>
                  <Image
                    width={24}
                    height={24}
                    src={`${selectedPlan === plan.id ? "/svg/radioChecked.svg" : "/svg/radio.svg"}`}
                    alt=""
                    className="block md:hidden"
                  ></Image>
                </div>
              </div>
            ))}
          </div>
        </div>
        <div className="w-full bg-white rounded-3xl p-8 max-md:px-4 max-md:py-6 h-fit max-xl:mt-8 max-md:mt-4">
          <div className="md:text-[28px] text-xl font-bold mb-4">
            {t("internet.order_summary")}
          </div>
          {/* <div className="flex justify-between items-center md:py-4 py-3 gap-x-4">
            <div className="font-normal text-sm md:text-base md:font-bold">
              {t("payment.payment_method")}
            </div>
            <div className="font-bold text-sm md:text-base">
              {t("payment.natcash")}
            </div>
          </div> */}
          <div className="flex justify-between items-center md:py-4 py-3 gap-x-4">
            <div className="font-normal text-sm md:text-base md:font-bold self-start">
              {t("internet.product_name")}
            </div>
            <div className="font-bold text-sm md:text-base max-w-40 md:max-w-96 whitespace-pre-line">
              <TextWithTooltip content={`${name ?? ""}`} />
            </div>
          </div>
          <div className="flex justify-between items-center md:py-4 py-3 gap-x-4">
            <div className="flex-1 w-11 md:w-full font-normal text-sm md:text-base md:font-bold self-start">
              {t("internet.number_of_months_of_use")}
            </div>
            <div className="font-bold text-sm md:text-base flex flex-col gap-0.5 md:gap-2 items-end">
              <div>
                {totalMonth || paymentTotal?.monthNumberPayment || 0}{" "}
                {totalMonth === 1 ? t("common.month") : t("common.months")}
              </div>
            </div>
          </div>
          <div className="bg-[#F5F6F7] p-4 rounded-xl">
            <div className="flex justify-between items-center text-[#616161] text-base ">
              <div className="md:block hidden text-sm md:text-base">
                {t("internet.payment_months")}
              </div>
              <div className="md:hidden block text-sm md:text-base">
                {t("internet.payment_months_mb")}
              </div>
              <div className="text-sm md:text-base">
                {paymentTotal?.monthNumberPayment || 0}{" "}
                {paymentTotal?.monthNumberPayment === 1
                  ? t("common.month")
                  : t("common.months")}
              </div>
            </div>
            {bonus !== 0 && (
              <div className="flex mt-2 justify-between items-center text-[#616161] text-base ">
                <div className="md:block hidden text-sm md:text-base">
                  {t("internet.bonus_months")}
                </div>
                <div className="md:hidden block text-sm md:text-base">
                  {t("internet.bonus_months_mb")}
                </div>
                <div className="text-sm md:text-base">
                  {(bonus)}{" "}
                  {(bonus) === 1
                    ? t("common.month")
                    : t("common.months")}
                </div>
              </div>
            )}
          </div>
          <div className="flex justify-between items-center md:py-4 py-3 gap-x-4">
            <div className="font-normal text-sm md:text-base md:font-bold">
              {t("internet.price")}
            </div>
            <div className="font-bold text-sm md:text-base">
              {formatMoney(price)} $
            </div>
          </div>

          <div className="flex justify-between items-center md:py-4 py-3 gap-x-4">
            <div className="font-normal text-sm md:text-base md:font-bold">
              {t("internet.speed")}
            </div>
            <div className="font-bold text-sm md:text-base">
              {speed || "0"} {t("internet.mbps")}
            </div>
          </div>
          <div className="flex justify-between items-center md:py-4 py-3 gap-x-4">
            <div className="font-normal text-sm md:text-base md:font-bold">
              {t("internet.installation_fee_register")}
            </div>
            <div className="font-bold text-sm md:text-base">
              {installationFee === 0
                ? t("common.free")
                : `${installationFee} $`}
            </div>
          </div>
          <div className="flex justify-between items-center md:py-4 py-3 gap-x-4">
            <div className="font-normal text-sm md:text-base md:font-bold">
              {t("internet.package_fee")}
            </div>
            <div className="font-bold text-sm md:text-base">
              {formatMoney(paymentTotal?.priceNoTCA)} $
            </div>
          </div>
          <div className="flex justify-between items-center md:py-4 py-3 gap-x-4">
            <div className="font-normal text-sm md:text-base md:font-bold">
              {t("common.TCA")}
            </div>
            <div className="font-bold text-sm md:text-base">
              {formatMoney(paymentTotal?.priceTCA)} $
            </div>
          </div>
          <div className="flex justify-between items-center md:py-4 py-3 gap-x-4 border-top border-[#E3E4E5] border-t-[1px]">
            <div className="text-sm md:text-base font-bold">
              {t("common.total")}
            </div>
            <div className="font-bold text-sm md:text-base flex flex-col gap-0.5 md:gap-2 items-end">
              <div>{formatMoney(paymentTotal?.totalAmount)} $</div>
              <div className="font-normal text-neutral-dark-04 text-sm">
                ( {t("internet.included_VAT")} )
              </div>
            </div>
          </div>
          <div className="flex md:flex-row-reverse flex-col  md:gap-4 gap-2 mt-4 md:mt-0 w-full">
            <Button
              className="w-full"
              variant={"default"}
              type="submit"
              disabled={isFormModified}
            >
              <TextCSRStyle>common.register</TextCSRStyle>
            </Button>
            <Button
              className="w-full"
              variant={"secondary"}
              onClick={() => {
                router.back();
              }}
              type="button"
            >
              {t("common.back")}
            </Button>
          </div>
        </div>
      </div>
    );
  }
);
OrderInternet.displayName = "OrderInternet";
export default OrderInternet;
