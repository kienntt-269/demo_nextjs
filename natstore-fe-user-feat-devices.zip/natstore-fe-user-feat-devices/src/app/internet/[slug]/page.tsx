import React from "react";
import PageContent from "@/components/page-content";
import Image from "next/image";
import BreadCrumbCommon from "@/components/breadcrumb-common";
import TextCSRStyle from "@/components/text-csr-style";
import { getTranslations } from "next-intl/server";
import { ILinks } from "@/types/package";
import internetApiRequest from "@/services/internet";
import BannerHomePage from "@/module/home-page/banner-home-page";
import PlanSummary from "@/module/mobile-services/component/plan-summary";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import TextWithTooltip from "@/components/text-width-tooltip";
import { getImageUrl } from "@/constants/imageUrl";
import mobilePackageApiRequest from "@/services/mobile-package";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import NoDataAvailable from "@/components/common/no-data-available/no-data-available";

export const dynamic = "force-dynamic";

const getData = async (slug: string) => {
  try {
    const res = await internetApiRequest.getDetailData(slug);
    return res.payload;
  } catch (error) {
    console.log(error);
    throw Error("error");
  }
};

const getFaqs = async () => {
  try {
    const res = await mobilePackageApiRequest.getFaqs("INTERNET");
    return res.payload.data;
  } catch (error) {
    console.log(error);
    throw Error("error");
  }
};

const InternetDetailPage = async ({ params }: { params: { slug: string } }) => {
  const t = await getTranslations();
  const response = await getData(params.slug);
  const faqs = await getFaqs();
  const breadCrumb: ILinks[] = [
    {
      label: t("personal.home"),
      link: "/",
    },
    {
      label: t("internet.internet"),
      link: "/internet",
    },
    {
      label: response?.data?.category,
      link: "/internet?internet-view=buy-internet-package",
    },
    {
      label: (
        <TextWithTooltip
          content={response.data?.name || ""}
          textSuffix={t("mobile_package.detail")}
        />
      ),
      link: ``,
    },
  ];
  return (
    <PageContent className="bg-background-content">
      <BannerHomePage />
      <div className="mt-6">
        <BreadCrumbCommon content={breadCrumb} />
      </div>
      <div className="my-10 px-28 max-md:my-6 max-2xl:px-16 max-lg:px-8 max-md:px-0">
        <PlanSummary data={response.data} isInternet />
        <div className="mt-6 w-full rounded-3xl p-8 max-md:p-4 bg-white">
          <div className="flex gap-8 md:flex-row flex-col">
            <div>
              <Image
                src={
                  getImageUrl(response?.data?.image) ||
                  "/svg/bgInternetDetail.svg"
                }
                width={361}
                height={252}
                alt="img detail"
                className="rounded-2xl w-[361px] h-[252px] object-contain mx-auto"
              ></Image>
            </div>
            <div className="flex flex-col justify-between flex-1">
              <div>
                <TextCSRStyle classStyle="font-bold text-[20px] max-xl:text-[18px] block max-md:text-[16px] leading-6">
                  internet.information
                </TextCSRStyle>
                {response?.data?.description ? (
                  <>
                    <div className="mt-4 max-md:mt-3 text-neutral-dark-04 font-normal text-sm md:text-base whitespace-pre-line">
                      {response.data?.description}
                    </div>
                  </>
                ) : (
                  <div className="text-sm lg:text-base font-normal mt-4 max-md:mt-3 text-neutral-dark-04 whitespace-pre-line">
                    {t("common.not_content")}
                  </div>
                )}
              </div>
              <div className="max-md:mt-4 mt-6">
                <Link
                  passHref
                  className=" "
                  href={`/internet/${params?.slug}/register`}
                >
                  <Button className="flex-1 px-11 py-[13.5px] max-md:h-8 font-bold max-md:w-full max-lg:text-[14px] max-lg:py-2 max-lg:px-4 max-md:py-[6px] max-md:leading-5 ">
                    <TextCSRStyle>common.register</TextCSRStyle>
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
        {(response.data?.productAndPricing ||
          response.data?.promotions ||
          response.data?.changePackage ||
          faqs?.length > 0) && (
          <div>
            <div className="hidden md:block mt-6 w-full rounded-3xl p-8 max-md:p-4 bg-white">
              <div className="text-center font-bold text-[28px]">
                {t("internet.other_information")}
              </div>
              <div className="mt-8 px-6 py-4 bg-[#F5F6F7] border-[#DEDEDE] border-solid border-[1px] rounded-xl">
                {response.data?.productAndPricing && (
                  <div>
                    <div className=" text-neutral-dark-03 text-xl font-bold">
                      {t("internet.product_pricing")}
                    </div>
                    <div className="whitespace-pre-line text-neutral-dark-01">
                      {response.data?.productAndPricing}
                    </div>
                  </div>
                )}
                {response?.data?.promotions && (
                  <div>
                    <div className=" text-neutral-dark-03 text-xl font-bold mt-6">
                      {t("internet.promotion")}
                    </div>
                    <div className="whitespace-pre-line text-neutral-dark-01">
                      {response?.data?.promotions}
                    </div>
                  </div>
                )}
                {response?.data?.changePackage && (
                  <div>
                    <div className=" text-neutral-dark-03 text-xl font-bold mt-6">
                      {t("internet.change_package")}
                    </div>
                    <div className="whitespace-pre-line text-neutral-dark-01">
                      {response?.data?.changePackage}
                    </div>
                  </div>
                )}

                <div>
                  <div className=" text-neutral-dark-03 text-xl font-bold mt-6 mb-2">
                    {t("internet.faqs")}
                  </div>
                  <div className="flex flex-col w-full">
                    {faqs?.length > 0 ? (
                      faqs.map((faq, index) => (
                        <div
                          key={faq.id}
                          className="border-solid border-[1px] border-[#C5C5C5] rounded-lg mb-4 "
                        >
                          <Accordion type="single" collapsible>
                            <AccordionItem value={faq.id}>
                              <AccordionTrigger className="!no-underline px-6 py-3 text-xs md:text-[14px] font-bold">
                                {index + 1}. {faq.question}
                              </AccordionTrigger>
                              <AccordionContent className="px-6 text-xs md:text-[14px] whitespace-pre-line">
                                {faq.answer}
                              </AccordionContent>
                            </AccordionItem>
                          </Accordion>
                        </div>
                      ))
                    ) : (
                      <NoDataAvailable />
                    )}
                  </div>
                </div>
              </div>
            </div>
            <div className="md:hidden bg-white px-4 rounded-3xl mt-4 pb-4">
              {response.data?.productAndPricing && (
                <Accordion type="single" collapsible>
                  <AccordionItem value="item-1" className="!border-b-0">
                    <AccordionTrigger className="!no-underli text-sm font-bold">
                      {t("internet.product_pricing")}
                    </AccordionTrigger>

                    <AccordionContent className="rounded-xl text-neutral-dark-04 !border-[1px] !border-[#DEDEDE] !border-solid  !no-underline text-xs font-bold whitespace-pre-line bg-[#F5F6F7] p-3">
                      {response.data?.productAndPricing}
                    </AccordionContent>
                  </AccordionItem>
                </Accordion>
              )}
              {response?.data?.promotions && (
                <Accordion type="single" collapsible>
                  <AccordionItem value="item-1" className="!border-b-0">
                    <AccordionTrigger className="!no-underline text-sm font-bold">
                      {t("internet.promotions")}
                    </AccordionTrigger>

                    <AccordionContent className="rounded-xl text-neutral-dark-04 !border-[1px] !border-[#DEDEDE] !border-solid  !no-underline text-xs font-bold whitespace-pre-line bg-[#F5F6F7] p-3">
                      {response?.data?.promotions}
                    </AccordionContent>
                  </AccordionItem>
                </Accordion>
              )}
              {response?.data?.changePackage && (
                <Accordion type="single" collapsible>
                  <AccordionItem value="item-1" className="!border-b-0">
                    <AccordionTrigger className="!no-underline text-sm font-bold">
                      {t("internet.change_package")}
                    </AccordionTrigger>

                    <AccordionContent className="rounded-xl text-neutral-dark-04 !border-[1px] !border-[#DEDEDE] !border-solid  !no-underline text-xs font-bold whitespace-pre-line bg-[#F5F6F7] p-3">
                      {response?.data?.changePackage}
                    </AccordionContent>
                  </AccordionItem>
                </Accordion>
              )}
              {response?.data?.changePackage && (
                <Accordion type="single" collapsible>
                  <AccordionItem value="item-1" className="!border-b-0">
                    <AccordionTrigger className="!no-underline text-sm font-bold">
                      {t("internet.faqs")}
                    </AccordionTrigger>

                    <AccordionContent className="rounded-xl  !border-[1px] !border-[#DEDEDE] !border-solid  !no-underline text-xs font-bold whitespace-pre-line bg-[#F5F6F7] p-3">
                      <div className="flex flex-col w-full">
                        {faqs?.length > 0 ? (
                          faqs.map((faq, index) => (
                            <div
                              key={faq.id}
                              className="border-solid border-[1px] border-[#C5C5C5] rounded-lg mb-4 "
                            >
                              <Accordion type="single" collapsible>
                                <AccordionItem value={faq.id}>
                                  <AccordionTrigger className="!no-underline px-6 py-3 text-xs md:text-[14px] font-bold">
                                    {index + 1}. {faq.question}
                                  </AccordionTrigger>
                                  <AccordionContent className="px-6 text-neutral-dark-04 text-xs md:text-[14px] whitespace-pre-line">
                                    {faq.answer}
                                  </AccordionContent>
                                </AccordionItem>
                              </Accordion>
                            </div>
                          ))
                        ) : (
                          <NoDataAvailable />
                        )}
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                </Accordion>
              )}
            </div>
          </div>
        )}
      </div>
    </PageContent>
  );
};

export default InternetDetailPage;
