import React from "react";
import BreadCrumbCommon from "@/components/breadcrumb-common";
import PageContent from "@/components/page-content";
import { ILinks } from "@/types/package";
import Image from "next/image";
import { getTranslations } from "next-intl/server";
import TitleStyle from "@/components/title-common";
import BannerHomePage from "@/module/home-page/banner-home-page";
import internetApiRequest from "@/services/internet";
import InternetClient from "@/module/internet-service/internet-client";
// import { IDataServiceCategories } from "@/schemaValidations/service-categories";

export const dynamic = "force-dynamic";
const dataGetInternet = async () => {
  const res = await internetApiRequest.getDataInternet({
    type: "BUY_INTERNET_PACKAGE",
  });
  return res.payload.data;
};

const dataCategoriesList = async () => {
  const res = await internetApiRequest.getDataInternetCategory();
  return res.payload.data;
};

interface InternetProps {
  searchParams: {
    [key: string]: string | string[] | undefined;
  };
}

async function Internet({ searchParams }: InternetProps) {
  const dataInternet = await dataGetInternet();
  const serviceCategoriesList = await dataCategoriesList();
  const t = await getTranslations();
  const listChildren = serviceCategoriesList?.[0]?.children;
  const internetView =
    searchParams?.["internet-view"] || listChildren?.[0]?.slug;
  const chilrenActive = listChildren.find((item) => item.slug === internetView);
  const breadCrumb: ILinks[] = [
    {
      label: t("personal.home"),
      link: "/",
    },
    {
      label: t("internet.internet"),
      link: "/internet",
    },
    {
      label: chilrenActive?.name,
      link: `/internet?internet-view=${chilrenActive?.slug}`,
    },
  ];
  return (
    <PageContent>
      <BannerHomePage />
      <div className="mt-6">
        <BreadCrumbCommon content={breadCrumb} />
      </div>
      <div className="mt-10 flex items-center gap-x-4 max-md:hidden">
        <Image
          src={"/svg/internet.svg"}
          alt="phone mobile"
          unoptimized
          quality={100}
          width={72}
          height={72}
        />

        <TitleStyle>{t("internet.internet")}</TitleStyle>
      </div>
      <InternetClient
        isList={true}
        dataInternet={dataInternet}
        serviceCategoriesList={serviceCategoriesList}
      />
    </PageContent>
  );
}

export default Internet;
