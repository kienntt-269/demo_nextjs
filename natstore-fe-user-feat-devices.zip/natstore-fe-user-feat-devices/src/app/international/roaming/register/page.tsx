"use client";

import { useEffect, useState } from "react";
import RegisterItem from "@/app/international/roaming/register/_components/register-item";
import { RegisterItemProps } from "@/types/mobile-package";
import RegisterDetail from "@/app/international/roaming/register/_components/register-detail";
import mobilePackageApiRequest from "@/services/mobile-package";
import NoDataAvailable from "@/components/common/no-data-available/no-data-available";
import { useLangStore } from "@/_stores/useLang.store";
import { useSearchParams } from "next/navigation";
import { useLoadingStore } from "@/_stores/useLoading,store";

export default function RegisterPage() {
  const { lang } = useLangStore();
  const { setIsLoading } = useLoadingStore();
  const [items, setItems] = useState<RegisterItemProps[]>([]);
  const roamingParams = useSearchParams();
  const dataSelected = roamingParams.get("id") || "";

  const getData = async () => {
    setIsLoading(true);
    try {
      const res = await mobilePackageApiRequest.getListRoaming();
      setItems(res.payload.data);
      setIsLoading(false);
      return res.payload.data;
    } catch (error) {
      console.log(error);
      throw Error("error");
    }
  };

  useEffect(() => {
    getData();
  }, [lang]);

  return (
    <>
      <div className="lg:px-6 w-full max-w-[1604px] mx-auto">
        {!dataSelected ? (
          <>
            {!!items.length ? (
              <div className="relative grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-3 gap-x-2 gap-y-3 lg:gap-4 mb-6 lg:mb-9">
                {items.map((item) => (
                  <RegisterItem key={item.id} data={item} />
                ))}
              </div>
            ) : (
              <NoDataAvailable />
            )}
          </>
        ) : (
          <RegisterDetail id={Number(dataSelected)} />
        )}
      </div>
    </>
  );
}
