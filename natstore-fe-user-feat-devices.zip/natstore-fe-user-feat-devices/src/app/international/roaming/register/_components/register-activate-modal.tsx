import React from "react";
import { useTranslations } from "next-intl";
import Image from "next/image";
import { Dialog } from "@radix-ui/react-dialog";
import Modal from "@/components/common/modal/Modal";
import { Button } from "@/components/ui/button";
import dayjs from "dayjs";

export type RegisterActivateModalProps = React.ComponentProps<typeof Dialog> & {
  isSuccessModal: Date;
  onClose: () => void;
  onSubmit: () => void;
  installationInstruction?: string;
};

export const RegisterActivateModal = ({
  isSuccessModal,
  onSubmit,
  onClose,
  installationInstruction,
}: RegisterActivateModalProps) => {
  const t = useTranslations("mobile_package.roaming");
  return (
    <Modal
      isOpen={!!isSuccessModal}
      onClose={onClose}
      contentClassName="w-[343px] lg:w-[504px] lg:max-w-full pb-[24px] pt-2 px-2 lg:p-6"
    >
      <div className="flex justify-center items-center">
        <Image
          src={
            isSuccessModal
              ? "/mobile-package/on-mobile.svg"
              : "/mobile-package/off-mobile.svg"
          }
          alt={isSuccessModal ? "on-mobile" : "off-mobile"}
          width={96}
          height={96}
          className="rounded-t-2xl"
        />
      </div>
      <h3 className="font-bold text-xl lg:text-2xl text-center text-black mt-4 mb-6">
        {t("notification_status_on")}
      </h3>
      <div className="text-sm lg:text-base text-neutral-dark-04 mb-6 text-center">
        {t("register_activate", {
          data: dayjs(isSuccessModal).format("DD/MM/YYYY"),
        })}
      </div>
      {installationInstruction && (
        <div className="text-sm lg:text-base text-neutral-dark-04 bg-[#F5F6F7] rounded-xl p-4 mb-6 whitespace-pre-line break-words">
          {installationInstruction}
        </div>
      )}
      <div className="flex justify-center items-center mb-2">
        <Button className="lg:min-w-[212px] min-w-[212px]" onClick={onSubmit}>
          {t("got_id")}
        </Button>
      </div>
    </Modal>
  );
};

export default RegisterActivateModal;
