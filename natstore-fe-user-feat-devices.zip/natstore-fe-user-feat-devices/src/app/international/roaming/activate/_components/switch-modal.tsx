import { useDialogAuthStore } from "@/_stores/useDialogAuth.store";
import { useProfileStore } from "@/_stores/useProfile.store";
import { useRoamingStore } from "@/_stores/useRoaming.store";
import PopupModal from "@/app/international/roaming/activate/_components/popup-modal";
import SuccessModal from "@/app/international/roaming/activate/_components/success-modal";
import { Switch } from "@/components/ui/switch";
import { SUCCESS_CODE3 } from "@/constants/http-response";
import { ActivateStatusUser } from "@/schemaValidations/mobile-package.schema";
import mobilePackageApiRequest from "@/services/mobile-package";
import { useTranslations } from "next-intl";
import { useRouter } from "next/navigation";
import React, { useState } from "react";

type SwitchModalProps = {
  status: ActivateStatusUser;
  setStatus: (status: ActivateStatusUser) => void;
};

const SwitchModal = ({ status, setStatus }: SwitchModalProps) => {
  const t = useTranslations("mobile_package.roaming");
  const { user } = useProfileStore();
  const { data, setData } = useRoamingStore();
  const { setIsOpen, setUrlLoginSuccess } = useDialogAuthStore();
  const router = useRouter();

  const [isPopupModal, setIsPopupModal] = useState<boolean>(false);
  const [isSuccessModal, setIsSuccessModal] = useState<boolean>(false);
  const activationStatus = status.activationStatus !== "NOT_ACTIVATED";
  const handleConfirmPopup = () => {
    if (activationStatus) {
      mobilePackageApiRequest.deactivateRoaming().then((res) => {
        if (res.payload.code === SUCCESS_CODE3) {
          setIsSuccessModal(true);
          setIsPopupModal(false);
          setData({ ...data, activationStatus: "NOT_ACTIVATED" });
        }
      });
    } else {
      mobilePackageApiRequest.activateRoaming().then((res) => {
        if (res.payload.code === SUCCESS_CODE3) {
          setIsSuccessModal(true);
          setIsPopupModal(false);
          setData({ ...data, activationStatus: "ACTIVATED" });
        }
      });
    }
  };
  const handleSwitchChange = () => {
    if (user?.id) {
      setIsPopupModal(!isPopupModal);
    } else {
      setIsOpen({ isOpen: true, mode: "LOGIN" });
      setUrlLoginSuccess("/international/roaming");
    }
  };

  const handleConfirmSuccess = () => {
    //success
    setIsSuccessModal(false);
    if (status.id !== 9007199254740991) {
      if (activationStatus) {
        setStatus({
          ...status,
          activationStatus: "NOT_ACTIVATED",
        });
      } else {
        setStatus({
          ...status,
          activationStatus: "ACTIVATED",
        });
      }
      router.refresh();
    }
  };

  return (
    <>
      <div className="w-[92px] h-[48px] lg:w-[136px] lg:h-[72px] my-6 lg:my-8">
        <Switch
          checked={activationStatus}
          onCheckedChange={handleSwitchChange}
          className="w-[100%] h-[100%]"
        />
      </div>
      <div className="text-xl lg:text-2xl font-bold text-neutral-dark-01">
        {activationStatus ? t("roaming_on") : t("not_enabled_roaming")}
      </div>
      <PopupModal
        isPopupModal={isPopupModal}
        status={activationStatus ? "off" : "on"}
        onSubmit={handleConfirmPopup}
        onClose={() => setIsPopupModal(false)}
      />
      <SuccessModal
        isSuccessModal={isSuccessModal}
        status={activationStatus ? "off" : "on"}
        onSubmit={handleConfirmSuccess}
        onClose={handleConfirmSuccess}
      />
    </>
  );
};

export default SwitchModal;
