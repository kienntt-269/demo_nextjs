import Modal from "@/components/common/modal/Modal";
import { Button } from "@/components/ui/button";
import { Dialog } from "@radix-ui/react-dialog";
import { useTranslations } from "next-intl";
import Image from "next/image";
import React from "react";

export type SuccessModalProps = React.ComponentProps<typeof Dialog> & {
  isSuccessModal: boolean;
  status: string;
  onClose: () => void;
  onSubmit: () => void;
};

export const SuccessModal = ({
  isSuccessModal,
  status,
  onSubmit,
  onClose,
}: SuccessModalProps) => {
  const t = useTranslations("mobile_package.roaming");
  return (
    <Modal
      isOpen={isSuccessModal}
      onClose={onClose}
      contentClassName="w-[343px] lg:w-[504px] lg:max-w-full pb-[24px] pt-2 px-2 lg:p-6"
    >
      <div className="flex justify-center items-center">
        <Image
          src={
            isSuccessModal
              ? "/mobile-package/on-mobile.svg"
              : "/mobile-package/off-mobile.svg"
          }
          alt={isSuccessModal ? "on-mobile" : "off-mobile"}
          width={96}
          height={96}
          className="rounded-t-2xl"
        />
      </div>
      <h3 className="font-bold text-xl lg:text-2xl text-center text-black my-4">
        {status === "on"
          ? t("notification_status_on")
          : t("notification_status_off")}
      </h3>
      <div className="max-sm:text-sm lg:text-base text-neutral-dark-04 mb-6">
        {status === "on"
          ? t("notification_status_desc_1")
          : t("notification_status_desc_2")}
      </div>
      <div className="flex justify-center items-center">
        <Button
          className="w-[100%] lg:min-w-[212px]  min-w-[212px] rounded-3xl"
          onClick={onSubmit}
        >
          {t("got_id")}
        </Button>
      </div>
    </Modal>
  );
};

export default SuccessModal;
