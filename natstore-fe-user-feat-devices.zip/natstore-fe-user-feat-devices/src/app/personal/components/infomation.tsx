"use client";
import { useLoadingStore } from "@/_stores/useLoading,store";
import ContentPagePersonal from "@/app/personal/components/content-page";
import RowInfoWithEdit from "@/components/common/RowInfoWithEdit";
import { toastError, toastSuccess } from "@/hooks/use-toast";
import { checkResSuccess, formatPhoneView, validateEmail } from "@/lib/utils";
import accountApiRequest from "@/services/account-client";
import { IUserProfile } from "@/types/user";
import { useTranslations } from "next-intl";
import { useRouter } from "next/navigation";
import React from "react";

const SectionPersonalInformation = ({ user }: { user?: IUserProfile }) => {
  const t = useTranslations();
  const router = useRouter();
  const { setIsLoading } = useLoadingStore();
  const handleUpdateEmail = async (value: string) => {
    setIsLoading(true);
    try {
      const response = await accountApiRequest.updateProfile({
        userId: user?.id || "",
        email: value,
        address: user?.address ?? "",
      });
      if (!checkResSuccess(response.payload.code)) {
        toastError(response.payload.message);
        setIsLoading(false);
        return false;
      } else {
        toastSuccess(t("personal.success.email"));
        router.refresh();
      }
      setIsLoading(false);
      return true;
    } catch (error) {
      console.log({ error });
      setIsLoading(false);
      return false;
    }
  };
  const handleUpdateAddress = async (value: string) => {
    if (!user?.id) return;
    setIsLoading(true);
    try {
      const response = await accountApiRequest.updateProfile({
        userId: user?.id || "",
        email: user?.email,
        address: value,
      });
      if (!checkResSuccess(response.payload.code)) {
        toastError(response.payload.message);
        setIsLoading(false);
        return false;
      } else {
        toastSuccess(t("personal.success.address"));
        router.refresh();
      }
      setIsLoading(false);
      return true;
    } catch (error) {
      console.log({ error });
      setIsLoading(false);
      return false;
    }
  };
  return (
    <ContentPagePersonal title={t("personal.account_information")}>
      <div className="flex flex-col gap-4 xl:gap-12">
        {/* <div className="flex flex-col gap-2 mt-2 xl:0">
          <span className="text-neutral-dark-04 text-sm lg:text-base">
            {t("personal.reward_point")}
          </span>
          <span className="lg:text-xl">1868</span>
        </div> */}
        <div className="flex flex-col gap-2">
          <span className="text-neutral-dark-04 text-sm lg:text-base">
            {t("personal.phone_number")}
          </span>
          <span className="lg:text-xl">{formatPhoneView(user?.isdn)}</span>
        </div>
        <div className="flex flex-col gap-2">
          <span className="text-neutral-dark-04 text-sm lg:text-base">
            {t("personal.email")}
          </span>
          <RowInfoWithEdit
            maxLength={255}
            placeholder={t("personal.changePassword.placeholder_input_email")}
            validateFunc={validateEmail}
            value={user?.email ?? ""}
            onSubmit={handleUpdateEmail}
          />
        </div>
        <div className="flex flex-col gap-2">
          <span className="text-neutral-dark-04 text-sm lg:text-base">
            {t("personal.address")}
          </span>
          <RowInfoWithEdit
            placeholder={t("personal.changePassword.placeholder_input_address")}
            value={user?.address ?? ""}
            onSubmit={handleUpdateAddress}
          />
        </div>
      </div>
    </ContentPagePersonal>
  );
};

export default SectionPersonalInformation;
