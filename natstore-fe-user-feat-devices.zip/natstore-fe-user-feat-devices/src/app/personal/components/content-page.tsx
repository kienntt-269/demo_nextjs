import { Typography } from "@/components/ui/typography";
import React from "react";

type Props = {
  title: string;
  children: React.ReactNode;
};

const ContentPagePersonal = ({ title, children }: Props) => {
  return (
    <div className="flex flex-col gap-6 xl:gap-10">
      <Typography variant="title2">{title}</Typography>
      {children}
    </div>
  );
};

export default ContentPagePersonal;
