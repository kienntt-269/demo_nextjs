import ArrowRightIcon from "@/components/icons/arrow-right-icon";
import clsx from "clsx";
import Link from "next/link";
import React from "react";

type Props = {
  title: string;
  icon: React.ReactNode;
  url: string;
  isActive: boolean;
};

export default function LeftSectionItem({ title, icon, isActive, url }: Props) {
  return (
    <Link href={`${url}`}>
      <div
        className={clsx(
          "flex p-4 lg:py-6 items-center justify-between rounded-xl lg:rounded-[20px] w-[59px] md:w-full ",
          "hover:bg-accent",
          { "bg-primary/[0.24]": isActive },
        )}
      >
        <div className="flex items-center gap-2.5">
          <div className="w-6">{icon}</div>
          <span className="hidden text-sm font-bold text-neutral-dark-02 xl:text-base md:inline-block">
            {title}
          </span>
        </div>
        <span className="cursor-pointer hidden md:inline-block">
          <ArrowRightIcon />
        </span>
      </div>
    </Link>
  );
}
