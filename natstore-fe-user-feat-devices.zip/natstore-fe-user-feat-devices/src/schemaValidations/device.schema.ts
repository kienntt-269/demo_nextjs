import {
  emailSchemaFnc,
  phoneSchemaFnc,
  validateAndAddIssue,
} from "@/lib/schema";
import z from "zod";

export const DeviceDetail = z.object({
  id: z.string(),
  name: z.string(),
  description: z.string(),
  price: z.number(),
  listImagePath: z.string(
    z.array(z.object({ path: z.string(), sort_order: z.string() }))
  ),
  outOfStock: z.number(),
  colors: z.array(z.string()),
  maxQuantity: z.number(),
  productHighlights: z.array(z.string()),
  promotion: z.string(),
  type: z.string().optional(),
  brand: z.string().optional(),
  operatingSystem: z.string().optional(),
  releaseDate: z.string().optional(),
  isIncludedVat: z.string().optional(),
  promotionPrice: z.number(),
  promotionStartTime: z.string().optional(),
  promotionEndTime: z.string().optional(),
  isActive: z.number(),
  status: z.string().optional(),
  stockStatus: z.string().optional(),
  stockNumber: z.string().optional(),
  color: z.string().optional(),
  storageCapacity: z.string().optional(),
  storageUnit: z.string().optional(),
  ramCapacity: z.string().optional(),
  ramUnit: z.string().optional(),
  imagePath: z.string(),
  isDelete: z.number(),
  slug: z.string(),
  categoryId: z.number(),
  seoTitle: z.string().optional(),
  seoDescription: z.string().optional(),
  code: z.string().optional(),
  ratePoint: z.string().optional(),
  rateNumber: z.number().optional(),
  discountType: z.string().optional(),
  discountValue: z.number().optional(),
  sku: z.string().optional(),
  tax: z.string().optional(),
});

const DevicePage = z.object({
  pagination: z.array(DeviceDetail),
});

export const Categories = z.object({
  id: z.string(),
  name: z.string(),
  description: z.string(),
  categoryId: z.string(),
  slug: z.string(),
  isActive: z.number(),
  isDelete: z.number(),
  home: z.boolean(),
  icon: z.string().optional(),
  order: z.string().optional(),
  type: z.number(),
  parentId: z.string(),
  popup: z.boolean(),
});

export const DeviceCategories = Categories.merge(
  z.object({
    children: DevicePage,
  })
);

export const DeviceCategoriesRes = z.object({
  data: z.array(DeviceCategories),
  message: z.string(),
  code: z.number(),
});

export const DeviceOrderInformation = (
  t: (key: string, values?: Record<string, string>) => string = (key: string) =>
    key
) =>
  z
    .object({
      email: z.string().optional().nullable(),
      fullName: z.string().optional().nullable(),
      mobileNumber: z.string().optional().nullable(),
      showroomId: z.string().optional().nullable(),
      provinceId: z.string().optional().nullable(),
      districtId: z.string().optional(),
      timeOfReceiving: z.date().optional().nullable(),
      paymentMethod: z.number().optional().nullable(),
      receivedType: z.string(),
      communeId: z.string().optional().nullable(),
      productId: z.number(),
      quantity: z.number(),
      price: z.number(),
    })
    .superRefine((data, ctx) => {
      if (data.email) {
        validateAndAddIssue(ctx, emailSchemaFnc(), data.email, ["email"]);
      }
      if (!data.fullName) {
        ctx.addIssue({
          code: "custom",
          message: t("name.required"),
          path: ["fullName"],
        });
      }

      validateAndAddIssue(ctx, phoneSchemaFnc(), data.mobileNumber, [
        "phoneNumber",
      ]);
      if (!data.provinceId)
        ctx.addIssue({
          code: "custom",
          message: t("province.required"),
          path: ["provinceId"],
        });
      if (!data.timeOfReceiving)
        ctx.addIssue({
          code: "custom",
          message: t("time_of_receving.required"),
          path: ["timeOfReceiving"],
        });
      // if (!data.showroomId)
      //   ctx.addIssue({
      //     code: "custom",
      //     message: t("store.required"),
      //     path: ["showroomId"],
      //   });
    });

export const RegisterAccountAffiliate = (
  t: (key: string, values?: Record<string, string>) => string = (key: string) =>
    key
) =>
  z
    .object({
      userName: z.string().optional().nullable(),
      email: z.string().optional().nullable(),
      fullName: z.string().optional().nullable(),
      dob: z.string().optional().nullable(),
      gender: z.string().optional().nullable(),
      typeOfDoc: z.string().optional().nullable(),
      idCard: z.string().optional().nullable(),
      taxCode: z.string().optional().nullable(),
      provinceId: z.any().optional().nullable(),
      districtId: z.any().optional().nullable(),
      precinctId: z.any().optional().nullable(),
      address: z.string().optional().nullable(),
      faceImage: z.any().optional().nullable(),
      frontIdCard: z.any().optional().nullable(),
      backIdcard: z.any().optional().nullable(),
      phoneNumber: z.string().optional().nullable(),
      paymentMethod: z.number().optional().nullable(),
    })
    .superRefine((data, ctx) => {
      if (data.email) {
        validateAndAddIssue(ctx, emailSchemaFnc(), data.email, ["email"]);
      }
      if (!data.fullName) {
        ctx.addIssue({
          code: "custom",
          message: t("name.required"),
          path: ["fullName"],
        });
      }

      validateAndAddIssue(ctx, phoneSchemaFnc(), data.phoneNumber, [
        "phoneNumber",
      ]);
      if (!data.provinceId)
        ctx.addIssue({
          code: "custom",
          message: t("province.required"),
          path: ["provinceId"],
        });
    });

export const DeviceListRes = z.object({
  data: DevicePage,
  message: z.string(),
  code: z.string(),
});

export const CategoryListRes = z.object({
  data: z.array(Categories),
  message: z.string(),
  code: z.string(),
});

export const DeviceDetailRes = z.object({
  data: DeviceDetail,
  message: z.string(),
  code: z.string(),
});

export const DevicePreOrder = z.object({
  id: z.string(),
  name: z.string(),
  color: z.string(),
  quantity: z.number(),
  description: z.string(),
  price: z.number(),
  imagePath: z.string(),
});

export const DataPreOrderRes = z.object({
  code: z.string(),
  message: z.string(),
  data: z.string(),
});

export type IDeviceListRes = z.TypeOf<typeof DeviceListRes>;
export type ICategoryListRes = z.TypeOf<typeof CategoryListRes>;
export type IDeviceDetailRes = z.TypeOf<typeof DeviceDetailRes>;

export const schemaDeviceOrderInformationType = DeviceOrderInformation();
export type DeviceOrderInformationType = z.TypeOf<
  typeof schemaDeviceOrderInformationType
>;

//RegisterAccountAffiliate
export const schemaRegisterAccountAffiliateType = RegisterAccountAffiliate();
export type RegisterAccountAffiliateType = z.TypeOf<
  typeof schemaRegisterAccountAffiliateType
>;

export type IDeviceCategoriesRes = z.TypeOf<typeof DeviceCategoriesRes>;
export type IDeviceCategories = z.TypeOf<typeof DeviceCategories>;
export type ICategories = z.TypeOf<typeof Categories>;
export type IDeviceDetail = z.TypeOf<typeof DeviceDetail>;
export type IDevicePreOrder = z.TypeOf<typeof DevicePreOrder>;
export type IDataPreOrderRes = z.TypeOf<typeof DataPreOrderRes>;
