import z from "zod";

export type DataServiceCategoryType = {
  id: string;
  name: string;
  description: string;
  active: boolean;
  home: boolean;
  icon: string;
  order: string;
  type: string;
  parentId: string;
  createdAt: string;
  updatedAt: string;
  createdBy: string;
  updatedBy: string;
  slug: string;
  categoryId: string;
  children: DataServiceCategoryType[];
};

export const DataServiceCategories: z.ZodType<DataServiceCategoryType> = z.lazy(
  () =>
    z.object({
      id: z.string(),
      name: z.string(),
      description: z.string(),
      active: z.boolean(),
      home: z.boolean(),
      icon: z.string(),
      order: z.string(),
      type: z.string(),
      parentId: z.string(),
      createdAt: z.string(),
      updatedAt: z.string(),
      createdBy: z.string(),
      updatedBy: z.string(),
      categoryId: z.string(),
      slug: z.string(),
      children: z.array(DataServiceCategories),
    }),
);

export const DataServiceCategoriesRes = z.object({
  data: z.array(DataServiceCategories),
  message: z.string(),
  code: z.number(),
});

export type IDataServiceCategoriesRes = z.infer<
  typeof DataServiceCategoriesRes
>;
export type IDataServiceCategories = z.infer<typeof DataServiceCategories>;
