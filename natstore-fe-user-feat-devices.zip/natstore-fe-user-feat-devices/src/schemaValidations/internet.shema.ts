import {
  districtSchemaFnc,
  driverLicenseSchemaFnc,
  emailSchemaFnc,
  fileSchemaFnc,
  identityNewCardSchemaFnc,
  identityOldCardSchemaFnc,
  nameInternetSchemaFnc,
  passportSchemaFnc,
  phoneSchemaFnc,
  precinctSchemaFnc,
  provinceSchemaFnc,
  validateAndAddIssue,
} from "@/lib/schema";
import z from "zod";

export const DataInternet = z.object({
  id: z.number().nullable(),
  name: z.string(),
  price: z.number(),
  speed: z.number(),
  promotion: z.string(),
  note: z.string(),
  slug: z.string(),
});
export const DataInternetDetail = z.object({
  id: z.string(),
  name: z.string(),
  price: z.number(),
  speed: z.string(),
  rating: z.number(),
  image: z.string(),
  description: z.string(),
  useTimeUnit: z.string(),
  useTime: z.string(),
  useTimeValue: z.string(),
  category: z.string(),
  ratingCount: z.number(),
  productAndPricing: z.string(),
  promotions: z.string(),
  changePackage: z.string(),
  faqs: z.string(),
  installationFee: z.number(),
});
export const DataInternetDetailPayment = z.object({
  id: z.number(),
  timeInSeconds: z.number(),
  bonusTimeInSeconds: z.number(),
  installationFee: z.number(),
});

export const DataInternetDetailPaymentTotal = z.object({
  monthNumberPayment: z.number(),
  monthNumberBonus: z.number(),
  installationFee: z.number(),
  priceNoTCA: z.number(),
  priceTCA: z.number(),
  totalAmount: z.number(),
});

export const DataDebtDetail = z.object({
  customerName: z.string(),
  contractNumber: z.string(),
  account: z.string(),
  paymentMethod: z.enum(["BANK_TRANSFER", "CASH", "CREDIT_CARD"]),
  priorDebit: z.coerce.number(),
  ariseDebit: z.coerce.number(),
  prepaid: z.coerce.number(),
  hotCharge: z.coerce.number(),
  paidAmount: z.coerce.number(),
  toPay: z.coerce.number(),
  currency: z.string(),
  totalDebit: z.coerce.number(),
  status: z.enum(["PENDING", "PAID", "FAILED"]), // mở rộng nếu có thêm
});

export const DataVerifyNasthCard = z.object({
  status: z.string(),
  transactionId: z.number(),
  transactionTime: z.date(),
  transactionStatus: z.string(),
  customer: z.object({
    fullName: z.string(),
    phoneNumber: z.string(),
    docType: z.string().nullable(),
    idCardNumber: z.string(),
  }),
  productSlug: z.string(),
  address: z.string(),
  productName: z.string(),
  monthBase: z.number(),
  monthBonus: z.number(),
});

export const DataInternetDetailPaymentRes = z.object({
  data: z.array(DataInternetDetailPayment),
  message: z.string(),
  code: z.number(),
});

export const DataInternetDetailPaymentTotalRes = z.object({
  data: DataInternetDetailPaymentTotal,
  message: z.string(),
  code: z.number(),
});

export const DataInternetRes = z.object({
  data: z.array(DataInternet),
  message: z.string(),
  code: z.number(),
});

export const DataInternetDetailRes = z.object({
  data: DataInternetDetail,
  message: z.string(),
  code: z.number(),
});

export const DataInternetDebtRes = z.object({
  data: z.array(DataDebtDetail),
  message: z.string(),
  code: z.number(),
});

export const DataBeginNasthCardRes = z.object({
  data: z.object({
    paymentUrl: z.string(),
  }),
  message: z.string(),
  code: z.string(),
});

export const DataVerifyNasthCardRes = z.object({
  code: z.string(),
  message: z.string(),
  data: DataVerifyNasthCard,
});
export type DataInternetCategoryType = {
  id: string;
  name: string;
  description: string;
  active: boolean;
  home: boolean;
  icon: string;
  order: string;
  type: string;
  parentId: string;
  createdAt: string;
  updatedAt: string;
  createdBy: string;
  updatedBy: string;
  slug: string;
  children: DataInternetCategoryType[];
};

export const DataInternetCategories: z.ZodType<DataInternetCategoryType> =
  z.lazy(() =>
    z.object({
      id: z.string(),
      name: z.string(),
      description: z.string(),
      active: z.boolean(),
      home: z.boolean(),
      icon: z.string(),
      order: z.string(),
      type: z.string(),
      parentId: z.string(),
      createdAt: z.string(),
      updatedAt: z.string(),
      createdBy: z.string(),
      updatedBy: z.string(),
      slug: z.string(),
      children: z.array(DataInternetCategories),
    })
  );

export const DataInternetCategoriesRes = z.object({
  data: z.array(DataInternetCategories),
  message: z.string(),
  code: z.number(),
});

export const DataCaptchaRes = z.object({
  data: z.object({
    captchaCode: z.string(),
    captchaToken: z.string(),
  }),
  message: z.string(),
  code: z.number(),
});

export const InternetRegisterInformation = (
  t: (key: string, values?: Record<string, string>) => string = (key) => key
) =>
  z
    .object({
      email: z.string().optional().nullable(),
      fullName: z.any().optional().nullable(),
      phoneNumber: z.any().optional().nullable(),
      cardId: z.string().optional().nullable(),
      typeOfDocument: z.string().optional().nullable(),
      note: z.string().optional().nullable(),
      address: z.string().optional().nullable(),
      fileFront: z.any().optional().nullable(),
      fileBack: z.any().optional().nullable(),
      provinceId: z.any().optional().nullable(),
      districtId: z.any().optional().nullable(),
      precinctId: z.any().optional().nullable(),
    })
    .superRefine((data, ctx) => {
      if (data.email) {
          validateAndAddIssue(ctx, emailSchemaFnc(), data.email, ["email"]);
        }
      if (!data.fileFront || data?.fileFront?.length === 0) {
        ctx.addIssue({
          code: "custom",
          message: "file.front_photo",
          path: ["fileFront"],
        });
      } else {
        validateAndAddIssue(
          ctx,
          fileSchemaFnc({ fileSizeLimit: 15 }),
          data.fileFront,
          ["fileFront"]
        );
      }

      if (!data.fileBack || data?.fileBack?.length === 0) {
        ctx.addIssue({
          code: "custom",
          message: "file.back_photo",
          path: ["fileBack"],
        });
      } else {
        validateAndAddIssue(
          ctx,
          fileSchemaFnc({ fileSizeLimit: 15 }),
          data.fileBack,
          ["fileBack"]
        );
      }

      validateAndAddIssue(ctx, nameInternetSchemaFnc(), data.fullName, [
        "fullName",
      ]);
      validateAndAddIssue(ctx, phoneSchemaFnc(), data.phoneNumber, [
        "phoneNumber",
      ]);

      if (!data.cardId) {
        ctx.addIssue({
          code: "custom",
          message: t("id_card_internet.required"),
          path: ["cardId"],
        });
      }

      if (!data.typeOfDocument) {
        ctx.addIssue({
          code: "custom",
          message: t("type_of_doc.required"),
          path: ["typeOfDocument"],
        });
      } else if (data.typeOfDocument === "OLD_IDENTITY_CARD") {
        validateAndAddIssue(ctx, identityNewCardSchemaFnc(), data.cardId, [
          "cardId",
        ]);
      } else if (data.typeOfDocument === "NEW_IDENTITY_CARD") {
        validateAndAddIssue(ctx, identityOldCardSchemaFnc(), data.cardId, [
          "cardId",
        ]);
      } else if (data.typeOfDocument === "DRIVER_LICENSE") {
        validateAndAddIssue(ctx, driverLicenseSchemaFnc(), data.cardId, [
          "cardId",
        ]);
      } else if (data.typeOfDocument === "PASSPORT") {
        validateAndAddIssue(ctx, passportSchemaFnc(), data.cardId, ["cardId"]);
      }

      validateAndAddIssue(ctx, provinceSchemaFnc(), data.provinceId, [
        "provinceId",
      ]);
      validateAndAddIssue(ctx, districtSchemaFnc(), data.districtId, [
        "districtId",
      ]);
      validateAndAddIssue(ctx, precinctSchemaFnc(), data.precinctId, [
        "precinctId",
      ]);
    });

export type IDataDebtDetail = z.TypeOf<typeof DataDebtDetail>;
export type IDataInternetRes = z.TypeOf<typeof DataInternetRes>;
export type IDataInternet = z.TypeOf<typeof DataInternet>;
export type IDataInternetDetailRes = z.TypeOf<typeof DataInternetDetailRes>;
export type IDataInternetDebtRes = z.TypeOf<typeof DataInternetDebtRes>;
export type IDataBeginNasthCardRes = z.TypeOf<typeof DataBeginNasthCardRes>;
export type IDataVerifyNasthCardRes = z.TypeOf<typeof DataVerifyNasthCardRes>;
export type IDataVerifyNasthCard = z.TypeOf<typeof DataVerifyNasthCard>;
export type IDataInternetDetail = z.TypeOf<typeof DataInternetDetail>;
export type IDataInternetDetailPaymentRes = z.TypeOf<
  typeof DataInternetDetailPaymentRes
>;
export type IDataInternetDetailPayment = z.TypeOf<
  typeof DataInternetDetailPayment
>;
export type IDataInternetDetailPaymentTotalRes = z.TypeOf<
  typeof DataInternetDetailPaymentTotalRes
>;
export type IDataInternetDetailPaymentTotal = z.TypeOf<
  typeof DataInternetDetailPaymentTotal
>;

export type IDataInternetCategoriesRes = z.infer<
  typeof DataInternetCategoriesRes
>;
export type IDataInternetCategories = z.infer<typeof DataInternetCategories>;

export const schemaInternetInformation = InternetRegisterInformation();
export type IInternetRegisterInformation = z.TypeOf<
  typeof schemaInternetInformation
>;

export type IDataCaptchaRes = z.TypeOf<typeof DataCaptchaRes>;
