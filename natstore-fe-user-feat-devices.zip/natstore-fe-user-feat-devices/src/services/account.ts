import envConfig from "@/config";
import { httpServer } from "@/lib/http-server";
import { AccountResType } from "@/schemaValidations/account.schema";

const accountApiRequest = {
  getUser: () =>
    httpServer.get<AccountResType>(`/api/proxy/v1/api/user`, {
      cache: "no-cache",
      credentials: "include",
      baseUrl: envConfig.NEXT_PUBLIC_URL,
    }),
};

export default accountApiRequest;
