import http from "@/lib/http";
import {
  ICustomerSupportFaqRes,
  ICustomerSupportStaticRes,
  ICustomerSupportTermsRes,
} from "@/schemaValidations/customer-support.schema";

const customerSupportApiRequest = {
  getFaq(categoryId: number) {
    return http.get<ICustomerSupportFaqRes>(
      `/v1/public/homepage/customer-support/faq?categoryId=${categoryId}`
    );
  },

  getFaqCategory() {
    return http.get<ICustomerSupportStaticRes>(
      `/v1/public/homepage/customer-support/faq-category?`
    );
  },

  getCustomerStatic() {
    return http.get<ICustomerSupportStaticRes>(
      `/v1/public/homepage/customer-support/customer-static?`
    );
  },

  getTerms() {
    return http.get<ICustomerSupportTermsRes>(
      `/v1/public/homepage/customer-support/term`
    );
  },
};

export default customerSupportApiRequest;
