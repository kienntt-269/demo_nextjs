"use client";
import { IPropsTabs } from "@/types/package";
import React, { useEffect, useRef, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";

const TabCommon: React.FC<IPropsTabs & { isApplyDefaultTab?: boolean }> = ({
  tabs,
  onChangeTab = () => {},
  defaultTab,
  isLine,
  isApplyDefaultTab,
}) => {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [activeTab, setActiveTab] = useState<number>(defaultTab ?? 0);
  const [indicatorStyle, setIndicatorStyle] = useState<{
    width: number;
    left: number;
  }>({
    width: 0,
    left: 0,
  });
  const tabRefs = useRef<(HTMLButtonElement | null)[]>([]);

  useEffect(() => {
    const slugParam = searchParams.get("slug");
    const index = tabs?.findIndex((tab) => tab.slug === slugParam);
    if (slugParam && index !== -1) {
      setActiveTab(index || 0);
    } else {
      const firstSlug = tabs?.[0]?.slug;
      if (firstSlug) {
        const newUrl = new URL(window.location.href);
        newUrl.searchParams.set("slug", firstSlug.toString());
        router.replace(newUrl.toString(), { scroll: false });
        setActiveTab(0);
      }
    }
  }, [searchParams, tabs]);

  useEffect(() => {
    const currentTab = tabRefs.current[activeTab];
    if (currentTab) {
      const { offsetWidth, offsetLeft } = currentTab;
      setIndicatorStyle({ width: offsetWidth, left: offsetLeft });
    }
  }, [activeTab, tabs]);

  useEffect(() => {
    if (isApplyDefaultTab) setActiveTab(defaultTab ?? 0);
  }, [defaultTab, isApplyDefaultTab]);

  const handleChangeTab = (index: number) => {
    setActiveTab(index);
    onChangeTab(index);

    const slug = tabs?.[index]?.slug || "";
    if (slug) {
      const newUrl = new URL(window.location.href);
      newUrl.searchParams.set("slug", slug.toString());
      router.push(newUrl.toString(), { scroll: false });
    }
  };

  return (
    <div className="overflow-x-scroll no-scrollbar">
      <div className="relative flex justify-start gap-x-2 max-md:gap-x-0 w-fit">
        {tabs?.map((tab, index) => (
          <button
            key={index}
            ref={(el: HTMLButtonElement) => {
              tabRefs.current[index] = el;
            }}
            className={`flex justify-center pb-2 mx-2 text-center xl:text-2xl md:text-xl text-base mmd:font-semibold w-fit truncate font-bold ${
              activeTab === index
                ? "text-primary"
                : "text-neutral-dark-03 transition-colors duration-300 ease-in-out hover:text-[hsl(var(--primary))]"
            } ${!tab?.label ? "hidden" : ""}`}
            onClick={() => handleChangeTab(index)}
          >
            {tab?.label}
          </button>
        ))}
        <div
          className="absolute z-[5] bottom-0 h-1 max-md:h-[3.2px] bg-[#FF8600] transition-all duration-300 rounded-t-lg"
          style={{
            width: `${indicatorStyle.width}px`,
            left: `${indicatorStyle.left}px`,
          }}
        ></div>
        {isLine && (
          <div className="absolute bottom-0 h-[1px] w-full bg-[#D9D9D9]"></div>
        )}
      </div>
      <div>{tabs?.[activeTab]?.content}</div>
    </div>
  );
};

export default TabCommon;
