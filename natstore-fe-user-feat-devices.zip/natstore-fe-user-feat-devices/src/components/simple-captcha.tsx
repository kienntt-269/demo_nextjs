"use client";
import ReloadIcon from "@/components/icons/reload-icon";
import { generateCaptcha } from "@/lib/utils";
import internetApiRequest from "@/services/internet";
import Image from "next/image";
import React, {
  useEffect,
  forwardRef,
  useImperativeHandle,
  useState,
} from "react";

type Props = {
  callbackValue?: ({ text, token }: { text: string; token: string }) => void;
};

export type CaptchaRef = {
  reloadCaptcha: () => void;
};

// eslint-disable-next-line react/display-name
const SimpleCaptcha = forwardRef<CaptchaRef, Props>(
  ({ callbackValue = () => {} }, ref) => {
    const [captchaText, setCaptchaText] = React.useState<string>("");
    const [captchaImage, setCaptchaImage] = useState<string | null>("");

    const handleGetCaptchaText = () => {
      internetApiRequest.getCaptcha().then((res) => {
        setCaptchaText(res.payload.data.captchaCode);
        callbackValue({
          text: res.payload.data.captchaCode,
          token: res.payload.data.captchaToken,
        });
      });
    };

    const handleReload = () => handleGetCaptchaText();

    useImperativeHandle(ref, () => ({
      reloadCaptcha: handleReload,
    }));

    useEffect(() => {
      if (!captchaText) return;
      const res = generateCaptcha(captchaText);
      setCaptchaImage(res);
    }, [captchaText]);

    useEffect(() => {
      handleGetCaptchaText();
    }, []);

    return (
      <div className="flex items-center gap-4">
        <div className="h-[48px] w-[100px] flex items-center rounded-xl border border-[#E3E4E5] form-box-shadow relative">
          {captchaImage && (
            <Image alt="captcha" src={captchaImage ?? ""} fill />
          )}
        </div>
        <div onClick={handleReload} className="cursor-pointer">
          <ReloadIcon />
        </div>
      </div>
    );
  },
);

export default SimpleCaptcha;
