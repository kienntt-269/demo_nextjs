import * as React from "react";
import {
  Control,
  Controller,
  FieldValues,
  Path,
  PathValue,
  UseFormTrigger,
} from "react-hook-form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { FieldWrapper, TFieldWrapperPassThroughProps } from "./field-wrapper";
import clsx from "clsx";

export type TOption = {
  label: React.ReactNode;
  value: string;
};

type TSelectFieldProps<TFormValues extends FieldValues> =
  TFieldWrapperPassThroughProps & {
    name: Path<TFormValues>;
    options: TOption[];
    className?: string;
    classNameLabel?: string;
    defaultValue?: PathValue<TFormValues, Path<TFormValues>>;
    placeholder?: string;
    control: Control<TFormValues>;
    trigger?: UseFormTrigger<TFormValues>;
  };

export const SelectField = <
  TFormValues extends Record<string, unknown> = Record<string, unknown>,
>({
  name,
  label,
  options,
  error,
  className,
  classNameLabel,
  required,
  defaultValue,
  placeholder,
  control,
  trigger,
}: TSelectFieldProps<TFormValues>) => {
  return (
    <FieldWrapper
      label={label}
      error={error}
      className={className}
      classNameLabel={classNameLabel}
      required={required}
    >
      <Controller
        name={name}
        control={control}
        defaultValue={defaultValue}
        render={({ field }) => (
          <Select
            value={field.value as string}
            onValueChange={(value) => {
              field.onChange(value);
              if ((name === "typeOfDocument" || name === "typeDocument") && trigger) {
                setTimeout(() => trigger("cardId" as Path<TFormValues>), 10);
              }
            }}
          >
            <SelectTrigger
              className={clsx({ "border-solid border border-error": !!error })}
            >
              {placeholder && (
                <div
                  className={clsx({
                    "text-neutral": !field.value,
                    "truncate block w-full text-left": !!field.value,
                  })}
                >
                  <SelectValue placeholder={placeholder} />
                </div>
              )}
            </SelectTrigger>
            <SelectContent>
              {options.map(({ label, value }) => (
                <SelectItem key={value} value={value}>
                  {label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        )}
      />
    </FieldWrapper>
  );
};
