import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Controller, Control, FieldValues, Path } from "react-hook-form";

type Option = {
  value: string;
  label: string;
};

type RadioButtonFieldProps<TFormValues extends FieldValues> = {
  name: Path<TFormValues>;
  control: Control<TFormValues>;
  options: Option[];
  className?: string;
  isBackgroundBorder?: boolean;
  onChange?: (value: string) => void;
};

const RadioButtonField = <TFormValues extends FieldValues>({
  name,
  control,
  options,
  className,
  isBackgroundBorder = false,
  onChange,
}: RadioButtonFieldProps<TFormValues>) => {
  return (
    <Controller
      name={name}
      control={control}
      render={({ field }) => (
        <RadioGroup
          defaultValue={options[0].value}
          value={field.value}
          onValueChange={(value) => {
            field.onChange(value);
            if (onChange) {
              onChange(value);
            }
          }}
          className={className}
        >
          {options.map((item) => (
            <div
              key={item.value}
              className={`flex items-center cursor-pointer ${isBackgroundBorder ? "h-12 flex-1 border-2 border-solid text-base py-3 px-4 lg:px-6 rounded-xl" : ""} ${isBackgroundBorder && field.value === item.value ? " bg-[#FFEBD6] border-[#FF8600]" : "text-neutral-dark-04 border-[#E3E4E5]"}`}
            >
              <RadioGroupItem
                value={item.value}
                id={item.value}
                checked={field.value === item.value}
              />
              <label
                className={`ml-2 text-sm cursor-pointer lg:text-base ${isBackgroundBorder && field.value === item.value ? "text-primary font-bold" : "text-neutral-dark-04"}`}
                htmlFor={item.value}
              >
                {item.label}
              </label>
            </div>
          ))}
        </RadioGroup>
      )}
    />
  );
};

export default RadioButtonField;
