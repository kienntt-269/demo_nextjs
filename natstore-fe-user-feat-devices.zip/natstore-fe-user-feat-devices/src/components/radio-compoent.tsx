export const RadioComponent = ({
  checked,
  onChange,
}: {
  checked: boolean;
  onChange: () => void;
}) => {
  return (
    <label className="cursor-pointer">
      <input
        type="radio"
        className="hidden"
        checked={checked}
        onChange={onChange}
      />
      {checked ? (
        <svg
          width="25"
          height="24"
          viewBox="0 0 25 24"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            d="M12.668 22C18.1908 22 22.668 17.5228 22.668 12C22.668 6.47715 18.1908 2 12.668 2C7.14512 2 2.66797 6.47715 2.66797 12C2.66797 17.5228 7.14512 22 12.668 22Z"
            stroke="#FF8600"
            strokeWidth="1.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <path
            d="M12.668 18C15.9817 18 18.668 15.3137 18.668 12C18.668 8.68629 15.9817 6 12.668 6C9.35426 6 6.66797 8.68629 6.66797 12C6.66797 15.3137 9.35426 18 12.668 18Z"
            fill="#FF8600"
          />
        </svg>
      ) : (
        <svg
          width="25"
          height="24"
          viewBox="0 0 25 24"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            d="M12.3359 22C17.8588 22 22.3359 17.5228 22.3359 12C22.3359 6.47715 17.8588 2 12.3359 2C6.81309 2 2.33594 6.47715 2.33594 12C2.33594 17.5228 6.81309 22 12.3359 22Z"
            stroke="#A2A2A2"
            strokeWidth="1.5"
            stroke-linecap="round"
            strokeLinejoin="round"
          />
        </svg>
      )}
    </label>
  );
};
