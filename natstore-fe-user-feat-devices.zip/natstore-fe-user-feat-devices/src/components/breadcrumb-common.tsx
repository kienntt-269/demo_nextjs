"use client";
import React from "react";
import Link from "next/link";
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbList,
  BreadcrumbPage,
} from "@/components/ui/breadcrumb";
import { IBreadCrumb, ILinks } from "@/types/package";
import { ChevronRight } from "lucide-react";

const BreadCrumbCommon: React.FC<IBreadCrumb> = ({ content }) => {
  return (
    <div className="max-md:mt-6">
      <Breadcrumb>
        <BreadcrumbList>
          {content.map((val: ILinks, index: number) => {
            return (
              <div key={val.link}>
                {index + 1 !== content.length ? (
                  <BreadcrumbItem className="text-[16px] max-md:text-[14px] leading-5 font-normal">
                    {/* <BreadcrumbLink className="text-neutral-dark-03 font-normal"> */}
                    <Link
                      href={val?.link || "#"}
                      className="text-neutral-dark-03 font-normal relative see-more-link"
                      scroll={false}
                    >
                      {val.label}
                    </Link>
                    {/* </BreadcrumbLink> */}
                    {/* <BreadcrumbSeparator className="text-neutral-dark-03" /> */}
                    <ChevronRight color="#333333" size={18} />
                  </BreadcrumbItem>
                ) : (
                  <BreadcrumbItem>
                    <BreadcrumbPage className="text-primary font-bold text-[16px] max-md:text-[14px] leading-5">
                      {val.label}
                    </BreadcrumbPage>
                  </BreadcrumbItem>
                )}
              </div>
            );
          })}
        </BreadcrumbList>
      </Breadcrumb>
    </div>
  );
};

export default BreadCrumbCommon;
