import clsx from "clsx";
import React from "react";

type Props = {
  children: React.ReactNode;
  className?: string;
};

const PageContent = ({ children, className = "" }: Props) => {
  return (
    <div
      className={clsx(
        "pt-0 md:pt-6 px-16 max-lg:px-10 max-md:px-4 pb-12 w-full max-w-[1689px] mx-auto h-auto bg-background-content overflow-hidden",
        className,
      )}
    >
      {children}
    </div>
  );
};
export default PageContent;
