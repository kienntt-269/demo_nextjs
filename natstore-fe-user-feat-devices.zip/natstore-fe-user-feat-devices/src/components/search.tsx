"use client";
import { Button } from "@/components/ui/button";
import { X } from "lucide-react";
import { useTranslations } from "next-intl";
import Image from "next/image";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import React, { useEffect, useState } from "react";

const Search = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [history, setHistory] = useState<string[]>([]);
  const searchParams = useSearchParams();
  const router = useRouter();
  useEffect(() => {
    const storedHistory = localStorage.getItem("search_history");
    if (storedHistory) {
      setHistory(JSON.parse(storedHistory));
    }
  }, []);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      handleSearch();
      (e.target as HTMLInputElement).blur();
    }
  };

  const handleClearHistory = () => {
    localStorage.removeItem("search_history");
    setHistory([]);
  };

  const handleRemove = (indexToRemove: number) => {
    const updatedHistory = history.filter(
      (_, index) => index !== indexToRemove
    );
    setHistory(updatedHistory);
    localStorage.setItem("search_history", JSON.stringify(updatedHistory));
  };

  const updateSearchHistory = (
    term: string,
    updateHistoryFn: React.Dispatch<React.SetStateAction<string[]>>
  ) => {
    const trimmed = term.trim();
    if (!trimmed) return;

    updateHistoryFn((prev: string[]) => {
      const updated = [
        trimmed,
        ...prev.filter((item: string) => item !== trimmed),
      ].slice(0, 5);
      localStorage.setItem("search_history", JSON.stringify(updated));
      return updated;
    });
  };

  const handleSearch = () => {
    if (!searchTerm.trim()) return;

    updateSearchHistory(searchTerm, setHistory);
    router.push(
      `/search?key=${encodeURIComponent(searchTerm.trim())}&parent=packages`
    );
  };

  useEffect(() => {
    const value = searchParams.get("key") || "";
    setSearchTerm(value);
    updateSearchHistory(value, setHistory);
  }, [searchParams.toString()]);
  const t = useTranslations();
  return (
    <div>
      <div className="flex items-center border border-none bg-[#E3E4E5] rounded-3xl h-8">
        <Image
          unoptimized
          quality={100}
          src={"/svg/search.svg"}
          width={16}
          height={16}
          alt="search image"
          className="max-md:size-4 ml-4 mr-2"
        />
        <div className="relative group w-full" id="search-result">
          <div className="relative w-full">
            <input
              type="text"
              placeholder={t("common.search")}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              onKeyDown={handleKeyDown}
              className="w-full bg-transparent outline-none text-gray-700 placeholder:text-neutral-mid-01 pr-8" // tăng pr để tránh nút x đè
            />

            {searchTerm && (
              <button
                type="button"
                onClick={() => setSearchTerm("")}
                className="absolute flex items-center right-3  top-[10px]  -translate-y-1/2 text-gray-400 hover:text-gray-600"
              >
                &times;
              </button>
            )}
          </div>
          <div className="suggest_search absolute  left-[-22%] z-[999999] top-[150%] hidden group-focus-within:flex flex-col bg-white text-black shadow-lg p-4 rounded-md w-[278px]">
            <div className="flex justify-between mb-4">
              <div className="font-bold text-xs text-neutral-dark-01">
                {t("search.search_history")}
              </div>
              {history.length > 0 &&
                <div
                  className="font-bold text-xs text-primary cursor-pointer"
                  onMouseDown={(e) => {
                    e.preventDefault();
                    handleClearHistory();
                  }}
                >
                  {t("search.clear_history")}
                </div>
              }
            </div>
            {
              <div className=" flex flex-col max-h-96 overflow-y-auto">
                {" "}
                {history.map((item, index) => (
                  <div
                    key={index}
                    className="flex px-2 justify-between items-center cursor-pointer overflow-visible hover:bg-gray-100 hover:text-primary rounded-md"
                  >
                    <Link
                      style={{ wordBreak: "break-word" }}
                      className="flex-1"
                      href={`/search?key=${item}&parent=packages`}
                      key={index}
                      onClick={(e) => {
                        (e.target as HTMLInputElement).blur();
                      }}
                    >
                      {item}
                    </Link>

                    <Button
                      variant={"ghost"}
                      onClick={() => handleRemove(index)}
                      className="!p-0"
                    >
                      <X size={20} className="!p-0" color="black" />
                    </Button>
                  </div>
                ))}
              </div>
            }
          </div>
        </div>
      </div>
    </div>
  );
};

export default Search;
