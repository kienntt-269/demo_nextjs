import React from "react";

const CloseCircleIcon = () => {
  return (
    <svg
      width="18"
      height="18"
      viewBox="0 0 18 18"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <rect x="0.5" y="0.5" width="17" height="17" rx="8.5" fill="black" />
      <rect x="0.5" y="0.5" width="17" height="17" rx="8.5" stroke="white" />
      <path
        d="M5.66797 12.3327L12.3346 5.66602"
        stroke="white"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M12.3346 12.3327L5.66797 5.66602"
        stroke="white"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
};

export default CloseCircleIcon;
