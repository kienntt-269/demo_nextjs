import React from "react";

const ChatIcon = () => {
  return (
    <svg
      width="56"
      height="49"
      viewBox="0 0 56 49"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <g opacity="0.3" filter="url(#filter0_d_14642_74471)">
        <path
          d="M51.668 13.2227V39.835C51.668 40.6484 50.7486 41.1215 50.0867 40.6488L43.634 36.0396C43.2948 35.7973 42.8883 35.6671 42.4715 35.6671L17.0013 35.6671C15.8967 35.6671 15.0013 34.7717 15.0013 33.6671V13.2227C15.0013 12.1181 15.8967 11.2227 17.0013 11.2227H49.668C50.7725 11.2227 51.668 12.1181 51.668 13.2227Z"
          fill="white"
        />
      </g>
      <g filter="url(#filter1_d_14642_74471)">
        <path
          d="M4 2V28.6124C4 29.4257 4.91937 29.8989 5.58124 29.4261L12.034 24.817C12.3732 24.5747 12.7796 24.4444 13.1965 24.4444L38.6667 24.4444C39.7712 24.4444 40.6667 23.549 40.6667 22.4444V2C40.6667 0.895431 39.7712 0 38.6667 0H6C4.89543 0 4 0.895432 4 2Z"
          fill="white"
        />
      </g>
      <defs>
        <filter
          id="filter0_d_14642_74471"
          x="11"
          y="11.2227"
          width="44.668"
          height="37.6133"
          filterUnits="userSpaceOnUse"
          colorInterpolationFilters="sRGB"
        >
          <feFlood floodOpacity="0" result="BackgroundImageFix" />
          <feColorMatrix
            in="SourceAlpha"
            type="matrix"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dy="4" />
          <feGaussianBlur stdDeviation="2" />
          <feComposite in2="hardAlpha" operator="out" />
          <feColorMatrix
            type="matrix"
            values="0 0 0 0 0.904167 0 0 0 0 0.241362 0 0 0 0 0.218507 0 0 0 0.25 0"
          />
          <feBlend
            mode="normal"
            in2="BackgroundImageFix"
            result="effect1_dropShadow_14642_74471"
          />
          <feBlend
            mode="normal"
            in="SourceGraphic"
            in2="effect1_dropShadow_14642_74471"
            result="shape"
          />
        </filter>
        <filter
          id="filter1_d_14642_74471"
          x="0"
          y="0"
          width="44.668"
          height="37.6133"
          filterUnits="userSpaceOnUse"
          colorInterpolationFilters="sRGB"
        >
          <feFlood floodOpacity="0" result="BackgroundImageFix" />
          <feColorMatrix
            in="SourceAlpha"
            type="matrix"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dy="4" />
          <feGaussianBlur stdDeviation="2" />
          <feComposite in2="hardAlpha" operator="out" />
          <feColorMatrix
            type="matrix"
            values="0 0 0 0 0.904167 0 0 0 0 0.241362 0 0 0 0 0.218507 0 0 0 0.25 0"
          />
          <feBlend
            mode="normal"
            in2="BackgroundImageFix"
            result="effect1_dropShadow_14642_74471"
          />
          <feBlend
            mode="normal"
            in="SourceGraphic"
            in2="effect1_dropShadow_14642_74471"
            result="shape"
          />
        </filter>
      </defs>
    </svg>
  );
};

export default ChatIcon;
