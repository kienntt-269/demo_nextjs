import React from "react";

const ChatMobileIcon = () => {
  return (
    <svg
      width="40"
      height="35"
      viewBox="0 0 40 35"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <g opacity="0.3" filter="url(#filter0_d_16181_9378)">
        <path
          d="M35.061 9.77832V25.2796C35.061 26.0929 34.1417 26.5661 33.4798 26.0933L30.1381 23.7064C29.7989 23.4641 29.3925 23.3339 28.9757 23.3339L13.7277 23.3339C12.6231 23.3339 11.7277 22.4384 11.7277 21.3339V9.77832C11.7277 8.67375 12.6231 7.77832 13.7277 7.77832H33.061C34.1656 7.77832 35.061 8.67375 35.061 9.77832Z"
          fill="white"
        />
      </g>
      <g filter="url(#filter1_d_16181_9378)">
        <path
          d="M4.72705 2.63672V18.138C4.72705 18.9513 5.64642 19.4245 6.30829 18.9517L9.64995 16.5648C9.98915 16.3225 10.3956 16.1923 10.8124 16.1923L26.0604 16.1923C27.165 16.1923 28.0604 15.2968 28.0604 14.1923V2.63672C28.0604 1.53215 27.165 0.636719 26.0604 0.636719H6.72705C5.62248 0.636719 4.72705 1.53215 4.72705 2.63672Z"
          fill="white"
        />
      </g>
      <defs>
        <filter
          id="filter0_d_16181_9378"
          x="7.72754"
          y="7.77832"
          width="31.3335"
          height="26.5029"
          filterUnits="userSpaceOnUse"
          colorInterpolationFilters="sRGB"
        >
          <feFlood floodOpacity="0" result="BackgroundImageFix" />
          <feColorMatrix
            in="SourceAlpha"
            type="matrix"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dy="4" />
          <feGaussianBlur stdDeviation="2" />
          <feComposite in2="hardAlpha" operator="out" />
          <feColorMatrix
            type="matrix"
            values="0 0 0 0 0.904167 0 0 0 0 0.241362 0 0 0 0 0.218507 0 0 0 0.25 0"
          />
          <feBlend
            mode="normal"
            in2="BackgroundImageFix"
            result="effect1_dropShadow_16181_9378"
          />
          <feBlend
            mode="normal"
            in="SourceGraphic"
            in2="effect1_dropShadow_16181_9378"
            result="shape"
          />
        </filter>
        <filter
          id="filter1_d_16181_9378"
          x="0.727051"
          y="0.636719"
          width="31.3335"
          height="26.5029"
          filterUnits="userSpaceOnUse"
          colorInterpolationFilters="sRGB"
        >
          <feFlood floodOpacity="0" result="BackgroundImageFix" />
          <feColorMatrix
            in="SourceAlpha"
            type="matrix"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dy="4" />
          <feGaussianBlur stdDeviation="2" />
          <feComposite in2="hardAlpha" operator="out" />
          <feColorMatrix
            type="matrix"
            values="0 0 0 0 0.904167 0 0 0 0 0.241362 0 0 0 0 0.218507 0 0 0 0.25 0"
          />
          <feBlend
            mode="normal"
            in2="BackgroundImageFix"
            result="effect1_dropShadow_16181_9378"
          />
          <feBlend
            mode="normal"
            in="SourceGraphic"
            in2="effect1_dropShadow_16181_9378"
            result="shape"
          />
        </filter>
      </defs>
    </svg>
  );
};

export default ChatMobileIcon;
