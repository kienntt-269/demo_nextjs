"use client";
import React from "react";
import Link from "next/link";
import TextCSRStyle from "@/components/text-csr-style";

type IProps = {
  href: string;
};

const ButtonSeeMore = ({ href }: IProps) => {
  return (
    <Link
      href={href || "#"}
      className="text-primary text-[32px] relative see-more-link group transition-all duration-300 max-2xl:text-[28px] max-xl:text-[24px] max-md:text-[14px] font-bold"
    >
      <TextCSRStyle>common.see_all</TextCSRStyle>
    </Link>
  );
};

export default ButtonSeeMore;
