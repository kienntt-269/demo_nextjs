"use client";
import { useTranslations } from "next-intl";
import React from "react";

type IProps = { children: React.ReactNode; classStyle?: string };

const TextCSRStyle: React.FC<IProps> = ({ children, classStyle }) => {
  const t = useTranslations();
  return <span className={`${classStyle}`}>{t(`${children}`)}</span>;
};

export default TextCSRStyle;
