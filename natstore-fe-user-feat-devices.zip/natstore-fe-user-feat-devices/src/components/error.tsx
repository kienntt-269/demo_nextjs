"use client";
import { cn } from "@/lib/utils";
import { useTranslations } from "next-intl";
import Image from "next/image";
import React from "react";

export default function ErrorPage() {
  const t = useTranslations();
  return (
    <div
      className={cn("flex flex-col items-center justify-center my-8 flex-1")}
    >
      <div className="w-full max-w-[480px] h-auto max-h-[216px]">
        <Image
          src={"/unavailable.svg"}
          alt="unavailable"
          fill
          quality={100}
          className="w-full !relative"
        />
      </div>
      <div className="mt-8 font-bold text-2xl md:text-[28px] text-neutral-dark3 text-center">
        {t("common.no_service")}
      </div>
      <div className="md:text-xl text-neutral-dark3">
        {t("common.try_again")}
      </div>
    </div>
  );
}
