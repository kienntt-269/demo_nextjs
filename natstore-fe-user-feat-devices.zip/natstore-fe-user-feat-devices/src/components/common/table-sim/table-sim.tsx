"use client";
import React, { useEffect, useRef, useState } from "react";
import { Input } from "@/components/ui/input";
import { useTranslations } from "next-intl";
import { ChevronLeft, ChevronRight, Search } from "lucide-react";

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import FilterSimPackage from "@/app/mobile-package/buy-sim/filter-sim-package";
import { IColumnTable } from "@/types/common";
import PaginationCustom from "@/components/pagination-custom";
import { usePathname, useRouter } from "next/navigation";
import simApiRequest from "@/services/sim-service";
import {
  ISimCard,
  ISimCardListRes,
  IHotKey,
  ISimType,
} from "@/schemaValidations/sim-card.schema";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useSimCardStore } from "@/_stores/useSimCard.store";
import { useIsMobile } from "@/hooks/use-mobile";
import Image from "next/image";

interface ITableSim {
  response?: ISimCardListRes;
  searchParams: { [key in string]: string };
  simType: ISimType;
}

export function TableSIM({ response, searchParams, simType }: ITableSim) {
  const t = useTranslations();
  const router = useRouter();
  const [searchValue, setSearchValue] = useState<string>("");
  const { setSimDetail } = useSimCardStore();
  // const [open, setOpen] = useState<boolean>(false);
  const [chooseSim, setChooseSim] = useState<string | number>();
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const [showPrev, setShowPrev] = useState<boolean>(false);
  const [showNext, setShowNext] = useState<boolean>(false);
  const [queryHotKey, setQueryHotKey] = useState<string>("");
  const isMobile = useIsMobile();
  const pathname = usePathname();
  const [total, setTotal] = useState<number>(0);
  const [page, setPage] = useState<number>(1);
  const [hotKey, setHotKey] = useState<IHotKey[]>([]);
  useEffect(() => {
    if (searchParams?.hotKey) {
      setSearchValue(searchParams?.hotKey);
    } else if (searchParams?.isdnNumber) {
      setSearchValue(searchParams?.isdnNumber);
    } else {
      setSearchValue("");
    }
    setSimDetail({} as ISimCard);

    setTotal(response?.data?.total_records ?? 0);
    setPage(response?.data?.current_page ?? 0);
    if (searchParams?.chooseSim) {
      const detail = response?.data.pagination.find(
        (val) => val.id == searchParams?.chooseSim
      );
      setChooseSim(Number(searchParams?.chooseSim));
      setSimDetail(detail as ISimCard);
    }
  }, [searchParams]);

  const updateSearchParams = (
    newParams: Record<string, string | null> | { [x: string]: boolean }
  ) => {
    const params = new URLSearchParams(searchParams);

    Object.entries(newParams).forEach(([key, value]) => {
      if (value === null) {
        params.delete(key);
      } else {
        params.set(key, value);
      }
    });
    return `?${params.toString()}`;
  };
  const column: IColumnTable<ISimCard>[] = [
    {
      header: t("common.no"),
      key: "id",
      classStyleHeader:
        "pl-8 w-[250px] 2xl:w-[300px] max-md:pl-3 max-xl:w-auto",
      render: (value, record, i) => {
        return (
          <div className="text-[20px] max-md:w-[20px] max-md:text-[14px] font-bold">
            <div>{page * 10 - 10 + i + 1}</div>
          </div>
        );
      },
    },

    {
      header: t("common.sim_number"),
      key: "phone",
      render: (value, record) => {
        return (
          <div className="text-[20px] max-md:text-[14px] max-md:w-[100px] font-bold max-md:font-normal">
            <div>{record?.isdn}</div>
          </div>
        );
      },
      classStyleHeader: "max-md:px-3",
    },
    {
      header: t("common.price"),
      key: "price",
      render: (value, record) => {
        return (
          <div className="text-primary font-bold text-[20px] max-md:text-[14px] flex gap-x-1">
            <div> {Number(record.price).toLocaleString("en-US")}</div>
            <div>{t("mobile_package.htg")}</div>
          </div>
        );
      },
      classStyleHeader: "max-xl:w-auto max-md:px-3",
    },
    {
      header: t("mobile_package.type_card"),
      key: "cycle",
      render: (value, record) => {
        return (
          <div className="text-[20px] max-md:text-[14px] max-md:w-[100px] font-bold">
            <div>{record?.typeCard ?? "-"}</div>
          </div>
        );
      },
      classStyleHeader: "max-md:px-3",
    },
    {
      header: "",
      key: "id",
      render: (value, record) => {
        return (
          <div className="flex items-center justify-center">
            <RadioGroup value={`${chooseSim}`}>
              <div className="flex items-center space-x-2">
                <RadioGroupItem
                  onClick={() => {
                    console.log(record);
                    setChooseSim(record?.id ?? "");
                    setSimDetail(record);
                  }}
                  value={`${record?.id ?? ""}`}
                  id={record?.id ?? ""}
                  className="border border-solid border-primary"
                />
              </div>
            </RadioGroup>
          </div>
        );
      },
      classStyleHeader: "max-md:px-3",
    },
  ];

  const simTypeChange = () => {
    switch (searchParams.type) {
      case "1":
        return t("mobile_package.sim_normal.xchange_sim");
      case "2":
        return t("mobile_package.sim_normal.student_sim");
      case "3":
        return t("mobile_package.sim_normal.dcom_sim");
      default:
        return t("mobile_package.sim_normal.xchange_sim");
    }
  };

  const checkScroll = () => {
    const container = scrollContainerRef.current;
    if (
      container &&
      container.scrollWidth > container.clientWidth &&
      container.scrollLeft + container.clientWidth < container.scrollWidth
    ) {
      setShowPrev(true);
      setShowNext(true);
    }
  };

  useEffect(() => {
    setTimeout(checkScroll, 300);
    window.addEventListener("resize", checkScroll);
    return () => window.removeEventListener("resize", checkScroll);
  }, []);

  const scroll = (direction: "left" | "right") => {
    const container = scrollContainerRef.current;
    if (container) {
      const scrollAmount = container.clientWidth / 2;
      container.scrollBy({
        left: direction === "left" ? -scrollAmount : scrollAmount,
        behavior: "smooth",
      });
    }
  };

  const getListHotKey = async () => {
    try {
      const res = await simApiRequest.getHotKey();
      const sortedList = res.payload?.data?.sort((a, b) => {
        if (a.sortOrder === null && b.sortOrder === null) return 0;
        if (a.sortOrder === null) return 1;
        if (b.sortOrder === null) return -1;
        return a.sortOrder - b.sortOrder;
      });
      setHotKey(sortedList ?? []);
    } catch (error) {
      console.log(error);
    }
  };

  const handleKeyDown = (event: React.KeyboardEvent<HTMLInputElement>) => {
    if (event.key === "Backspace" || event.key === "Delete") {
      setQueryHotKey("");
    }
  };

  useEffect(() => {
    getListHotKey();
  }, []);
  const simTypeChangeBg = () => {
    switch (searchParams.type) {
      case "1":
        return "md:bg-[url('/mobile-package/bg_description_sim.png')]";
      case "2":
        return "md:bg-[url('/mobile-package/student-sim.png')]";
      case "3":
        return "md:bg-[url('/mobile-package/d-com-sim.png')]";
      default:
        return "md:bg-[url('/mobile-package/bg_description_sim.png')]";
    }
  };
  return (
    <div>
      <div className="mt-6 flex max-lg:block justify-between items-center ">
        <div className="gap-x-6 flex-1 2xl:flex items-center max-lg:mb-2 justify-between">
          <div className="flex gap-x-2">
            <div className="relative xl:max-w-[596px] max-xl:w-full">
              <Input
                className="xl:w-[329px] max-lg:w-full text-normal pl-8 h-[38px] bg-[#E3E4E5] rounded-xl font-normal outline-none border-none"
                placeholder={t("mobile_package.sim_normal.search_sim")}
                value={searchValue}
                onChange={(event) => {
                  if (
                    event.target.value === "" ||
                    (/^\d*$/.test(event.target.value) &&
                      Number(event.target.value) >= 0)
                  ) {
                    setSearchValue(event.target.value);
                  }
                  if (!event.target.value) {
                    setQueryHotKey("");
                    router.push(
                      `${pathname}${updateSearchParams({
                        isdnNumber: "",
                        hotKey: "",
                        page: "1",
                      })}`,
                      {
                        scroll: false,
                      }
                    );
                  }
                }}
                onKeyDown={(event) => {
                  handleKeyDown(event);
                  if (event.key === "Enter") {
                    router.push(
                      `${pathname}${updateSearchParams({
                        isdnNumber: queryHotKey ? "" : searchValue,
                        hotKey: queryHotKey ?? "",
                        page: "1",
                      })}`,
                      {
                        scroll: false,
                      }
                    );
                  }
                }}
              />
              <Search
                strokeWidth={1}
                className="absolute top-[11px] left-2 size-4"
              />
            </div>
            <button
              onClick={() => {
                router.push(
                  `${pathname}${updateSearchParams({
                    isdnNumber: queryHotKey ? "" : searchValue,
                    hotKey: queryHotKey ?? "",
                  })}`,
                  {
                    scroll: false,
                  }
                );
              }}
              className="h-[40px] max-md:h-[38px] max-md:w-[70px] px-[52px] flex items-center justify-center rounded-2xl bg-primary border-none text-white font-bold text-[14px]"
            >
              {t("common.search")}
            </button>
          </div>
          <div className="flex items-center gap-x-2 max-xl:mt-4 max-xl:block max-lg:mt-2">
            {hotKey.length > 0 && (
              <div className="font-semibold text-neutral-mid-01 max-md:text-[12px]">
                {t("common.hot_key")}
              </div>
            )}
            <div className="flex justify-between items-center gap-x-4 max-md:block">
              {hotKey.length > 0 && (
                <div className="flex items-center gap-x-2">
                  {showPrev && (
                    <button
                      className="rounded xl:size-8 size-6 flex items-center justify-center bg-[#E3E4E5] max-md:hidden"
                      onClick={() => scroll("left")}
                      aria-label="Previous Slide"
                    >
                      <ChevronLeft size={isMobile ? 12 : 16} />
                    </button>
                  )}
                  <div
                    ref={scrollContainerRef}
                    className="flex max-w-[550px] items-center gap-x-8 max-md:gap-x-4 text-primary font-bold text-xl max-md:text-[14px] overflow-x-scroll no-scrollbar"
                  >
                    {hotKey.length > 0 &&
                      hotKey.map((val) => {
                        return (
                          <div
                            key={val.id}
                            onClick={() => {
                              setSearchValue(val.hotKey);
                              setQueryHotKey(val.hotKey);
                            }}
                            className="cursor-pointer"
                          >
                            {val.hotKey}
                          </div>
                        );
                      })}
                  </div>
                  {showNext && (
                    <button
                      className="rounded xl:size-8 size-6 flex items-center justify-center bg-[#E3E4E5] max-md:hidden"
                      onClick={() => scroll("right")}
                      aria-label="Previous Slide"
                    >
                      <ChevronRight size={isMobile ? 12 : 16} />
                    </button>
                  )}
                </div>
              )}
              <FilterSimPackage searchParams={searchParams} />
            </div>
          </div>
        </div>
      </div>

      <div className="mt-6 max-md:mt-4">
        {/* <div className="h-full w-full bg-primary rounded-3xl max-xl:mb-4 max-xl:h-[300px] max-md:h-[200px]">
            <div className="text-white font-bold text-[28px] max-md:text-[16px] max-md:p-4 max-xl:text-[24px] py-7 h-full flex flex-col items-center max-md:items-start">
              <div>
                {(searchParams?.type === "1" || !searchParams.type) &&
                  t("mobile_package.sim_normal.xchange_sim")}
                {searchParams?.type === "2" &&
                  t("mobile_package.sim_normal.student_sim")}
                {searchParams?.type === "3" &&
                  t("mobile_package.sim_normal.dcom_sim")}
              </div>
              <div className="flex-1 flex-col flex justify-center items-center ">
                <div
                  className="text-[20px] max-md:text-[14px] text-white py-2 px-6 bg-[#FFFFFF33] rounded-[26px] cursor-pointer"
                  onClick={() => {
                    setOpen(true);
                  }}
                >
                  {t("common.description")}
                </div>
              </div>
              <Modal
                isOpen={open}
                onClose={(value) => {
                  setOpen(value);
                }}
                title={simTypeChange() + " " + t("mobile_package.detail")}
              >
                <div className="max-md:text-[12px] whitespace-pre-line max-h-[600px] overflow-y-scroll">
                  {simType.value}
                </div>
              </Modal>
            </div>
          </div> */}
        <div
          className={`${simTypeChangeBg()} w-full relative h-80 max-xl:h-60 max-2xl:h-72 max-lg:h-44 max-md:h-[149px] max-md:rounded-2xl overflow-hidden max-md:bg-primary bg-[url('/mobile-package/bg_description_sim_mob.png')] bg-no-repeat bg-contain p-0 border-0 max-md:p-4`}
          style={{
            backgroundSize: "100% 100%",
          }}
        >
          <div className="absolute max-md:hidden top-0 left-0 w-[58.5%] py-[71px] max-2xl:py-16 max-xl:py-10 px-14 h-full text-white font-bold">
            <div className="text-[32px] max-xl:text-[24px]">
              {simTypeChange()}
            </div>
            <div className="mt-6 max-xl:mt-3 text-2xl max-xl:text-[18px] line-clamp-4 max-2xl:line-clamp-3 max-lg:line-clamp-2">
              {simType.value}
            </div>
          </div>
          <div className="hidden max-md:block text-white font-bold">
            <div className="text-base">{simTypeChange()}</div>
            <div className="mt-4 line-clamp-4 text-xs">{simType.value}</div>
          </div>
        </div>
        <div className="mt-6 max-md:mt-4">
          <Table className="rounded-t-lg md:rounded-t-2xl overflow-hidden">
            <TableHeader className="bg-[#212121] text-white h-14 max-md:h-8">
              <TableRow className="hover:bg-[#212121]">
                {column.map((col, index) => (
                  <TableHead
                    key={`header-table${index}`}
                    className={`text-white font-bold text-xl max-md:text-[12px] ${col.classStyleHeader}`}
                  >
                    {col.header}
                  </TableHead>
                ))}
              </TableRow>
            </TableHeader>
            <TableBody className="bg-white">
              {response?.data?.pagination &&
                response?.data?.pagination.length > 0 &&
                response?.data.pagination?.map((row, indexRow) => (
                  <TableRow
                    key={indexRow}
                    onClick={() => {
                      setChooseSim(row?.id ?? "");
                      setSimDetail(row);
                    }}
                    className={`text-xl h-20 max-md:h-[54px] hover:bg-[#ffebd6] ${chooseSim === row.id ? "bg-[#ffebd6]" : ""}`}
                  >
                    {column.map((col, i) => (
                      <TableCell
                        className={`font-bold text-neutral-dark-02 ${col.classStyleHeader}`}
                        key={i}
                      >
                        {col?.render
                          ? col.render(
                              row[col.key as keyof typeof row],
                              row,
                              indexRow
                            )
                          : (row as unknown as Record<string, string>)[col.key]}
                      </TableCell>
                    ))}
                  </TableRow>
                ))}
            </TableBody>
          </Table>
          {response?.data?.pagination.length === 0 && (
            <div className="py-28 max-lg:py-12 max-md:py-4 max-lg:h-auto text-neutral-dark-03 bg-[white] flex flex-col items-center justify-center w-full">
              <Image
                src={"/unavailable.svg"}
                alt=""
                unoptimized
                quality={100}
                className="object-contain max-lg:w-[400px] max-lg:h-[200px]"
                width={600}
                height={600}
              />
              <div className="text-[28px] max-lg:text-[20px] font-bold mt-4 max-lg:mt-2">
                {t("mobile_package.no_sim_found")}
              </div>
              <div className="text-[20px] max-lg:text-[14px] font-normal mt-4 max-lg:mt-2">
                {t("mobile_package.please_try_another_number")}
              </div>
            </div>
          )}
        </div>
        {total > 0 && (
          <div className="mt-6 max-md:mt-3">
            <PaginationCustom
              totalItems={total}
              itemsPerPage={10}
              current={page}
              onChange={(value) => {
                router.push(
                  `${pathname}${updateSearchParams({
                    page: `${value}`,
                  })}`,
                  {
                    scroll: false,
                  }
                );
              }}
            />
          </div>
        )}
      </div>
    </div>
  );
}

export default TableSIM;
