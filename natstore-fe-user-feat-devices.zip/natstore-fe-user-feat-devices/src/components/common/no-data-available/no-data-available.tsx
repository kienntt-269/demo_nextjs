"use client";
import React from "react";
import Image from "next/image";
import { useTranslations } from "next-intl";

const NoDataAvailable = () => {
  const t = useTranslations();
  return (
    <div className="w-full py-8 max-lg:py-4 flex flex-col items-center justify-center">
      <Image
        src={"/unavailable.svg"}
        alt=""
        unoptimized
        quality={100}
        className="object-contain w-auto h-[216px] max-lg:h-[140px]"
        width={600}
        height={600}
      />
      <div className="text-[28px] max-lg:text-[20px] font-bold mt-4 max-lg:mt-2">
        {t("common.no_data")}
      </div>
    </div>
  );
};

export default NoDataAvailable;
