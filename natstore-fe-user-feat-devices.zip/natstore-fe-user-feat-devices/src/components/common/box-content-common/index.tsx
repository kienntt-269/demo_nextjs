import { cn } from "@/lib/utils";
import React from "react";

type Props = {
  className: string;
  children: React.ReactNode;
};

const BoxContentCommon = ({ className, children }: Props) => {
  return (
    <div
      className={cn(
        "w-full shadow-box-card rounded-3xl p-4 md:p-8 flex flex-col gap-6 md:gap-8 bg-white",
        className,
      )}
    >
      {children}
    </div>
  );
};

export default BoxContentCommon;
