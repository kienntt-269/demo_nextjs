"use client";
import React from "react";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Filter } from "lucide-react";

type IFilterPackage = React.ComponentProps<typeof Popover> & {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  children: React.ReactNode;
  title?: string;
  icon?: React.ReactNode | string;
};

const FilterPackage: React.FC<IFilterPackage> = ({
  isOpen = false,
  onOpenChange,
  children,
  title,
  icon,
  ...props
}) => {
  return (
    <Popover {...props} open={isOpen} onOpenChange={onOpenChange}>
      <PopoverTrigger asChild>
        <button className="py-3 px-5 max-md:px-3 max-md:py-[6px] rounded-3xl border-[#333333] text-neutral-dark-03 border-solid border flex items-center gap-x-2">
          {icon ? icon : <Filter className="text-[24px] max-md:size-4" />}
          <div className="font-semibold max-md:text-[14px]">
            {title ?? "Filter"}
          </div>
        </button>
      </PopoverTrigger>
      <PopoverContent className="w-60 mt-[-100px] rounded-xl border-white shadow-filterPopover">
        {children}
      </PopoverContent>
    </Popover>
  );
};

export default FilterPackage;
