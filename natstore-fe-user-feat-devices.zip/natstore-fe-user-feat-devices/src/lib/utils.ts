import {
  ERROR_UNAUTHEN,
  ERROR_UNAUTHEN2,
  FAIL_CODE20,
  FAIL_CODE21,
  FAIL_CODE22,
  FAIL_CODE23,
  FAIL_CODE24,
  FAIL_CODE25,
  FAIL_CODE26,
  SUCCESS_CODE,
  SUCCESS_CODE2,
  SUCCESS_CODE3,
} from "@/constants/http-response";
import { emailSchema, phoneSchema } from "@/schemaValidations/auth.schema";
import { clsx, type ClassValue } from "clsx";
import { jwtDecode } from "jwt-decode";
import { twMerge } from "tailwind-merge";
import { z } from "zod";
import CryptoJS from "crypto-js";
import {
  FORMAT_HHMM,
  FORMAT_TIME_CHAT_SERVER,
  LIST_PHONE_HAITI_PREFIX,
} from "@/constants/common";
import dayjsLib from "@/lib/dayjs";
import uploaderApiRequest from "@/services/uploader";
import envConfig from "@/config";
import parse, { DOMNode } from "html-react-parser";
import { getImageUrl } from "@/constants/imageUrl";
import React from "react";
import { useTranslations } from "next-intl";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export const normalizePath = (path: string) => {
  return path.startsWith("/") ? path.slice(1) : path;
};

export const buildEndpoint = (
  path: string,
  params: Record<string, string | number | boolean | undefined | null>
): string => {
  const filteredParams = Object.fromEntries(
    Object.entries(params).filter(
      ([_, value]) => value !== undefined && value !== null && value !== "" && _
    )
  );

  const queryString = new URLSearchParams(
    filteredParams as Record<string, string>
  ).toString();

  return queryString ? `${path}?${queryString}` : path;
};
export const validatePhone = (phone: string) => {
  let error: null | z.ZodIssue = null;
  try {
    phoneSchema.parse({ phoneNumber: phone });
  } catch (er: unknown) {
    if (er instanceof z.ZodError) {
      error = er.errors[0];
    }
  }
  return error;
};

export const validateEmail = (email: string) => {
  let error: null | z.ZodIssue = null;
  try {
    emailSchema.parse({ email: email });
  } catch (er: unknown) {
    if (er instanceof z.ZodError) {
      error = er.errors[0];
    }
  }
  return error;
};

export const decodeAccessToken = (token: string) => {
  return jwtDecode(token);
};

export const focusInput = (id: string) => {
  const input = document.getElementById(id);
  if (input) {
    input.focus();
  }
};

export const checkResSuccess = (code: string) =>
  code === SUCCESS_CODE || code === SUCCESS_CODE2 || code === SUCCESS_CODE3;

export const checkResErrorData = (code: string) =>
  code === FAIL_CODE20 ||
  code === FAIL_CODE21 ||
  code === FAIL_CODE22 ||
  code === FAIL_CODE23 ||
  code === FAIL_CODE24 ||
  code === FAIL_CODE25 ||
  code === FAIL_CODE26;

export const checkResUnauthen = (code: string) =>
  code == ERROR_UNAUTHEN || code == ERROR_UNAUTHEN2;

export const truncateText = (text: string, maxLength: number) => {
  return text.length > maxLength ? text.slice(0, maxLength) + "..." : text;
};

const secretKey = "mySecretKey";
export const encryptPhoneChatSupporting = (phone: string) =>
  CryptoJS.AES.encrypt(phone, secretKey).toString();

export const decryptPhoneChatSupporting = (cipherText?: string) => {
  if (!cipherText) return "";
  return CryptoJS.AES.decrypt(cipherText, secretKey).toString(
    CryptoJS.enc.Utf8
  );
};

export function isCustomerSupportOnline() {
  const hoursUTC = new Date().getUTCHours();
  const hour = hoursUTC - 5;
  return hoursUTC - 5 >= 7 && hour < 19;
}
export const characterMaps: { [key: string]: string } = {
  "&nbsp;": " ",
  "\n": " ",
};

const encodedString = (str: string) => {
  let newStr = str.trim();
  Object.entries(characterMaps).forEach((value) => {
    const regex = new RegExp(`(${value[0]})`, "gim");
    newStr = newStr.replace(regex, `${value[1] || " "}`);
  });
  return newStr;
};
export const ORIGIN_TEXT = /(<([^>]+)>)/gi;

export const formatHaitiTime = (
  time?: string | Date,
  format = "DD/MM/YYYY HH:mm:ss"
) => {
  return dayjsLib(time).tz("America/Port-au-Prince").format(format);
};

export const getUrlLinks = (text: string) => {
  if (!text) return [];
  const links: Array<string> = [];
  const urlRegex = /(((https?:\/\/)|(www\.))[^\s]+)/g;
  const textOrigin = encodedString(text);
  textOrigin.split(" ").forEach((content) => {
    if (urlRegex.test(content)) {
      const origanalText = content.replace(ORIGIN_TEXT, "");
      links.push(origanalText);
    }
  });
  return links;
};

export const setURL = (text: string) => {
  const urlRegex = /(https?:\/\/[^\s]+)/g;
  return text.replace(urlRegex, (url) => {
    const urlOrigin = url.replace(ORIGIN_TEXT, "");
    return `<a href="${urlOrigin}" target="_blank" rel="noopener" class="underline break-all">${urlOrigin}</a>`;
  });
};

export const formatTimeChatUTC = () =>
  dayjsLib.utc().format(FORMAT_TIME_CHAT_SERVER);
export const formatTimeChatLocal = (timeUTC: string) =>
  dayjsLib.utc(timeUTC).local().format(FORMAT_TIME_CHAT_SERVER);
export const formatTimeMessage = (timeUTC: string) =>
  dayjsLib(formatTimeChatLocal(timeUTC)).format(FORMAT_HHMM);

export const handleUploadFile = async (file: File, bucket = "chat-images") => {
  const formData = new FormData();
  formData.append("file", file);
  formData.append("bucket", bucket);
  const res = await uploaderApiRequest.uploadFile(formData);
  return res?.url;
};

export const convertUrlImageChat = (url: string) => {
  if (url.includes("blob") || url.startsWith("https")) return url;
  if (url.startsWith("/")) return `${envConfig.NEXT_PUBLIC_CMS_URL}${url}`;
  return `${envConfig.NEXT_PUBLIC_CMS_URL}/${url}`;
};

export const formatPhoneSubmit = (phone: string) => {
  phone = phone?.replaceAll("+", "");
  if (phone?.length < 9 || !phone.startsWith("509")) return `509${phone}`;
  return phone;
};

export const formatUnRead = (number: number) => {
  if (!number) return "";
  if (number < 10) return `${number}`;
  return "9+";
};

export const formatPhoneView = (phone?: string) =>
  phone ? `+509${phone}` : "";

export function generateCaptcha(text: string, width = 100, height = 48) {
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext("2d");

  if (!ctx) return null;

  // Reset canvas
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  // // Background
  // ctx.fillStyle = "#fff";
  // ctx.fillRect(0, 0, canvas.width, canvas.height);

  // Noise lines
  for (let i = 0; i < 5; i++) {
    ctx.strokeStyle = getRandomColor();
    ctx.beginPath();
    ctx.moveTo(Math.random() * canvas.width, Math.random() * canvas.height);
    ctx.lineTo(Math.random() * canvas.width, Math.random() * canvas.height);
    ctx.stroke();
  }

  // Captcha text
  ctx.font = "bold 30px Arial";
  ctx.fillStyle = "#000";
  ctx.textBaseline = "middle";
  ctx.textAlign = "center";

  // Slight rotation and placement
  const x = canvas.width / 2;
  const y = canvas.height / 2;
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate((Math.random() - 0.5) * 0.3); // slight rotation
  ctx.fillText(text, 0, 0);
  ctx.restore();

  // Return the data URL of the image
  return canvas.toDataURL();
}

function getRandomColor() {
  const letters = "0123456789ABCDEF";
  let color = "#";
  for (let i = 0; i < 6; i++) {
    color += letters[Math.floor(Math.random() * 16)];
  }
  return color;
}

export function formatMoney(amount?: number): string {
  if (!amount) return "0.0";
  const formatter = new Intl.NumberFormat("en-US", {
    style: "decimal",
    minimumFractionDigits: 0,
    maximumFractionDigits: 1,
  });

  return formatter.format(amount);
}

export function parseStringToHTML(htmlString: string) {
  return parse(htmlString, {
    replace: (domNode: DOMNode, index: number) => {
      if (
        typeof domNode === "object" &&
        domNode.type === "tag" &&
        domNode.name === "img"
      ) {
        const attribs = domNode.attribs || {};
        const src = attribs.src || "";
        attribs.src = getImageUrl(src);
        return React.createElement("img", { ...attribs, key: index });
      }
    },
  });
}

export const checkIsPhoneHaiti = (phone: string) => {
  if (!phone) return false;
  const prefix = phone.slice(0, 2);
  return LIST_PHONE_HAITI_PREFIX.includes(Number(prefix));
};

export const formatTimeWithDay = (
  t: ReturnType<typeof useTranslations>,
  time?: string | Date
): string => {
  if (!time) return "-";
  let parsed;
  if (typeof time === "string") {
    parsed = dayjsLib(time, "DD/MM/YYYY HH:mm:ss", true);
  } else {
    parsed = dayjsLib(time);
  }
  if (!parsed.isValid()) return "-";
  const dayName = parsed.format("dddd");
  return `${parsed.format("HH:mm:ss")} ${t(`common.${dayName}`)} ${parsed.format("MM/DD/YYYY")}`;
};
