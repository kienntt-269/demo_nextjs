export type AddressReceiveValue = "showroom" | "email";
export type PaymentMethodValue = "0" | "1";

export type AddressReceiveOption = {
  label: string;
  value: AddressReceiveValue;
};

export type PaymentMethodOption = {
  label: string;
  value: PaymentMethodValue;
};

export type IParamsSimCard = {
  type?: number | string;
  payType?: number | string;
  isdnNumber?: string;
  hotKey?: string;
  page?: number | string;
  size?: number | string;
  sort?: string;
  typeCard?: string;
};

export type IParamsAddress = {
  type?: number | string;
  parentId?: number | string;
};

export type IVerifyPaymentSimCard = {
  simCardOrderId?: number;
  orderId?: number;
  responseCode?: string;
  billNumber?: string;
  paymentNumber?: string;
};

export type IShowroomDetail = {
  id?: string;
  name?: string;
  location?: string;
  order?: string;
  active?: boolean;
  districtName?: string;
  districtId?: number | string;
  provinceId?: number | string;
  provinceName?: string;
};
