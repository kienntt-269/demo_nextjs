export type DeviceListParams = {
  category?: number | string;
  page?: number;
  size?: number;
  sort?: string;
};
