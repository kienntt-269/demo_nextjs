import React from "react";

export type ILinks = {
  link: string;
  label: string | React.ReactNode;
};

export type IBreadCrumb = {
  content: ILinks[];
};

export type ITab = {
  label?: string | React.ReactNode;
  content?: React.ReactNode | string;
  slug?: React.ReactNode | string;
};

export type IPropsTabs = {
  tabs?: ITab[];
  onChangeTab?: (index: number) => void;
  defaultTab?: number;
  isLine?: boolean;
};

export type ITabs = {
  id: string | number;
  label: string;
  content: React.ReactNode | string;
  params: string;
};

export type TabsProps = {
  data: ITabs[];
  defaultTab?: string;
  textLength?: number;
};

export type ICard = {
  title?: string;
  textBtn?: string;
  description?: string;
  price?: string | number;
  rating?: number;
  image?: string;
  tag?: "hot_plan" | "best_selled" | "recomended";
};
export type ICardVoice = {
  price?: string;
  title?: string;
  textBtn?: string;
  description?: string;
  image?: string;
  day?: string;
  content?: string;
};
