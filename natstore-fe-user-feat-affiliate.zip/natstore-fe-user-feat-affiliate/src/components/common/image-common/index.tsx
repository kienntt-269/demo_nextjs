"use client";
import { useEffect, useState } from "react";
import Image, { ImageProps } from "next/image";

interface ImageCommonProps extends Omit<ImageProps, "src"> {
  src: string;
  fallbackSrc?: string;
}

const ImageCommon: React.FC<ImageCommonProps> = ({
  src,
  fallbackSrc = "/images/vas-default.png",
  ...props
}) => {
  const [imgSrc, setImgSrc] = useState(src);

  useEffect(() => {
    setImgSrc(src);
  }, [src]);

  return (
    <Image
      {...props}
      src={imgSrc}
      onError={() => setImgSrc(fallbackSrc)}
      alt={props.alt}
    />
  );
};

export default ImageCommon;
