import { TOption } from "@/components/form/select-field";
import {
  Select as SelectUI,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import clsx from "clsx";
import React from "react";

type SelectProps = {
  options: TOption[];
  placeholder?: string;
  onValueChange: (value: string) => void;
  className?: string;
};

const Select = ({
  options,
  placeholder,
  onValueChange,
  className,
}: SelectProps) => {
  return (
    <div className={clsx(className)}>
      <SelectUI defaultValue={options?.[0].value} onValueChange={onValueChange}>
        <SelectTrigger
          className={clsx(
            "py-[12px] px-[16px] h-[48px] rounded-xl mt-2 border-2 data-[placeholder]:text-neutral-mid-01"
          )}
        >
          <SelectValue placeholder={placeholder} />
        </SelectTrigger>
        <SelectContent>
          {options?.map((val) => {
            return (
              <SelectItem key={val.value} value={`${val.value}`} className="">
                {val.label}
              </SelectItem>
            );
          })}
        </SelectContent>
      </SelectUI>
    </div>
  );
};

export default Select;
