import { Controller, Control, FieldValues, Path } from "react-hook-form";
import { Input } from "@/components/ui/input";
import Image from "next/image";
import { useState } from "react";
import { useTranslations } from "next-intl";

interface ButtonFilePropsField<TFormValues extends FieldValues> {
  name: Path<TFormValues>;
  control: Control<TFormValues>;
  className?: string;
  label?: string;
  labelBottom?: string;
}

const UploadFileSingle = <TFormValues extends FieldValues>({
  name,
  control,
  className = "",
  label = "Upload File",
  labelBottom = "Upload File",
}: ButtonFilePropsField<TFormValues>) => {
  const t = useTranslations();
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);

  return (
    <Controller
      name={name}
      control={control}
      render={({ field, fieldState: { error } }) => {
        const handleFileChange = (
          event: React.ChangeEvent<HTMLInputElement>
        ) => {
          const files = event.target.files
            ? Array.from(event.target.files)
            : [];
          const validFiles = files.filter((file) =>
            ["image/png", "image/jpeg", "image/jpg"].includes(file.type)
          );

          if (files.length === 0) return;
          const file = validFiles[0];
          const imageUrl = URL.createObjectURL(file);
          setPreviewUrl(imageUrl);

          field.onChange([file]);
          event.target.value = "";
        };

        const handleRemoveFile = () => {
          setPreviewUrl(null);

          field.onChange(null);
        };

        return (
          <div className="flex flex-col items-center">
            <div className={`relative w-[120px] h-[120px] ${className}`}>
              <label className="relative flex flex-col items-center cursor-pointer w-full h-full border-2 max-md:rounded-[8px] border-solid border-[#FF8600] rounded-2xl bg-[#FFEBD6] overflow-hidden">
                {previewUrl ? (
                  <Image
                    src={previewUrl}
                    alt="Preview"
                    layout="fill"
                    objectFit="cover"
                    className="absolute inset-0 rounded-xl max-md:rounded-[8px]"
                  />
                ) : (
                  <div className="flex flex-col items-center justify-center w-full h-full">
                    <Image
                      src="/images/icon/add.svg"
                      alt="add icon"
                      width={24}
                      height={24}
                    />
                    <span className="mt-2 max-md:text-xs text-primary text-base font-bold">
                      {label}
                    </span>
                  </div>
                )}
                <Input
                  type="file"
                  accept="image/png, image/jpeg, image/jpg"
                  className="hidden"
                  onChange={handleFileChange}
                />
              </label>

              {previewUrl && (
                <button
                  type="button"
                  onClick={() => handleRemoveFile()}
                  className="absolute top-1 right-1 bg-white rounded-full p-1 shadow-md"
                >
                  <Image
                    src="/images/icon/delete.png"
                    alt="delete"
                    width={16}
                    height={16}
                  />
                </button>
              )}
            </div>
            {error && (
              <span className="mt-2 text-error text-xs lg:text-sm max-w-60 max-md:max-w-32 text-center">
                {t(`common.message.${error?.message}`)}
              </span>
            )}
            <div className="text-neutral-dark-04 max-md:text-xs max-md:max-w-[68px] text-sm mt-2 text-center">
              {labelBottom}
            </div>
          </div>
        );
      }}
    />
  );
};

export default UploadFileSingle;
