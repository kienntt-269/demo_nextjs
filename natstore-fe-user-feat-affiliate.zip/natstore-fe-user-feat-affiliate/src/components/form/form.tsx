import { zodResolver } from "@hookform/resolvers/zod";
import clsx from "clsx";
import * as React from "react";
import {
  Path,
  PathValue,
  SubmitHandler,
  UseFormProps,
  UseFormReturn,
  useForm,
} from "react-hook-form";
import { ZodType, ZodTypeDef } from "zod";

type FormProps<TFormValues extends Record<string, unknown>, Schema> = {
  className?: string;
  onSubmit: SubmitHandler<TFormValues>;
  children: (methods: UseFormReturn<TFormValues>) => React.ReactNode;
  options?: UseFormProps<TFormValues>;
  id?: string;
  schema?: Schema;
  defaultValue?: Record<string, unknown>;
  isUpdateDefault?: boolean;
};

export type RefForm<
  TFormValues extends Record<string, unknown> = Record<string, unknown>,
> = {
  methods: UseFormReturn<TFormValues>;
};

const FormCommon = React.forwardRef(
  <
    TFormValues extends Record<string, unknown> = Record<string, unknown>,
    Schema extends ZodType<unknown, ZodTypeDef, unknown> = ZodType<
      unknown,
      ZodTypeDef,
      unknown
    >,
  >(
    {
      onSubmit,
      children,
      className,
      options,
      id,
      schema,
      defaultValue,
      isUpdateDefault,
    }: FormProps<TFormValues, Schema>,
    ref: React.Ref<RefForm<TFormValues>>
  ) => {
    const isMounted = React.useRef(false);
    const methods = useForm<TFormValues>({
      ...options,
      resolver: schema && zodResolver(schema),
    });

    React.useImperativeHandle(ref, () => ({ methods }), [methods]);

    React.useEffect(() => {
      if (defaultValue) {
        if (!isMounted.current || (isMounted.current && isUpdateDefault))
          for (const [key, value] of Object.entries(defaultValue)) {
            methods.setValue(
              key as Path<TFormValues>,
              value as PathValue<TFormValues, Path<TFormValues>>
            );
          }
      }
      isMounted.current = true;
    }, [defaultValue, isUpdateDefault]);
    return (
      <form
        autoComplete="false"
        className={clsx("", className)}
        onSubmit={methods.handleSubmit(onSubmit)}
        id={id}
      >
        <input
          autoComplete="false"
          name="hidden"
          type="text"
          id="autocomplete-hidden"
          style={{ display: "none" }}
        />
        {children(methods)}
      </form>
    );
  }
);

FormCommon.displayName = "FormCommon";

export const Form = FormCommon as unknown as <
  TFormValues extends Record<string, unknown> = Record<string, unknown>,
  Schema extends ZodType<unknown, ZodTypeDef, unknown> = ZodType<
    unknown,
    ZodTypeDef,
    unknown
  >,
>(
  props: FormProps<TFormValues, Schema> & {
    ref?: React.Ref<RefForm<TFormValues>>;
  }
) => ReturnType<typeof FormCommon>;
