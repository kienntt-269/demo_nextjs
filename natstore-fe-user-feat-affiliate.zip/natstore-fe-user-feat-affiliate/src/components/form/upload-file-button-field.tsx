// UploadFileButtonField.tsx
import {
  Controller,
  Control,
  FieldValues,
  Path,
  FieldErrors,
} from "react-hook-form";
import { Input } from "@/components/ui/input";
import Image from "next/image";
import { useTranslations } from "next-intl";
// import uploaderApiRequest from "@/services/uploader";

interface ButtonFilePropsField<TFormValues extends FieldValues> {
  name: Path<TFormValues>;
  control: Control<TFormValues>;
  className?: string;
  label?: string;
  multiple?: boolean;
  errors: FieldErrors<FieldValues>;
}

const UploadFileButtonField = <TFormValues extends FieldValues>({
  name,
  control,
  className = "",
  label = "Upload Files",
  multiple = true,
  errors,
}: ButtonFilePropsField<TFormValues>) => {
  const t = useTranslations("common.message");
  // comment tạm BE đang báo gửi dạng file
  // const uploadFileMinio = async (file: File) => {
  //   try {
  //     const formData = new FormData();
  //     formData.append("file", file);
  //     const res = await uploaderApiRequest.uploadFile(formData);
  //     console.log(res);
  //   } catch (error) {
  //     console.log(error);
  //   }
  // };
  return (
    <Controller
      name={name}
      control={control}
      render={({ field }) => {
        const errorMessages = Array.isArray(errors?.[name])
          ? errors?.[name].filter((e) => e?.message).map((e) => e.message)
          : [];

        const error =
          errorMessages.length > 0
            ? errorMessages[errorMessages.length - 1]
            : (errors?.[name]?.message as string);
        const handleFileChange = (
          event: React.ChangeEvent<HTMLInputElement>,
        ) => {
          console.log(event.target.files);
          // if (event.target.files) {
          //   uploadFileMinio(event.target.files[0]);
          // }
          const selectedFiles = Array.from(event.target.files || [])
            .filter((file) =>
              ["image/png", "image/jpeg", "image/jpg"].includes(file.type),
            )
            .slice(0, 3); // Chỉ lấy 3 ảnh đầu tiên
          field.onChange(
            [...(field.value || []), ...selectedFiles].slice(0, 3),
          );
          event.target.value = "";
        };

        const handleRemoveFile = (index: number) => {
          const newFiles = (field.value as unknown[]).filter(
            (_, i) => i !== index,
          );
          field.onChange(newFiles);
        };

        return (
          <>
            <div
              className={`flex justify-start items-center gap-x-4 ${className}`}
            >
              {
                <label className="flex flex-col items-center cursor-pointer px-6 py-[22px] w-24 h-24 border-2 border-solid border-[#FF8600] rounded-xl bg-[#FFEBD6]">
                  <div className="">
                    <Image
                      src="/images/icon/add.svg"
                      alt="add icon"
                      width={24}
                      height={24}
                    />
                  </div>
                  <div className="flex items-center mt-2 text-primary text-base font-bold">
                    <span>{label}</span>
                    <Input
                      type="file"
                      multiple={multiple}
                      accept="image/png, image/jpeg, image/jpg"
                      className="hidden"
                      onChange={handleFileChange}
                    />
                  </div>
                </label>
              }
              {Array.isArray(field.value) && field.value.length > 0 && (
                <>
                  {field.value.map((file: File, index: number) => (
                    <div
                      key={index}
                      className="relative flex items-center gap-4 rounded-lg"
                    >
                      <Image
                        alt={file.name}
                        src={URL.createObjectURL(file)}
                        width={96}
                        height={96}
                      />
                      <Image
                        alt="delete"
                        src="/images/icon/delete.png"
                        width={16}
                        height={16}
                        onClick={() => handleRemoveFile(index)}
                        className="absolute top-2 right-2 rounded-full cursor-pointer"
                      />
                    </div>
                  ))}
                </>
              )}
            </div>
            {error && (
              <span className="mt-2 text-error text-xs lg:text-sm">
                {t(error)}
              </span>
            )}
          </>
        );
      }}
    />
  );
};

export default UploadFileButtonField;
