"use client";

import * as React from "react";
import {
  Controller,
  Control,
  FieldValues,
  Path,
  FieldErrors,
  FieldError,
} from "react-hook-form";

import { cn } from "@/lib/utils";

import { DatePicker } from "@/components/ui/date-picker";
import { FieldWrapper } from "@/components/form/field-wrapper";

interface DatePickerFieldProps<TFormValues extends FieldValues> {
  name: Path<TFormValues>;
  label?: string;
  control: Control<TFormValues>;
  className?: string;
  classNameLabel?: string;
  placeholder?: string;
  errors?: FieldErrors<TFormValues>;
  startYear?: number;
  endYear?: number;
  required?: boolean;
  disabled?: boolean;
}

const DatePickerField = <TFormValues extends FieldValues>({
  name,
  label,
  control,
  className,
  classNameLabel,
  errors,
  placeholder,
  required,
  disabled = false,
}: DatePickerFieldProps<TFormValues>) => {
  return (
    <Controller
      name={name}
      control={control}
      defaultValue={undefined}
      render={({ field: { value, onChange } }) => {
        const error = errors?.[name]?.message as string;
        return (
          <FieldWrapper
            label={label}
            error={errors?.[name] as FieldError}
            required={required}
            className={className}
            classNameLabel={classNameLabel}
          >
            <div className={cn("flex flex-col space-y-1", className)}>
              <DatePicker
                value={value}
                onChange={onChange}
                error={error}
                placeholder={placeholder}
                disabled={disabled}
              />
            </div>
          </FieldWrapper>
        );
      }}
    />
  );
};

export default DatePickerField;
