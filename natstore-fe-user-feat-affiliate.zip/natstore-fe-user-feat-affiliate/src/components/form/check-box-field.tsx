import React from "react";
import {
  Control,
  Controller,
  FieldError,
  FieldErrors,
  FieldValues,
  Path,
} from "react-hook-form";
import { FieldWrapper, TFieldWrapperPassThroughProps } from "./field-wrapper";

// Sử dụng Checkbox từ shadcn/ui
import { Checkbox } from "@/components/ui/checkbox";

type TCheckboxFieldProps<TFormValues extends FieldValues> =
  TFieldWrapperPassThroughProps & {
    name: Path<TFormValues>;
    control: Control<TFormValues>;
    children?: React.ReactNode;
    required?: boolean;
    errors?: FieldErrors<FieldValues>;
    label?: React.ReactNode;
    label2?: React.ReactNode;
    disabled?: boolean;
    className?: string;
  };

export const CheckboxField = <
  TFormValues extends Record<string, unknown> = Record<string, unknown>,
>(
  props: TCheckboxFieldProps<TFormValues>
) => {
  const {
    name,
    control,
    children,
    required,
    errors,
    label,
    label2,
    disabled = false,
    className,
    ...rest
  } = props;

  const error = errors?.[name] as FieldError | undefined;

  return (
    <Controller
      name={name}
      control={control}
      render={({ field }) => (
        <FieldWrapper
          label={label}
          label2={label2}
          error={error}
          required={required}
          className={className}
        >
          <div className="my-6 lg:my-8 flex gap-x-2 items-start">
            <Checkbox
              checked={field.value as boolean}
              disabled={disabled}
              onCheckedChange={(checked) => field.onChange(checked)}
              {...rest}
            />
            {children && (
              <div className="text-sm text-gray-600">{children}</div>
            )}
          </div>
        </FieldWrapper>
      )}
    />
  );
};

export default CheckboxField;
