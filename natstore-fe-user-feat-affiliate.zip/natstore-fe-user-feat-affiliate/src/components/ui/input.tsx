import * as React from "react";

import { cn } from "@/lib/utils";
import CloseIcon from "@/components/icons/close-icon";

const Input = React.forwardRef<
  HTMLInputElement,
  React.ComponentProps<"input"> & {
    isError?: boolean;
    classNameWrapper?: string;
    onClear?: () => void;
  }
>(({ className, classNameWrapper, type, isError, onClear, ...props }, ref) => {
  return (
    <div className={cn("relative", classNameWrapper)}>
      <input
        autoComplete="off"
        autoCorrect="off"
        autoCapitalize="off"
        type={type}
        className={cn(
          "flex h-9 w-full rounded-md border border-input bg-transparent px-4 py-3 lg:text-base transition-colors file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground placeholder:text-muted-foreground outline-none disabled:cursor-not-allowed disabled:opacity-50 text-sm",
          { "border-solid border border-error": isError },
          {
            "focus:border-ring focus:border": !isError,
          },
          className,
        )}
        ref={ref}
        {...props}
      />
      {props.value != "" && onClear && (
        <div
          className="absolute top-3 right-3 cursor-pointer"
          onClick={onClear}
        >
          <CloseIcon />
        </div>
      )}
    </div>
  );
});
Input.displayName = "Input";

export { Input };
