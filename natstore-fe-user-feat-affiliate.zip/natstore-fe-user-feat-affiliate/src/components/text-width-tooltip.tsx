"use client";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { cn } from "@/lib/utils";
import React, { useEffect, useState } from "react";

type Props = {
  content: string;
  textSuffix?: string;
  limit?: number;
  className?: string;
};

const TextWithTooltip = ({
  content,
  limit = 30,
  textSuffix = "",
  className,
}: Props) => {
  const [textVisiable, setTextVisiable] = useState("");
  const [isShowTooltip, setIsShowTooltip] = useState(false);
  const [isOpen, setIsOpen] = useState(false);

  const handleMobileClick = () => {
    setIsOpen(!isOpen);
  };

  useEffect(() => {
    if (content.length > limit) {
      setTextVisiable(
        content.slice(0, limit) + "..." + ` ${textSuffix ? textSuffix : ""}`
      );
      setIsShowTooltip(true);
    } else {
      setIsShowTooltip(false);
      setTextVisiable(content + ` ${textSuffix ? textSuffix : ""}`);
    }
  }, [content, limit, textSuffix]);
  return (
    <TooltipProvider>
      <Tooltip open={isOpen} onOpenChange={handleMobileClick}>
        <TooltipTrigger asChild onClick={handleMobileClick}>
          <span className={cn(className)}>{textVisiable}</span>
        </TooltipTrigger>
        {isShowTooltip && (
          <TooltipContent>
            <p className="max-w-52 break-words">
              {content + ` ${textSuffix ? textSuffix : ""}`}
            </p>
          </TooltipContent>
        )}
      </Tooltip>
    </TooltipProvider>
  );
};

export default TextWithTooltip;
