import React from "react";

const PurchaseIcon = () => {
  return (
    <svg
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M21 12C21 7.0293 16.9707 3 12 3C7.02931 3 3.00001 7.0293 3.00001 12C2.99801 13.4786 3.36159 14.9348 4.05841 16.239L3.00001 21L7.76281 19.9425C9.06639 20.639 10.522 21.0023 12 21C16.9707 21 21 16.9707 21 12Z"
        stroke="black"
        strokeWidth="1.5"
        strokeLinecap="round"
      />
      <path
        d="M12 12V7"
        stroke="black"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M12 12H16.5"
        stroke="black"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
};

export default PurchaseIcon;
