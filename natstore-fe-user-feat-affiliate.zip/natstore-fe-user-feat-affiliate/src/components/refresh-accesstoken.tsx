"use client";
import authApiRequest from "@/services/auth";
import { useRouter } from "next/navigation";
import { useEffect } from "react";

const RefreshAccessToken = () => {
  const router = useRouter();
  useEffect(() => {
    authApiRequest.refreshToken().then((res) => {
      if (!res?.accessToken) {
        window.location.href = "/";
      } else router.refresh();
    });
  }, [router]);
  return <div></div>;
};

export default RefreshAccessToken;
