"use client";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import React, {
  useEffect,
  useRef,
  useState,
  cloneElement,
  isValidElement,
} from "react";

type Props = {
  content: React.ReactNode | string;
  children: React.ReactNode;
};

const ComponentWithTooltip = ({ content, children }: Props) => {
  const [isOpen, setIsOpen] = useState(false);
  const [isOverflowed, setIsOverflowed] = useState(false);
  const textRef = useRef<HTMLElement | null>(null);

  const handleMobileClick = () => {
    setIsOpen(!isOpen);
  };

  const trigger = isValidElement(children)
    ? cloneElement(children as React.ReactElement, {
        ref: textRef,
        onClick: handleMobileClick,
        className: `${children.props.className ?? ""}`,
      })
    : children;

  useEffect(() => {
    const el = textRef.current;
    if (!el) return;

    const checkOverflow = () => {
      const isHorizontallyOverflowed = el.scrollWidth > el.offsetWidth;
      const isVerticallyOverflowed = el.scrollHeight > el.clientHeight;
      setIsOverflowed(isHorizontallyOverflowed || isVerticallyOverflowed);
    };

    const timer = setTimeout(checkOverflow, 30);
    return () => clearTimeout(timer);
  }, [children]);

  return (
    <TooltipProvider>
      <Tooltip open={isOpen} onOpenChange={handleMobileClick}>
        <TooltipTrigger asChild onClick={handleMobileClick}>
          {trigger}
        </TooltipTrigger>
        {isOverflowed && (
          <TooltipContent>
            <p className="max-w-52 break-words">{content}</p>
          </TooltipContent>
        )}
      </Tooltip>
    </TooltipProvider>
  );
};

export default ComponentWithTooltip;
