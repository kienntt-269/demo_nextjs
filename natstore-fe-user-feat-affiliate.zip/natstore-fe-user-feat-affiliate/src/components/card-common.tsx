"use client";
import React from "react";
import { Button } from "@/components/ui/button";
import TagServiceMobile from "@/module/mobile-services/component/tag-service";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import Image from "next/image";
import { Ratings } from "./ui/rating";
import { IDataPlan } from "@/schemaValidations/mobile-service.schema";
import { useRouter } from "next/navigation";
import { Check } from "lucide-react";
import { useDialogAuthStore } from "@/_stores/useDialogAuth.store";
import { useTranslations } from "next-intl";
import { useProfileStore } from "@/_stores/useProfile.store";
import { useSimCardStore } from "@/_stores/useSimCard.store";
import { cn } from "@/lib/utils";
import { useLangStore } from "@/_stores/useLang.store";
import ComponentWithTooltip from "@/components/component-with-tooltip";

type IPropsCard = {
  data?: IDataPlan;
  action?: () => void;
  onDetail?: () => void;
  type: "large" | "medium";
  redirectLink?: string;
  redirectBuy?: string;
  target?: "sim" | "data";
};

const CardCommon: React.FC<IPropsCard> = ({
  data,
  type = "medium",
  action,
  redirectLink,
  redirectBuy,
  target,
  onDetail,
}) => {
  const router = useRouter();
  const t = useTranslations();
  const { lang } = useLangStore();
  const { packageData, setPackageData } = useSimCardStore();
  const { user } = useProfileStore();
  const { setIsOpen, setUrlLoginSuccess } = useDialogAuthStore();

  return (
    <Card
      className="rounded-3xl max-md:rounded-2xl overflow-hidden border-none"
      style={{
        boxShadow: "0px 3.09px 12.37px 0px #00000014",
      }}
      onClick={() => {
        if (action) action();
      }}
    >
      <CardHeader
        className={`p-0 px-3 text-center space-y-0  ${
          type === "large"
            ? ""
            : "bg-[url('/mobile-package/card-header.png')] bg-cover py-[15px] max-md:py-3"
        }`}
      >
        {type === "medium" ? (
          <ComponentWithTooltip content={data?.name ?? "ASWÈ NÈT"}>
            <div className="text-white text-card text-[24px] max-xl:text-[20px] hover:scale-105 transition-all max-md:text-[16px] max-md:font-semibold leading-[34px] max-md:leading-5 font-bold truncate text-ellipsis text-nowrap overflow-hidden">
              {data?.name ?? "ASWÈ NÈT"}
            </div>
          </ComponentWithTooltip>
        ) : (
          <Image
            unoptimized
            quality={100}
            width={368}
            height={260}
            src={"./pic-card.png"}
            className="object-cover w-full"
            alt=""
          />
        )}
      </CardHeader>
      <CardContent className="p-6 max-md:p-3">
        {type === "large" && (
          <>
            <div className="font-bold text-black text-[24px] leading-6 mb-2">
              {data?.name ?? "International Voice"}
            </div>
            <div className="mb-3">
              <Ratings
                rating={data?.rating ?? 0}
                variant="orange"
                totalStars={5}
              />
            </div>
          </>
        )}
        <div className="flex items-center justify-between mb-2 max-md:mb-1 max-md:h-6">
          <div className="flex gap-x-2 items-center line-clamp-1 flex-1">
            <div className="font-semibold max-md:text-[14px] xl:text-[20px] line-clamp-1">
              {Number(data?.price ?? 0)?.toLocaleString("en-US")}
              <span className="text-neutral-mid-01">
                {" "}
                {t("mobile_package.htg")}
              </span>
            </div>
          </div>

          <Ratings
            rating={data?.rating ?? 0}
            variant="orange"
            className="max-md:hidden flex"
          />
          <Ratings
            rating={data?.rating ?? 0}
            variant="orange"
            size={12}
            className="hidden max-md:flex"
          />
        </div>
        <TagServiceMobile data={data} />
        <div className="flex gap-x-2 mt-3 max-md:mt-2 items-start">
          <div className="line-clamp-2 h-10 font-normal text-[14px] leading-5 text-neutral3 max-md:text-[12px] max-md:leading-[15px] max-md:h-8 whitespace-pre-line">
            {data?.description}
          </div>
        </div>
        {/* <button
          className={`mt-4 max-md:mt-3 max-md:h-8 max-md:text-[14px] h-12 flex items-center justify-center w-full border border-solid border-primary py-[13.5px] text-center text-primary font-semibold rounded-3xl  relative overflow-hidden group ${
            type === "large" ? "text-white bg-primary" : ""
          }`}
          onClick={() => {
            if (onRegister) onRegister();
          }}
        >
          <span className="z-10 relative group-hover:text-white">
            {data?.textBtn ?? "Detail"}
          </span>
          <span className="absolute inset-0 bg-primary transform -translate-x-full transition-transform duration-300 ease-in-out group-hover:translate-x-0"></span>
        </button> */}
        <div
          className={cn(
            "flex max-md:flex-col gap-y-2 items-center gap-x-3 max-md:mt-3 mt-6",
            {
              "flex-col": lang === "fr" || lang === "ht",
            }
          )}
        >
          {target === "data" && (
            <Button
              onClick={() => {
                if (user?.id) {
                  router.push(`${redirectBuy}`);
                } else {
                  setIsOpen({ isOpen: true, mode: "LOGIN" });
                  setUrlLoginSuccess(`${redirectBuy}`);
                }
              }}
              className={cn(
                "flex-1 py-[13.5px] max-md:h-8 font-bold w-full max-lg:text-[14px] max-lg:py-2 max-lg:px-4 max-md:py-[6px] max-md:leading-5"
              )}
            >
              {t("mobile_package.data.buy_now")}
            </Button>
          )}
          <Button
            className="flex-1 py-[13.5px] max-md:h-8 font-bold w-full max-lg:text-[14px] max-lg:py-2 max-lg:px-4 max-md:py-[6px] max-md:leading-5"
            variant={"secondary"}
            onClick={() => {
              if (redirectLink) {
                router.push(`${redirectLink}`);
              } else if (onDetail) {
                onDetail();
              }
            }}
          >
            {t("mobile_package.detail")}
          </Button>
          {target === "sim" && (
            <Button
              onClick={() => {
                if (packageData?.id === data?.id) {
                  setPackageData();
                } else {
                  setPackageData(data);
                }
              }}
              className={`flex-1 py-[13.5px] max-md:h-8 font-bold w-full max-lg:text-[14px] max-lg:py-2 max-lg:px-4 max-md:py-[6px] max-md:leading-5 ${packageData?.id === data?.id ? "opacity-50" : "opacity-100"}`}
            >
              <div className="flex items-center justify-center gap-x-2">
                {packageData?.id === data?.id ? <Check /> : <></>}
                {t("common.select")}
              </div>
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default CardCommon;
