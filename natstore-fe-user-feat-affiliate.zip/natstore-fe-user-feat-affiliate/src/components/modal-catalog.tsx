"use client";
import { useDialogAuthStore } from "@/_stores/useDialogAuth.store";
import Modal from "@/components/common/modal/Modal";
import ServiceTabs from "@/module/home-page/component/service-tab";
import { useTranslations } from "next-intl";
import React, { useEffect, useState } from "react";

const ModalCatalog = () => {
  const [isFirstTime, setIsFirstTime] = useState(true);
  const { isOpen } = useDialogAuthStore();

  useEffect(() => {
    const storedValue = sessionStorage.getItem("isFirstTime");

    if (storedValue === null || storedValue === "true") {
      setIsFirstTime(true);
      sessionStorage.setItem("isFirstTime", "true");
    } else {
      setIsFirstTime(false);
    }
  }, []);

  const handleClosePopup = () => {
    setIsFirstTime(false);
    sessionStorage.setItem("isFirstTime", "false");
  };
  const t = useTranslations();

  if (!isFirstTime || isOpen) return null;
  return (
    <div>
      <Modal
        isOpen={isFirstTime}
        onClose={handleClosePopup}
        contentClassName="w-[350px] md:w-[600px] lg:w-[756px] max-w-full bg-background-content"
        title={""}
      >
        <div className="text-center pb-2">
          <div className="font-bold text-2xl mb-6">
            {t("modal_catalog.questtion")}
          </div>
          <div className="text-neutral-dark-04 mb-6">
            {t("modal_catalog.quickly")}
          </div>
          <ServiceTabs classProps="grid grid-cols-3" isCatalog={true} />
        </div>
      </Modal>
    </div>
  );
};

export default ModalCatalog;
