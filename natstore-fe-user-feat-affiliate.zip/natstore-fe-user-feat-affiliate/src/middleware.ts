import { XSRF_TOKEN } from "@/constants/authority";
import { NextRequest, NextResponse } from "next/server";
// This function can be marked `async` if using `await` inside
const privatePaths = ["/personal", "/natcom-point", "/affiliate/register"];
const orderTrackingPublicPaths = [
  "/order-tracking/input-phone",
  "/order-tracking/input-otp",
];
export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;
  const sessionToken = request.cookies.get(XSRF_TOKEN)?.value;

  if (pathname.startsWith("/mobile-package/swap-sim")) {
    return NextResponse.redirect(new URL("/", request.url));
  }

  if (orderTrackingPublicPaths.includes(pathname) && sessionToken) {
    return NextResponse.redirect(new URL("/order-tracking", request.url));
  }

  if (
    pathname.startsWith("/order-tracking") &&
    !orderTrackingPublicPaths.some((path) => pathname.startsWith(path)) &&
    !sessionToken
  ) {
    return NextResponse.redirect(
      new URL("/order-tracking/input-phone", request.url)
    );
  }

  if (privatePaths.some((path) => pathname.startsWith(path)) && !sessionToken) {
    return NextResponse.redirect(new URL("/", request.url));
  }

  const paymentRouteRegex = /^\/mobile-package\/data\/[^/]+\/payment$/;

  if (paymentRouteRegex.test(pathname)) {
    if (!sessionToken) {
      return NextResponse.redirect(new URL("/", request.url));
    } else {
      return NextResponse.next();
    }
  }

  return NextResponse.next();
}

// See "Matching Paths" below to learn more
export const config = {
  matcher: [
    "/",
    "/personal",
    "/natcom-point",
    "/mobile-package/data/:slug/payment",
    "/mobile-package/swap-sim/:path*",
    "/order-tracking/input-phone",
    "/order-tracking/input-otp",
    "/order-tracking",
    "/affiliate/register",
  ],
};
