import { IProfileStore, IUseProfileStore } from "@/types/stores";
import { create } from "zustand";

export const useProfileStore = create<IUseProfileStore>((set) => ({
  user: null,
  token: null,
  refreshToken: null,
  isAffiliate: null,
  setProfile: (profile: IProfileStore) =>
    set((state: IUseProfileStore) => ({ ...state, ...profile })),
}));
