import { ActivateStatusUser } from "@/schemaValidations/mobile-package.schema";
import { IRoamingStore } from "@/types/stores";
import { create } from "zustand";

export const useRoamingStore = create<IRoamingStore>((set) => ({
  data: {
    id: 9007199254740991,
    name: "string",
    transactionId: "string",
    registerAt: "2025-02-13T14:01:13.809Z",
    expireAt: new Date("2025-02-13T14:01:13.809Z"),
    registerStatus: "NOT_REGISTERED",
    activationStatus: "NOT_ACTIVATED",
    usageStatus: {
      remainingDataInByte: 9007199254740991,
      usingDataInByte: 9007199254740991,
    },
    installationInstruction: "string",
  },
  setData: (data: ActivateStatusUser) => set({ data: data }),
}));
