import { create } from "zustand";

export const useDialogAuthStore = create<{
  mode: "LOGIN" | "REGISTER" | "FORGOT" | "LOGOUT";
  isOpen: boolean;
  isAffiliate: boolean;
  urlLoginSuccess: string;
  setIsOpen: ({
    isOpen,
    mode,
    isAffiliate,
  }: {
    isOpen?: boolean;
    mode?: "LOGIN" | "REGISTER" | "FORGOT" | "LOGOUT";
    isAffiliate?: boolean;
  }) => void;
  setUrlLoginSuccess: (endpoint: string) => void;
}>((set) => ({
  mode: "LOGIN",
  isOpen: false,
  isAffiliate: false,
  urlLoginSuccess: "/",
  setIsOpen: (newState) => set((state) => ({ ...state, ...newState })),
  setUrlLoginSuccess: (endpoint) =>
    set((state) => ({ ...state, urlLoginSuccess: endpoint })),
}));
