import envConfig from "@/config";
import http from "@/lib/http";
import { IRequestOtpFormRes } from "@/schemaValidations/mobile-package.schema";
import {
  IAffiliateFAQRes,
  IBannerAffiliateRes,
  IAffiliatePostRes,
  IAffiliatePut,
  IAffiliatePutRes,
  IDetailAffiliateRes,
} from "@/types/affiliate";

const affiliateApiRequest = {
  getFAQ() {
    return http.get<IAffiliateFAQRes>(`/v1/public/affiliate-home/faq`, {
      cache: "no-cache",
    });
  },
  getBannerAffiliate() {
    return http.get<IBannerAffiliateRes>(`/v1/public/affiliate-home/banner`, {
      cache: "no-cache",
    });
  },
  getAffiliateRegister(isdn: string) {
    return http.get<IDetailAffiliateRes>(
      `/v1/public/affiliate/get-detail/${isdn}`,
      {
        cache: "no-cache",
      }
    );
  },
  requestsOtp: (data: { phoneNumber: string }) =>
    http.post<IRequestOtpFormRes>(
      `/v1/public/swap-sim/requests/otp-request`,
      data as unknown as BodyInit
    ),
  postRegister: (data: FormData) => {
    return http.post<IAffiliatePostRes>(
      "/v1/public/affiliate/register",
      data as unknown as BodyInit
    );
  },
  putRegister: (data: IAffiliatePut) =>
    http.put<IAffiliatePutRes>(
      `/v1/public/affiliate`,
      data as unknown as BodyInit,
      {
        baseUrl: envConfig.NEXT_PUBLIC_URL,
      }
    ),
};

export default affiliateApiRequest;
