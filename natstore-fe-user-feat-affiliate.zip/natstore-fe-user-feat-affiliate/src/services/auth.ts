import envConfig from "@/config";
import http from "@/lib/http";
import { storage } from "@/lib/storage";
import { checkResSuccess } from "@/lib/utils";
import {
  LoginBodyType,
  LoginResType,
  RegisterBodyType,
  RegisterOtpResType,
  RegisterResType,
} from "@/schemaValidations/auth.schema";

const authApiRequest = {
  logout: async () => {
    try {
      await fetch(`/api/auth/logout`, {
        method: "POST",
      });
    } catch (error) {
      console.log({ error });
    }
  },
  refreshToken: async () => {
    try {
      const refreshTokenRequest = fetch(`/api/auth/refresh-token`, {
        method: "POST",
      }).then(async (res) => {
        const dataRes = await res.json();
        return dataRes;
      });

      const dataRes = await refreshTokenRequest;
      if (!checkResSuccess(dataRes.code)) {
        storage.removePhoneSupporting();
        return {};
      }
      const { refreshToken: newRefreshToken, accessToken } = dataRes.data;
      return { accessToken, refreshToken: newRefreshToken };
    } catch (error) {
      console.log({ error });
    }
  },
  forgotPassword: (body: LoginBodyType) =>
    http.post<LoginResType>(
      "/v1/public/auth/forget-password",
      body as unknown as BodyInit
    ),
  login: (body: LoginBodyType) =>
    http.post<LoginResType>("/api/auth/login", body as unknown as BodyInit, {
      baseUrl: envConfig.NEXT_PUBLIC_URL,
    }),
  getOtpLogin: (body: { phoneNumber: string; actionType: string }) =>
    http.post<RegisterOtpResType>(
      "/v1/public/auth/check-login-user",
      body as unknown as BodyInit
    ),
  getOtpUpdatePassword: (userId: string) =>
    http.post<RegisterOtpResType>(
      "/api/proxy/v1/api/auth/check-update-password",
      "",
      {
        headers: { "user-id": userId },
        baseUrl: envConfig.NEXT_PUBLIC_URL,
      }
    ),
  register: (body: RegisterBodyType) =>
    http.post<RegisterResType>(
      "/v1/public/auth/register",
      body as unknown as BodyInit
    ),
  getOtpRegister: (body: {
    phoneNumber: string;
    email?: string;
    actionType: string;
  }) =>
    http.post<RegisterOtpResType>(
      "/v1/public/auth/check-register-user",
      body as unknown as BodyInit
    ),
};

export default authApiRequest;
