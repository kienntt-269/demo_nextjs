import envConfig from "@/config";
import http from "@/lib/http";
import {
  IPaymentDataPlanRes,
  IPaymentMethodRes,
} from "@/schemaValidations/payment.schema";
import { RegistrationType } from "@/types/common";

export const paymentService = {
  createDataPlanOrder: async ({ packageId }: { packageId?: string }) => {
    return http.post<{ data: { orderId: string }; code: string }>(
      "/api/proxy/v1/api/data-plans/orders",
      {
        packageId,
      } as unknown as BodyInit,
      {
        baseUrl: envConfig.NEXT_PUBLIC_URL,
      }
    );
  },
  dataPlanbeginNatcashPayment: async ({
    orderId,
    registrationType,
    sharePhoneNumber,
    paymentPhoneNumber,
    debitedPoint,
  }: {
    orderId: string;
    registrationType: RegistrationType;
    sharePhoneNumber?: string;
    paymentPhoneNumber?: string;
    debitedPoint?: number;
  }) => {
    return http.post<{
      data: { paymentUrl: string; price: string };
      code: string;
    }>(
      "/api/proxy/v1/api/data-plans/orders/begin-natcash-payment",
      {
        orderId,
        registrationType,
        sharePhoneNumber,
        paymentPhoneNumber,
        debitedPoint,
      } as unknown as BodyInit,
      {
        baseUrl: envConfig.NEXT_PUBLIC_URL,
      }
    );
  },
  dataPlanVerifyNatcashPayment: async ({
    transactionId,
    code,
    ncTransId,
    signature,
  }: {
    transactionId: string;
    code: string;
    ncTransId: string;
    signature: string;
  }) => {
    return http.post<IPaymentDataPlanRes>(
      "/api/proxy/v1/api/data-plans/orders/verify-natcash-payment",
      {
        transactionId,
        code,
        ncTransId,
        signature,
      } as unknown as BodyInit,
      {
        baseUrl: envConfig.NEXT_PUBLIC_URL,
      }
    );
  },
  dataPlanOrdeNatcomPayment: async ({
    orderId,
    registrationType,
    sharePhoneNumber,
    paymentPhoneNumber,
    debitedPoint,
  }: {
    orderId: string;
    registrationType: RegistrationType;
    sharePhoneNumber?: string;
    paymentPhoneNumber?: string;
    debitedPoint?: number;
  }) => {
    return http.post<IPaymentDataPlanRes>(
      "/api/proxy/v1/api/data-plans/orders/natcom-payment",
      {
        orderId,
        registrationType,
        sharePhoneNumber,
        paymentPhoneNumber,
        debitedPoint,
      } as unknown as BodyInit,
      {
        baseUrl: envConfig.NEXT_PUBLIC_URL,
      }
    );
  },
  simVerifyNatcashPayment: async ({
    transactionId,
    code,
    ncTransId,
    signature,
  }: {
    transactionId: string;
    code: string;
    ncTransId: string;
    signature: string;
  }) => {
    return http.post<IPaymentDataPlanRes>(
      "/api/proxy/v1/public/sim-card-order/verify-payment",
      {
        transactionId,
        code,
        ncTransId,
        signature,
      } as unknown as BodyInit,
      {
        baseUrl: envConfig.NEXT_PUBLIC_URL,
      }
    );
  },

  getPaymentMethods: async (code: "sim" | "internet" | "data" | "roaming") => {
    return http.get<IPaymentMethodRes>(
      `/api/proxy/v1/public/order/common/payment-methods?code=${code}&includeAll=true`,
      { baseUrl: envConfig.NEXT_PUBLIC_URL }
    );
  },

  natcomPayment: async ({
    orderId,
    registrationType,
    paymentPhoneNumber,
    otp,
  }: {
    orderId?: string;
    registrationType?: string;
    paymentPhoneNumber?: string;
    otp?: string;
  }) => {
    return http.post<{ data: { orderId: string }; code: string }>(
      `/api/proxy/v1/api/data-plans/orders/natcom-payment`,
      {
        orderId,
        registrationType,
        paymentPhoneNumber,
        otp,
      } as unknown as BodyInit,
      {
        baseUrl: envConfig.NEXT_PUBLIC_URL,
      }
    );
  },
};
