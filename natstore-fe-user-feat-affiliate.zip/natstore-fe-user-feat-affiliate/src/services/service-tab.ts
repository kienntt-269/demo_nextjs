import http from "@/lib/http";
import { IServiceTabRes } from "@/schemaValidations/service-tab.schema";

const URL_SERVICE_TAB = "/v1/public/homepage/categories";

const serviceTabApiRequest = {
  getDataServiceTab: () => {
    return http.get<IServiceTabRes>(`${URL_SERVICE_TAB}`, {
      cache: "no-cache",
    });
  },
};

export default serviceTabApiRequest;
