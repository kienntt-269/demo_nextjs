import { ISearchHomeRes } from "@/schemaValidations/search-home.schema";
import http from "@/lib/http";

const URL_SEARCH_HOME = "v1/search-service/docs/v1/public/search/home";

const searchHomeApiRequest = {
  getDataSearchHome: (name: string) => {
    return http.get<ISearchHomeRes>(`${URL_SEARCH_HOME}?name=${name}`, {
      cache: "no-cache",
    });
  },
};

export default searchHomeApiRequest;
