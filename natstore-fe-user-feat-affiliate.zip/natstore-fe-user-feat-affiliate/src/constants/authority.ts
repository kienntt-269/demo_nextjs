export enum Authority {
  ADMIN = "ADMIN",
  USER = "USER",
}
export const TOTAL_COUNT_RESPONSE_HEADER = "X-Total-Count";
export const JSESSIONID = "JSESSIONID";
export const XSRF_TOKEN = "XSRF-TOKEN";
export const XSRF_USERID = "XSRF-USERID";
export const XSRF_REFRESH_TOKEN = "XSRF-REFRESH-TOKEN";
export const XSRF_ISAFFILIATE = "XSRF-ISAFFILIATE";
export const ERROR_RETRY_COUNT = 3;
