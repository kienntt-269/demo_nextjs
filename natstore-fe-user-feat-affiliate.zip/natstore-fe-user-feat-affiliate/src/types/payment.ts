export type IPaymentMethod = {
  name?: string;
  code?: string;
  active?: boolean;
};
