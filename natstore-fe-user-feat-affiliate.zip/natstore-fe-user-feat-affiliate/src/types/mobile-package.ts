//vas

import { RegistrationType } from "@/types/common";

export type VasListParams = {
  categoryId?: number;
  categorySlug?: string;
  sortBy?: string;
  promotion?: boolean;
  latest?: boolean;
};

//roaming
export type RegisterItemProps = {
  id?: string | null;
  name?: string | null;
  vote?: number | null;
  price?: string | null;
  imageUrl?: string | null;
  note?: string | null;
  detail?: string | null;
};

export type RegisterItemType = {
  data: RegisterItemProps;
};

export type RoamingDetailType = {
  id: number;
};

export type ConfirmModalProps = {
  data: RegisterItemProps;
  isOpenModal: boolean;
  onClose: () => void;
  onRegister: (phone?: string) => void;
};

export type RegisterDetailType = {
  image: string;
  titleDetail: string;
  titlePackage: string;
  rating: number;
  information: string;
};

export type ICategoryDataPlans = {
  id?: string;
  name: string;
  description: string;
  active: boolean;
  home: boolean;
  icon: string;
  order: string;
  type: string;
  parentId: string;
  createdAt: string;
  updatedAt: string;
  createdBy: string;
  updatedBy: string;
  slug: string;
};

export type IParamsDataPlans = {
  categorySlug?: string;
  sortBy?: string;
  promotion?: boolean;
  latest?: boolean;
  simCard?: boolean;
  categoryId?: string | number;
};

export type PaymentFormValues = {
  orderId: string;
  registrationType: RegistrationType;
  sharePhoneNumber?: string;
  paymentPhoneNumber?: string;
  otp?: string;
  packageId?: string;
  method?: string;
};

export type ISimCardOrder = {
  request: {
    simNumber?: string;
    type: number;
    price?: number;
    packageId?: string | number;
    packagePrice?: number;
    isIncludedVat?: number;
    vatPrice?: number;
    provinceId?: string | number;
    districtId?: string | number;
    communeId?: number;
    fullName: string;
    dob: string;
    cardId: string;
    vatId?: number;
    mobileNumber: string;
    simType: number;
    receivedType: number;
    timeOfReceiving: string;
    showroomId?: string | number;
    email?: string;
    whatsappNumber?: string;
    paymentMethod?: string | number;
    typeDocument?: number;
  };
  files?: File[];
  frontIdCard?: string;
  backIdcard?: string;
  faceImage?: string;
};
