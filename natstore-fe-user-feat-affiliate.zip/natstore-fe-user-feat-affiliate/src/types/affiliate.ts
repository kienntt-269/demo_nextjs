import { RegisterAccountAffiliateType } from "@/schemaValidations/affiliate.schema";

export interface IAffiliateFAQ {
  id?: string;
  question?: string;
  answer?: string;
  sortOrder?: string;
  faqCategoryId?: string;
  createdAt?: string;
}

export interface IAffiliateFAQRes {
  code: string;
  data: IAffiliateFAQ[];
  message: string;
}

export interface IBannerAffiliate {
  imagePath: string;
  imageWapPath: string;
  bannerLink: string | number;
  bannerName: string;
}

export interface IBannerAffiliateRes {
  code: string;
  data: IBannerAffiliate;
  message: string;
}

export interface IDetailAffiliateRes {
  code: string;
  data: RegisterAccountAffiliateType;
  message: string;
}

export type IAffiliatePost = {
  isdn: string;
  email: string;
  fullName: string;
  birthday: string;
  gender: number;
  customerDocType: number;
  cardId: string;
  taxNumber: string;
  provinceId: number;
  districtId: number;
  communeId: number;
  addressDetail: string;
  paymentPhone: string;
  paymentMethod: number;
  terms: number;
  isLoginOtp: number;
  otp?: string;
};

export interface IDataAffiliate {
  isLoginWithPass?: number;
}

export interface IAffiliatePostRes {
  code: string;
  data: IDataAffiliate;
  message: string;
}

export interface IAffiliatePut {
  isdn: number;
  email: string;
  taxNumber: string;
  provinceId: number;
  districtId: number;
  communeId: number;
  addressDetail: string;
  paymentPhone: string;
  isValidateOtp: number;
}

export interface IAffiliatePutRes {
  code: string;
  data: IAffiliatePut;
  message: string;
}
