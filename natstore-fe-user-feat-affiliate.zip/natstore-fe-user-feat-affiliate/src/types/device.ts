export type DeviceListParams = {
  category?: number | string;
  slug?: string;
  page?: number;
  size?: number;
  sort?: string;
};

export type IDeviceOrder = {
  provinceId?: string | number;
  districtId?: string | number;
  communeId?: number;
  fullName: string;
  mobileNumber: string;
  receivedType: number;
  timeOfReceiving: string;
  showroomId?: string | number;
  email?: string;
  paymentMethod?: string | number;
  productId?: number;
  quantity?: number;
  price?: number;
};
