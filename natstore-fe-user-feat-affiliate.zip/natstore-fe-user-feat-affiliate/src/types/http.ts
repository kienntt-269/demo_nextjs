export type CustomOptions = Omit<RequestInit, "method"> & {
  baseUrl?: string | undefined;
  refreshToken?: string | undefined;
  body?: BodyInit | object;
};

export type EntityErrorPayload = {
  message: string;
  errors: {
    field: string;
    message: string;
  }[];
};

export type PayloadType = { message: string; [key: string]: string | object };
