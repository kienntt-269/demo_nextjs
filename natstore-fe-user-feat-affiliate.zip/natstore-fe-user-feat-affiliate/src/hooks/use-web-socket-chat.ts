import {
  useEffect,
  useState,
  useRef,
  MutableRefObject,
  useCallback,
} from "react";
import SockJS from "sockjs-client";
import { Client } from "@stomp/stompjs";
import envConfig from "@/config";
import { MessageDataType } from "@/types/common";

const useWebSocketChat = (roomId?: string) => {
  const [lastMessage, setLastMessage] = useState(null);
  const [isConnected, setIsConnected] = useState(false);
  const stompClientRef = useRef<Client>(
    null,
  ) as MutableRefObject<Client | null>;

  const sendMessageFromAdmin = useCallback(
    (messageContent: MessageDataType) => {
      if (stompClientRef.current && stompClientRef.current.connected) {
        console.log("%cSending message from admin", "color: blue", messageContent);
        stompClientRef.current.publish({
          destination: `/app/server/chat/${roomId}/sendMessage`,
          body: JSON.stringify(messageContent),
        });
      }
    },
    [roomId],
  );

  const sendMessage = useCallback(
    (messageContent: MessageDataType) => {
      if (stompClientRef.current && stompClientRef.current.connected) {
        console.log("%cSending message", "color: blue", messageContent);
        stompClientRef.current.publish({
          destination: `/app/client/chat/${roomId}/sendMessage`,
          body: JSON.stringify(messageContent),
        });
      }
    },
    [roomId],
  );

  useEffect(() => {
    if (!roomId) {
      if (stompClientRef.current) stompClientRef?.current?.deactivate();
      return;
    }
    const socket = new SockJS(`${envConfig.NEXT_PUBLIC_API_ENDPOINT}/ws`);
    const client = new Client({
      webSocketFactory: () => socket,
      reconnectDelay: 5000,
      onConnect: () => {
        console.log("%cConnected to WebSocket", "color: green");
        setIsConnected(true);
        client.subscribe(`/topic/chat/client/${roomId}`, (message) => {
          const parsedMessage = JSON.parse(message.body);
          setLastMessage(parsedMessage);
        });
      },
      onDisconnect: () => {
        setIsConnected(false);
        console.log("@cDisconnected from WebSocket", "color: red");
      },
    });

    client.activate();
    stompClientRef.current = client;

    return () => {
      client.deactivate();
    };
  }, [roomId]);

  return { lastMessage, isConnected, sendMessage, sendMessageFromAdmin };
};

export default useWebSocketChat;
