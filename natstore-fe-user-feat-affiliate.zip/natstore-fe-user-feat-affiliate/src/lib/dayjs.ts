import dayjsLib from "dayjs";
import utc from "dayjs/plugin/utc";
import timezone from "dayjs/plugin/timezone";
import customParseFormat from "dayjs/plugin/customParseFormat";
dayjsLib.extend(utc);
dayjsLib.extend(timezone);
dayjsLib.extend(customParseFormat);
export default dayjsLib;
