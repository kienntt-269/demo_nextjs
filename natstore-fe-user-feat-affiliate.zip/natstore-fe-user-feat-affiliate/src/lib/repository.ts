import devicesApiRequest from "@/services/devices";

export const getDeviceCategories = async () => {
  try {
    const res = await devicesApiRequest.getCategoryProduct();
    return res.payload.data;
  } catch (error) {
    console.log(error);
    throw Error("error");
  }
};

export const getDevice = async (slug: string) => {
  try {
    const res = await devicesApiRequest.getProduct({
      category: slug,
      page: 1,
      size: 3,
      sort: "rateNumber_desc",
    });
    return res.payload.data;
  } catch (error) {
    console.log(error);
    throw Error("error");
  }
};
