"use client";
import { useProfileStore } from "@/_stores/useProfile.store";
import ContentPagePersonal from "@/app/personal/components/content-page";
import pointApiRequest from "@/services/point-service";
import { useTranslations } from "next-intl";
import React, { useEffect } from "react";

const PointOverview = () => {
  const [point, setPoint] = React.useState<number | undefined>(0);
  const { user } = useProfileStore();
  const t = useTranslations();

  useEffect(() => {
    if (!user?.id) return;
    pointApiRequest.getMyBalance(user.id).then((res) => {
      setPoint(res?.payload?.data ?? 0);
    });
  }, [user?.id]);

  return (
    <div className="w-full h-full bg-white p-4 lg:p-8 rounded-2xl md:rounded-3xl">
      <ContentPagePersonal title={t("natcom_points.title")} titleClassName="lg:text-[32px] text-neutral-dark-01 lg:leading-[39px]">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="px-6 py-4 flex flex-col gap-2 rounded-2xl bg-primary/16">
            <p className="font-bold text-primary">
              {t("natcom_points.you_have")}
            </p>
            <p className="text-xl font-bold text-primary">
              {point ?? 0} {t("common.points")}
            </p>
          </div>
          <div className="px-6 py-4 flex flex-col gap-2 rounded-2xl bg-[#F5F6F7]">
            <p className="font-bold md:text-xl">{t("natcom_points.how_to_earn")}</p>
            <p className="text-sm md:text-base text-neutral-dark-04 whitespace-break-spaces">
              {t("natcom_points.how_to_earn_desc")}
            </p>
          </div>
          <div className="px-6 py-4 flex flex-col gap-2 rounded-2xl bg-[#F5F6F7]">
            <p className="font-bold md:text-xl">{t("natcom_points.how_to_use")}</p>
            <p className="text-sm md:text-base text-neutral-dark-04 whitespace-break-spaces">
              {t("natcom_points.how_to_use_desc")}
            </p>
          </div>
        </div>
      </ContentPagePersonal>
    </div>
  );
};

export default PointOverview;
