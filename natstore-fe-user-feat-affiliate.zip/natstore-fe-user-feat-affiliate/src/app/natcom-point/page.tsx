import PointOverview from "@/app/natcom-point/components/point-overview";
import PointTableView from "@/app/natcom-point/components/point-table-View";
import PointTableSearch from "@/app/natcom-point/components/point-table-search";
import ContentPagePersonal from "@/app/personal/components/content-page";
import BreadCrumbCommon from "@/components/breadcrumb-common";
import PageContent from "@/components/page-content";
import { ILinks } from "@/types/package";
import { getTranslations } from "next-intl/server";
import React from "react";

const NatcomPointPage = async ({
  searchParams,
}: {
  searchParams: { [key in string]: string };
}) => {
  const t = await getTranslations();
  const breadCrumb: ILinks[] = [
    {
      label: t("common.home"),
      link: "/",
    },

    {
      label: t("natcom_points.title"),
      link: "/natcom-point",
    },
  ];
  return (
    <PageContent className="bg-background-content">
      <BreadCrumbCommon content={breadCrumb} />
      <div className="mt-6 flex flex-col gap-4 md:mt-10 md:gap-10">
        <PointOverview />
        <div className="w-full h-full bg-white p-4 lg:p-8 rounded-2xl md:rounded-3xl">
          <ContentPagePersonal
            title={t("natcom_points.points_history")}
            titleClassName="lg:text-[32px] text-neutral-dark-01 lg:leading-[39px]"
          >
            <PointTableSearch searchParams={searchParams} />
            <PointTableView searchParams={searchParams} />
          </ContentPagePersonal>
        </div>
      </div>
    </PageContent>
  );
};

export default NatcomPointPage;
