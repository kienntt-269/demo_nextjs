"use client";
import ServicePointItem from "@/app/personal/components/service-point-item";
import NoDataAvailable from "@/components/common/no-data-available/no-data-available";
import InputCustom from "@/components/custom-ui/input-custom";
import SelectComponent from "@/components/custom-ui/select-component";
import { IAddressDetail } from "@/schemaValidations/sim-card.schema";
import simApiRequest from "@/services/sim-service";
import { warrantyService } from "@/services/warranty-service";
import { IShowroomDetail } from "@/types/swap-sim";
import { debounce } from "lodash";
import { useTranslations } from "next-intl";
import React, { useEffect, useMemo, useState } from "react";

const WarrantyServicePoint = () => {
  const t = useTranslations();

  const [params, setParams] = useState<{
    searchKey?: string | number;
    addressId?: string | number;
  }>({
    searchKey: undefined,
    addressId: undefined,
  });

  const [provinces, setProvinces] = useState<IAddressDetail[]>([
    { name: t("common.no_data"), id: 0 },
  ]);
  const [districts, setDistricts] = useState<IAddressDetail[]>([
    { name: t("common.no_data"), id: 0 },
  ]);

  const [listShowroom, setListShowroom] = useState<IShowroomDetail[]>([]);

  const debouncedSearch = useMemo(
    () =>
      debounce((value) => {
        warrantyService
          .getShowroom({
            searchKey: value.searchKey,
            addressId: value.addressId,
          })
          .then((res) => {
            setListShowroom(res.payload.data);
          });
      }, 500),
    []
  );

  const getProvince = async () => {
    try {
      const res = await simApiRequest.getAddress({
        type: 1,
      });
      setProvinces(
        res?.payload?.data.length > 0
          ? res.payload.data
          : [{ name: t("common.no_data"), id: 0 }]
      );
    } catch (error) {
      console.log(error);
    }
  };

  const getDistrict = async (id: string) => {
    try {
      const res = await simApiRequest.getAddress({
        type: 2,
        parentId: id,
      });
      setDistricts(
        res?.payload?.data.length > 0
          ? res.payload.data
          : [{ name: t("common.no_data"), id: 0 }]
      );
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    getProvince();
  }, []);

  useEffect(() => {
    debouncedSearch(params);
  }, [params]);

  return (
    <div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6">
        <div className="flex-1">
          <InputCustom
            label={t("personal.warranty_information.warranty_service_point")}
            inputProps={{
              placeholder: t("personal.warranty_information.enter_location"),
            }}
            onChange={(e) => {
              setParams((prev) => ({ ...prev, searchKey: e.target.value }));
            }}
          />
        </div>
        <div className="flex-1">
          <SelectComponent
            label={t("mobile_package.sim_normal.province_city")}
            placeholder={t("mobile_package.sim_normal.province_city")}
            options={provinces.map((item) => ({
              label: item.name || "",
              value: item?.id?.toString() || "",
            }))}
            onChange={(val) => {
              setParams((prev) => ({ ...prev, addressId: val }));
              getDistrict(val);
            }}
          />
        </div>
        <div className="flex-1">
          <SelectComponent
            label={t("mobile_package.sim_normal.disctrict")}
            placeholder={t("mobile_package.sim_normal.disctrict")}
            options={districts.map((item) => ({
              label: item.name || "",
              value: item?.id?.toString() || "",
            }))}
            onChange={(val) => {
              setParams((prev) => ({ ...prev, addressId: val }));
            }}
          />
        </div>
      </div>
      {listShowroom?.length > 0 ? (
        <div className="mt-10 grid grid-cols-1 md:grid-cols-2 gap-4 overflow-auto max-h-[396px] pr-2">
          {listShowroom?.map((item, index) => (
            <ServicePointItem key={item.id} item={item} index={index + 1} />
          ))}
        </div>
      ) : (
        <NoDataAvailable />
      )}
    </div>
  );
};

export default WarrantyServicePoint;
