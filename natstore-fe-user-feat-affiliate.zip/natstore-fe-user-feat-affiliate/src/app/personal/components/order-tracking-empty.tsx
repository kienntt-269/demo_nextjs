"use client";
import OrderEmptyIcon from "@/components/icons/order-empty-icon";
import { Button } from "@/components/ui/button";
import { useTranslations } from "next-intl";
import React from "react";

const OrderTrackingEmpty = () => {
  const t = useTranslations();
  return (
    <div className="flex flex-col items-center justify-center gap-8">
      <OrderEmptyIcon />
      <div className="flex flex-col justify-center items-center">
        <p className="font-bold text-size-28 leading-[34px] text-center text-neutral-dark-03">
          {t("order_tracking.you_do_not_have_order")}
        </p>
        <Button className="mt-4 max-w-[243px]">
          {t("order_tracking.shopping")}
        </Button>
      </div>
    </div>
  );
};

export default OrderTrackingEmpty;
