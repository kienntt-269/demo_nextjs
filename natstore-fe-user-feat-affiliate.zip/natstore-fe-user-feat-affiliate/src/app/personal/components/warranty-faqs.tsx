import NoDataAvailable from "@/components/common/no-data-available/no-data-available";
import SearchInput from "@/components/common/search-input";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";
import { warrantyService } from "@/services/warranty-service";
import { IAffiliateFAQ } from "@/types/affiliate";
import { debounce } from "lodash";
import { useTranslations } from "next-intl";
import React, { useEffect, useMemo } from "react";

const WarrantyFaqs = () => {
  const [inputValue, setInputValue] = React.useState("");
  const t = useTranslations();
  const [information, setInformation] = React.useState<IAffiliateFAQ[]>([]);

  const debouncedSearch = useMemo(
    () =>
      debounce((value) => {
        warrantyService.getFaqs(value).then((res) => {
          setInformation(res.payload.data);
        });
      }, 500),
    []
  );

  useEffect(() => {
    debouncedSearch(inputValue);
  }, [inputValue]);
  return (
    <div className="flex flex-col">
      <div className="flex gap-2 max-w-[648px]">
        <SearchInput
          value={inputValue}
          onChange={(val) => setInputValue(val)}
          inputClassName="h-[38px] rounded-xl"
        />
        <Button className="!h-[38px] md:min-w-[150px]">
          {t("common.search")}
        </Button>
      </div>
      <div className="mt-6 md:mt-10 flex flex-col gap-4 md:gap-6 max-h-[396px] overflow-auto pr-2">
        {information?.length > 0 ? (
          information.map((val) => (
            <div
              key={val.id}
              className="border-solid border border-[#C5C5C5] bg-gray rounded-lg h-auto w-full"
            >
              <Accordion type="single" collapsible>
                <AccordionItem value={"1"}>
                  <AccordionTrigger className="!no-underline p-4 font-bold">
                    {val.question}
                  </AccordionTrigger>
                  <AccordionContent className="px-4 text-[14px] font-normal text-[#212121] whitespace-pre-line mt-3">
                    {val.answer}
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </div>
          ))
        ) : (
          <NoDataAvailable />
        )}
      </div>
    </div>
  );
};

export default WarrantyFaqs;
