import { useProfileStore } from "@/_stores/useProfile.store";
import DetailAccountAffiliate from "@/app/affiliate/register/[slug]/page";
import RegisterAffiliateForm from "@/app/affiliate/register/_components/affiliate-form";
import { useRouter } from "next/navigation";
import React, { useEffect } from "react";

const Affiliate = () => {
  const { isAffiliate } = useProfileStore();
  const router = useRouter();
  useEffect(() => {
    // đã đăng ký
    if (Number(isAffiliate) == 2) {
      router.push("/affiliate/dashboard");
    }
  }, [isAffiliate, router]);

  return (
    <div>
      {/* chưa đăng ký */}
      {(Number(isAffiliate) == 0 || Number(isAffiliate) == 3) && (
        <RegisterAffiliateForm className="!p-0" />
      )}
      {/* chờ duyệt */}
      {Number(isAffiliate) == 1 && <DetailAccountAffiliate />}
    </div>
  );
};

export default Affiliate;
