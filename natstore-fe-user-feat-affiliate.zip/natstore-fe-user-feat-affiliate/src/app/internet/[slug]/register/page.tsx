"use client";
import BreadCrumbCommon from "@/components/breadcrumb-common";
import PageContent from "@/components/page-content";
import { Form, InputField, SelectField } from "@/components/form";
import { ILinks } from "@/types/package";
import { useTranslations } from "next-intl";
import React, { useEffect, useMemo, useRef, useState } from "react";
import { IAddressDetail } from "@/schemaValidations/sim-card.schema";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Controller } from "react-hook-form";
import { useRouter, useSearchParams } from "next/navigation";
import simApiRequest from "@/services/sim-service";
import {
  IDataInternetDetail,
  IInternetRegisterInformation,
  InternetRegisterInformation,
} from "@/schemaValidations/internet.shema";
import OrderInternet from "@/app/internet/[slug]/register/order-internet";
import internetApiRequest from "@/services/internet";
import { getTypeOfDocV1 } from "@/constants/variable";
import UploadFileSingle from "@/components/form/upload-file-single";
import { InputPhoneNumberField } from "@/components/form/input-phone-number-field";
import { useDialogAuthStore } from "@/_stores/useDialogAuth.store";
import { useProfileStore } from "@/_stores/useProfile.store";
import clsx from "clsx";
import { formatPhoneSubmit } from "@/lib/utils";
import InternetSuccess from "@/app/internet/[slug]/register/internet-success";
import { storage } from "@/lib/storage";
import { useLangStore } from "@/_stores/useLang.store";
import TextWithTooltip from "@/components/text-width-tooltip";

import InternetError from "@/app/internet/[slug]/register/internet-error";
import { useLoadingStore } from "@/_stores/useLoading,store";

const Page = ({ params }: { params: { slug: string } }) => {
  const t = useTranslations();
  const { lang } = useLangStore();
  const searchParams = useSearchParams();
  const { setIsLoading } = useLoadingStore();
  const schema = useMemo(() => InternetRegisterInformation(), []);
  const [provinces, setProvinces] = useState<IAddressDetail[]>([
    { name: t("common.no_data"), id: 0 },
  ]);
  const [districts, setDistricts] = useState<IAddressDetail[]>([
    { name: t("common.no_data"), id: 0 },
  ]);
  const [precincts, setPrecincts] = useState<IAddressDetail[]>([
    { name: t("common.no_data"), id: 0 },
  ]);
  const router = useRouter();
  const [dataDetail, setDataDetail] = useState<IDataInternetDetail>();

  const childRef = useRef<{ getData: () => string } | null>(null);

  const getData = async (slug: string) => {
    try {
      const res = await internetApiRequest.getDetailData(slug);
      setDataDetail(res.payload.data);
    } catch (error) {
      console.log(error);
      throw Error("error");
    }
  };

  const breadCrumb: ILinks[] = [
    {
      label: t("personal.home"),
      link: "/",
    },
    {
      label: t("internet.internet"),
      link: "/internet",
    },
    {
      label: dataDetail?.category,
      link: "/internet?internet-view=buy-internet-package",
    },
    {
      label: <TextWithTooltip content={dataDetail?.name || ""} />,
      link: `/internet/${params.slug}`,
    },
    {
      label: t("common.register"),
      link: ``,
    },
  ];

  const getProvince = async () => {
    try {
      const res = await simApiRequest.getAddress({
        type: 1,
      });
      setProvinces(
        res?.payload?.data.length > 0
          ? res.payload.data
          : [{ name: t("common.no_data"), id: 0 }]
      );
    } catch (error) {
      console.log(error);
    }
  };

  const getDistrict = async (id: string) => {
    try {
      const res = await simApiRequest.getAddress({
        type: 2,
        parentId: id,
      });
      setDistricts(
        res?.payload?.data.length > 0
          ? res.payload.data
          : [{ name: t("common.no_data"), id: 0 }]
      );
      setPrecincts([{ name: t("common.no_data"), id: 0 }]);
    } catch (error) {
      console.log(error);
    }
  };
  const getPrecinct = async (id: string) => {
    try {
      const res = await simApiRequest.getAddress({
        type: 3,
        parentId: id,
      });
      setPrecincts(
        res?.payload?.data.length > 0
          ? res.payload.data
          : [{ name: t("common.no_data"), id: 0 }]
      );
    } catch (error) {
      console.log(error);
    }
  };

  const handleSubmit = async (data: IInternetRegisterInformation) => {
    setIsLoading(true);
    data.phoneNumber = formatPhoneSubmit(data.phoneNumber);
    storage.setInternetRegister(params.slug);
    const formData = new FormData();
    const jsonString = JSON.stringify({
      customer: {
        fullName: data.fullName,
        phoneNumber: data.phoneNumber,
        docType: data.typeOfDocument,
        idCardNumber: data.cardId,
        email: data.email,
      },
      address: {
        provinceId: Number(data.provinceId),
        districtId: Number(data.districtId),
        precinctId: Number(data.precinctId),
        details: data.address,
        note: data.note,
      },
      paymentPlanId: childRef?.current?.getData(),
      packageId: dataDetail?.id,
    });

    const jsonBlob = new Blob([jsonString], { type: "application/json" });
    formData.append("data", jsonBlob);

    formData.append("frontImage", data.fileFront[0] as File);
    formData.append("backImage", data.fileBack[0] as File);

    const res = await internetApiRequest.postRegisterInternet(formData);

    storage.setResponsePaymentDataInternet(JSON.stringify(res.payload.data));

    if (res.payload?.code === "00") {
      router.push(`/internet/${params.slug}/register?statusPayment=success`);
    } else {
      router.push(`/internet/${params.slug}/register?statusPayment=fail`);
    }
    setIsLoading(false);
  };

  useEffect(() => {
    getProvince();
    getData(params.slug);
  }, [lang]);
  const { user } = useProfileStore();
  const { setIsOpen, setUrlLoginSuccess } = useDialogAuthStore();

  return (
    <PageContent>
      <BreadCrumbCommon content={breadCrumb} />
      {searchParams.get("statusPayment") === "success" && (
        <InternetSuccess dataDetail={dataDetail} />
      )}
      {searchParams.get("statusPayment") === "fail" && (
        <InternetError dataDetail={dataDetail} />
      )}
      {!searchParams.get("statusPayment") && (
        <Form<IInternetRegisterInformation, typeof schema>
          schema={schema}
          onSubmit={handleSubmit}
          options={{
            mode: "all",
          }}
          defaultValue={{}}
        >
          {({
            control,
            formState: { errors, isValid },
            watch,
            setValue,
            trigger,
          }) => {
            const values = watch();

            return (
              <div className="grid grid-cols-[6fr_8fr] gap-x-6 mt-10 max-lg:mt-8 max-md:mt-4 max-xl:block">
                <div className="w-full bg-white rounded-3xl p-8 max-md:px-4 max-md:py-6">
                  <div className="text-[28px] max-md:text-[20px] font-bold">
                    {t("mobile_package.sim_normal.customer_information")}
                  </div>
                  <div className="mt-4 text-neutral-dark-04 text-[14px] max-md:text-[12px]">
                    (*) {t("mobile_package.sim_normal.please_fill_in")}
                  </div>
                  {!user?.id && (
                    <div className="mt-8 text-neutral-dark-04 text-[14px] max-md:text-[12px] flex items-center gap-1">
                      <span>{t("internet.account_login")}</span>
                      <div
                        onClick={() => {
                          setIsOpen({ isOpen: true, mode: "LOGIN" });

                          setUrlLoginSuccess(
                            `/internet/${params.slug}/register`
                          );
                        }}
                        className="ml-1 text-primary font-semibold text-sm underline cursor-pointer"
                      >
                        {t("login.login")}
                      </div>
                    </div>
                  )}
                  <div className="text-[20px] font-bold mt-8 max-md:mt-6 max-md:text-[16px]">
                    {t("mobile_package.sim_normal.personal_information")}
                  </div>
                  <div className="grid grid-cols-2 gap-4 max-md:grid-cols-1 mt-2">
                    <div>
                      <div className="mb-2">
                        <label className="text-sm md:text-base" htmlFor="">
                          {t("mobile_package.swap_sim.full_name")}
                          <span className="text-red-500">*</span>
                        </label>
                      </div>
                      <InputField
                        name="fullName"
                        placeholder={t("internet.full_name_placeholder")}
                        type="text"
                        control={control}
                        errors={errors}
                        maxLength={50}
                      />
                    </div>
                    <div>
                      <div className="mb-2">
                        <label className="text-sm md:text-base" htmlFor="">
                          {t("internet.phone_number")}
                          <span className="text-red-500">*</span>
                        </label>
                      </div>

                      <InputPhoneNumberField
                        control={control}
                        errors={errors}
                        name="phoneNumber"
                        type="text"
                        placeholder={t("internet.phone_number")}
                      />
                    </div>
                    <div>
                      <div className="mb-2">
                        <label className="text-sm md:text-base" htmlFor="">
                          {t("mobile_package.swap_sim.type_of_doc")}
                          <span className="text-red-500">*</span>
                        </label>
                      </div>
                      <SelectField
                        control={control}
                        placeholder={t("mobile_package.swap_sim.type_of_doc")}
                        name="typeOfDocument"
                        options={getTypeOfDocV1(t).map((item) => ({
                          label: item.name,
                          value: item.id + "",
                        }))}
                        trigger={trigger}
                        error={errors?.typeOfDocument}
                      />
                    </div>
                    <div>
                      <div className="mb-2">
                        <label className="text-sm md:text-base" htmlFor="">
                          {t("internet.id_card")}
                          <span className="text-red-500">*</span>
                        </label>
                      </div>
                      <InputField
                        name="cardId"
                        placeholder={t("internet.id_card")}
                        type="text"
                        className=""
                        control={control}
                        errors={errors}
                        required
                        disabled={!values.typeOfDocument}
                      />
                    </div>
                    <div>
                      <label className="text-sm md:text-base" htmlFor="">
                        {t("register.email")}
                      </label>
                      <InputField
                        maxLength={255}
                        name="email"
                        classNameLabel="!font-normal text-sm lg:text-base !text-neutral-dark-01 mt-2"
                        placeholder={t("register.email")}
                        type="text"
                        control={control}
                        errors={errors}
                        required={false}
                      />
                    </div>
                  </div>
                  <div className="text-base md:text-[20px] font-bold mt-8 mb-4 max-md:mt-6">
                    {t("common.upload_id_image")}
                    <span className="text-red-500">*</span>
                  </div>
                  <>
                    <div className="mt-4 text-neutral-dark-04 text-xs md:text-[14px]">
                      {t("internet.file_upload")}
                    </div>
                    <div className="flex gap-6">
                      <div className="mt-4 ">
                        <UploadFileSingle
                          label={t("common.upload")}
                          name="fileFront"
                          control={control}
                          labelBottom={t("internet.front_photo")}
                          className="max-md:h-[72px] max-md:w-[72px]"
                        />
                      </div>
                      <div className="mt-4 ">
                        <UploadFileSingle
                          label={t("common.upload")}
                          name="fileBack"
                          control={control}
                          labelBottom={t("internet.back_photo")}
                          className="max-md:h-[72px] max-md:w-[72px]"
                        />
                      </div>
                    </div>
                  </>
                  <div className="text-base md:text-[20px] font-bold mt-8 mb-4 max-md:mt-6">
                    {t("common.installation_address")}
                  </div>
                  <>
                    <div className="mt-4 grid grid-cols-2 gap-4 max-md:grid-cols-1">
                      <div>
                        <label className="text-sm md:text-base" htmlFor="">
                          {t("mobile_package.sim_normal.province_city")}
                          <span className="text-red-500">*</span>
                        </label>
                        <Controller
                          name="provinceId"
                          control={control}
                          render={({
                            field: { onChange },
                            fieldState: { error },
                          }) => {
                            return (
                              <div className="flex flex-col">
                                <Select
                                  onValueChange={(value) => {
                                    setValue("districtId", "");
                                    setValue("precinctId", "");
                                    onChange(value);
                                    getDistrict(value);
                                  }}
                                >
                                  <SelectTrigger
                                    className={clsx(
                                      "flex-1 py-[12px] px-[16px] h-[48px] rounded-xl mt-2 data-[placeholder]:text-neutral-mid-01",
                                      {
                                        "border-solid border border-error":
                                          !!error,
                                      }
                                    )}
                                  >
                                    <SelectValue
                                      placeholder={t(
                                        "mobile_package.sim_normal.province_city"
                                      )}
                                    />
                                  </SelectTrigger>
                                  <SelectContent>
                                    {provinces?.map((val) => {
                                      return (
                                        <SelectItem
                                          key={val.id}
                                          value={`${val.id}`}
                                        >
                                          {val.name}
                                        </SelectItem>
                                      );
                                    })}
                                  </SelectContent>
                                </Select>
                                {error && (
                                  <p className="text-red-500 text-sm mt-1">
                                    {t(`common.message.${error.message}`)}
                                  </p>
                                )}
                              </div>
                            );
                          }}
                        />
                      </div>
                      <div>
                        <label className="text-sm md:text-base" htmlFor="">
                          {t("mobile_package.sim_normal.disctrict")}
                          <span className="text-red-500">*</span>
                        </label>
                        <Controller
                          name="districtId"
                          control={control}
                          render={({
                            field: { onChange, value },
                            fieldState: { error },
                          }) => {
                            return (
                              <div className="flex flex-col">
                                <Select
                                  onValueChange={(value) => {
                                    setValue("precinctId", "");
                                    onChange(value);
                                    getPrecinct(value);
                                  }}
                                  value={value}
                                >
                                  <SelectTrigger
                                    className={clsx(
                                      "flex-1 py-[12px] px-[16px] h-[48px] rounded-xl mt-2 data-[placeholder]:text-neutral-mid-01",
                                      {
                                        "border-solid border border-error":
                                          !!error,
                                      }
                                    )}
                                  >
                                    <SelectValue
                                      key={values.precinctId}
                                      placeholder={t(
                                        "mobile_package.sim_normal.disctrict"
                                      )}
                                    />
                                  </SelectTrigger>
                                  <SelectContent>
                                    {districts?.map((val) => {
                                      return (
                                        <SelectItem
                                          key={val.id}
                                          value={`${val.id ? val.id : null}`}
                                          disabled={districts?.[0].id === 0}
                                        >
                                          {val.name}
                                        </SelectItem>
                                      );
                                    })}
                                  </SelectContent>
                                </Select>
                                {error && (
                                  <p className="text-red-500 text-sm mt-1">
                                    {t(`common.message.${error.message}`)}
                                  </p>
                                )}
                              </div>
                            );
                          }}
                        />
                      </div>
                      <div>
                        <label className="text-sm md:text-base" htmlFor="">
                          {t("common.precinct")}
                        </label>
                        <span className="text-red-500">*</span>
                        <Controller
                          name="precinctId"
                          control={control}
                          render={({
                            field: { onChange, value },
                            fieldState: { error },
                          }) => {
                            return (
                              <div className="flex flex-col">
                                <Select
                                  onValueChange={(value) => {
                                    onChange(value);
                                  }}
                                  value={value}
                                >
                                  <SelectTrigger
                                    className={clsx(
                                      "flex-1 py-[12px] px-[16px] h-[48px] rounded-xl mt-2 data-[placeholder]:text-neutral-mid-01",
                                      {
                                        "border-solid border border-error":
                                          !!error,
                                      }
                                    )}
                                  >
                                    <SelectValue
                                      placeholder={t("common.precinct")}
                                    />
                                  </SelectTrigger>
                                  <SelectContent>
                                    {precincts?.map((val) => {
                                      return (
                                        <SelectItem
                                          key={val.id}
                                          value={`${val.id}`}
                                          disabled={precincts?.[0].id === 0}
                                        >
                                          {val.name}
                                        </SelectItem>
                                      );
                                    })}
                                  </SelectContent>
                                </Select>
                                {error && (
                                  <p className="text-red-500 text-sm mt-1">
                                    {t(`common.message.${error.message}`)}
                                  </p>
                                )}
                              </div>
                            );
                          }}
                        />
                      </div>

                      <div>
                        <label className="text-sm md:text-base" htmlFor="">
                          {t("common.address")}
                        </label>
                        <InputField
                          name="address"
                          placeholder={t("common.address")}
                          className="mt-2"
                          control={control}
                          maxLength={200}
                          required={false}
                        />
                      </div>
                    </div>
                    <div className="mt-4">
                      <label className="text-sm md:text-base" htmlFor="">
                        {t("common.note")}
                      </label>
                      <InputField
                        name="note"
                        placeholder={t("common.note")}
                        className="mt-2"
                        control={control}
                        maxLength={200}
                        required={false}
                      />
                    </div>
                  </>
                </div>

                <div>
                  <OrderInternet
                    id={dataDetail?.id || ""}
                    price={dataDetail?.price || 0}
                    speed={dataDetail?.speed || ""}
                    name={dataDetail?.name || ""}
                    ref={childRef}
                    isFormModified={!isValid}
                  />
                </div>
              </div>
            );
          }}
        </Form>
      )}
    </PageContent>
  );
};

export default Page;
