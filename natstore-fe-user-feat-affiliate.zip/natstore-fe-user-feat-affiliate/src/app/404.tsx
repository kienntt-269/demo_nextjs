import React from "react";

export default function Custom404() {
  return <h1>Oops! Page Not Found.</h1>;
}
