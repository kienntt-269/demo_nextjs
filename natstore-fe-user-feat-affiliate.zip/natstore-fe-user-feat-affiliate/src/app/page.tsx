import * as React from "react";
import PageContent from "@/components/page-content";
import HomePageContent from "@/module/home-page/home-page-content";
import ModalCatalog from "@/components/modal-catalog";
import BannerHomePage from "@/module/home-page/banner-home-page";
import { Metadata } from "next";

export const dynamic = "force-dynamic";

export default function HomePage() {
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Organization",
    name: "Natcom",
    alternateName: "National and Telecom",
    url: "https://natcomstore.arabicatech.vn",
    logo: "https://natcomstore.arabicatech.vn/logo.png",
    description:
      "Natcom is a telecommunications company based in Port-au-Prince, Haiti. It is the third international market Viettel has invested in, following Laos and Cambodia.",
    founder: {
      "@type": "Organization",
      name: "Viettel",
    },
    location: {
      "@type": "Place",
      address: {
        "@type": "PostalAddress",
        addressLocality: "Port-au-Prince",
        addressCountry: "HT",
      },
    },
    sameAs: [
      "https://en.wikipedia.org/wiki/Natcom",
      "https://www.facebook.com/NatcomHaiti",
      "https://www.linkedin.com/company/natcomhaiti/",
    ],
  };
  return (
    <div>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />
      <PageContent>
        <BannerHomePage />
        <HomePageContent />
      </PageContent>
      <ModalCatalog />
    </div>
  );
}

export const generateMetadata = async (): Promise<Metadata> => {
  return {
    title: "Natcom – Viettel’s Telecommunications Investment in Haiti",
    description:
      "Natcom is the abbreviation of National and Telecom, a telecommunications network based in Port-au-Prince, Haiti. It is the third international market Viettel has invested in after Laos and Cambodia.",
    keywords: [
      "Natcom",
      "Viettel",
      "Haiti Telecom",
      "Telecommunications",
      "National Telecom",
      "Viettel Haiti",
    ],
    openGraph: {
      title: "Natcom – Viettel’s Telecommunications Investment in Haiti",
      description:
        "Discover how Natcom, based in Port-au-Prince, marks Viettel’s third international telecom market after Laos and Cambodia.",
      url: "https://natcomstore.arabicatech.vn",
      siteName: "Natcom – Viettel’s Telecommunications",
      locale: "en_US",
      type: "article",
      images: [
        {
          url: "https://minio-natstore.arabicatech.vn/public/images/banner/2025-03-26/67e428d8174f6_Screenshot%202025-03-26%20at%2011.18.16%E2%80%AFPM.png",
          height: 600,
          width: 800,
          alt: `Natcom image`,
        },
        {
          url: "https://minio-natstore.arabicatech.vn/public/images/banner/2025-04-24/680a1a71c9f28_Banner.png",
          width: 1600,
          height: 1200,
          alt: `Natcom image`,
        },
      ],
    },
    twitter: {
      card: "summary_large_image",
      title: "Natcom – Viettel’s Telecommunications Investment in Haiti",
      description:
        "Natcom stands for National and Telecom, and is Viettel’s telecom network in Haiti, their third international market.",
    },
  };
};
