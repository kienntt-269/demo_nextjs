"use client";

import React from "react";
import { useTranslations } from "next-intl";
import { Button } from "@/components/ui/button";
import { Ratings } from "@/components/ui/rating";
import { RegisterItemType } from "@/types/mobile-package";
import { getImageUrl } from "@/constants/imageUrl";
import ImageCommon from "@/components/common/image-common";
import { useRouter } from "next/navigation";
import { cx } from "class-variance-authority";
import ComponentWithTooltip from "@/components/component-with-tooltip";

export const formatNumber = (num: number) => {
  return num < 1000 ? num.toString() : num.toLocaleString("en-US");
};
const RegisterItem = ({ data }: RegisterItemType) => {
  const t = useTranslations("mobile_package");
  const router = useRouter();
  const handleShowDetail = (id: number) => {
    router.push(`/international/roaming?name=register&id=${id}`);
  };
  return (
    <div className="bg-white shadow hover:shadow-lg transition-shadow rounded-2xl">
      <ImageCommon
        src={data.imageUrl ? getImageUrl(data.imageUrl) : "/"}
        alt={data?.name || ""}
        width={371}
        height={260}
        className={cx("max-sm:h-[112px] w-full h-[260px] rounded-t-2xl", {
          "object-contain": data.imageUrl,
        })}
        fallbackSrc="/images/roaming-default.png"
      />
      <div className="flex flex-col p-3 pb-4 lg:p-6">
        <div className="grow mb-4 lg:mb-6">
          <h2 className="text-sm lg:text-2xl font-bold truncate text-black">
            <ComponentWithTooltip content={data?.name}>
              <div className="text-[24px] max-sm:text-sm max-xl:text-[18px] max-2xl:text-[20px] font-bold max-md:mt-1 text-black overflow-hidden text-ellipsis whitespace-nowrap">
                {data?.name}
              </div>
            </ComponentWithTooltip>
          </h2>
          <p className="text-xs lg:text-sm text-neutral-dark-04 h-8 lg:h-10 my-2 lg:my-3 line-clamp-2 whitespace-pre-line">
            {data.note ?? "-"}
          </p>
          <div className="flex gap-2 mb-1 lg:mb-2">
            <p className="text-sm lg:text-xl font-bold text-black">
              {formatNumber(Number(data.price))}
            </p>
            <p className="text-sm lg:text-xl font-bold text-neutral-mid-01">
              {" "}
              {t("htg")}
            </p>
          </div>
          <div className="">
            <Ratings rating={Number(data.vote ?? 0)} variant="orange" />
          </div>
        </div>
        <Button
          className="w-full grow-0 rounded-3xl max-sm:text-sm text-base h-8 lg:h-12 font-semibold"
          onClick={() => handleShowDetail(Number(data.id))}
        >
          {t("roaming.register")}
        </Button>
      </div>
    </div>
  );
};

export default RegisterItem;
