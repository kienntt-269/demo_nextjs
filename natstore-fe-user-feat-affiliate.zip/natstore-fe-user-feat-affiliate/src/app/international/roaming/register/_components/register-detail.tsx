"use client";

import React, { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { useTranslations } from "next-intl";
import Image from "next/image";
import { useDialogAuthStore } from "@/_stores/useDialogAuth.store";
import ConfirmModal from "@/app/international/roaming/register/_components/confirm-modal";
import TabsCommon from "@/components/common/tabs/tabs";
import { Button } from "@/components/ui/button";
import { Ratings } from "@/components/ui/rating";
import mobilePackageApiRequest from "@/services/mobile-package";
import { RegisterItemProps, RoamingDetailType } from "@/types/mobile-package";
import { ITabs } from "@/types/package";
import RegisterActivateModal from "@/app/international/roaming/register/_components/register-activate-modal";
import { formatNumber } from "@/app/international/roaming/register/_components/register-item";
import { useProfileStore } from "@/_stores/useProfile.store";
import { SUCCESS_CODE3 } from "@/constants/http-response";
import { toastError } from "@/hooks/use-toast";
import ImageCommon from "@/components/common/image-common";
import { getImageUrl } from "@/constants/imageUrl";
import { IRoamingMetadata } from "@/schemaValidations/mobile-package.schema";
import { useLangStore } from "@/_stores/useLang.store";
import ComponentWithTooltip from "@/components/component-with-tooltip";
import { useRoamingStore } from "@/_stores/useRoaming.store";
import { useLoadingStore } from "@/_stores/useLoading,store";

const getDetailRoaming = async (id: number) => {
  try {
    const res = await mobilePackageApiRequest.getDetailRoaming(id);
    return res.payload;
  } catch (error) {
    console.log(error);
    throw Error("error");
  }
};

const getMetaData = async (id: number) => {
  try {
    const res = await mobilePackageApiRequest.getMetadata(id);
    return res.payload;
  } catch (error) {
    console.log(error);
    throw Error("error");
  }
};

const RegisterDetail = ({ id }: RoamingDetailType) => {
  const { user } = useProfileStore();
  const { lang } = useLangStore();
  const { data, setData } = useRoamingStore();
  const { setIsLoading } = useLoadingStore();
  const t = useTranslations("");
  const router = useRouter();
  const { setIsOpen, setUrlLoginSuccess } = useDialogAuthStore();
  const [detail, setDetail] = useState<RegisterItemProps>();
  const [metadata, setMetadata] = useState<IRoamingMetadata>();
  const [isShowConfirm, setIsShowConfirm] = useState<boolean>(false);
  const [isSuccessModal, setIsSuccessModal] = useState<Date>();

  const contentRender = (data?: string) => (
    <div className="px-6 py-4 rounded-xl bg-[#f5f6f7] bg-gray">
      <p className="text-sm lg:text-base text-neutral-dark-01 font-normal whitespace-pre-line">
        {data ?? t("common.not_content")}
      </p>
    </div>
  );

  const tabs: ITabs[] = [
    {
      id: "product_pricing",
      label: t("mobile_package.roaming.product_pricing"),
      content: contentRender(
        metadata?.descriptionAndPricing?.productPricingDes
      ),
      params: "",
    },
    {
      id: "promotion",
      label: t("mobile_package.roaming.promotion"),
      content: contentRender(metadata?.promotion?.promotionDes),
      params: "",
    },
    {
      id: "change_package",
      label: t("mobile_package.roaming.change_package"),
      content: contentRender(metadata?.changePackageDes),
      params: "",
    },
    {
      id: "faqs",
      label: t("mobile_package.roaming.faqs"),
      content: contentRender(metadata?.faqDes),
      params: "",
    },
  ];

  const handleRegister = (phone?: string) => {
    if (user?.id) {
      mobilePackageApiRequest.registerRoaming(id, phone).then((res) => {
        setIsLoading(false);
        if (res.payload.code === SUCCESS_CODE3) {
          setIsShowConfirm(false);
          setIsSuccessModal(res.payload.data.expireAt);
          setData({
            ...res.payload.data,
            activationStatus: data.activationStatus,
          });
        } else {
          toastError(res.payload.message);
        }
      });
    }
  };

  const handleGotIt = () => {
    setIsSuccessModal(undefined);
    router.replace("/international/roaming?name=activate");
    router.refresh();
  };

  useEffect(() => {
    getDetailRoaming(id).then((res) => {
      setDetail(res.data);
    });
    getMetaData(id).then((res) => {
      setMetadata(res.data);
    });
  }, [id, lang]);

  return (
    <div className="mb-4">
      {detail && (
        <div className="py-6 lg:py-10">
          <div className="grid grid-cols-3 gap-x-6 max-lg:grid-cols-1 max-lg:gap-2">
            <div className="px-6 py-[18px] max-xl:p-4 flex items-center gap-x-4 max-md:gap-x-2 bg-white border-[0.46px] border-solid border-[#DEDEDE] rounded-2xl">
              <div className="size-12 max-xl:size-10 max-lg:size-8 flex-shrink-0">
                <Image
                  alt="icon"
                  src={"/images/icon/mobile.png"}
                  width={48}
                  height={48}
                  style={{ width: "100%", height: "auto" }}
                  className=""
                />
              </div>
              <div className="text-neutral-dark-03 min-w-0 flex-1">
                <div className="text-xs lg:text-sm mb-1 lg:mb-2">
                  {t("payment.plan_name")}
                </div>
                <ComponentWithTooltip content={detail.name}>
                  <div className="text-xl max-xl:text-[18px] max-2xl:text-[20px] max-md:text-sm font-bold overflow-hidden text-ellipsis whitespace-nowrap">
                    {detail.name}
                  </div>
                </ComponentWithTooltip>
              </div>
            </div>
            <div className="px-6 py-[18px] max-xl:p-4 flex items-center gap-x-4 max-md:gap-x-2 bg-white border-[0.46px] border-solid border-[#DEDEDE] rounded-2xl">
              <div className="size-12 max-xl:size-10 max-lg:size-8 flex-shrink-0">
                <Image
                  alt="icon"
                  src={"/images/icon/coin.png"}
                  width={48}
                  height={48}
                  style={{ width: "100%", height: "auto" }}
                />
              </div>
              <div className="text-neutral-dark-03">
                <div className="text-xs lg:text-sm mb-1 lg:mb-2">
                  {t("common.price")}
                </div>
                <div className="text-xl lg:text-2xl font-bold">
                  {formatNumber(Number(detail.price))}{" "}
                  <span className="text-xl lg:text-2xl text-neutral-mid-01">
                    {t("mobile_package.htg")}
                  </span>
                </div>
              </div>
            </div>
            <div className="px-6 py-[18px] max-xl:p-4 flex items-center gap-x-4 max-md:gap-x-2 bg-white border-[0.46px] border-solid border-[#DEDEDE] rounded-2xl">
              <div className="size-12 max-xl:size-10 max-lg:size-8 flex-shrink-0">
                <Image
                  alt="icon"
                  src={"/images/icon/rating.png"}
                  width={48}
                  height={48}
                  style={{ width: "100%", height: "auto" }}
                />
              </div>
              <div className="">
                <div className="text-xs lg:text-sm mb-1 lg:mb-2">
                  {t("common.rating")}
                </div>
                <div className="lg:w-auto flex">
                  {detail.vote ? (
                    <Ratings rating={detail.vote} variant="orange" />
                  ) : (
                    <Ratings rating={0} variant="orange" />
                  )}
                </div>
              </div>
            </div>
          </div>
          <div className="bg-white mt-4 lg:mt-6 rounded-3xl p-4 lg:p-8 flex gap-y-4 lg:gap-x-8 flex-col-reverse lg:flex-row">
            <div className="text-3xl flex-1 flex flex-col">
              <div className="mb-4 lg:mb-6 flex-1">
                <div className="mb-3 lg:mb-4 text-base font-semibold">
                  {t("mobile_package.roaming.information")}
                </div>
                <p className="line-clamp-6 text-sm lg:text-base text-neutral-dark-04 whitespace-pre-line break-all">
                  {detail.detail ?? "-"}
                </p>
              </div>
              <Button
                navigate={`/`}
                className="w-full lg:w-[156px] grow-0 rounded-3xl font-semibold"
                onClick={() => {
                  if (user?.id) {
                    setIsShowConfirm(true);
                  } else {
                    setIsOpen({ isOpen: true, mode: "LOGIN" });
                    setUrlLoginSuccess(`/international/roaming?name=register`);
                  }
                }}
              >
                {t("mobile_package.swap_sim.next")}
              </Button>
            </div>
            <ImageCommon
              src={detail.imageUrl ? getImageUrl(detail.imageUrl) : "/"}
              alt={detail?.name || ""}
              width={361}
              height={252}
              className="h-[252px] object-contain rounded-2xl"
              fallbackSrc="/images/roaming-default.png"
            />
          </div>
        </div>
      )}
      <div className="bg-white p-8 rounded-3xl mt-6 border-gray">
        <TabsCommon data={tabs} />
      </div>
      {isShowConfirm && (
        <ConfirmModal
          data={detail!}
          isOpenModal={isShowConfirm}
          onClose={() => setIsShowConfirm(false)}
          onRegister={handleRegister}
        />
      )}
      {isSuccessModal && (
        <RegisterActivateModal
          isSuccessModal={isSuccessModal}
          onSubmit={handleGotIt}
          onClose={() => setIsSuccessModal(undefined)}
          installationInstruction={data?.installationInstruction}
        />
      )}
    </div>
  );
};

export default RegisterDetail;
