"use client";

import React, { useEffect, useState } from "react";
import Image from "next/image";
import SwitchModal from "@/app/international/roaming/activate/_components/switch-modal";
import { HttpError } from "@/lib/http";
import { useProfileStore } from "@/_stores/useProfile.store";
import { useDialogAuthStore } from "@/_stores/useDialogAuth.store";
import { useTranslations } from "next-intl";
import mobilePackageApiRequest from "@/services/mobile-package";
import { ActivateStatusUser } from "@/schemaValidations/mobile-package.schema";
import { useRoamingStore } from "@/_stores/useRoaming.store";

export const getStatusRoaming = async () => {
  try {
    const res = await mobilePackageApiRequest.getStatus();
    return res.payload.data;
  } catch (error: unknown) {
    console.log(error);
    throw Error("error: " + error);
  }
};

const Activate = () => {
  const t = useTranslations("mobile_package.roaming");
  const { user } = useProfileStore();
  const { data } = useRoamingStore();
  const { setIsOpen, setUrlLoginSuccess } = useDialogAuthStore();
  const [isRender, setIsRender] = useState<boolean>(false);
  const [status, setStatus] = useState<ActivateStatusUser>(data);

  useEffect(() => {
    if (isRender) {
      if (typeof window !== "undefined" && user?.id) {
        getStatusRoaming()
          .then((res) => {
            setStatus(res);
          })
          .catch((err: HttpError) => {
            console.log("🚀 ~ getStatusRoaming ~ err:", err);
          });
      } else {
        setIsOpen({ isOpen: true, mode: "LOGIN" });
        setUrlLoginSuccess("/international/roaming");
      }
    }
    setIsRender(true);
  }, [setIsOpen, setUrlLoginSuccess, isRender, user?.id]);
  return (
    <div className="data-management flex flex-col items-center">
      <div className="flex flex-col justify-center items-center text-dark p-4 lg:p-8">
        <div className="text-sm lg:text-xl text-center">
          {status.activationStatus !== "NOT_ACTIVATED"
            ? t("disactive_title_1")
            : t("active_title_1")}
        </div>
        <div className="text-sm lg:text-xl text-center">
          {status.activationStatus !== "NOT_ACTIVATED"
            ? t("disactive_title_2")
            : t("active_title_2")}
        </div>
        <SwitchModal status={status} setStatus={setStatus} />
      </div>
      <div className="-mt-[16px] lg:-mt-[94px]">
        <Image
          src="/mobile-package/illustration_roaming.png"
          alt="illustration roaming"
          width={991}
          height={456}
        />
      </div>
    </div>
  );
};

export default Activate;
