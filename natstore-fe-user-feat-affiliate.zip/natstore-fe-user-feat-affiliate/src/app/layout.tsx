import type { Metadata } from "next";
import { ThemeProvider } from "@/components/themes/theme-provider";
import { NextIntlClientProvider } from "next-intl";
import { getLocale, getMessages } from "next-intl/server";
import "./globals.css";
import { Provider } from "@/app/provider";
import { DialogLogin } from "@/module/dialog-auth/dialog-auth";
import HeaderComponent from "@/components/header";
import FooterComponent from "@/components/footer";
import LoadingFullScreen from "@/components/common/loading-fullscreen";
import { cookies } from "next/headers";
import {
  XSRF_ISAFFILIATE,
  XSRF_REFRESH_TOKEN,
  XSRF_TOKEN,
} from "@/constants/authority";
import accountApiRequest from "@/services/account";
import { Toaster } from "@/components/ui/toaster";
import ServerError from "@/components/server-error";
import { inter } from "@/lib/font";
import ErrorBoundary from "@/components/error-boundary";
import { HttpError } from "@/lib/http";
import { checkResSuccess, checkResUnauthen } from "@/lib/utils";
import ChatOnline from "@/module/chat-online";
import ToastContainerCustom from "@/module/toast-container";
import { Locale } from "@/i18n/config";
// const geistSans = localFont({
//   src: "./fonts/GeistVF.woff",
//   variable: "--font-geist-sans",
//   weight: "100 900",
// });
// const geistMono = localFont({
//   src: "./fonts/GeistMonoVF.woff",
//   variable: "--font-geist-mono",
//   weight: "100 900",
// });

export const metadata: Metadata = {
  title: "Natcom – Viettel’s Telecommunications Investment in Haiti",
  description:
    "Natcom is the abbreviation of National and Telecom, a telecommunications network based in Port-au-Prince, Haiti. It is the third international market Viettel has invested in after Laos and Cambodia.",
  keywords: [
    "Natcom",
    "Viettel",
    "Haiti Telecom",
    "Telecommunications",
    "National Telecom",
    "Viettel Haiti",
  ],
  openGraph: {
    title: "Natcom – Viettel’s Telecommunications Investment in Haiti",
    description:
      "Discover how Natcom, based in Port-au-Prince, marks Viettel’s third international telecom market after Laos and Cambodia.",
    url: "https://natcomstore.arabicatech.vn",
    siteName: "Natcom – Viettel’s Telecommunications",
    locale: "en_US",
    type: "article",
    images: [
      {
        url: "https://minio-natstore.arabicatech.vn/public/images/banner/2025-03-26/67e428d8174f6_Screenshot%202025-03-26%20at%2011.18.16%E2%80%AFPM.png",
        height: 600,
        width: 800,
        alt: `Natcom image`,
      },
      {
        url: "https://minio-natstore.arabicatech.vn/public/images/banner/2025-04-24/680a1a71c9f28_Banner.png",
        width: 1600,
        height: 1200,
        alt: `Natcom image`,
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "Natcom – Viettel’s Telecommunications Investment in Haiti",
    description:
      "Natcom stands for National and Telecom, and is Viettel’s telecom network in Haiti, their third international market.",
  },
};

export default async function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const locale = await getLocale();
  const messages = await getMessages();
  let user = null;
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Organization",
    name: "Natcom",
    alternateName: "National and Telecom",
    url: "https://natcomstore.arabicatech.vn",
    logo: "https://natcomstore.arabicatech.vn/logo.png",
    description:
      "Natcom is a telecommunications company based in Port-au-Prince, Haiti. It is the third international market Viettel has invested in, following Laos and Cambodia.",
    founder: {
      "@type": "Organization",
      name: "Viettel",
    },
    location: {
      "@type": "Place",
      address: {
        "@type": "PostalAddress",
        addressLocality: "Port-au-Prince",
        addressCountry: "HT",
      },
    },
    sameAs: [
      "https://en.wikipedia.org/wiki/Natcom",
      "https://www.facebook.com/NatcomHaiti",
      "https://www.linkedin.com/company/natcomhaiti/",
    ],
  };
  try {
    const cookieStore = cookies();
    const token = cookieStore.get(XSRF_TOKEN)?.value;
    const refreshToken = cookieStore.get(XSRF_REFRESH_TOKEN)?.value;
    const isAffiliate = cookieStore.get(XSRF_ISAFFILIATE)?.value;
    if (token) {
      const userRes = await accountApiRequest.getUser();
      if (
        checkResUnauthen(userRes.payload?.code) ||
        !checkResSuccess(userRes.payload.code)
      ) {
        console.log({ userRes });
        throw new HttpError({
          status: 401,
          payload: userRes.payload,
        });
      }
      user = userRes.payload.data;
    }

    // call api get user info
    return (
      <html lang={locale}>
        <head>
          <meta
            name="viewport"
            content="width=device-width, initial-scale=1.0, user-scalable=1.0, minimum-scale=1.0, maximum-scale=1.0"
          />
          <script
            type="application/ld+json"
            dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
          />
        </head>
        <body className={`${inter.className} antialiased bg-[#F5F6F7]`}>
          <ThemeProvider
            attribute="class"
            defaultTheme="system"
            enableSystem
            disableTransitionOnChange
          >
            <NextIntlClientProvider messages={messages}>
              <Provider
                account={{
                  user,
                  token,
                  refreshToken,
                  isAffiliate,
                }}
              >
                <ChatOnline />
                <Toaster />
                <ToastContainerCustom />
                <LoadingFullScreen />
                <DialogLogin />
                <HeaderComponent isLogin={!!user} locale={locale as Locale} />
                <ErrorBoundary>
                  <div>{children}</div>
                </ErrorBoundary>
                <FooterComponent />
              </Provider>
            </NextIntlClientProvider>
          </ThemeProvider>
        </body>
      </html>
    );
  } catch (error) {
    console.log({ error });
    return (
      <html lang="en">
        <body className={`${inter.className} antialiased bg-[#F5F6F7]`}>
          <ThemeProvider
            attribute="class"
            defaultTheme="system"
            enableSystem
            disableTransitionOnChange
          >
            <NextIntlClientProvider messages={messages}>
              <Toaster />
              <HeaderComponent isLogin={!!user} locale={locale as Locale} />
              <ErrorBoundary>
                <ServerError error={error} />
              </ErrorBoundary>
            </NextIntlClientProvider>
          </ThemeProvider>
        </body>
      </html>
    );
  }
}
