"use client";
import React, { useEffect, useMemo, useRef, useState } from "react";
import { useTranslations } from "next-intl";
import { Form, InputField, RefForm } from "@/components/form";
import { checkIsPhoneHaiti, updateSearchParams } from "@/lib/utils";
import { OrderTrackingBody } from "@/schemaValidations/auth.schema";
import { InputPhoneNumberField } from "@/components/form/input-phone-number-field";
import { Button } from "@/components/ui/button";
import { useRouter } from "next/navigation";

type RegisterFormValues = {
  phoneNumber: string;
  email: string;
};

function FormInputPhone() {
  const formRef = useRef<RefForm<RegisterFormValues> | null>(null);
  const router = useRouter();
  const [phoneNumber, setPhoneNumber] = useState("");
  const t = useTranslations();
  const RegisterBodySchema = useMemo(() => {
    const isPhoneHaiti = checkIsPhoneHaiti(phoneNumber);
    if (isPhoneHaiti && formRef.current) {
      formRef.current?.methods.clearErrors("email");
    }
    return OrderTrackingBody({
      isRequiredEmail: !checkIsPhoneHaiti(phoneNumber),
    });
  }, [phoneNumber]);

  const handleSubmit = (data: RegisterFormValues) => {
    router.push("/order-tracking/input-otp?" + updateSearchParams(data));
  };

  return (
    <div>
      <h1 className="text-xl md:text-size-28 font-bold text-neutral-dark-01 text-center">
        {t("order_tracking.title")}
      </h1>
      <div className="mt-6 md:mt-8 max-w-[476px] mx-auto">
        <Form<RegisterFormValues, typeof RegisterBodySchema>
          ref={formRef}
          onSubmit={handleSubmit}
          schema={RegisterBodySchema}
          options={{
            mode: "onChange",
          }}
          defaultValue={{
            phoneNumber: "",
            email: "",
          }}
        >
          {({ control, watch, formState: { errors } }) => {
            const phoneVal = watch("phoneNumber");
            // eslint-disable-next-line react-hooks/rules-of-hooks
            useEffect(() => {
              setPhoneNumber(phoneVal);
            }, [phoneVal]);
            return (
              <div className="flex flex-col mt-4 lg:mt-6">
                <InputPhoneNumberField
                  label={t("common.phone_number")}
                  autoFocus
                  required
                  control={control}
                  errors={errors}
                  id="register-phone"
                  name="phoneNumber"
                  type="text"
                  placeholder={t("register.phone_number")}
                />
                {phoneVal && !checkIsPhoneHaiti(phoneVal) && (
                  <InputField<RegisterFormValues>
                    label={t("common.email")}
                    required
                    maxLength={255}
                    className="mt-8"
                    control={control}
                    errors={errors}
                    name="email"
                    placeholder={t("register.email")}
                  />
                )}
                <Button
                  type="submit"
                  className="w-full mt-4 lg:mt-8 md:max-w-[244px] mx-auto"
                >
                  {t("common.continue")}
                </Button>
              </div>
            );
          }}
        </Form>
      </div>
    </div>
  );
}

export default FormInputPhone;
