"use client";
import SearchResultOrderTrackingItem from "@/app/order-tracking/components/search-result-item";
import SearchInput from "@/components/common/search-input";
import { Button } from "@/components/ui/button";
import { Typography } from "@/components/ui/typography";
import { FORMAT_DATE_TIME_ORDER } from "@/constants/common";
import { formatDateTime } from "@/lib/utils";
import { useTranslations } from "next-intl";
import React from "react";

const FormSearchView = () => {
  const t = useTranslations();
  const [valueSearch, setValueSearch] = React.useState("");
  return (
    <div>
      <p className="text-[32px] leading-[39px] font-bold text-neutral-dark-01 text-center">
        {t("order_tracking.order_list")}
      </p>
      <div className="mt-10 gap-8 flex flex-col items-center justify-center">
        <SearchInput
          className="max-w-[504px]"
          inputClassName="h-12 bg-[#E3E4E5] rounded-xl"
          value={valueSearch}
          onChange={(val) => setValueSearch(val)}
        />
        <Button className="min-w-[244px]">{t("common.search")}</Button>
        <div className="rounded-3xl p-8 w-full max-w-[1032px] mx-auto bg-white form-box-shadow">
          <Typography variant="title2">
            {t("order_tracking.search_result", { count: 123 })}
          </Typography>
          <div className="mt-8 flex flex-col gap-8">
            <SearchResultOrderTrackingItem
              orderId="2025140412"
              customer="0569828869"
              orderDate={formatDateTime(new Date(), FORMAT_DATE_TIME_ORDER)}
              total="100 HTG"
              paymentMethod="Natcash"
              status="delivered"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default FormSearchView;
