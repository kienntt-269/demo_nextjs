import FormSearchView from "@/app/order-tracking/components/form-search-view";
import React from "react";
function OrderTrackingPage() {
  return (
    <div className="mt-10">
      <FormSearchView />
    </div>
  );
}

export default OrderTrackingPage;
