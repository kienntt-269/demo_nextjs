import React from "react";
import VasItem from "@/app/mobile-package/vas/_components/vas-item";
import { VasListParams } from "@/types/mobile-package";
import mobilePackageApiRequest from "@/services/mobile-package";
import { IVasDetail } from "@/schemaValidations/mobile-package.schema";
import NoDataAvailable from "@/components/common/no-data-available/no-data-available";

const getListVas = async (data: VasListParams) => {
  try {
    const res = await mobilePackageApiRequest.getListVas(data);
    return res.payload.data;
  } catch (error) {
    console.log(error);
    throw Error("error");
  }
};

type TabVasListProps = {
  data: VasListParams;
};

const TabVasList = async ({ data }: TabVasListProps) => {
  let vasList: IVasDetail[] = [];
  if (data.categorySlug) {
    vasList = await getListVas({
      categorySlug: data.categorySlug,
      sortBy: "PRICE_DESC",
    });
  }
  return (
    <>
      <div className="mb-6">
        {!!vasList.length ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2 lg:gap-6">
            {vasList.map((data: IVasDetail) => (
              <VasItem key={data.slug} data={data} />
            ))}
          </div>
        ) : (
          <NoDataAvailable />
        )}
      </div>
    </>
  );
};

export default TabVasList;
