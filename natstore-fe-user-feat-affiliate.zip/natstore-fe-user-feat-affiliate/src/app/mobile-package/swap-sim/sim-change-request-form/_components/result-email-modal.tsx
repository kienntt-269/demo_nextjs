import ImageCommon from "@/components/common/image-common";
import Modal from "@/components/common/modal/Modal";
import { Button } from "@/components/ui/button";
import { Dialog } from "@/components/ui/dialog";
import { useTranslations } from "next-intl";
import React from "react";

export type ResultEmailModalProps = React.ComponentProps<typeof Dialog> & {
  isModal: boolean;
  onClose: () => void;
};

const ResultEmailModal = ({ isModal, onClose }: ResultEmailModalProps) => {
  const t = useTranslations("mobile_package");
  return (
    <Modal
      isOpen={isModal}
      onClose={onClose}
      contentClassName="w-[343px] lg:w-[504px] lg:max-w-full pb-[24px] pt-2 px-2 lg:p-6"
    >
      <div className="flex justify-center items-center">
        <ImageCommon
          src="/images/icon/check-success.svg"
          alt="check-success"
          width={96}
          height={96}
          className="rounded-t-2xl"
        />
      </div>
      <h3 className="font-bold text-xl lg:text-2xl text-center text-black my-4">
        {t("swap_sim.result_email_title")}
      </h3>
      <div className="max-sm:text-sm text-base text-neutral-dark-04 mb-6">
        {t("swap_sim.result_email_desc")}
      </div>
      <div className="flex justify-center items-center">
        <Button
          className="text-base font-bold text-white h-[32px] lg:min-w-[212px] min-w-[212px] rounded-3xl"
          onClick={onClose}
        >
          {t("roaming.got_id")}
        </Button>
      </div>
    </Modal>
  );
};

export default ResultEmailModal;
