"use client";
import NoDataAvailable from "@/components/common/no-data-available/no-data-available";
import { IDataPlan } from "@/schemaValidations/mobile-service.schema";
import React, { useCallback, useRef, useState } from "react";
import { Swiper, SwiperSlide, SwiperRef } from "swiper/react";
import { Navigation, Pagination, Autoplay } from "swiper/modules";
import "swiper/css";
import "swiper/css/navigation";
import "swiper/css/pagination";
import { Check, ChevronLeft, ChevronRight } from "lucide-react";
import { useIsMobile } from "@/hooks/use-mobile";
import { cn } from "@/lib/utils";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Ratings } from "@/components/ui/rating";
import { useTranslations } from "next-intl";
import TagServiceMobile from "@/module/mobile-services/component/tag-service";
import { useSimCardStore } from "@/_stores/useSimCard.store";
import { Button } from "@/components/ui/button";
import SimDetailModal from "@/app/mobile-package/buy-sim/sim-detail";
import TextWithTooltip from "@/components/text-width-tooltip";

interface IProps {
  listDataPackage?: IDataPlan[];
  isShowPaging?: boolean;
  length?: number;
  quantity?: number;
  quantityMobile?: number;
}

const CarouselSimPackage = ({
  listDataPackage,
  isShowPaging = true,
  length = 0,
  quantityMobile = 2,
  quantity = 4,
}: IProps) => {
  const { packageData, setPackageData } = useSimCardStore();
  const [activeIndex, setActiveIndex] = useState(0);
  const sliderRef = useRef<SwiperRef>(null);
  const [selectPackage, setSelectPackage] = useState<IDataPlan>();
  const [isVisible, setIsVisible] = useState<boolean>(false);
  const t = useTranslations();
  const handlePrev = useCallback(() => {
    if (!sliderRef.current) return;
    sliderRef.current.swiper.slidePrev();
  }, []);

  const handleNext = useCallback(() => {
    if (!sliderRef.current) return;
    sliderRef.current.swiper.slideNext();
  }, []);
  const isMobile = useIsMobile();
  const updateSearchParams = (key: string, value: string) => {
    const url = new URL(window.location.href);
    url.searchParams.set(key, value);
    window.history.replaceState({}, "", url);
  };
  return (
    <div className="w-full gap-x-2 relative overflow-visible">
      <SimDetailModal
        isVisible={isVisible}
        dataPlant={selectPackage}
        onClose={(data: boolean) => {
          setIsVisible(data);
        }}
      />
      <div>
        <button
          className={cn(
            "hidden absolute top-[43%] -left-16 max-xl:-left-12 max-lg:-left-10 transform -translate-y-1/2 z-0 xl:size-14 size-9 md:flex items-center justify-center bg-[#E3E4E5] rounded-full",
            {
              "cursor-default": activeIndex === 0,
            }
          )}
          onClick={handlePrev}
          aria-label="Previous Slide"
        >
          <ChevronLeft />
        </button>
        <button
          className={cn(
            "hidden absolute top-[43%] -right-16 max-xl:-right-12 max-lg:-right-10 transform -translate-y-1/2 z-0 xl:size-14 size-9 md:flex items-center justify-center bg-[#E3E4E5] rounded-full",
            {
              "cursor-default": activeIndex === 4,
            }
          )}
          onClick={handleNext}
          aria-label="Next Slide"
        >
          <ChevronRight />
        </button>
      </div>
      <Swiper
        ref={sliderRef}
        modules={[Navigation, Pagination, Autoplay]}
        slidesPerView={quantity}
        spaceBetween={isMobile ? 8 : 8}
        onSlideChange={(swiper) => {
          setActiveIndex(swiper.activeIndex);
        }}
        autoplay={false}
        loop={false}
        pagination={{
          clickable: true,
          renderBullet: (index, className) =>
            `<span class="${className} custom-bullet"></span>`,
        }}
        breakpoints={{
          0: { slidesPerView: quantityMobile },
          640: { slidesPerView: !!(quantity - 2) ? quantity - 2 : 1 },
          768: { slidesPerView: !!(quantity - 2) ? quantity - 2 : 1 },
          1024: { slidesPerView: !!(quantity - 2) ? quantity - 2 : 1 },
          1280: { slidesPerView: quantity },
        }}
        className={`${length > 3 - 1 ? "md:!pb-8 !pb-4 custom-swiper" : "!pb-3 "} ${!isShowPaging ? "hide-paging" : ""} !z-0`}
      >
        {listDataPackage && listDataPackage?.length > 0 ? (
          listDataPackage.map((val) => (
            <SwiperSlide key={val.id}>
              <Card
                className="rounded-3xl max-md:rounded-2xl overflow-hidden border-none"
                style={{
                  boxShadow: "0px 3.09px 12.37px 0px #00000014",
                }}
              >
                <CardHeader
                  className={`p-0 px-3 text-center space-y-0  bg-[url('/mobile-package/card-header.png')] bg-cover py-3 max-md:py-3`}
                >
                  <div className="text-white text-card hover:scale-105 transition-all max-md:text-[16px] max-md:font-semibold leading-[34px] max-md:leading-5 font-bold truncate text-ellipsis text-nowrap overflow-hidden">
                    <TextWithTooltip content={`${val?.name}`} />
                  </div>
                </CardHeader>
                <CardContent className="p-4 max-md:py-4 max-md:px-3">
                  <div className="flex items-center justify-between mb-2 max-md:mb-1 max-md:h-6">
                    <div className="flex gap-x-2 items-center line-clamp-1 flex-1">
                      <div className="font-semibold max-md:text-sm xl:text-[20px] line-clamp-1">
                        {Number(val?.price ?? 0)?.toLocaleString("en-US")}
                        <span className="text-neutral-mid-01">
                          {" "}
                          {t("mobile_package.htg")}
                        </span>
                      </div>
                    </div>

                    <Ratings
                      rating={val?.rating ?? 0}
                      variant="orange"
                      className="max-md:hidden flex"
                    />
                    <Ratings
                      rating={val?.rating ?? 0}
                      variant="orange"
                      size={12}
                      className="hidden max-md:flex"
                    />
                  </div>
                  <div className="overflow-hidden no-scrollbar">
                    <TagServiceMobile data={val} />
                  </div>{" "}
                  <div className="flex gap-x-2 mt-3 max-md:mt-2 items-start">
                    <div className="line-clamp-2 h-10 font-normal text-[14px] leading-5 text-neutral3 max-md:leading-[15px] max-md:h-8 whitespace-pre-line">
                      {val?.description}
                    </div>
                  </div>
                  <Button
                    onClick={() => {
                      setPackageData(val);
                      updateSearchParams("package", `${val.id}`);
                    }}
                    className={`flex-1 mt-4 py-[13.5px] max-md:h-8 font-bold w-full max-lg:text-[14px] max-lg:py-2 max-lg:px-4 max-md:py-[6px] max-md:leading-5 ${packageData?.id === val?.id ? "opacity-50" : "opacity-100"}`}
                  >
                    <div className="flex items-center justify-center gap-x-2">
                      {packageData?.id === val?.id ? <Check /> : <></>}
                      {t("common.select")}
                    </div>
                  </Button>
                  <Button
                    className="flex-1 py-[13.5px] max-md:h-8 font-bold w-full max-lg:text-[14px] max-lg:py-2 max-lg:px-4 max-md:py-[6px] max-md:leading-5 mt-2"
                    variant={"secondary"}
                    onClick={() => {
                      setIsVisible(true);
                      setSelectPackage(val);
                    }}
                  >
                    {t("mobile_package.detail")}
                  </Button>
                </CardContent>
              </Card>
            </SwiperSlide>
          ))
        ) : (
          <NoDataAvailable />
        )}
      </Swiper>{" "}
      <style>{`
      
      .custom-swiper .swiper-pagination {
        bottom: 0px !important;
        height: 18px !important;
      }

      .custom-swiper.hide-paging {
        padding-bottom: 0 !important;
      }

      .custom-swiper.hide-paging .swiper-pagination {
        display: none !important;
      }
      .swiper {
        box-shadow: 
    -4px 0 2px -4px #00000014, /* Bóng trái */
     4px 0 2px -4px #00000014;  /* Bóng phải */
     }

      .custom-bullet {
        width: 8px;
        height: 8px;
        background: gray;
        margin: 0 5px;
        border-radius: 50%;
        transition: all 0.3s ease;
      }

      .custom-swiper .swiper-pagination-bullet-active {
        width: 24px;
        height: 8px;
        background: #ff8600;
        border-radius: 5px;
      }

      @media (max-width: 640px) {
        .custom-swiper .swiper-pagination {
          height: 18px !important;
        }
        .custom-swiper .swiper-pagination-bullet-active {
          height: 6px;
        }
        .custom-bullet {
          width: 6px;
          height: 6px;
        }
      }
    `}</style>
    </div>
  );
};

export default CarouselSimPackage;
