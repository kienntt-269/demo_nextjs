"use client";
import { useTranslations } from "next-intl";
import React from "react";

type IProps = {
  step?: number;
};

const StepSimComponent: React.FC<IProps> = ({ step }: IProps) => {
  const t = useTranslations();
  return (
    <div className="m-auto mt-10 max-md:mt-4 rounded-3xl h-[228px] max-md:h-[108px] max-md:rounded-2xl flex flex-col items-center justify-center px-[188px] max-md:px-[15%] max-w-[766px] bg-[#FF8600] bg-blend-overlay bg-gradient-to-b from-[rgba(0,0,0,0)] to-[rgba(0,0,0,0.3)]">
      <div className="flex items-center w-full px-10 pr-8">
        <div className="bg-white rounded-t-[13.33px] rounded-br-[13.33px] max-md:rounded-t-[8px] max-md:rounded-br-[8px] size-10 max-md:size-6 text-[24px] max-md:text-[12px] leading-6 max-md:leading-none text-center pt-2 text-primary font-bold">
          1
        </div>
        <div className="flex-1 bg-white h-[6px] max-md:h-1"></div>
        <div
          className={`border-solid border-white border-[3px] rounded-t-[13.33px] rounded-br-[13.33px] max-md:rounded-t-[8px] max-md:rounded-br-[8px] size-10 max-md:size-6 text-[24px] max-md:text-[12px] leading-6 max-md:leading-none text-center pt-2 max-md:pt-1 font-bold ${step === 2 ? "bg-white text-primary" : "text-white"}`}
        >
          2
        </div>
      </div>
      <div className="flex justify-between w-full mt-4 max-md:mt-2 text-white text-[24px] max-md:text-[12px] max-md:px-6">
        <div className="font-bold">
          {t("mobile_package.sim_normal.select_sim")}
        </div>
        <div className="font-normal">
          {t("mobile_package.roaming.register")}
        </div>
      </div>
    </div>
  );
};

export default StepSimComponent;
