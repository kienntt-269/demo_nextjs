"use client";
import { useSimCardStore } from "@/_stores/useSimCard.store";
import FilterSimPackage from "@/app/mobile-package/buy-sim/filter-sim-package";
import TabCommon from "@/components/tabs-common";
import { Input } from "@/components/ui/input";
import { useIsMobile } from "@/hooks/use-mobile";
import { updateSearchParams } from "@/lib/utils";
import { IHotKey, ISimCard } from "@/schemaValidations/sim-card.schema";
import simApiRequest from "@/services/sim-service";
import { ChevronLeft, ChevronRight, Search } from "lucide-react";
import { useTranslations } from "next-intl";
import { usePathname, useRouter } from "next/navigation";
import React, { useEffect, useRef, useState } from "react";

function TabSimChange({
  searchParams,
}: {
  searchParams: { [key in string]: string };
}) {
  const t = useTranslations();
  const router = useRouter();
  const pathname = usePathname();
  const isMobile = useIsMobile();
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const [hotKey, setHotKey] = useState<IHotKey[]>([]);
  const { setSimDetail } = useSimCardStore();
  const [showPrev, setShowPrev] = useState<boolean>(false);
  const [showNext, setShowNext] = useState<boolean>(false);
  const [searchValue, setSearchValue] = useState<string>("");
  const [queryHotKey, setQueryHotKey] = useState<string>("");

  const categoriesSim = [
    {
      label: t("mobile_package.swap_sim.physical_sim"),
      type: "physical",
    },
    // {
    //   label: t("mobile_package.esim"),
    //   type: "esim",
    // },
  ];

  const handleKeyDown = (event: React.KeyboardEvent<HTMLInputElement>) => {
    if (event.key === "Backspace" || event.key === "Delete") {
      setQueryHotKey("");
    }
  };

  useEffect(() => {
    if (searchParams?.hotKey) {
      setSearchValue(searchParams?.hotKey);
    } else if (searchParams?.isdnNumber) {
      setSearchValue(searchParams?.isdnNumber);
    } else {
      setSearchValue("");
    }
    setSimDetail({} as ISimCard);
  }, [searchParams]);

  const scroll = (direction: "left" | "right") => {
    const container = scrollContainerRef.current;
    if (container) {
      const scrollAmount = container.clientWidth / 2;
      container.scrollBy({
        left: direction === "left" ? -scrollAmount : scrollAmount,
        behavior: "smooth",
      });
    }
  };

  const getListHotKey = async () => {
    try {
      const res = await simApiRequest.getHotKey();
      const sortedList = res.payload?.data?.sort((a, b) => {
        if (a.sortOrder === null && b.sortOrder === null) return 0;
        if (a.sortOrder === null) return 1;
        if (b.sortOrder === null) return -1;
        return a.sortOrder - b.sortOrder;
      });
      setHotKey(sortedList ?? []);
    } catch (error) {
      console.log(error);
    }
  };

  const checkScroll = () => {
    const container = scrollContainerRef.current;
    if (
      container &&
      container.scrollWidth > container.clientWidth &&
      container.scrollLeft + container.clientWidth < container.scrollWidth
    ) {
      setShowPrev(true);
      setShowNext(true);
    }
  };

  useEffect(() => {
    getListHotKey();
    setTimeout(checkScroll, 300);
    window.addEventListener("resize", checkScroll);
    return () => window.removeEventListener("resize", checkScroll);
  }, []);

  return (
    <div className="flex flex-col items-center mt-10 max-lg:mt-4">
      <TabCommon
        tabs={categoriesSim}
        // defaultTab={categoriesSim.findIndex(
        //   (item) => item.type === searchParams?.slug
        // )}
        defaultTab={0}
        onChangeTab={(index) => {
          const newparams = updateSearchParams({
            type: "1",
            slug: index === 1 ? "esim" : "physical",
          });
          router.push(newparams, {
            scroll: false,
          });
        }}
      />
      <div className="flex gap-x-2 mt-10 max-lg:mt-4 w-[766px] max-lg:w-full">
        <div className="relative flex-1">
          <Input
            className="w-full text-normal pl-8 h-[49px] max-md:h-[38px] bg-[#E3E4E5] rounded-xl font-normal outline-none border-none"
            placeholder={t("mobile_package.sim_normal.search_sim")}
            value={searchValue}
            onChange={(event) => {
              if (
                event.target.value === "" ||
                (/^\d*$/.test(event.target.value) &&
                  Number(event.target.value) >= 0)
              ) {
                setSearchValue(event.target.value);
              }
              if (!event.target.value) {
                setQueryHotKey("");
                router.push(
                  `${pathname}${updateSearchParams({
                    isdnNumber: "",
                    hotKey: "",
                    page: "1",
                  })}`,
                  {
                    scroll: false,
                  }
                );
              }
            }}
            onKeyDown={(event) => {
              handleKeyDown(event);
              if (event.key === "Enter") {
                router.push(
                  `${pathname}${updateSearchParams({
                    isdnNumber: queryHotKey ? "" : searchValue,
                    hotKey: queryHotKey ?? "",
                    page: "1",
                  })}`,
                  {
                    scroll: false,
                  }
                );
              }
            }}
          />
          <Search
            strokeWidth={1}
            className="absolute top-4 max-md:top-[10px] left-2 size-[18px]"
          />
        </div>
        <button
          onClick={() => {
            router.push(
              `${pathname}${updateSearchParams({
                isdnNumber: queryHotKey ? "" : searchValue,
                hotKey: queryHotKey ?? "",
              })}`,
              {
                scroll: false,
              }
            );
          }}
          className="h-[49px] max-md:h-[38px] max-md:w-[70px] px-[52px] flex items-center justify-center rounded-2xl bg-primary border-none text-white font-bold text-[14px]"
        >
          {t("common.search")}
        </button>
      </div>
      <div className="mt-6 max-lg:mt-4 flex max-lg:block justify-between items-center w-full">
        <div className="gap-x-6 flex-1 2xl:flex items-center justify-between">
          <div className="flex items-center gap-x-2 max-xl:mt-4 max-xl:block max-lg:mt-2">
            {hotKey.length > 0 && (
              <div className="font-semibold text-neutral-mid-01 max-md:text-[12px] flex-shrink-0">
                {t("common.hot_key")}
              </div>
            )}
            {hotKey.length > 0 && (
              <div className="flex items-center gap-x-2">
                {showPrev && (
                  <button
                    className="rounded xl:size-8 size-6 flex items-center justify-center bg-[#E3E4E5] max-md:hidden"
                    onClick={() => scroll("left")}
                    aria-label="Previous Slide"
                  >
                    <ChevronLeft size={isMobile ? 12 : 16} />
                  </button>
                )}
                <div
                  ref={scrollContainerRef}
                  className="flex flex-1 items-center gap-x-8 max-md:gap-x-4 text-primary font-bold text-xl max-md:text-[14px] overflow-x-scroll no-scrollbar"
                >
                  {hotKey.length > 0 &&
                    hotKey.map((val) => {
                      return (
                        <div
                          key={val.id}
                          onClick={() => {
                            setSearchValue(val.hotKey);
                            setQueryHotKey(val.hotKey);
                          }}
                          className="cursor-pointer"
                        >
                          {val.hotKey}
                        </div>
                      );
                    })}
                </div>
                {showNext && (
                  <button
                    className="rounded xl:size-8 size-6 flex items-center justify-center bg-[#E3E4E5] max-md:hidden"
                    onClick={() => scroll("right")}
                    aria-label="Previous Slide"
                  >
                    <ChevronRight size={isMobile ? 12 : 16} />
                  </button>
                )}
              </div>
            )}
          </div>
          <FilterSimPackage searchParams={searchParams} />
        </div>
      </div>
    </div>
  );
}

export default TabSimChange;
