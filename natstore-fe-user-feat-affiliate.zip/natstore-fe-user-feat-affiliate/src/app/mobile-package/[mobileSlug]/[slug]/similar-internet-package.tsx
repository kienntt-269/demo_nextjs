"use server";
import CardCommon from "@/components/card-common";
import CarouselData from "@/components/common/carousel-data/carousel-data";
import TitleStyle from "@/components/title-common";
import mobileApiRequest from "@/services/mobile-service";
import React from "react";
import { getTranslations } from "next-intl/server";
import NoDataAvailable from "@/components/common/no-data-available/no-data-available";

const getData = async (packageId: string) => {
  try {
    const res = await mobileApiRequest.getListSimilar(packageId);
    return res.payload;
  } catch (error) {
    console.log(error);
    throw Error("error");
  }
};

const SimilarInternetPackage = async ({ slug }: { slug: string }) => {
  const response = await getData(slug);
  const t = await getTranslations();
  return (
    <div>
      <TitleStyle>
        {t("mobile_package.roaming.similar_internet_package")}
      </TitleStyle>
      <div className="mt-6 max-md:mt-3">
        <CarouselData quantity={4} length={response?.data.length}>
          {Array.isArray(response?.data) ? (
            response?.data?.map((val) => {
              return (
                <CardCommon
                  key={val.id}
                  target="data"
                  type="medium"
                  data={val}
                  redirectBuy={`/mobile-package/data/${val.slug}/payment`}
                  redirectLink={`/mobile-package/data/${val.slug}`}
                />
              );
            })
          ) : (
            <NoDataAvailable />
          )}
        </CarouselData>
      </div>
    </div>
  );
};

export default SimilarInternetPackage;
