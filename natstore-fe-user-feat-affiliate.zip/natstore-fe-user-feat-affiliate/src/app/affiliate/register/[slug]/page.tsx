import RegisterAffiliateForm from "@/app/affiliate/register/_components/affiliate-form";
import BreadCrumbCommon from "@/components/breadcrumb-common";
import PageContent from "@/components/page-content";
import { ILinks } from "@/types/package";
import { getTranslations } from "next-intl/server";

const DetailAccountAffiliate = async () => {
  const t = await getTranslations("");

  const breadCrumb: ILinks[] = [
    {
      label: t("personal.home"),
      link: "/",
    },
    {
      label: "Affiliate",
      link: "/device",
    },
    {
      label: t("common.register"),
      link: `/`,
    },
  ];

  return (
    <PageContent>
      <BreadCrumbCommon content={breadCrumb} />
      <div className="mt-10 max-md:mt-6">
        <RegisterAffiliateForm />
      </div>
    </PageContent>
  );
};

export default DetailAccountAffiliate;
