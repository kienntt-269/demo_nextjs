import Modal from "@/components/common/modal/Modal";
import { Button } from "@/components/ui/button";
import { Dialog } from "@/components/ui/dialog";
import { useTranslations } from "next-intl";
import Image from "next/image";
import { useRouter } from "next/navigation";
import React from "react";

export type SuccessModalProps = React.ComponentProps<typeof Dialog> & {
  time: string;
  onSubmit: () => void;
};

const RegisterSuccessModal = ({ time, onSubmit }: SuccessModalProps) => {
  const t = useTranslations("");
  const router = useRouter();
  return (
    <Modal
      isOpen={!!time}
      onClose={onSubmit}
      contentClassName="w-[343px] lg:w-[504px] lg:max-w-full pb-[24px] pt-2 px-4 lg:p-6"
    >
      <div className="flex justify-center items-center mb-3 lg:mb-4">
        <Image
          src={"/images/icon/check-success.svg"}
          quality={100}
          unoptimized
          height={64}
          width={64}
          alt=""
          className="max-md:size-[72px]"
        />
      </div>
      <h3 className="font-bold text-xl lg:text-2xl text-center text-black my-4">
        {t("affiliate.register_success_popup_title")}
      </h3>
      <div className="text-center text-sm text-neutral-dark-04 mb-4 lg:mb-6">
        {time}
      </div>
      <div className="max-sm:text-sm lg:text-base text-center text-neutral-dark-04 mb-4 lg:mb-6">
        {t("affiliate.register_success_popup_desc")}
        <div
          className="font-semibold text-primary underline ml-1 cursor-pointer"
          onClick={() => {
            router.push(`/personal`);
          }}
        >
          {t("personal.account_information")}
        </div>
      </div>
      <div className="flex justify-center items-center lg:mb-2">
        <Button
          className="w-[100%] lg:max-w-[212px] min-w-[212px] rounded-3xl"
          onClick={onSubmit}
        >
          {t("mobile_package.sim_normal.back_to_homepage")}
        </Button>
      </div>
    </Modal>
  );
};

export default RegisterSuccessModal;
