"use client";

import { useLoadingStore } from "@/_stores/useLoading,store";
import { useProfileStore } from "@/_stores/useProfile.store";
import RegisterSuccessModal from "@/app/affiliate/register/_components/register-success-modal";
import OtpModal from "@/app/mobile-package/swap-sim/_component/otp-modal";
import { Form, InputField, SelectField } from "@/components/form";
import CheckboxField from "@/components/form/check-box-field";
import DatePickerField from "@/components/form/date-picker-field";
import { InputPhoneNumberField } from "@/components/form/input-phone-number-field";
import UploadFileSingle from "@/components/form/upload-file-single";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { FAIL_CODE2, SUCCESS_CODE3 } from "@/constants/http-response";
import { getGender, getTypeOfDocV2 } from "@/constants/variable";
import { toastError } from "@/hooks/use-toast";
import { checkResSuccess, formatPhoneSubmit } from "@/lib/utils";
import {
  RegisterAccountAffiliateType,
  RegisterAccountAffiliate as RegisterAccountAffiliate1,
} from "@/schemaValidations/affiliate.schema";

import { IAddressDetail } from "@/schemaValidations/sim-card.schema";
import affiliateApiRequest from "@/services/affiliate";
import simApiRequest from "@/services/sim-service";
import { IAffiliatePost } from "@/types/affiliate";
import clsx from "clsx";
import dayjs from "dayjs";
import { useTranslations } from "next-intl";
import Image from "next/image";
import { useRouter } from "next/navigation";
import React, { useEffect, useMemo, useState } from "react";
import { Controller } from "react-hook-form";

type RegisterAffiliateFormType = {
  className?: string;
};

const RegisterAffiliateForm = ({ className }: RegisterAffiliateFormType) => {
  const t = useTranslations("");
  const schema = useMemo(() => RegisterAccountAffiliate1(), []);
  const router = useRouter();
  const { user } = useProfileStore();
  const { setIsLoading } = useLoadingStore();

  const defaultValues = React.useMemo(
    () => ({
      isdn: user?.isdn ? "+" + formatPhoneSubmit(user?.isdn) : "",
      email: user?.isdn ? "+" + formatPhoneSubmit(user?.isdn) : "",
      fullName: user?.isdn ? "+" + formatPhoneSubmit(user?.isdn) : "",
    }),
    [user?.isdn]
  );
  const [provinces, setProvinces] = useState<IAddressDetail[]>([
    { name: t("common.no_data"), id: 0 },
  ]);
  const [districts, setDistricts] = useState<IAddressDetail[]>([
    { name: t("common.no_data"), id: 0 },
  ]);
  const [wards, setwards] = useState<IAddressDetail[]>([
    { name: t("common.no_data"), id: 0 },
  ]);
  const [isVisible, setIsVisible] = useState<boolean>(false);
  const [error, setError] = useState<string>("");
  const [isGetOtp, setIsGetOtp] = useState(false);
  const [dataForm, setDataForm] = useState<RegisterAccountAffiliateType>();

  const getProvince = async () => {
    try {
      const res = await simApiRequest.getAddress({
        type: 1,
      });
      setProvinces(res.payload.data);
    } catch (error) {
      console.log(error);
    }
  };

  const getDistrict = async (id: string) => {
    try {
      const res = await simApiRequest.getAddress({
        type: 2,
        parentId: id,
      });
      setDistricts(
        res?.payload?.data.length > 0
          ? res.payload.data
          : [{ name: t("common.no_data"), id: 0 }]
      );
      setwards([{ name: t("common.no_data"), id: 0 }]);
    } catch (error) {
      console.log(error);
    }
  };
  const getward = async (id: string) => {
    try {
      const res = await simApiRequest.getAddress({
        type: 3,
        parentId: id,
      });
      setwards(
        res?.payload?.data.length > 0
          ? res.payload.data
          : [{ name: t("common.no_data"), id: 0 }]
      );
    } catch (error) {
      console.log(error);
    }
  };

  const handleSubmit = async (data: RegisterAccountAffiliateType) => {
    if (Number(localStorage.getItem("is_login_otp")) == 0) {
      const res = await affiliateApiRequest.requestsOtp({
        phoneNumber: data?.mobileNumber ?? "",
      });
      if (res.payload.code === FAIL_CODE2) {
        setError(t("otp_error_2"));
        toastError(t("otp_error_2"));
        return;
      }
      if (res.payload.code === SUCCESS_CODE3) {
        setIsVisible(true);
        setDataForm(data);
      }
    } else {
      registerAccountAffiliate(data);
    }
  };

  const registerAccountAffiliate = async (
    data?: RegisterAccountAffiliateType,
    otp?: string
  ) => {
    try {
      const formattedDOB = dayjs(data?.birthday).toString();
      const newData: IAffiliatePost = {
        isdn: data?.isdn ?? "",
        email: data?.email ?? "",
        fullName: data?.fullName ?? "",
        birthday: formattedDOB,
        gender: Number(data?.gender) ?? 0,
        customerDocType: Number(data?.customerDocType) ?? 0,
        cardId: data?.cardId ?? "",
        taxNumber: data?.taxNumber ?? "",
        provinceId: data?.provinceId ?? "",
        districtId: data?.districtId ?? "",
        communeId: data?.communeId ?? "",
        addressDetail: data?.addressDetail ?? "",
        paymentPhone: data?.mobileNumber ?? "",
        paymentMethod: data?.paymentMethod ?? 0,
        terms: 1,
        isLoginOtp: Number(localStorage.getItem("is_login_otp")) ?? 0,
        otp: otp,
      };
      const formData = new FormData();
      formData.append(
        "data",
        new Blob([JSON.stringify(newData)], {
          type: "application/json",
        })
      );
      if (
        data?.backIdcard &&
        data?.backIdcard.length > 0 &&
        data?.frontIdCard &&
        data?.frontIdCard.length > 0 &&
        data?.faceImage &&
        data?.faceImage.length > 0
      ) {
        formData.append("frontIdCard", data.frontIdCard[0]);
        formData.append("backIdCard", data.backIdcard[0]);
        formData.append("personalImage", data.faceImage[0]);
      } else {
        formData.append(
          "frontIdCard",
          new File([], "empty-face.jpg", { type: "image/jpeg" })
        );
        formData.append(
          "backIdCard",
          new File([], "empty-face.jpg", { type: "image/jpeg" })
        );
        formData.append(
          "personalImage",
          new File([], "empty-face.jpg", { type: "image/jpeg" })
        );
      }
      const res = await affiliateApiRequest.postRegister(formData);
      if (res.payload.code == SUCCESS_CODE3) {
      }
      if (checkResSuccess(res.payload.code)) {
        if (res.payload.data.isLoginWithPass == 1) {
          setIsVisible(true);
        } else {
        }
      }
      setIsLoading(false);
    } catch (error) {
      console.log("🚀 ~ registerAccountAffiliate ~ error:", error);
    }
  };

  const handleSuccess = () => {
    router.push("/personal");
  };

  const sendOTPRegister = (otp: string) => {
    setIsLoading(true);
    registerAccountAffiliate(dataForm, otp);
  };

  useEffect(() => {
    getProvince();
  }, []);
  return (
    <div>
      <Form<RegisterAccountAffiliateType, typeof schema>
        schema={schema}
        onSubmit={handleSubmit}
        options={{
          mode: "onChange",
        }}
        defaultValue={defaultValues}
        isUpdateDefault={true}
      >
        {({
          control,
          formState: { errors, isValid },
          setValue,
          watch,
          trigger,
        }) => {
          const values = watch();
          console.log("🚀 ~ RegisterAccountAffiliate ~ values:", values);
          return (
            <div
              className={clsx(
                "w-full bg-white rounded-3xl p-8 max-md:p-4",
                className
              )}
            >
              <div className="text-[28px] max-md:text-[20px] font-bold mb-4 max-md:mb-2 text-black">
                {t("phone_device.register_account")}
              </div>
              <div className="flex items-center gap-2 text-primary text-sm font-bold mb-8 max-md:mb-6">
                <Image
                  alt="info"
                  src="/info.svg"
                  width={24}
                  height={24}
                  className="max-md:size-[20px]"
                />
                {t("phone_device.collaborator_policy")}
              </div>
              <div className="text-[20px] font-bold max-md:text-[16px]">
                {t("phone_device.login_information")}
              </div>
              <div className="mt-2 text-neutral-dark-04 text-[14px] max-md:text-[12px]">
                (*) {t("mobile_package.sim_normal.please_fill_in")}
              </div>
              <div className="flex flex-row max-md:flex-col lg:items-center justify-center gap-6 max-lg:gap-3 mt-4 max-md:mt-2">
                <div className="flex-1">
                  <InputField
                    maxLength={50}
                    name="isdn"
                    label={t("common.userName")}
                    classNameLabel="!font-normal text-sm lg:text-base !text-neutral-dark-01"
                    placeholder={`${t("common.userName")}*`}
                    type="text"
                    control={control}
                    errors={errors}
                    disabled
                  />
                </div>
                <div className="flex-1">
                  <InputField
                    maxLength={255}
                    name="email"
                    label={t("register.email")}
                    classNameLabel="!font-normal text-sm lg:text-base !text-neutral-dark-01"
                    placeholder={`${t("register.email")}*`}
                    type="text"
                    control={control}
                    errors={errors}
                    required
                  />
                </div>
              </div>
              <div className="text-[20px] font-bold mt-8 max-md:mt-6 max-md:text-[16px]">
                {t("phone_device.identity_document_information")}
              </div>
              <div className="grid grid-cols-3 gap-x-6 gap-y-4 max-lg:gap-3 max-md:grid-cols-1 mt-4 max-md:mt-2">
                <InputField
                  maxLength={50}
                  name="fullName"
                  label={t("mobile_package.swap_sim.full_name")}
                  classNameLabel="!font-normal text-sm lg:text-base !text-neutral-dark-01"
                  placeholder={`${t("mobile_package.swap_sim.full_name")}*`}
                  type="text"
                  control={control}
                  errors={errors}
                  required
                />
                <DatePickerField
                  name="birthday"
                  label={t("mobile_package.swap_sim.date_placholder")}
                  control={control}
                  errors={errors}
                  placeholder={t("mobile_package.swap_sim.date_placholder")}
                  classNameLabel="!font-normal text-sm lg:text-base !text-neutral-dark-01"
                  required
                />
                <SelectField
                  name="gender"
                  label={t("mobile_package.swap_sim.gender")}
                  control={control}
                  placeholder={`${t("mobile_package.swap_sim.gender")}*`}
                  options={getGender(t)}
                  trigger={trigger}
                  error={errors?.gender}
                />
                <SelectField
                  error={errors?.customerDocType}
                  control={control}
                  placeholder={t("mobile_package.swap_sim.type_of_doc")}
                  name="customerDocType"
                  label={t("mobile_package.swap_sim.type_of_doc")}
                  classNameLabel="!font-normal text-xs lg:text-base !text-neutral-dark-01"
                  options={getTypeOfDocV2(t).map((item) => ({
                    label: item.name,
                    value: item.id + "",
                  }))}
                  required
                />
                <InputField
                  name="cardId"
                  label={t("mobile_package.sim_normal.id_card")}
                  placeholder={t("mobile_package.sim_normal.id_card")}
                  classNameLabel="!font-normal text-sm lg:text-base !text-neutral-dark-01"
                  type="text"
                  className=""
                  control={control}
                  errors={errors}
                  required
                  disabled={!values.customerDocType}
                />
                <InputField
                  maxLength={50}
                  name="taxNumber"
                  label={t("phone_device.tax_code")}
                  classNameLabel="!font-normal text-sm lg:text-base !text-neutral-dark-01"
                  placeholder={`${t("phone_device.tax_code")}*`}
                  type="text"
                  control={control}
                  errors={errors}
                  required
                />
              </div>
              <div className="mt-4 grid grid-cols-2 gap-4 max-md:grid-cols-1">
                <div>
                  <label className="text-sm md:text-base" htmlFor="">
                    {t("mobile_package.sim_normal.province_city")}
                    <span className="text-red-500">*</span>
                  </label>
                  <Controller
                    name="provinceId"
                    control={control}
                    render={({
                      field: { onChange },
                      fieldState: { error },
                    }) => {
                      return (
                        <div className="flex flex-col">
                          <Select
                            onValueChange={(value) => {
                              setValue("districtId", "");
                              setValue("communeId", "");
                              onChange(value);
                              getDistrict(value);
                            }}
                          >
                            <SelectTrigger
                              className={clsx(
                                "flex-1 py-[12px] px-[16px] h-[48px] rounded-xl mt-2 data-[placeholder]:text-neutral-mid-01",
                                {
                                  "border-solid border border-error": !!error,
                                }
                              )}
                            >
                              <SelectValue
                                placeholder={t(
                                  "mobile_package.sim_normal.province_city"
                                )}
                              />
                            </SelectTrigger>
                            <SelectContent>
                              {provinces?.map((val) => {
                                return (
                                  <SelectItem key={val.id} value={`${val.id}`}>
                                    {val.name}
                                  </SelectItem>
                                );
                              })}
                            </SelectContent>
                          </Select>
                          {error && (
                            <p className="text-red-500 text-sm mt-1">
                              {t(`common.message.${error.message}`)}
                            </p>
                          )}
                        </div>
                      );
                    }}
                  />
                </div>
                <div>
                  <label className="text-sm md:text-base" htmlFor="">
                    {t("mobile_package.sim_normal.disctrict")}
                    <span className="text-red-500">*</span>
                  </label>
                  <Controller
                    name="districtId"
                    control={control}
                    render={({
                      field: { onChange, value },
                      fieldState: { error },
                    }) => {
                      return (
                        <div className="flex flex-col">
                          <Select
                            onValueChange={(value) => {
                              setValue("communeId", "");
                              onChange(value);
                              getward(value);
                            }}
                            value={value}
                          >
                            <SelectTrigger
                              className={clsx(
                                "flex-1 py-[12px] px-[16px] h-[48px] rounded-xl mt-2 data-[placeholder]:text-neutral-mid-01",
                                {
                                  "border-solid border border-error": !!error,
                                }
                              )}
                            >
                              <SelectValue
                                key={values.communeId}
                                placeholder={t(
                                  "mobile_package.sim_normal.disctrict"
                                )}
                              />
                            </SelectTrigger>
                            <SelectContent>
                              {districts?.map((val) => {
                                return (
                                  <SelectItem
                                    key={val.id}
                                    value={`${val.id ? val.id : null}`}
                                    disabled={districts?.[0].id === 0}
                                  >
                                    {val.name}
                                  </SelectItem>
                                );
                              })}
                            </SelectContent>
                          </Select>
                          {error && (
                            <p className="text-red-500 text-sm mt-1">
                              {t(`common.message.${error.message}`)}
                            </p>
                          )}
                        </div>
                      );
                    }}
                  />
                </div>
                <div>
                  <label className="text-sm md:text-base" htmlFor="">
                    {t("phone_device.ward")}
                  </label>
                  <span className="text-red-500">*</span>
                  <Controller
                    name="communeId"
                    control={control}
                    render={({
                      field: { onChange, value },
                      fieldState: { error },
                    }) => {
                      return (
                        <div className="flex flex-col">
                          <Select
                            onValueChange={(value) => {
                              onChange(value);
                            }}
                            value={value}
                          >
                            <SelectTrigger
                              className={clsx(
                                "flex-1 py-[12px] px-[16px] h-[48px] rounded-xl mt-2 data-[placeholder]:text-neutral-mid-01",
                                {
                                  "border-solid border border-error": !!error,
                                }
                              )}
                            >
                              <SelectValue
                                placeholder={t("phone_device.ward")}
                              />
                            </SelectTrigger>
                            <SelectContent>
                              {wards?.map((val) => {
                                return (
                                  <SelectItem
                                    key={val.id}
                                    value={`${val.id}`}
                                    disabled={wards?.[0].id === 0}
                                  >
                                    {val.name}
                                  </SelectItem>
                                );
                              })}
                            </SelectContent>
                          </Select>
                          {error && (
                            <p className="text-red-500 text-sm mt-1">
                              {t(`common.message.${error.message}`)}
                            </p>
                          )}
                        </div>
                      );
                    }}
                  />
                </div>

                <div>
                  <label className="text-sm md:text-base" htmlFor="">
                    {t("common.address")}
                  </label>
                  <InputField
                    name="addressDetail"
                    placeholder={t("phone_device.detai_address")}
                    className="mt-2"
                    control={control}
                    maxLength={200}
                    required={false}
                  />
                </div>
              </div>
              <div className="text-base md:text-[20px] font-bold mt-8 max-md:mt-6">
                {t("common.upload_id_image")}
                <span className="text-red-500">*</span>
              </div>
              <>
                <div className="my-4 text-neutral-dark-04 text-xs md:text-[14px]">
                  {t("internet.file_upload")}
                </div>
                <div className="mt-4 flex gap-6 max-md:gap-4">
                  <div className="flex flex-col">
                    <UploadFileSingle
                      label={t("common.upload")}
                      name="faceImage"
                      control={control}
                      labelBottom={t("mobile_package.sim_normal.face_photo")}
                      className="max-md:h-[72px] max-md:w-[72px]"
                    />
                  </div>
                  <div className="flex flex-col">
                    <UploadFileSingle
                      label={t("common.upload")}
                      name="backIdcard"
                      control={control}
                      className="max-md:h-[72px] max-md:w-[72px]"
                      labelBottom={t("internet.back_photo")}
                    />
                  </div>
                  <div className="flex flex-col">
                    <UploadFileSingle
                      label={t("common.upload")}
                      name="frontIdCard"
                      control={control}
                      className="max-md:h-[72px] max-md:w-[72px]"
                      labelBottom={t("internet.front_photo")}
                    />
                  </div>
                </div>
              </>
              <div className="flex items-center flex-row max-md:flex-col max-md:items-start gap-4 mt-8 mb-4 max-md:mt-6 max-md:mb-4">
                <div className="text-[20px] max-md:text-[16px] font-bold">
                  {t("mobile_package.swap_sim.payment_method")}
                </div>
                <RadioGroup defaultValue={"1"} value={"1"}>
                  <div className="grid grid-cols-3 gap-x-4 max-md:grid-cols-1 max-md:gap-y-2">
                    <label
                      htmlFor="paymentMethod"
                      className={`w-full flex items-center cursor-pointer justify-between`}
                    >
                      <div className="flex items-center space-x-2 cursor-pointer gap-x-2 max-lg:text-[14px]">
                        <RadioGroupItem
                          value="1"
                          id="paymentMethod"
                          className={`border-primary border-[2px]`}
                        />
                        {t("payment.natcash")}
                      </div>
                    </label>
                  </div>
                </RadioGroup>
              </div>
              <div className="">
                <InputPhoneNumberField
                  maxLength={50}
                  name="mobileNumber"
                  label={t("phone_device.phone_wallet")}
                  classNameLabel="!font-normal text-sm lg:text-base !text-neutral-dark-01"
                  placeholder={`${t("login.phone_number")}*`}
                  type="text"
                  control={control}
                  errors={errors}
                  required
                />
              </div>
              <div className="mt-4 text-sm lg:text-base font-bold text-neutral-dark-04">
                {t("common.note")}:
              </div>
              <div className="list-item list-disc ml-5 text-xs lg:text-sm text-neutral-dark-04">
                {t("phone_device.note_register_ffiliate")}
              </div>
              <div className="my-6 lg:my-8 flex gap-x-2 items-start">
                <CheckboxField
                  control={control}
                  errors={errors}
                  required
                  name="checkCondition"
                >
                  <div className="text-sm text-[#A2A2A2]">
                    {t("payment.i_agree_to_the")}
                    <span
                      className="font-semibold text-primary underline ml-1 cursor-pointer"
                      onClick={() => {
                        router.push(`/customer-care/support?name=terms`);
                      }}
                    >
                      {t("payment.terms_of_purchase")}
                    </span>
                  </div>
                </CheckboxField>
              </div>
              <div className="flex flex-col items-center gap-2 lg:gap-4">
                <Button
                  className="min-w-[197px] max-md:w-full font-bold rounded-3xl max-md:rounded-2xl py-[12px]"
                  disabled={!isValid}
                  type="submit"
                >
                  {t("common.register")}
                </Button>
              </div>
            </div>
          );
        }}
      </Form>
      {isVisible && (
        <OtpModal
          isModal={isVisible}
          onSubmit={(otp) => {
            sendOTPRegister(otp);
          }}
          time={20}
          phoneNumber={`(+509) ${user?.isdn}`}
          error={error}
          onClose={() => {
            setIsVisible(false);
          }}
          isGetOTP={isGetOtp}
          timeExpired={299}
          setError={(val) => {
            setError(val);
          }}
          onResend={() => {
            setIsGetOtp(false);
            sendOTPRegister("");
          }}
        />
      )}
      <RegisterSuccessModal
        time=""
        // time="21:22:05 Monday 03/22/2025"
        onSubmit={handleSuccess}
      />
    </div>
  );
};

export default RegisterAffiliateForm;
