"use client";
import React, { useEffect, useRef, useState } from "react";
import SubCategoriesMobile from "@/components/sub-categories-mobile";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { VasCategoryType } from "@/schemaValidations/mobile-package.schema";
import { useRouter } from "next/navigation";

const SubTabVas = ({
  searchParams,
  categoriesRes,
  name,
}: {
  searchParams?: { [key: string]: string | undefined };
  categoriesRes?: VasCategoryType[];
  name: string;
}) => {
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const [showPrev, setShowPrev] = useState<boolean>(false);
  const [showNext, setShowNext] = useState<boolean>(false);
  const router = useRouter();

  const handleScroll = () => {
    if (!scrollContainerRef.current) return;
    const { scrollLeft, scrollWidth, clientWidth } = scrollContainerRef.current;
    setShowPrev(scrollLeft > 0);
    setShowNext(scrollLeft + clientWidth < scrollWidth);
  };

  const scroll = (direction: "left" | "right") => {
    if (!scrollContainerRef.current) return;
    const { clientWidth } = scrollContainerRef.current;
    const scrollAmount = clientWidth * 0.8;

    if (direction === "left") {
      scrollContainerRef.current.scrollBy({
        left: -scrollAmount,
        behavior: "smooth",
      });
    } else {
      scrollContainerRef.current.scrollBy({
        left: scrollAmount,
        behavior: "smooth",
      });
    }
  };

  useEffect(() => {
    const container = scrollContainerRef.current;
    if (container) {
      container.addEventListener("scroll", handleScroll);
      handleScroll();
    }
    return () => container?.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <div className="relative w-full">
      {showPrev && (
        <button
          className="hidden absolute top-[43%] -left-16 max-xl:-left-12 max-lg:-left-10 transform -translate-y-1/2 z-0 xl:size-14 size-9 md:flex items-center justify-center bg-[#E3E4E5] rounded-full"
          onClick={() => scroll("left")}
          aria-label="Previous Slide"
        >
          <ChevronLeft />
        </button>
      )}
      {showNext && (
        <button
          className="hidden absolute top-[43%] -right-16 max-xl:-right-12 max-lg:-right-10 transform -translate-y-1/2 z-0 xl:size-14 size-9 md:flex items-center justify-center bg-[#E3E4E5] rounded-full"
          onClick={() => scroll("right")}
          aria-label="Next Slide"
        >
          <ChevronRight />
        </button>
      )}
      <div
        ref={scrollContainerRef}
        className="flex items-center gap-x-4 mt-6 max-md:gap-x-2 max-md:mt-2 w-full overflow-x-scroll no-scrollbar relative"
      >
        {categoriesRes?.[0].children.map((val, i) => {
          const isSelected = searchParams?.vasSlug
            ? searchParams?.vasSlug === val.slug
            : i === 0;
          return (
            <div
              key={val.id}
              onClick={() => {
                router.push(`${name}?vasSlug=${val.slug}`, { scroll: false });
              }}
            >
              <SubCategoriesMobile isActive={isSelected} name={val.name} />
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default SubTabVas;
