"use client";
import React, { useEffect, useState } from "react";
import TabCommon from "@/components/tabs-common";
import ButtonSeeMore from "@/components/btn-see-more";
import MobileServicesPackage from "@/module/mobile-services/component/mobile-service-package";
import { IDataServiceCategories } from "@/schemaValidations/service-categories";
import SubTabMobileHome from "@/module/mobile-services/component/sub-tab-mobile-home";
import TitleStyle from "@/components/title-common";
import TableSimService from "@/app/mobile-package/table-sim-service";
import TextWithTooltip from "@/components/text-width-tooltip";

type IProp = {
  serviceCategoriesList?: IDataServiceCategories;
};

const MobileServices = ({ serviceCategoriesList }: IProp) => {
  const [activeTab, setActiveTab] = useState(0);
  const [tabActiveChildren, setTabActiveChildren] = useState<number>(0);
  const [getId, setGetId] = useState<{
    id: number;
    type: number;
  }>({
    id: 0,
    type: 0,
  });
  const handleTabChange = (index: number) => {
    setActiveTab(index);
    setTabActiveChildren(0);
  };

  const handleChildTabChange = (id: number, type: number) => {
    setGetId({
      id: id,
      type: type,
    });
  };

  useEffect(() => {
    if (serviceCategoriesList?.children?.[activeTab]?.children?.[0]?.id) {
      setGetId({
        id: Number(serviceCategoriesList.children?.[activeTab]?.children[0].id),
        type: Number(
          serviceCategoriesList.children?.[activeTab]?.children[0].type
        ),
      });
    } else if (
      serviceCategoriesList?.children?.[activeTab]?.children?.length === 0
    ) {
      setGetId({
        id: Number(serviceCategoriesList?.children?.[activeTab]?.id),
        type: Number(serviceCategoriesList?.children?.[activeTab]?.type),
      });
    } else {
      setGetId({
        id: 0,
        type: 0,
      });
    }
  }, [serviceCategoriesList, activeTab]);

  return (
    <div>
      <div className="mt-10 max-lg:mt-8  flex justify-between items-center relative">
        <div className="flex xl:gap-24 md:gap-10 items-center">
          <TitleStyle>{serviceCategoriesList?.name ?? ""}</TitleStyle>
        </div>
        {!!serviceCategoriesList?.children?.length ? (
          <ButtonSeeMore href={"/mobile-package"} />
        ) : null}
      </div>
      <div className="flex justify-start w-full mt-4">
        <TabCommon
          tabs={
            serviceCategoriesList?.children?.map((item) => ({
              label: <TextWithTooltip content={item.name} key={item.id} />,
            })) || []
          }
          onChangeTab={handleTabChange}
        />
      </div>
      {serviceCategoriesList?.children?.[activeTab]?.children?.length ? (
        <SubTabMobileHome
          dataServiceDetail={serviceCategoriesList.children[
            activeTab
          ].children.map((item) => ({
            label: item.name,
            id: item.id,
            type: item.type,
          }))}
          setTabActiveChildren={setTabActiveChildren}
          tabActiveChildren={tabActiveChildren}
          onChangeTab={handleChildTabChange}
        />
      ) : (
        ""
      )}
      {serviceCategoriesList?.children?.[activeTab]?.slug === "sim-card" ? (
        <TableSimService isHome />
      ) : (
        getId !== null && (
          <div>
            <MobileServicesPackage getId={getId.id} type={getId.type} />
          </div>
        )
      )}
    </div>
  );
};

export default MobileServices;
