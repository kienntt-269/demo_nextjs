"use client";
import ChatIcon from "@/components/icons/chat-icon";
import { ChatPoolContainer } from "@/module/chat-online/chat-pool";
import React, { useCallback, useEffect, useRef, useState } from "react";
import { useChatOnline } from "@/_stores/useChatOnline";
import ChatInput from "@/module/chat-online/chat-input";
import ChatHeader from "@/module/chat-online/chat-header";
import StartScreen from "@/module/chat-online/start-screen";
import { chatApiRequest } from "@/services/chat-service";
import useWebSocketChat from "@/hooks/use-web-socket-chat";
import { MessageDataType } from "@/types/common";
import { formatTimeChatUTC, formatUnRead, handleUploadFile } from "@/lib/utils";
import { PHONE_SUPPORTING_KEY } from "@/constants/storage";
import { v4 as uuidv4 } from "uuid";
import { useTranslations } from "next-intl";
import clsx from "clsx";
import useGetPhoneSupporting from "@/hooks/use-get-phone-supporting";
import ChatMobileIcon from "@/components/icons/chat-mobile-icon";
import { useIsMobile } from "@/hooks/use-mobile";
import { debounce } from "lodash";
import { DialogRatingCOnversation } from "@/module/dialog-auth/dialog-rating-conversation";
import { toast } from "react-toastify";

const ChatOnline = () => {
  const isScrollToBottom = useRef(true);
  const isMobile = useIsMobile();
  const t = useTranslations();
  const isSendStart = useRef(false);
  const timeoutId = useRef<NodeJS.Timeout | null>(null);
  const timeoutId2 = useRef<NodeJS.Timeout | null>(null);
  const { isOpen, roomIsExist, mode, roomData, setStateChatOnline } =
    useChatOnline();

  const { phoneSupporting } = useGetPhoneSupporting();
  const [isOpenRating, setIsOpenRating] = useState(false);
  const [listMessageNotRead, setListMessageNotRead] = useState<string[]>([]);
  const [messageHistory, setMessageHistory] = useState<MessageDataType[]>([]);
  const [lastMessageHistory, setLastMessageHistory] =
    useState<MessageDataType | null>(null);
  const [isSendStartMessage, setIsSendMessageStart] = useState(false);
  const { sendMessage, sendMessageFromAdmin, lastMessage, isConnected } =
    useWebSocketChat(roomData?.roomId);
  const [firstMessage, setFirstMessage] = useState<
    undefined | MessageDataType
  >();

  const scrollToBottom = () => {
    if (!isScrollToBottom.current) return;
    const scroll = document.getElementById("sroll-bottom-chat-pool");
    if (scroll)
      scroll.scrollIntoView({
        behavior: "smooth",
      });
  };

  const handleSubmitRate = (rate: number) => {
    if (rate) {
      chatApiRequest
        .ratingConversation(rate, roomData?.roomId ?? "")
        .then(() => {
          toast.success(t("chat_online.thanks_feedback"));
        });
    }
  };

  const handleSendMessageAutoFromAdmin = useCallback(
    debounce(({ message, isAuto }: { message: string; isAuto: boolean }) => {
      if (!roomData?.roomId) return;

      const dataStart: MessageDataType = {
        roomId: roomData?.roomId,
        isSupporter: 1,
        message: message,
        isAuto: !!isAuto ? 1 : 0,
      };
      sendMessageFromAdmin(dataStart);
    }, 300), // Debounce 300ms để tránh spam tin nhắn
    [roomData, sendMessageFromAdmin]
  );

  const handleSendMessageImage = useCallback(
    debounce(
      async ({
        files,
        type,
        message,
      }: {
        files?: File[];
        message?: string;
        type?: "1" | "2" | "3";
      }) => {
        if (!roomData?.roomId || !files?.length) return;
        isScrollToBottom.current = true;

        const dataStart: MessageDataType = {
          senderId: phoneSupporting,
          roomId: roomData.roomId,
          imagePath: files.map((item) => URL.createObjectURL(item)).join(","),
          type,
          message,
        };

        setMessageHistory((prev) => [
          { id: uuidv4(), createdTime: formatTimeChatUTC(), ...dataStart },
          ...prev,
        ]);

        const uploadPromises = files.map((file) => handleUploadFile(file));
        const imagesUrl = await Promise.all(uploadPromises);

        dataStart.imagePath = imagesUrl.join(",");
        if (!dataStart.imagePath && !dataStart.message) return;
        sendMessage(dataStart);
      },
      300 // debounce delay in ms
    ),
    [roomData, phoneSupporting, sendMessage]
  );

  const handleSendMessage = useCallback(
    debounce(
      ({
        message,
        imagePath,
        type,
      }: {
        message?: string;
        imagePath?: string;
        type?: "1" | "2" | "3";
      }) => {
        if (!roomData?.roomId) return;
        isScrollToBottom.current = true;

        const dataStart: MessageDataType = {
          senderId: phoneSupporting,
          roomId: roomData?.roomId,
          message,
          imagePath,
          type,
        };

        sendMessage(dataStart);
        setMessageHistory((prev) => [
          { id: uuidv4(), createdTime: formatTimeChatUTC(), ...dataStart },
          ...prev,
        ]);

        if (type === "3") {
          setTimeout(() => {
            handleSendMessageAutoFromAdmin({
              message: t("chat_online.message_auto_admin_thanks"),
              isAuto: true,
            });
            setIsOpenRating(true);
          }, 500);
        }

        if (type === "1") {
          setTimeout(() => {
            handleSendMessageAutoFromAdmin({
              message: t("chat_online.message_auto_admin"),
              isAuto: true,
            });
          }, 500);
        } else {
        }
      },
      300, // Thời gian debounce (300ms)
      { leading: true, trailing: false }
    ),
    [roomData, phoneSupporting, t, sendMessage]
  );

  const handleLoadMore = useCallback(() => {
    if (!lastMessageHistory || !roomData?.roomId) return;
    chatApiRequest
      .getHistory(roomData?.roomId ?? "", lastMessageHistory?.id)
      .then((response) => {
        isScrollToBottom.current = false;
        const listItems = response?.payload?.data?.messages;
        if (!listItems.length) {
          setLastMessageHistory(null);
        } else {
          setLastMessageHistory(listItems[listItems.length - 1]);
          setMessageHistory((prev) => [...prev, ...listItems]);
        }
      });
  }, [lastMessageHistory, roomData]);

  useEffect(() => {
    if (!messageHistory.length) return;
    const firstMessage = messageHistory.find((item) => !item.isSupporter);
    setFirstMessage(firstMessage);
  }, [messageHistory.length]);

  useEffect(() => {
    if (timeoutId.current) clearTimeout(timeoutId.current);
    const lastMessage = messageHistory[0];
    if (
      !isConnected ||
      !lastMessage ||
      lastMessage?.isSupporter ||
      (lastMessage?.message?.length || 0) < 20
    ) {
      return;
    }
    console.log("%c Sending auto message after 5 minutes", "color: green");
    timeoutId.current = setTimeout(
      () => {
        handleSendMessageAutoFromAdmin({
          message: t("chat_online.message_auto_admin5p"),
          isAuto: true,
        });
      },
      5 * 60 * 1000
    );
  }, [messageHistory.length, t, isConnected, handleSendMessageAutoFromAdmin]);

  useEffect(() => {
    if (timeoutId2.current) clearTimeout(timeoutId2.current);
    const lastMessage = messageHistory[0];
    if (
      !isConnected ||
      !lastMessage ||
      !lastMessage?.isSupporter ||
      !!lastMessage.isAuto
    ) {
      return;
    }
    console.log("%c Sending auto message after 30 minutes", "color: green");
    timeoutId2.current = setTimeout(
      () => {
        handleSendMessageAutoFromAdmin({
          message: t("chat_online.message_auto_admin30p"),
          isAuto: true,
        });
      },
      30 * 60 * 1000
    );
  }, [messageHistory.length, t, isConnected, handleSendMessageAutoFromAdmin]);

  useEffect(() => {
    if (isOpen) {
      if (listMessageNotRead.length) {
        chatApiRequest.readMessages(listMessageNotRead);
        setListMessageNotRead([]);
      }
    }
  }, [isOpen, listMessageNotRead]);

  useEffect(() => {
    scrollToBottom();
    const listNotSeen = messageHistory
      .filter((item) => !!item.isSupporter && !item.isRead)
      .map((item) => item.id ?? "");
    if (!isOpen) {
      setListMessageNotRead(listNotSeen);
    } else {
      if (listNotSeen.length) {
        chatApiRequest.readMessages(listNotSeen ?? []).then(() => {
          setMessageHistory((prevMessages) =>
            prevMessages.map((msg) => ({ ...msg, isRead: 1 }))
          );
        });
      }
    }
  }, [messageHistory, isOpen]);

  useEffect(() => {
    if (!phoneSupporting) {
      setStateChatOnline({
        phoneSupporting: "",
        roomData: null,
        mode: "FORM",
        roomIsExist: false,
      });
      return;
    }
    chatApiRequest.checkRoomExist(phoneSupporting).then((checkRoomRes) => {
      const isExistRoom = !!checkRoomRes?.payload?.data?.roomId;
      if (!isExistRoom) localStorage.removeItem(PHONE_SUPPORTING_KEY);
      setStateChatOnline({
        phoneSupporting: isExistRoom ? phoneSupporting : "",
        roomData: checkRoomRes?.payload?.data || null,
        mode: isExistRoom ? "CHAT" : "FORM",
        roomIsExist: isExistRoom,
      });
    });
  }, [phoneSupporting, setStateChatOnline]);

  useEffect(() => {
    setIsSendMessageStart(false);
    isSendStart.current = false;
    if (!roomData?.roomId) {
      setMessageHistory([]);
      return;
    }
    chatApiRequest.getHistory(roomData?.roomId).then((response) => {
      const listItems = response?.payload?.data?.messages ?? [];
      setMessageHistory(listItems);
      setIsSendMessageStart(!response?.payload?.data?.messages?.length);
      setLastMessageHistory(listItems[listItems.length - 1]);
    });
  }, [roomData?.roomId]);

  useEffect(() => {
    if (lastMessage !== null) {
      setMessageHistory((prev) => [lastMessage, ...prev]);
    }
  }, [lastMessage]);

  useEffect(() => {
    if (!isConnected || !isSendStartMessage || isSendStart.current) return;
    handleSendMessage({ type: "1", message: t("chat_online.start") });
    isSendStart.current = true;
  }, [
    isConnected,
    isSendStartMessage,
    handleSendMessage,
    handleSendMessageAutoFromAdmin,
    t,
  ]);

  return (
    <div className="fixed z-50 flex items-center justify-center bottom-[16px] md:bottom-[110px] left-[calc(100vw-88px-8px-24px)] md:left-[calc(100vw-88px-8px-44px)] w-14 md:w-[88px] h-14 md:h-[88px] bg-gradient-chat rounded-full shadow-badge-online">
      <span
        onClick={() =>
          setStateChatOnline({
            isOpen: !isOpen,
            mode: roomIsExist ? "CHAT" : "FORM",
          })
        }
        className="cursor-pointer"
      >
        {isMobile ? <ChatMobileIcon /> : <ChatIcon />}
      </span>
      {!!listMessageNotRead.length && (
        <div className="absolute top-[-6px] right-[-6px] md:top-0 md:right-0 w-6 h-6 flex items-center justify-center bg-viettel-red border border-background-content rounded-full font-semibold text-[15px] text-white">
          {formatUnRead(listMessageNotRead.length)}
        </div>
      )}
      {isOpen && (
        <div
          className={clsx(
            `fixed top-0 left-0 w-full h-full md:left-auto md:top-auto md:absolute md:w-[411px] flex flex-col rounded-none md:rounded-3xl shadow-chat-online right-0 md:bottom-[104px] bg-white ${roomIsExist ? "md:h-[481px]" : "md:h-auto"}`
          )}
        >
          {mode === "FORM" ? (
            <>
              <ChatHeader />
              <StartScreen />
            </>
          ) : (
            <>
              <ChatHeader isProcessing />
              <ChatPoolContainer
                messages={messageHistory}
                hasMore={!!lastMessageHistory}
                onLoadMore={handleLoadMore}
              />
              <ChatInput
                handleSubmit={handleSendMessage}
                handleSendImage={handleSendMessageImage}
                isShowSuggestion={firstMessage?.type === "1"}
              />
            </>
          )}
        </div>
      )}
      <DialogRatingCOnversation
        isOpen={isOpenRating}
        onClose={() => setIsOpenRating(false)}
        onSubmit={handleSubmitRate}
      />
    </div>
  );
};

export default ChatOnline;
