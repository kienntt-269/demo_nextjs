"use client";

import { ModalViewImage } from "@/components/modal-view-image";
import { setURL } from "@/lib/utils";
import Image from "next/image";
import { useState } from "react";

type Props = {
  avatar: string;
  text?: string;
  image?: string;
  time: string;
  isOwnMessage: boolean;
  isHeaderMessage?: boolean;
  isFinalMessage?: boolean;
  images: string[];
  // createdTime?: string;
};

const MessageImageText = ({
  images,
  text,
  avatar,
  time,
  // createdTime,
  isOwnMessage,
}: Props) => {
  const [isOpen, setIsOpen] = useState(0);
  const handleImageClick = (index: number) => {
    setIsOpen(index);
  };

  const visibleImages = images.slice(0, 4);
  const remainingCount = images.length - 4;

  const gridLayout =
    images.length === 1
      ? "grid-cols-1 grid-rows-1"
      : images.length === 2
        ? "grid-cols-2 grid-rows-1"
        : images.length === 3
          ? "grid-cols-2 grid-rows-2"
          : "grid-cols-2 grid-rows-2";

  return (
    <div
      className={`flex ${isOwnMessage ? "justify-end" : "justify-start"} my-2 items-start`}
    >
      {!isOwnMessage && (
        <div className="relative w-10 h-10 mr-2">
          <Image
            src={avatar}
            alt="Avatar"
            fill
            className="rounded-full object-cover"
          />
        </div>
      )}
      <div className="flex flex-col gap-1">
        <div
          className={`bg-gradient-content-chat p-1 rounded-xl w-[204px] h-[204px] ${
            !isOwnMessage
              ? "bg-[#f5f5f5] text-black "
              : "bg-gradient-content-chat text-white self-end"
          }`}
        >
          <div className={`grid gap-1 ${gridLayout} h-full`}>
            {visibleImages.map((img, index) => (
              <div
                key={index}
                className={`relative cursor-pointer rounded-[10px] overflow-hidden w-full h-full ${images.length === 3 && index === 0 ? "col-span-2 row-span-1" : ""}`}
                onClick={() => handleImageClick(index + 1)}
              >
                <Image
                  src={img}
                  alt={`Image ${index}`}
                  width={196}
                  height={196}
                  className="w-full h-full object-cover"
                />
                {index === 3 && remainingCount > 0 && (
                  <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center text-white font-bold text-lg">
                    +{remainingCount}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
        <div
          className={`py-2 px-3 rounded-xl max-w-[270px] w-fit ${
            !isOwnMessage
              ? "bg-[#f5f5f5] text-black rounded-es-none"
              : "bg-gradient-content-chat text-white rounded-ee-none self-end"
          }`}
        >
          {text && (
            <div>
              <span
                style={{ wordBreak: "break-word" }}
                className="text-sm inline-block whitespace-pre-wrap tracking-[-0.3px] break-words"
                dangerouslySetInnerHTML={{ __html: setURL(text || "") }}
              />
            </div>
          )}
        </div>
        <div
          className={`text-xs text-neutral mt-1 ${isOwnMessage ? "text-right" : "text-left"}`}
        >
          {time}
        </div>
      </div>
      {!!isOpen && (
        <ModalViewImage
          // date={createdTime}
          isOpen={!!isOpen}
          indexDefault={isOpen}
          onClose={() => setIsOpen(0)}
          images={images}
        />
      )}
    </div>
  );
};

export default MessageImageText;
