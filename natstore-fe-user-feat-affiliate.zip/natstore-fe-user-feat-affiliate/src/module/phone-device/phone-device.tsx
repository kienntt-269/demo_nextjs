import ButtonSeeMore from "@/components/btn-see-more";
import TitleStyle from "@/components/title-common";
import { getTranslations } from "next-intl/server";
import React from "react";
const PhoneService = async () => {
  const t = await getTranslations();
  return (
    <div>
      <div className="md:mt-10 mt-8 flex justify-between items-center">
        <div className=" flex xl:gap-24 md:gap-10 items-center">
          <TitleStyle>{t("phone_device.phone_device")}</TitleStyle>
        </div>
        <ButtonSeeMore href={""} />
      </div>
    </div>
  );
};

export default PhoneService;
