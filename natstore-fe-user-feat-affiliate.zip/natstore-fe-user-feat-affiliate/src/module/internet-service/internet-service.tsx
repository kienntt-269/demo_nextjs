"use server";
import InternetClient from "@/module/internet-service/internet-client";
import internetApiRequest from "@/services/internet";

const InternetService = async () => {
  const dataInternet = await internetApiRequest.getDataInternet({
    type: "BUY_INTERNET_PACKAGE",
  });
  const serviceCategoriesList =
    await internetApiRequest.getDataInternetCategory();
  return (
    <InternetClient
      dataInternet={dataInternet.payload.data}
      serviceCategoriesList={serviceCategoriesList.payload.data}
    />
  );
};

export default InternetService;
