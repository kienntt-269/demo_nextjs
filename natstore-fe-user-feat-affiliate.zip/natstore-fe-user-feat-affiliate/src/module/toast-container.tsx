"use client";
import ToastCloseIcon from "@/components/icons/toast-close-icon";
import { CloseButtonProps, ToastContainer } from "react-toastify";

export default function ToastContainerCustom() {
  const CloseButton = ({ closeToast }: CloseButtonProps) => (
    <div onClick={closeToast} className="absolute top-4 right-4 cursor-pointer">
      <ToastCloseIcon />
    </div>
  );
  return (
    <ToastContainer
      autoClose={5000}
      hideProgressBar
      closeButton={CloseButton}
    />
  );
}
