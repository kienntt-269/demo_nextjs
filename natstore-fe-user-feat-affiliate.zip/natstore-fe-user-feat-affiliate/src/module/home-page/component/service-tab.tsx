"use client";
import { useLangStore } from "@/_stores/useLang.store";
import CarouselData from "@/components/common/carousel-data/carousel-data";
import TextWithTooltip from "@/components/text-width-tooltip";
// import { Skeleton } from "@/components/ui/skeleton";
import { getImageUrl } from "@/constants/imageUrl";
import { useIsMobile } from "@/hooks/use-mobile";
import {
  IServiceTab,
  IServiceTabRes,
} from "@/schemaValidations/service-tab.schema";
import serviceTabApiRequest from "@/services/service-tab";
import Image from "next/image";
import Link from "next/link";
import { useEffect, useState } from "react";
import ContentLoader from "react-content-loader";

export default function ServiceTabs({
  classProps,
  isCatalog,
}: {
  classProps?: string;
  isCatalog?: boolean;
}) {
  const [serviceTab, setServiceTab] = useState<IServiceTabRes>();
  const [loading, setLoading] = useState(true);
  const isMobile = useIsMobile();
  const { lang } = useLangStore();
  const getData = async () => {
    try {
      setLoading(true);
      const res = await serviceTabApiRequest.getDataServiceTab();
      setServiceTab(res.payload);
      setTimeout(() => {
        setLoading(false);
      }, 300);
    } catch (error) {
      console.log(error);
      throw Error("error");
    }
  };
  useEffect(() => {
    getData();
  }, [lang]);
  if (loading) {
    return (
      <>
        <div className={`${classProps} w-full gap-4 mt-8`}>
          {Array(isMobile ? 3 : 6)
            .fill(null)
            .map((_, index) => (
              <ContentLoader
                key={index}
                speed={1.5}
                viewBox="0 0 160 120"
                backgroundColor="#d6d6d6"
                foregroundColor="#fcc583"
                className="py-4 w-full md:h-[126px] h-20"
                style={{
                  borderRadius: "12px",
                  boxShadow: "0px 3.09px 12.37px 0px #00000014",
                }}
              >
                <circle cx="80" cy="40" r="30" />
                <rect x="30" y="80" rx="6" ry="6" width="100" height="20" />
              </ContentLoader>
            ))}
        </div>
      </>
    );
  }

  return (
    <div className={` w-full md:gap-4 gap-2 mt-4 xl:mt-8`}>
      {(Number(serviceTab?.data.length) > 6 || isMobile) && !isCatalog ? (
        <CarouselData
          quantityMobile={3.5}
          quantity={6}
          length={serviceTab?.data.length}
        >
          {serviceTab?.data.map((item: IServiceTab) => {
            return (
              <Link href={item?.slug || "#"} key={item.slug}>
                <div
                  className="flex flex-col justify-center group h-full items-center gap-2 md:gap-4 pt-4 pb-4 md:pb-[22px] w-full bg-white rounded-2xl shadow-[0px_3.09px_12.37px_0px_#00000014] hover:shadow-[0px_5px_15px_rgba(0,0,0,0.2)] transition-all duration-300 ease-in-out hover:scale-[1.025]"
                  key={item.name}
                  // style={{ boxShadow: "0px 3.09px 12.37px 0px #00000014" }}
                >
                  <Image
                    src={getImageUrl(item.icon) || "/"}
                    alt="img content"
                    width={isMobile ? 24 : 48}
                    height={isMobile ? 24 : 48}
                    className="md:h-12 md:w-12 w-6 h-6 object-contain"
                  />
                  <div className="font-bold text-neutral-dark-02 text-xs md:text-lg text-center xl:text-xl line-clamp-1">
                    <TextWithTooltip content={item.name}></TextWithTooltip>
                  </div>
                </div>
              </Link>
            );
          })}
        </CarouselData>
      ) : (
        <div className={`${classProps} w-full md:gap-4 gap-2 mt-4 xl:mt-8`}>
          {serviceTab?.data.map((item: IServiceTab) => {
            return (
              <Link href={item?.slug || "#"} key={item.slug}>
                <div
                  className="flex flex-col justify-center group h-full items-center gap-2 md:gap-4 pt-4 pb-4 md:pb-[22px] w-full bg-white rounded-2xl shadow-[0px_3.09px_12.37px_0px_#00000014] hover:shadow-[0px_5px_15px_rgba(0,0,0,0.2)] transition-all duration-300 ease-in-out hover:scale-[1.025]"
                  key={item.name}
                  // style={{ boxShadow: "0px 3.09px 12.37px 0px #00000014" }}
                >
                  <Image
                    src={getImageUrl(item.icon) || "/"}
                    alt="img content"
                    width={isMobile ? 24 : 48}
                    height={isMobile ? 24 : 48}
                    className="md:h-12 md:w-12 w-6 h-6 object-contain"
                  />
                  <div className="font-bold text-neutral-dark-02 text-xs sm:text-base lg:text-xl text-center line-clamp-1">
                    <TextWithTooltip content={item.name}></TextWithTooltip>
                  </div>
                </div>
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}
