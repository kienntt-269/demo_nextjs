"use client";
import React from "react";

import Image from "next/image";
import { Card, CardContent } from "@/components/ui/card";

const NewsCardChildren = () => {
  return (
    <div className="">
      <Card className="shadow-md border border-gray-200 rounded-3xl bg-white h-full ">
        <div className="flex h-full">
          <Image
            src="/app-store.png"
            alt="img content"
            width={237}
            height={143}
            layout="fix"
            className="rounded-3xl xl:w-[237px] w-[200px]"
          />
          <CardContent className="p-6 h-full flex-1">
            <div className="flex flex-col justify-between h-full">
              <div className="xl:text-xl font-bold text-neutral-dark-01 md:text-base">
                Promotion explosion: Natcom offers 25% discount when buying
                packages on the app
              </div>
              <div className="lg:text-base font-semibold text-neutral-mid-01 md:text-sm">
                Monday, December 23, 2024
              </div>
            </div>
          </CardContent>
        </div>
      </Card>
    </div>
  );
};

export default NewsCardChildren;
