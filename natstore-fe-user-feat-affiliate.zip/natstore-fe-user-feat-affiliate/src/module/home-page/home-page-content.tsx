// import CardPhone from "@/components/card-phone";
// import CarouselData from "@/components/common/carousel-data/carousel-data";
// import { Button } from "@/components/ui/button";
// import Image from "next/image";
import MobileServices from "@/module/mobile-services/mobile-service";
// import ServiceTabs from "@/module/home-page/component/service-tab";
import InternetService from "@/module/internet-service/internet-service";
import categoryApiRequest from "@/services/category-list";
import TableSimService from "@/app/mobile-package/table-sim-service";
// import PhoneService from "@/module/phone-device/phone-device";
// import { getTranslations } from "next-intl/server";

const getDataCategories = async () => {
  try {
    const res = await categoryApiRequest.getDataCategories();
    return res.payload || [];
  } catch (error) {
    console.log(error);
    throw Error("error");
  }
};

const HomePageContent = async () => {
  const data = await getDataCategories();
  // const t = await getTranslations();
  return (
    <div>
      <div className="">
        {/* <ServiceTabs classProps="grid md:grid-cols-6"></ServiceTabs> */}

        <MobileServices serviceCategoriesList={data?.data?.[0]} />
        <TableSimService pageSize={5} />
        <InternetService />

        {/* <PhoneService /> */}

        {/* <div className="md:mt-6 mt-4">
          <CarouselData quantity={3} length={5} quantityMobile={1.5}>
            <CardPhone
              type="medium"
              data={{
                title: "ASWÈ NÈT",
                price: "20 HTG",

                description:
                  "You will receive Unlimited internet, unlimited calls & all SMS you can send from 11:00 PM t...",
                textBtn: "Register",
              }}
            />
            <CardPhone
              type="medium"
              data={{
                title: "ASWÈ NÈT",
                price: "20 HTG",
                description:
                  "You will receive Unlimited internet, unlimited calls & all SMS you can send from 11:00 PM t...",
                textBtn: "Register",
              }}
            />
            <CardPhone
              type="medium"
              data={{
                title: "ASWÈ NÈT",
                price: "20 HTG",
                description:
                  "You will receive Unlimited internet, unlimited calls & all SMS you can send from 11:00 PM t...",
                textBtn: "Register",
              }}
            />
            <CardPhone
              type="medium"
              data={{
                title: "ASWÈ NÈT",
                price: "20 HTG",

                description:
                  "You will receive Unlimited internet, unlimited calls & all SMS you can send from 11:00 PM t...",
                textBtn: "Register",
              }}
            />
            <CardPhone
              type="medium"
              data={{
                title: "ASWÈ NÈT",
                price: "20 HTG",
                description:
                  "You will receive Unlimited internet, unlimited calls & all SMS you can send from 11:00 PM t...",
                textBtn: "Register",
              }}
            />
          </CarouselData>
        </div> */}
        {/* <div className="mt-10">
          <div className="font-bold md:text-[32px] text-[20px] md:mb-6 mb-3">
            Natcom++
          </div>
          <div className=" gap-6 flex md:flex-row flex-col-reverse">
            <div className="md:p-8 md:w-1/3 w-full">
              <div className="text-sm text-neutral-dark-04 font-normal pb-6">
                The largest customer service program for customers using Natcom
                telecommunications services with outstanding privileges:
              </div>
              <ul className="list-disc text-sm text-neutral-dark-04 font-normal pl-4">
                <li className="pb-6">
                  Accumulate points on every customer interaction.
                </li>
                <li className="pb-6">
                  Resonate points on all services that customers are using to
                  upgrade membership as quickly as possible
                </li>
                <li className="pb-6">
                  Great experience with thousands of special offers in the
                  fields of shopping, consumption, travel, hotels, etc.
                </li>
              </ul>
              <div className="flex md:justify-start justify-center ">
                <Button className="w-[50%]">
                  {t("phone_device.join_now")}
                </Button>
              </div>
            </div>
            <div className="md:w-1/3 w-full">
              <Image
                src="/unavailable.svg"
                alt="illustration roaming"
                width={504}
                height={440}
                className="w-full md:h-[440px] h-[257px]"
              ></Image>
            </div>
            <div className="md:w-1/3 w-full">
              <Image
                src="/unavailable.svg"
                alt="illustration roaming"
                width={504}
                height={440}
                className="md:h-[440px] w-full h-[257px]"
              ></Image>
            </div>
          </div>
        </div> */}
      </div>
    </div>
  );
};

export default HomePageContent;
