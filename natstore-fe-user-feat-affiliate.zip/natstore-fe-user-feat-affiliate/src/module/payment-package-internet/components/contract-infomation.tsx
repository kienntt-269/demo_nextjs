import BoxContentCommon from "@/components/common/box-content-common";
import InputCustom from "@/components/custom-ui/input-custom";
import { FieldWrapper } from "@/components/form";
import { Button } from "@/components/ui/button";
import { Typography } from "@/components/ui/typography";
import { storage } from "@/lib/storage";
import { formatMoney } from "@/lib/utils";
import PopupResonse from "@/module/payment-package-internet/components/popup-success";
import { IDataDebtDetail } from "@/schemaValidations/internet.shema";
import { useTranslations } from "next-intl";
import { useRouter, useSearchParams } from "next/navigation";
import React, { useEffect, useMemo, useState } from "react";

const ContractInfomation = () => {
  const t = useTranslations();
  const searchParams = useSearchParams();
  const contractNumber = searchParams.get("contractNumber");
  const dataPaymentPackages = storage.getDataPaymentPackage();
  const router = useRouter();
  const [amount, setAmount] = React.useState<string | undefined>(undefined);
  const [isShowHotCharge, setIsShowHotCharge] = React.useState(false);
  const [dataRes, setDataRes] = useState({
    isOpen: false,
    isSuccess: false,
    customerName: "",
    numberContact: "",
    paymentAmount: "",
  });
  const [error, setError] = React.useState<string | undefined>(undefined);
  const [isSubmited, setIsSubmitted] = React.useState(false);

  const data = useMemo(() => {
    return dataPaymentPackages.find((item: IDataDebtDetail) => {
      return item.contractNumber === contractNumber;
    }) as IDataDebtDetail;
  }, [contractNumber]);

  const handlePayment = async () => {
    if (!validateAmount()) {
      return;
    }
    setIsSubmitted(true);
    if (Number(amount) < 1000) {
      setDataRes((prev) => ({
        ...prev,
        isOpen: true,
        isSuccess: true,
        customerName: data.customerName || "",
        numberContact: data.contractNumber || "",
        paymentAmount: amount || "",
      }));
    } else {
      setDataRes((prev) => ({
        ...prev,
        isOpen: true,
        isSuccess: false,
        customerName: data.customerName || "",
        numberContact: data.contractNumber || "",
        paymentAmount: amount || "",
      }));
    }
  };

  const validateAmount = () => {
    if (!amount) {
      setError(t("payment_amount.required"));
      return false;
    } else if (Number(amount) <= 0) {
      setError(t("payment_amount.min"));
      return false;
    } else if (Number(amount) <= Number(data.priorDebit)) {
      setError(t("payment_package_internet.err_payment_amount"));
      return false;
    } else {
      setError(undefined);
    }
    return true;
  };

  useEffect(() => {
    if (isSubmited) {
      validateAmount();
    }
  }, [isSubmited, amount]);

  if (!data) {
    const updatedParams = new URLSearchParams(searchParams);
    updatedParams.delete("contractNumber");
    router.push(`/internet?${updatedParams.toString()}`, { scroll: false });
    return null;
  }

  return (
    <BoxContentCommon className="max-w-[1032px] mx-auto">
      <Typography variant={"title2"} className="text-black">
        {t("payment_package_internet.contract_information")}
      </Typography>
      <div className="flex flex-col">
        <div className="flex items-center justify-between py-3 md:py-4">
          <Typography variant="bodyEmphasize" className="md:font-bold">
            {t("payment_package_internet.customer_name")}
          </Typography>
          <Typography
            variant="bodyEmphasize"
            className="font-bold text-neutral-dark2"
          >
            {data.customerName}
          </Typography>
        </div>
        <div className="flex items-center justify-between py-3 md:py-4">
          <Typography variant="bodyEmphasize" className="md:font-bold">
            {t("payment_package_internet.number_contract")}
          </Typography>
          <Typography
            variant="bodyEmphasize"
            className="font-bold text-neutral-dark2"
          >
            {data.contractNumber}
          </Typography>
        </div>
        <div className="flex items-center justify-between py-3 md:py-4">
          <Typography variant="bodyEmphasize" className="md:font-bold">
            {t("payment_package_internet.account")}
          </Typography>
          <Typography
            variant="bodyEmphasize"
            className="font-bold text-neutral-dark2"
          >
            {data.account}
          </Typography>
        </div>
        <div className="flex items-center justify-between py-3 md:py-4">
          <Typography variant="bodyEmphasize" className="md:font-bold">
            {t("payment_package_internet.payment_method")}
          </Typography>
          <Typography
            variant="bodyEmphasize"
            className="font-bold text-neutral-dark2"
          >
            {data.paymentMethod}
          </Typography>
        </div>
        <div className="flex items-center justify-between py-3 md:py-4">
          <Typography variant="bodyEmphasize" className="md:font-bold">
            {t("payment_package_internet.prior_debit")}
          </Typography>
          <Typography
            variant="bodyEmphasize"
            className="font-bold text-neutral-dark2"
          >
            {formatMoney(data.priorDebit)}
          </Typography>
        </div>
        <div className="flex items-center justify-between py-3 md:py-4">
          <Typography variant="bodyEmphasize" className="md:font-bold">
            {t("payment_package_internet.arise_debit")}
          </Typography>
          <Typography
            variant="bodyEmphasize"
            className="font-bold text-neutral-dark2"
          >
            {formatMoney(data.ariseDebit)}
          </Typography>
        </div>
        <div className="flex items-center justify-between py-3 md:py-4">
          <Typography variant="bodyEmphasize" className="md:font-bold">
            {t("payment_package_internet.prepaid")}
          </Typography>
          <Typography
            variant="bodyEmphasize"
            className="font-bold text-neutral-dark2"
          >
            {formatMoney(data.prepaid)}
          </Typography>
        </div>
        <div className="flex items-center justify-between py-3 md:py-4">
          <Typography variant="bodyEmphasize" className="md:font-bold">
            {t("payment_package_internet.hot_charge")}
          </Typography>
          {isShowHotCharge ? (
            <Typography
              variant="bodyEmphasize"
              className="font-bold text-neutral-dark2"
            >
              <span
                className="inline-block mr-2 font-bold text-primary cursor-pointer"
                onClick={() => setIsShowHotCharge(false)}
              >
                {t("payment_package_internet.hide")}
              </span>{" "}
              {formatMoney(data.hotCharge)}
            </Typography>
          ) : (
            <Typography
              onClick={() => setIsShowHotCharge(true)}
              variant="bodyEmphasize"
              className="font-bold text-primary cursor-pointer"
            >
              {t("payment_package_internet.sum_hot_charge")}
            </Typography>
          )}
        </div>
        <div className="flex items-center justify-between py-3 md:py-4">
          <Typography variant="bodyEmphasize" className="md:font-bold">
            {t("payment_package_internet.paid_amount")}
          </Typography>
          <Typography
            variant="bodyEmphasize"
            className="font-bold text-neutral-dark2"
          >
            {formatMoney(data.paidAmount)}
          </Typography>
        </div>
        <div className="flex items-center justify-between py-3 md:py-4">
          <Typography variant="bodyEmphasize" className="md:font-bold">
            {t("payment_package_internet.to_pay")}
          </Typography>
          <Typography
            variant="bodyEmphasize"
            className="font-bold text-neutral-dark2"
          >
            {formatMoney(data.toPay)}
          </Typography>
        </div>
        <div className="flex items-center justify-between py-3 md:py-4">
          <Typography variant="bodyEmphasize" className="md:font-bold">
            {t("payment_package_internet.currency")}
          </Typography>
          <Typography
            variant="bodyEmphasize"
            className="font-bold text-neutral-dark2"
          >
            {data.currency}
          </Typography>
        </div>
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between mt-2 md:mt-0 md:py-4 gap-2 md:gap-0">
          <Typography
            variant="bodyEmphasize"
            className="md:font-bold text-black md:text-neutral-dark2 h-12 self-start flex items-center"
          >
            {t("payment_package_internet.payment_amount")}{" "}
            <span className="text-red-500">*</span>
          </Typography>
          <span className="w-full flex-1 md:max-w-[484px]">
            <FieldWrapper
              error={error ? { message: error, type: "custom" } : undefined}
            >
              <InputCustom
                inputProps={{
                  placeholder: t("payment_package_internet.payment_amount"),
                }}
                isError={!!error}
                variant="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
              />
            </FieldWrapper>
          </span>
        </div>
      </div>
      <PopupResonse
        customerName={dataRes.customerName || ""}
        numberContact={dataRes.numberContact || ""}
        paymentAmount={dataRes.paymentAmount || ""}
        isOpen={dataRes.isOpen}
        isSuccess={dataRes.isSuccess}
        onClose={() => {
          setDataRes({ ...dataRes, isOpen: false });
        }}
      />
      <div className="flex flex-col-reverse md:flex-row gap-2 md:gap-4 justify-center">
        <Button
          className="w-full md:w-[276px]"
          variant="secondary"
          onClick={() => {
            router.back();
          }}
        >
          {t("common.back")}
        </Button>
        <Button
          className="w-full md:w-[276px]"
          onClick={handlePayment}
          disabled={amount === undefined || amount === "" || amount === null}
        >
          {t("common.payment")}
        </Button>
      </div>
    </BoxContentCommon>
  );
};

export default ContractInfomation;
