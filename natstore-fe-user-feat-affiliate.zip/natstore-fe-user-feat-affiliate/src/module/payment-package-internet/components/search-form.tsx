"use client";
import React, { Ref, useMemo, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Form, InputField, RefForm } from "@/components/form";
import { useTranslations } from "next-intl";
import { paymentInternetFormValue } from "@/types/common";
import { schemaPaymentInternet } from "@/schemaValidations/payment-internet.schema";
import {
  REGEX_INPUT_ID_CARD,
  REGEX_INPUT_ID_CARD_NUMBER,
} from "@/constants/regex";
import { Typography } from "@/components/ui/typography";
import BoxContentCommon from "@/components/common/box-content-common";
import RadioButtonField from "@/components/form/radio-button-field";
import { SEARCH_TYPE_PAYMENT_PACKAGE } from "@/constants/common";
import { useInternetDebtStore } from "@/_stores/useInternetDebt.store";

type Props = {
  onSearch: (values: paymentInternetFormValue) => void;
};

const SearchForm = ({ onSearch }: Props) => {
  const formRef = useRef(null);
  const t = useTranslations();
  const { setInternetDebt } = useInternetDebtStore();
  const { searchType: searchTypeState, searchKey } = useInternetDebtStore();
  const [searchType, setSearchType] = useState(searchTypeState);
  const schema = useMemo(() => {
    return schemaPaymentInternet(searchType);
  }, [searchType]);

  return (
    <Form<paymentInternetFormValue, typeof schema>
      ref={formRef as Ref<RefForm<paymentInternetFormValue>>}
      onSubmit={(values) => {
        onSearch(values);
      }}
      schema={schema}
      options={{
        mode: "onChange",
      }}
      defaultValue={{
        searchType: searchType,
        valueSearch: searchKey,
      }}
    >
      {({ control, watch, clearErrors, setValue, formState: { errors } }) => {
        return (
          <BoxContentCommon className=" max-w-[1032px] mx-auto">
            <Typography variant={"title2"} className="text-black">
              {t("payment_package_internet.search_options")}
            </Typography>
            <div className="flex flex-col gap-3 md:gap-4">
              <div className="flex flex-col items-start gap-4">
                <RadioButtonField
                  onChange={(val) => {
                    clearErrors("valueSearch");
                    setValue("valueSearch", "");
                    setInternetDebt({
                      searchKey: "",
                    });
                    setSearchType(val);
                  }}
                  className="flex row gap-4 font-bold"
                  name="searchType"
                  control={control}
                  options={[
                    {
                      label: t("payment_package_internet.number_account"),
                      value: SEARCH_TYPE_PAYMENT_PACKAGE.NUMBER_ACCOUNT,
                    },
                    {
                      label: t("payment_package_internet.id_card_number"),
                      value: SEARCH_TYPE_PAYMENT_PACKAGE.ID_CARD_NUMBER,
                    },
                  ]}
                />
                <div className="flex-1 w-full">
                  <InputField
                    isPassValue
                    formatValueRegex={
                      watch("searchType") ===
                      SEARCH_TYPE_PAYMENT_PACKAGE.NUMBER_ACCOUNT
                        ? REGEX_INPUT_ID_CARD
                        : REGEX_INPUT_ID_CARD_NUMBER
                    }
                    maxLength={50}
                    name="valueSearch"
                    placeholder={
                      watch("searchType") ===
                      SEARCH_TYPE_PAYMENT_PACKAGE.NUMBER_ACCOUNT
                        ? t("payment_package_internet.pl_enter_account")
                        : t("payment_package_internet.pl_enter_card")
                    }
                    type="text"
                    className=""
                    control={control}
                    errors={errors}
                  />
                </div>
              </div>
              {/* <div className="flex flex-col md:flex-row items-start md:items-center gap-2 md:gap-4">
                <Typography className="text-black min-w-[290px] text-sm md:text-base lg:text-xl md:h-12 self-start flex items-center">
                  {t("payment_package_internet.enter_captcha")}:
                </Typography>
                <div className="flex w-full items-center gap-2 md:gap-4 flex-1">
                  <div className="flex-1">
                    <InputField
                      maxLength={5}
                      name="captcha"
                      placeholder={t("payment_package_internet.enter_captcha")}
                      type="text"
                      className=""
                      control={control}
                      errors={errors}
                    />
                  </div>
                  <div className="self-baseline">
                    <SimpleCaptcha
                      ref={refCaptcha as LegacyRef<CaptchaRef>}
                      callbackValue={({ token }) => {
                        setValue("captchaToken", token);
                      }}
                    />
                  </div>
                </div>
              </div> */}
            </div>
            <div className="flex justify-center">
              <Button
                type="submit"
                className="md:max-w-[243px] w-full"
                disabled={!watch("valueSearch")}
              >
                {t("common.search")}
              </Button>
            </div>
          </BoxContentCommon>
        );
      }}
    </Form>
  );
};

export default SearchForm;
