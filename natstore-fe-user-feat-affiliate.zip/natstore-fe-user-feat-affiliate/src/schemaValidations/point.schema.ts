import { z } from "zod";

const DataItemSchema = z.object({
  description: z.string(),
  pointAdd: z.number(),
  pointMinus: z.number(),
  createdAt: z.string(), // ISO string
});

const PagingSchema = z.object({
  pageSize: z.number(),
  totalRecords: z.number(),
  currentPage: z.number(),
  totalPages: z.number(),
  nextPage: z.number(),
  prevPage: z.number(),
});

export const ApiResponseSchema = z.object({
  code: z.string(),
  message: z.string(),
  data: z.array(DataItemSchema),
  paging: PagingSchema,
});

export type PointHistoryResType = z.infer<typeof ApiResponseSchema>;
export type PointHistoryItemType = z.infer<typeof DataItemSchema>;
export type Paging = z.infer<typeof PagingSchema>;
