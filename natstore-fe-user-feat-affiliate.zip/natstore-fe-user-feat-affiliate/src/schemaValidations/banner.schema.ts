import z from "zod";

export const DataBanner = z.object({
  bannerLink: z.string(),
  bannerName: z.string(),
  imagePath: z.string(),
  imageWapPath: z.string(),
});

export const DataBannerRes = z.object({
  data: z.array(DataBanner),
  message: z.string(),
  code: z.number(),
});

export type IDataBannerRes = z.TypeOf<typeof DataBannerRes>;

export type IDataBanner = z.TypeOf<typeof DataBanner>;
