import {
  confirmPasswordSchemaFnc,
  currentPasswordSchemaFnc,
  newPasswordSchemaFnc,
  otpSchemaFnc,
} from "@/lib/schema";
import z from "zod";

export const AccountRes = z
  .object({
    data: z.object({
      id: z.number(),
      isdn: z.string(),
      name: z.string(),
      userName: z.string(),
      email: z.string(),
      phoneNumber: z.string(),
      address: z.string(),
    }),
    code: z.string(),
    message: z.string(),
  })
  .strict();

export type AccountResType = z.TypeOf<typeof AccountRes>;

export const changePasswordSchema = z
  .object({
    otp: otpSchemaFnc(),
    currentPassword: currentPasswordSchemaFnc(),
    newPassword: newPasswordSchemaFnc(),
    confirmPassword: confirmPasswordSchemaFnc(),
  })
  .superRefine(({ newPassword, confirmPassword }, ctx) => {
    if (newPassword !== confirmPassword) {
      ctx.addIssue({
        code: "custom",
        message: "confirm_password.match",
        path: ["confirmPassword"],
      });
    }
  });

export type updatePasswordType = z.TypeOf<typeof changePasswordSchema>;
