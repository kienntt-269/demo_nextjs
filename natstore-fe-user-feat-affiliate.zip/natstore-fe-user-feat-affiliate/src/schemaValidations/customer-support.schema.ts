import { z } from "zod";

export const CustomerSupportFaq = z.object({
  id: z.number(),
  question: z.string(),
  answer: z.string(),
  sortOrder: z.number(),
  faqCategoryId: z.number(),
});

export const CustomerSupportTerms = z.object({
  id: z.number(),
  name: z.string(),
  content: z.string(),
  sortOrder: z.number(),
  createdAt: z.string().nullable(),
});

export const CustomerSupportStatic = z.object({
  id: z.number(),
  name: z.string(),
  content: z.string().nullable().optional(),
  imagePath: z.string().nullable().optional(),
  sortOrder: z.number(),
});

export const CustomerSupportFaqRes = z.object({
  message: z.string(),
  code: z.number(),
  data: z.array(CustomerSupportFaq),
});

export const CustomerSupportTermsRes = z.object({
  message: z.string(),
  code: z.number(),
  data: z.array(CustomerSupportTerms),
});

export const CustomerSupportStaticRes = z.object({
  message: z.string(),
  code: z.number(),
  data: z.array(CustomerSupportStatic),
});

export type ICustomerSupportFaq = z.TypeOf<typeof CustomerSupportFaq>;
export type ICustomerSupportTerms = z.TypeOf<typeof CustomerSupportTerms>;
export type ICustomerSupportStatic = z.TypeOf<typeof CustomerSupportStatic>;
export type ICustomerSupportFaqRes = z.TypeOf<typeof CustomerSupportFaqRes>;
export type ICustomerSupportTermsRes = z.TypeOf<typeof CustomerSupportTermsRes>;
export type ICustomerSupportStaticRes = z.TypeOf<
  typeof CustomerSupportStaticRes
>;
