import { z } from "zod";

export const schemaPaymentInternet = (type: string) =>
  z.object({
    searchType: z.string(),
    valueSearch: z
      .string()
      .trim()
      .nonempty(
        type === "numberAccount"
          ? "number_account.required"
          : "id_card_number.required"
      ),
  });
