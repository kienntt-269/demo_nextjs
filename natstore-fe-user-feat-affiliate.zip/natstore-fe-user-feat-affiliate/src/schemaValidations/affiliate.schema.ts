import {
  addressSchemaFnc,
  dateSchemaFnc,
  districtSchemaFnc,
  driverLicenseSchemaFnc,
  emailSchemaFnc,
  fileSchemaFnc,
  identityNewCardSchemaFnc,
  identityOldCardSchemaFnc,
  passportSchemaFnc,
  phoneSchemaFnc,
  precinctSchemaFnc,
  provinceSchemaFnc,
  validateAndAddIssue,
} from "@/lib/schema";
import { z } from "zod";

export const RegisterAccountAffiliate = (
  t: (key: string, values?: Record<string, string>) => string = (key: string) =>
    key
) =>
  z
    .object({
      isdn: z.string().optional().nullable(),
      userName: z.string().optional().nullable(),
      email: z.string().optional().nullable(),
      fullName: z.string().optional().nullable(),
      birthday: z.date().optional().nullable(),
      gender: z.string().optional().nullable(),
      customerDocType: z.string().optional().nullable(),
      cardId: z.string().optional().nullable(),
      taxNumber: z.string().optional().nullable(),
      provinceId: z.any().optional().nullable(),
      districtId: z.any().optional().nullable(),
      communeId: z.any().optional().nullable(),
      addressDetail: z.string().optional().nullable(),
      faceImage: z.any().optional().nullable(),
      frontIdCard: z.any().optional().nullable(),
      backIdcard: z.any().optional().nullable(),
      mobileNumber: z.string().optional().nullable(),
      paymentMethod: z.number().optional().nullable(),
      checkCondition: z.boolean().optional().nullable(),
    })
    .superRefine((data, ctx) => {
      validateAndAddIssue(ctx, emailSchemaFnc(), data.email, ["email"]);
      validateAndAddIssue(ctx, dateSchemaFnc(), data.birthday, ["dob"]);
      if (!data.fullName) {
        ctx.addIssue({
          code: "custom",
          message: t("name.required"),
          path: ["fullName"],
        });
      }
      if (!data.gender) {
        ctx.addIssue({
          code: "custom",
          message: t("gender.required"),
          path: ["gender"],
        });
      }
      if (!data.customerDocType) {
        ctx.addIssue({
          code: "custom",
          message: t("type_of_doc.required"),
          path: ["customerDocType"],
        });
      } else if (data.customerDocType === "1") {
        validateAndAddIssue(ctx, identityNewCardSchemaFnc(), data.cardId, [
          "cardId",
        ]);
      } else if (data.customerDocType === "2") {
        validateAndAddIssue(ctx, identityOldCardSchemaFnc(), data.cardId, [
          "cardId",
        ]);
      } else if (data.customerDocType === "3") {
        validateAndAddIssue(ctx, driverLicenseSchemaFnc(), data.cardId, [
          "cardId",
        ]);
      } else if (data.customerDocType === "4") {
        validateAndAddIssue(ctx, passportSchemaFnc(), data.cardId, ["cardId"]);
      }

      validateAndAddIssue(ctx, phoneSchemaFnc(), data.mobileNumber, [
        "mobileNumber",
      ]);
      validateAndAddIssue(ctx, provinceSchemaFnc(), data.provinceId, [
        "provinceId",
      ]);
      validateAndAddIssue(ctx, districtSchemaFnc(), data.districtId, [
        "districtId",
      ]);
      validateAndAddIssue(ctx, precinctSchemaFnc(), data.communeId, [
        "precinctId",
      ]);
      validateAndAddIssue(ctx, addressSchemaFnc(), data.addressDetail, [
        "address",
      ]);
      // Validate faceImage
      if (!data.faceImage || data?.faceImage?.length === 0) {
        ctx.addIssue({
          code: "custom",
          message: "file.face_photo",
          path: ["faceImage"],
        });
      } else {
        validateAndAddIssue(
          ctx,
          fileSchemaFnc({ fileSizeLimit: 15 }),
          data.faceImage,
          ["faceImage"]
        );
      }

      // Validate frontIdCard
      if (!data.frontIdCard || data?.frontIdCard?.length === 0) {
        ctx.addIssue({
          code: "custom",
          message: "file.front_photo",
          path: ["frontIdCard"],
        });
      } else {
        validateAndAddIssue(
          ctx,
          fileSchemaFnc({ fileSizeLimit: 15 }),
          data.frontIdCard,
          ["frontIdCard"]
        );
      }

      // Validate backIdcard
      if (!data.backIdcard || data?.backIdcard?.length === 0) {
        ctx.addIssue({
          code: "custom",
          message: "file.back_photo",
          path: ["backIdcard"],
        });
      } else {
        validateAndAddIssue(
          ctx,
          fileSchemaFnc({ fileSizeLimit: 15 }),
          data.backIdcard,
          ["backIdcard"]
        );
      }
    });

//RegisterAccountAffiliate
export const schemaRegisterAccountAffiliate = RegisterAccountAffiliate();
export type RegisterAccountAffiliateType = z.TypeOf<
  typeof schemaRegisterAccountAffiliate
>;
