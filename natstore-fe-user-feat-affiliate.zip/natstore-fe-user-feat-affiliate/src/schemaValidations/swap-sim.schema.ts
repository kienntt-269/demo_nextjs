import {
  addressSchemaFnc,
  customerNameSchemaFnc,
  dateSchemaFnc,
  emailSchemaFnc,
  emailSchemaNoRequireFnc,
  fileSchemaFnc,
  idCardSchemaFnc,
  nameSchemaFnc,
  phoneSchemaFnc,
  phoneSchemaNoRequireFnc,
  typeOfDocSchemaFnc,
} from "@/lib/schema";
import z from "zod";

export const EnterInformationBody = z
  .object({
    phoneNumber: phoneSchemaFnc(),
    fullname: nameSchemaFnc(),
    dob: dateSchemaFnc(),
    identityNumber: idCardSchemaFnc(),
    typeOfSim: z.string(),
    files: fileSchemaFnc({ fileSizeLimit: 15 }),
    otp: z.string().optional(),
  })
  .strict();

export type EnterInformationType = z.TypeOf<typeof EnterInformationBody>;

export const ReceivingMethodPost = z
  .object({
    phoneNumber: z.string(),
    emailAddress: z.string(),
    showroomId: z.number(),
  })
  .strict();

export type ReceivingMethodPostType = z.TypeOf<typeof ReceivingMethodPost>;

export const PayPost = z
  .object({
    paymentMethod: z.number(),
  })
  .strict();

export type PayPostType = z.TypeOf<typeof PayPost>;

export const FormsPost = z
  .object({
    phoneNumber: z.string().optional(),
    contactNumber1: z.string(),
    contactNumber2: z.string(),
    contactNumber3: z.string(),
    contactNumber4: z.string().optional(),
    contactNumber5: z.string().optional(),
    fullname: z.string(),
    gender: z.string(),
    contactPhoneNumber: z.string(),
    identityNumber: z.string(),
    typeofDoc: z.string().optional(),
    dob: z.date(),
    address: z.string().optional(),
    email: z.string().optional(),
    sim_swap: z.string(),
  })
  .strict();

export type FormsPostType = z.TypeOf<typeof FormsPost>;

export const SelectSimReceiving = z
  .object({
    type: z.string(),
    address_receive: z.enum(["showroom", "email"]),
    email: z.string().optional(),
    showroom: z.string().optional(),
  })
  .superRefine((data, ctx) => {
    if (data.address_receive === "email") {
      if (!data.email) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: "The Email fields must be require",
          path: ["email"],
        });
      } else {
        const emailValidation = emailSchemaFnc().safeParse(data.email);
        if (!emailValidation.success) {
          ctx.addIssue({
            code: z.ZodIssueCode.custom,
            message: emailValidation.error.issues[0].message,
            path: ["email"],
          });
        }
      }
    }

    if (data.address_receive === "showroom" && !data.showroom) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: "The Showroom fields must be require",
        path: ["showroom"],
      });
    }
  });

export type SelectSimReceivingType = z.TypeOf<typeof SelectSimReceiving>;

export const SimChangeRequestSim = z
  .object({
    phoneNumber: phoneSchemaNoRequireFnc(),
    contactNumber1: phoneSchemaFnc(),
    contactNumber2: phoneSchemaFnc(),
    contactNumber3: phoneSchemaFnc(),
    contactNumber4: phoneSchemaNoRequireFnc(),
    contactNumber5: phoneSchemaNoRequireFnc(),
    fullname: customerNameSchemaFnc(),
    gender: z.string(),
    contactPhoneNumber: phoneSchemaFnc(),
    identityNumber: idCardSchemaFnc(),
    typeOfDoc: typeOfDocSchemaFnc(),
    dob: dateSchemaFnc(),
    address: addressSchemaFnc(),
    email: emailSchemaNoRequireFnc(),
    sim_swap: z.string(),
  })
  .strict();

export type SimChangeRequestSimType = z.TypeOf<typeof SimChangeRequestSim>;

export type SwapSimForm = EnterInformationType & SelectSimReceivingType;
