import z from "zod";

export type ListMenuType = {
  id: string;
  label: string;
  url: string;
  children: ListMenuType[];
};

export const Language = z.object({
  locale: z.string(),
  name: z.string(),
  image: z.string().nullable(),
});

export const LanguageRes = z.object({
  data: z.array(Language),
  message: z.string(),
  code: z.string(),
});

export const DataListMenu: z.ZodType<ListMenuType> = z.lazy(() =>
  z.object({
    id: z.string(),
    label: z.string(),
    url: z.string(),
    children: z.array(DataListMenu),
  })
);

export const DataListMenuRes = z.object({
  data: z.array(DataListMenu),
  message: z.string(),
  code: z.number(),
});

export type IDataListMenuRes = z.infer<typeof DataListMenuRes>;
export type IDataListMenu = z.infer<typeof DataListMenu>;
export type ILanguage = z.infer<typeof Language>;
export type ILanguageRes = z.infer<typeof LanguageRes>;
