import { phoneSchemaFnc, serviceSchemaFnc } from "@/lib/schema";
import z from "zod";

export const MessageRes = z
  .object({
    message: z.string(),
  })
  .strict();

export const StartChatSchema = ({
  isRequiredPhone,
}: {
  isRequiredPhone: boolean;
}) =>
  z
    .object({
      phone: isRequiredPhone ? phoneSchemaFnc() : z.string(),
      name: z.string(),
      service: serviceSchemaFnc(),
    })
    .strict();

export type MessageResType = z.TypeOf<typeof MessageRes>;
