export const PHONE_SUPPORTING_KEY = "phone_supporting_session";
export const DATA_PACKAGE_REGISTER_KEY = "data_package_register";
export const SIM_REGISTER_KEY = "sim_register";
export const SIM_TYPE_REGISTER_KEY = "sim_type_register";
export const INTERNET_REGISTER_KEY = "internet_register";
export const IS_SHOW_SUGGESTION_KEY = "is_show_suggestion_chat";
export const DATA_PAYMENT_PACKAGE_INTERNET = "data_payment_package_internet";
export const RESPONSE_PAYMENT_INTERNET = "response_payment_internet";
