export const dataList = [
  {
    label: "Mobile",
    link: "/mobile-package",
    icon: "/svg/mobile.svg",
  },
  {
    label: "Internet",
    link: "",
    icon: "/svg/globe.svg",
  },
  {
    label: "Devices",
    link: "",
    icon: "/svg/device.svg",
  },
  {
    label: "Promotion",
    link: "",
    icon: "/svg/gift.svg",
  },
  {
    label: "Natcash",
    link: "",
    icon: "/svg/money.svg",
  },
  {
    label: "Customer Support",
    link: "",
    icon: "/svg/heart.svg",
  },
];

export const listMenu = [
  {
    label: "Mobile",
    link: "#",
    children: [
      {
        label: "Data Plans",
        link: "/mobile-package",
      },
      {
        label: "Promotion",
        link: "#",
      },
      {
        label: "Xchange Plans",
        link: "#",
      },
      {
        label: "Voice Plans",
        link: "#",
      },
      {
        label: "SMS Plans",
        link: "#",
      },
    ],
  },
  {
    label: "Internet",
    link: "#",
    children: [
      {
        label: "Online package payment",
        link: "#",
      },
      {
        label: "Home internet package",
        link: "#",
      },
      {
        label: "Business internet package",
        link: "#",
      },
    ],
  },
  {
    label: "Devices",
    link: "#",
    children: [
      {
        label: "Router",
        link: "#",
      },
      {
        label: "Wi-Fi Modem",
        link: "#",
      },
      {
        label: "Phone",
        link: "#",
      },
    ],
  },
  {
    label: "Promotion",
    link: "#",
  },
  {
    label: "Natcash",
    link: "#",
    children: [
      {
        label: "Buy Natcash",
        link: "#",
      },
      {
        label: "Pay for Services via Natcash",
        link: "#",
      },
    ],
  },
  {
    label: "Affiliate",
    link: "#",
  },
  {
    label: "Order Tracking",
    link: "#",
  },
  {
    label: "Customer Support",
    link: "#",
  },
  {
    label: "Agents",
    link: "#",
  },
  {
    label: "Natcash topup",
    link: "https://www.natcomtopup.com",
  },
];

export const getMonths = (t: (key: string) => string) => {
  return [
    t("january"),
    t("february"),
    t("march"),
    t("april"),
    t("may"),
    t("june"),
    t("july"),
    t("august"),
    t("september"),
    t("october"),
    t("november"),
    t("december"),
  ];
};

export const TYPE_OF_DOC = [
  {
    id: 1,
    name: "ID Card",
  },
  {
    id: 2,
    name: "Passport",
  },
  {
    id: 3,
    name: "Driver's license",
  },
];

export const getTypeOfDocV2 = (t: (key: string) => string) => {
  return [
    {
      id: 1,
      name: t("mobile_package.sim_normal.citizen_identification_10"),
    },
    {
      id: 2,
      name: t("mobile_package.sim_normal.citizen_identification_17"),
    },
    {
      id: 3,
      name: t("common.driver_license"),
    },
    {
      id: 4,
      name: t("common.passport"),
    },
  ];
};

export const getTypeOfDocV1 = (t: (key: string) => string) => {
  return [
    {
      id: "OLD_IDENTITY_CARD",
      name: t("mobile_package.sim_normal.citizen_identification_10"),
    },
    {
      id: "NEW_IDENTITY_CARD",
      name: t("mobile_package.sim_normal.citizen_identification_17"),
    },
    {
      id: "DRIVER_LICENSE",
      name: t("common.driver_license"),
    },
    {
      id: "PASSPORT",
      name: t("common.passport"),
    },
  ];
};
