export const STATUS_CONVERSATION = {
  NEW: "1",
  PROCESSING: "2",
  CLOSEED: "3",
};
