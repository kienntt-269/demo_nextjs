import BoxContentCommon from "@/components/common/box-content-common";
import CarouselData from "@/components/common/carousel-data/carousel-data";
import NoDataAvailable from "@/components/common/no-data-available/no-data-available";
import { Button } from "@/components/ui/button";
import { Typography } from "@/components/ui/typography";
import SearchResultItem from "@/module/payment-package-internet/components/search-result-item";
import { IDataDebtDetail } from "@/schemaValidations/internet.shema";
import { useTranslations } from "next-intl";
import React, { useEffect, useState } from "react";

type Props = {
  data: IDataDebtDetail[];
  onContinue: (data?: IDataDebtDetail) => void;
};

const SearchResult = ({ data, onContinue }: Props) => {
  const t = useTranslations();
  const [itemSelected, setItemSelected] = useState<
    IDataDebtDetail | undefined
  >();
  const handleSelect = (item: IDataDebtDetail) => {
    setItemSelected(item);
  };

  useEffect(() => {
    setItemSelected(data?.[0]);
  }, [data]);

  return (
    <BoxContentCommon className="max-w-[1032px] mx-auto">
      {!data?.length ? (
        <NoDataAvailable />
      ) : (
        <>
          <Typography variant={"title2"} className="text-black">
            {t("payment_package_internet.search_result", {
              count: data?.length,
            })}
          </Typography>
          <CarouselData
            swipperClassName={data.length === 1 ? "!pb-0" : ""}
            quantity={3}
            quantityLg={3}
            quantityMd={3}
            quantitySm={2}
            quantityXs={2}
            length={data?.length || 0}
            quantityMobile={1}
          >
            {data?.map((item) => (
              <SearchResultItem
                key={item.contractNumber}
                data={item}
                isSelected={
                  itemSelected?.contractNumber === item.contractNumber
                }
                onSelected={handleSelect}
              />
            ))}
          </CarouselData>
          <div className="flex justify-center">
            <Button
              className="max-w-[243px] w-full"
              disabled={!itemSelected}
              onClick={() => onContinue(itemSelected)}
            >
              {t("common.continue")}
            </Button>
          </div>
        </>
      )}
    </BoxContentCommon>
  );
};

export default SearchResult;
