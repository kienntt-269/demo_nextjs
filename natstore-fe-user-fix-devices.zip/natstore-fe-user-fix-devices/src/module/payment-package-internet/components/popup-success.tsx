import Modal from "@/components/common/modal/Modal";
import { Button } from "@/components/ui/button";
import { Typography } from "@/components/ui/typography";
import { Dialog } from "@radix-ui/react-dialog";
import { useTranslations } from "next-intl";
import Image from "next/image";
import { useRouter } from "next/navigation";
import React from "react";

export type SuccessModalProps = React.ComponentProps<typeof Dialog> & {
  isSuccess: boolean;
  isOpen: boolean;
  customerName: string;
  numberContact?: string;
  paymentAmount?: string;
  onClose: () => void;
};

export const PopupResonse = ({
  isSuccess,
  isOpen,
  customerName,
  numberContact,
  paymentAmount,
  onClose,
}: SuccessModalProps) => {
  const t = useTranslations("");
  const router = useRouter();
  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      contentClassName="max-w-[504px]"
      contentChildWrapper="px-0"
    >
      <div className="flex justify-center items-center">
        <div className="p-4">
          <Image
            src={
              isSuccess
                ? "/images/icon/check-success.svg"
                : "/images/icon/check-error.svg"
            }
            alt={isSuccess ? "on-mobile" : "off-mobile"}
            width={64}
            height={64}
            className="rounded-t-2xl"
          />
        </div>
      </div>
      <h3 className="font-bold text-xl lg:text-2xl text-center text-black mt-4">
        {isSuccess
          ? t("common.payment_successfully")
          : t("common.payment_failed")}
      </h3>
      <div className="mt-6">
        {isSuccess ? (
          <div className="bg-background-content rounded-2xl p-4">
            <div className="flex items-center justify-between py-2">
              <Typography variant="bodyRegular">
                {t("payment_package_internet.customer_name")}
              </Typography>
              <Typography variant="bodyEmphasize" className="font-bold">
                {customerName}
              </Typography>
            </div>
            <div className="flex items-center justify-between py-2">
              <Typography variant="bodyRegular">
                {t("payment_package_internet.number_contract")}
              </Typography>
              <Typography variant="bodyEmphasize" className="font-bold">
                {numberContact}
              </Typography>
            </div>
            <div className="flex items-center justify-between py-2">
              <Typography variant="bodyRegular">
                {t("payment_package_internet.payment_amount")}
              </Typography>
              <Typography variant="bodyEmphasize" className="font-bold">
                {paymentAmount} $
              </Typography>
            </div>
          </div>
        ) : (
          <Typography
            variant="bodyRegular"
            className=" text-neutral-dark-04 text-center"
          >
            {t("payment_package_internet.payment_fail")}
          </Typography>
        )}
      </div>
      <div className="flex justify-center items-center mt-4 lg:mt-6">
        <Button
          className="w-full font-boldtext-white lg:max-w-[212px] rounded-3xl"
          onClick={() => {
            onClose();
            router.push("/");
          }}
        >
          {t("common.back_home_page")}
        </Button>
      </div>
    </Modal>
  );
};

export default PopupResonse;
