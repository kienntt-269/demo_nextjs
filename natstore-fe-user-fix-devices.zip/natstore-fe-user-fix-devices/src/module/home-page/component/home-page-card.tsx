"use client";
import React from "react";

import Image from "next/image";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

const ListHomeCard = () => {
  return (
    <div className="">
      <Card className="shadow-md border border-gray-200 rounded-3xl bg-white ">
        <Image
          src="/imgHome.png"
          alt="img content"
          width={477}
          height={351}
          layout="responsive"
          className="rounded-3xl"
        />
        <CardContent className="p-6">
          <div className="">
            <h2 className="text-2xl font-bold text-neutral-dark-01 mb-4">
              Super Xchange 200
            </h2>
            <p className="text-sm text-[#7D7D7D] mb-6">
              This is a bundle plan that offers you Free WhatsApp and 12000 HTG
              which can be used either for internet or for call Nat-Nat in 30
              day...
            </p>
            <div className="flex justify-between items-center mt-6">
              <div className="flex space-x-1">
                {Array(5)
                  .fill(0)
                  .map((item, index) => (
                    <div key={index}>
                      <Image
                        src="/star.png"
                        alt="Super Xchange"
                        width={24}
                        height={24}
                        className="rounded-3xl"
                      />
                    </div>
                  ))}
              </div>
              <Button className="bg-[#FF8600] rounded-3xl text-white px-5 py-[6px] hover:bg-orange-600 transition font-semibold">
                View detail
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ListHomeCard;
