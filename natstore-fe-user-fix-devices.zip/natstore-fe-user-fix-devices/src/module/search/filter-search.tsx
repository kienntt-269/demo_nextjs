import { Button } from "@/components/ui/button";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import {
  ArrowDownRight,
  ArrowUpRight,
  ChevronDown,
  ChevronUp,
} from "lucide-react";
import { useTranslations } from "next-intl";
import { useRouter, useSearchParams } from "next/navigation";
import React, { useEffect, useState } from "react";

const FilterSearch = () => {
  const t = useTranslations();
  const listFilterSearch = [
    // {
    //   value: "hot",
    //   text: t("search.hot"),
    // },
    // {
    //   value: "promotion",
    //   text: t("search.promotion"),
    // },
    {
      value: "lastest",
      text: t("search.lastest"),
    },
    // {
    //   value: "bestSeller",
    //   text: t("search.best_seller"),
    // },
  ];
  const [isOpen, setIsOpen] = useState<boolean>(false);
  const router = useRouter();

  const searchParams = useSearchParams();
  const categorize = searchParams.get("categorize") || "";
  const [selectedCategory, setSelectedCategory] = useState(categorize);
  const newParams = new URLSearchParams(searchParams);
  const handleChange = (value: string) => {
    setSelectedCategory(value);

    newParams.set("categorize", value);
    setSelectedCategory(value);

    router.push(`/search?${newParams.toString()}`, { scroll: false });
  };

  const handleClick = (value: string) => {
    newParams.set("sort_by", value);
    router.push(`/search?${newParams.toString()}`, { scroll: false });
  };

  const handleClear = () => {
    newParams.delete("categorize");
    newParams.delete("sort_by");
    setSelectedCategory("");
    router.push(`/search?${newParams.toString()}`, { scroll: false });
  };

  useEffect(() => {
    setSelectedCategory(categorize);
  }, [categorize]);
  return (
    <div>
      <Popover
        open={isOpen}
        onOpenChange={() => {
          setIsOpen(!isOpen);
        }}
      >
        <PopoverTrigger asChild>
          <button
            className={`py-3 px-5 max-xl:py-2 max-md:px-3 max-md:py-[6px] rounded-3xl ${searchParams.get("sortBy") || searchParams.get("categorize") || isOpen ? "bg-[#FF860029]" : "border-[#333333] text-neutral-dark-03 border-solid border"}  flex items-center gap-x-2`}
          >
            {searchParams.get("sortBy") ||
            searchParams.get("categorize") ||
            isOpen ? (
              <ChevronUp className="text-[24px] max-xl:size-5 max-md:size-4" />
            ) : (
              <ChevronDown className="text-[24px] max-xl:size-5 max-md:size-4" />
            )}
            <div className="font-semibold max-xl:text-[14px]">
              {t("common.sort_by")}
            </div>
          </button>
        </PopoverTrigger>
        <PopoverContent className="w-60 rounded-xl border-white shadow-md">
          <div>
            <div className="font-semibold">{t("common.categorize")}</div>
            <RadioGroup
              defaultValue={categorize}
              value={selectedCategory}
              onValueChange={handleChange}
              className="flex flex-col gap-y-4 mt-3"
            >
              {listFilterSearch.map((item) => (
                <label
                  key={item.value}
                  htmlFor={`radio-${item.value}`}
                  className="flex items-center space-x-2 cursor-pointer gap-x-2 text-neutral-dark-04 hover:text-primary"
                >
                  <RadioGroupItem
                    value={item.value}
                    id={`radio-${item.value}`}
                    className="max-md:size-[18px]"
                  />
                  {item.text}
                </label>
              ))}
            </RadioGroup>
          </div>
          <div className="mt-4">
            <div className="font-semibold">{t("common.price")}</div>
            <div
              className="flex gap-x-[10px] max-md:gap-x-2 text-neutral-dark-04 items-center mt-3 cursor-pointer group"
              onClick={() => handleClick("PRICE_ASC")}
            >
              <ArrowUpRight
                strokeWidth={1.5}
                className={`group-hover:text-primary ${searchParams.get("sort_by") === "PRICE_ASC" ? "text-primary" : ""}`}
              />
              <div
                className={`group-hover:text-primary ${searchParams.get("sort_by") === "PRICE_ASC" ? "text-primary" : ""}`}
              >
                {t("mobile_package.low_to_high")}
              </div>
            </div>
            <div
              className="flex gap-x-[10px] max-md:gap-x-2 text-neutral-dark-04 items-center mt-4 cursor-pointer group"
              onClick={() => handleClick("PRICE_DESC")}
            >
              <ArrowDownRight
                strokeWidth={1.5}
                className={`group-hover:text-primary ${searchParams.get("sort_by") === "PRICE_DESC" ? "text-primary" : ""}`}
              />
              <div
                className={`group-hover:text-primary ${searchParams.get("sort_by") === "PRICE_DESC" ? "text-primary" : ""}`}
              >
                {t("mobile_package.high_to_low")}
              </div>
            </div>
            <div className="flex justify-end">
              <Button variant={"ghost"} onClick={handleClear}>
                {t("common.clear")}
              </Button>
            </div>
          </div>
        </PopoverContent>
      </Popover>
    </div>
  );
};

export default FilterSearch;
