"use client";
import React, { useEffect, useRef, useState } from "react";
import SubCategoriesMobile from "@/components/sub-categories-mobile";
import { ICategoryDataRes } from "@/schemaValidations/mobile-service.schema";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { usePathname, useRouter } from "next/navigation";

const SubTabMobile = ({
  searchParams,
  categoriesRes,
}: {
  searchParams?: { [key in string]: string };
  categoriesRes?: ICategoryDataRes;
}) => {
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const [showPrev, setShowPrev] = useState<boolean>(false);
  const [showNext, setShowNext] = useState<boolean>(false);
  const pathName = usePathname();
  const router = useRouter();

  const handleScroll = () => {
    if (!scrollContainerRef.current) return;
    const { scrollLeft, scrollWidth, clientWidth } = scrollContainerRef.current;
    setShowPrev(scrollLeft > 0);
    setShowNext(scrollLeft + clientWidth < scrollWidth - 1);
  };

  const scroll = (direction: "left" | "right") => {
    if (!scrollContainerRef.current) return;
    const { clientWidth } = scrollContainerRef.current;
    const scrollAmount = clientWidth * 0.8;

    if (direction === "left") {
      scrollContainerRef.current.scrollBy({
        left: -scrollAmount,
        behavior: "smooth",
      });
    } else {
      scrollContainerRef.current.scrollBy({
        left: scrollAmount,
        behavior: "smooth",
      });
    }
  };

  useEffect(() => {
    const container = scrollContainerRef.current;
    if (container) {
      const checkScroll = () => {
        handleScroll();
      };
      checkScroll();
      container.addEventListener("scroll", handleScroll);
      const resizeObserver = new ResizeObserver(() => {
        handleScroll();
      });
      resizeObserver.observe(container);

      const timer = setTimeout(checkScroll, 100);

      return () => {
        container.removeEventListener("scroll", handleScroll);
        resizeObserver.disconnect();
        clearTimeout(timer);
      };
    }
  }, [categoriesRes]);

  return (
    <div className="relative w-full">
      {showPrev && (
        <button
          className="max-md:hidden absolute top-[43%] -left-16 max-xl:-left-12 max-lg:-left-10 transform -translate-y-1/2 z-0 xl:size-14 size-9 md:flex items-center justify-center bg-[#E3E4E5] rounded-full"
          onClick={() => scroll("left")}
          aria-label="Previous Slide"
        >
          <ChevronLeft />
        </button>
      )}
      {showNext && (
        <button
          className="max-md:hidden absolute top-[43%] -right-16 max-xl:-right-12 max-lg:-right-10 transform -translate-y-1/2 z-0 xl:size-14 size-9 md:flex items-center justify-center bg-[#E3E4E5] rounded-full"
          onClick={() => scroll("right")}
          aria-label="Next Slide"
        >
          <ChevronRight />
        </button>
      )}
      <div
        ref={scrollContainerRef}
        className="flex items-center gap-x-4 mt-6 max-md:gap-x-2 max-md:mt-2 w-full overflow-x-scroll no-scrollbar relative"
      >
        {categoriesRes?.data[0].children.map((val, i) => {
          const isSelected = searchParams?.categoryId
            ? searchParams?.categoryId === val.id
            : i === 0;
          return (
            <div
              key={val.id}
              onClick={() => {
                router.push(`${pathName}?categoryId=${val.id}`, {
                  scroll: false,
                });
              }}
            >
              <SubCategoriesMobile isActive={isSelected} name={val.name} />
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default SubTabMobile;
