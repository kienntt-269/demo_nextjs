"use client";
import React, { LegacyRef, useRef, useState } from "react";
import { Form, InputField } from "@/components/form";
import { Button } from "@/components/ui/button";
import { useTranslations } from "next-intl";
import { useDialogAuthStore } from "@/_stores/useDialogAuth.store";
import CountdownTimer, {
  CountdownTimerHandle,
} from "@/components/count-down-timer";
import clsx from "clsx";
import { useLoadingStore } from "@/_stores/useLoading,store";
import { UseFormClearErrors, UseFormSetError } from "react-hook-form";
import authApiRequest from "@/services/auth";
import { InputPhoneNumberField } from "@/components/form/input-phone-number-field";
import { useRouter } from "next/navigation";
import { checkResSuccess, formatPhoneSubmit, validatePhone } from "@/lib/utils";
import { LoginBody } from "@/schemaValidations/auth.schema";
import { REGEX_INPUT_PASSWORD } from "@/constants/regex";
import { toastError, toastSuccess } from "@/hooks/use-toast";
type LoginFormValues = {
  phone: string;
  password: string;
  [key: string]: string;
};

const LoginForm = () => {
  const t = useTranslations();
  const router = useRouter();
  const { setIsLoading } = useLoadingStore();
  const { setIsOpen, urlLoginSuccess } = useDialogAuthStore();
  const [isGetOtp, setIsGetOtp] = useState(false);
  const [isExpiredOtp, setIsExpiredOtp] = useState(0);
  const [isNewGetOtp, setIsNewGetOtp] = useState(false);
  const [otpMapWithPhone, setOtpMapWithPhone] = useState<
    Record<string, boolean>
  >({});
  const otpRef = useRef<CountdownTimerHandle>();

  const handleRedirectTerms = () => {
    setIsOpen({ isOpen: false });
    router.push("/customer-care/support?name=terms");
  };

  const handleSubmit = async (data: LoginFormValues) => {
    setIsLoading(true);
    try {
      const phoneSend = formatPhoneSubmit(data.phoneNumber);
      const response = await authApiRequest.login({
        phoneNumber: phoneSend,
        ...(otpMapWithPhone[phoneSend] ? { otp: data.password } : {}),
        password: data.password,
      });
      if (checkResSuccess(response.payload.code)) {
        setIsLoading(false);
        setIsOpen({ isOpen: false });
        router.push(`${urlLoginSuccess}`);
        router.refresh();
      } else {
        toastError(response.payload.message || t("common.error"));
        setIsLoading(false);
      }
    } catch (error) {
      setIsLoading(false);
      console.log({ error });
    }
  };

  const handleGetOTP = async (
    phone: string,
    setError: UseFormSetError<LoginFormValues>,
    clearErrors: UseFormClearErrors<LoginFormValues>
  ) => {
    if (isNewGetOtp) return;
    const error = validatePhone(phone);
    if (error) {
      setError("phoneNumber", error);
      return;
    } else {
      clearErrors("phoneNumber");
    }
    setIsLoading(true);
    const phoneSend = formatPhoneSubmit(phone);
    authApiRequest
      .getOtpLogin({
        phoneNumber: phoneSend,
        actionType: "LOGIN",
      })
      .then((response) => {
        if (checkResSuccess(response.payload.code)) {
          toastSuccess(response?.payload?.message);
          setIsExpiredOtp(300);
          otpRef.current?.reset();
          setIsNewGetOtp(true);
          setIsGetOtp(true);
          setOtpMapWithPhone((prev) => ({
            ...prev,
            [phoneSend]: true,
          }));
        } else {
          toastError(response.payload.message || t("common.error"));
        }
      })
      .catch(() => {
        setIsNewGetOtp(false);
        setIsLoading(false);
        toastError(t("login.please_check_phone"));
      })
      .finally(() => {
        setIsLoading(false);
      });
  };

  return (
    <Form<LoginFormValues, typeof LoginBody>
      schema={LoginBody}
      onSubmit={handleSubmit}
      options={{
        mode: "onChange",
      }}
      defaultValue={{
        phoneNumber: "",
        password: "",
      }}
    >
      {({
        control,
        getValues,
        setError,
        clearErrors,
        formState: { errors },
      }) => {
        return (
          <div className="flex flex-col mt-4 lg:mt-6">
            <InputPhoneNumberField
              autoComplete="off"
              role="presentation"
              autoFocus
              control={control}
              errors={errors}
              name="phoneNumber"
              type="text"
              placeholder={t("login.phone_number")}
            />
            <InputField
              formatValueRegex={REGEX_INPUT_PASSWORD}
              className="mt-3 lg:mt-6"
              control={control}
              errors={errors}
              name="password"
              type="password"
              placeholder={t("login.password_otpcode")}
            />
            {isGetOtp &&
              (isExpiredOtp ? (
                <span className="text-xs lg:text-sm text-neutral mt-3 lg:mt-6">
                  <i>{t("login.otp_valid_period")}</i>
                  <CountdownTimer
                    ref={otpRef as LegacyRef<CountdownTimerHandle>}
                    time={isExpiredOtp}
                    callback={() => {
                      setIsExpiredOtp(0);
                    }}
                  />
                </span>
              ) : (
                <span className="text-xs lg:text-sm  text-error mt-3 lg:mt-6">
                  {t("login.resend_otp")}
                </span>
              ))}
            <div className="flex justify-between mt-2 lg:mt-6">
              <div className="text-primary font-semibold text-sm  text-center flex justify-start flex-wrap gap-1 lg:gap-2">
                <p
                  className={clsx(
                    "font-semibold text-sm transition-all duration-300 ease-in-out md:hover:opacity-80 underline cursor-pointer",
                    {
                      "pointer-events-none": isNewGetOtp,
                      "text-gray-400": isNewGetOtp,
                      "cursor-default": isNewGetOtp,
                    }
                  )}
                  onClick={() =>
                    handleGetOTP(
                      getValues("phoneNumber"),
                      setError,
                      clearErrors
                    )
                  }
                >
                  {t("login.get_otp_code")}
                </p>
                {isNewGetOtp && (
                  <CountdownTimer
                    time={20}
                    callback={() => {
                      setIsNewGetOtp(false);
                    }}
                  />
                )}
              </div>
              <p
                className="font-semibold whitespace-nowrap text-sm text-text-primary underline cursor-pointer transition-all duration-300 ease-in-out md:hover:opacity-80"
                onClick={() => {
                  setIsOpen({ mode: "FORGOT" });
                }}
              >
                {t("login.forgot_password")}
              </p>
            </div>
            <Button type="submit" className="w-full mt-4 lg:mt-6">
              {t("login.login")}
            </Button>
            <p className="text-center text-neutral text-xs lg:text-sm mt-3 lg:mt-6">
              {t.rich("login.question", {
                guidelines: (chunks) => (
                  <span
                    onClick={() => setIsOpen({ mode: "REGISTER" })}
                    className="font-semibold text-primary underline transition-all duration-300 ease-in-out md:hover:opacity-80 cursor-pointer"
                  >
                    {chunks}
                  </span>
                ),
              })}
            </p>
            <p
              className="text-center text-primary font-semibold text-xs lg:text-sm underline cursor-pointer mt-4 lg:mt-6"
              onClick={handleRedirectTerms}
            >
              {t("login.terms")}
            </p>
          </div>
        );
      }}
    </Form>
  );
};

export default LoginForm;
