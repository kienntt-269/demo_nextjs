"use client";
import { useDialogAuthStore } from "@/_stores/useDialogAuth.store";
import Modal from "@/components/common/modal/Modal";
import ForgotPasswordForm from "@/module/dialog-auth/forgot-password-form";
import LoginForm from "@/module/dialog-auth/login-form";
import LogoutForm from "@/module/dialog-auth/logout-form";
import RegisterForm from "@/module/dialog-auth/register-form";
import { useTranslations } from "next-intl";

export function DialogLogin() {
  const { isOpen, mode, setIsOpen } = useDialogAuthStore();
  const t = useTranslations();
  const renderTitle = () => {
    switch (mode) {
      case "REGISTER":
        return t("register.title");
      case "FORGOT":
        return t("forgot.title");
      case "LOGOUT":
        return t("logout.title");
      default:
        return t("login.title");
    }
  };
  const renderContent = () => {
    switch (mode) {
      case "REGISTER":
        return <RegisterForm />;
      case "FORGOT":
        return <ForgotPasswordForm />;
      case "LOGOUT":
        return <LogoutForm />;
      default:
        return <LoginForm />;
    }
  };
  return (
    <Modal
      isOpen={isOpen}
      onClose={(open) => setIsOpen({ isOpen: open })}
      title={renderTitle()}
      contentChildWrapper="px-0 lg:px-4"
    >
      {renderContent()}
    </Modal>
  );
}
