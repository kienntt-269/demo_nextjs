"use client";
import React, { LegacyRef, useRef, useState } from "react";
import { Form, InputField } from "@/components/form";
import { Button } from "@/components/ui/button";
import { useTranslations } from "next-intl";
import { useDialogAuthStore } from "@/_stores/useDialogAuth.store";
import authApiRequest from "@/services/auth";
import { useLoadingStore } from "@/_stores/useLoading,store";
import { toastError, toastSuccess } from "@/hooks/use-toast";
import { UseFormClearErrors, UseFormSetError } from "react-hook-form";
import {
  checkResSuccess,
  focusInput,
  formatPhoneSubmit,
  validatePhone,
} from "@/lib/utils";
import CountdownTimer, {
  CountdownTimerHandle,
} from "@/components/count-down-timer";
import clsx from "clsx";
import { InputPhoneNumberField } from "@/components/form/input-phone-number-field";
import { ForgotPasswordBodySchema } from "@/schemaValidations/auth.schema";
import { REGEX_INPUT_OTP, REGEX_INPUT_PASSWORD } from "@/constants/regex";
type ForgotFormValues = {
  phone: string;
  otp: string;
  password: string;
  confirmPassword: string;
  [key: string]: string;
};

const ForgotPasswordForm = () => {
  const t = useTranslations();
  const { setIsLoading } = useLoadingStore();
  const { setIsOpen } = useDialogAuthStore();
  const [isGetOtp, setIsGetOtp] = useState(false);
  const [isExpiredOtp, setIsExpiredOtp] = useState(0);
  const [isNewGetOtp, setIsNewGetOtp] = useState(false);
  const otpRef = useRef<CountdownTimerHandle>();

  const handleSubmit = async (data: ForgotFormValues) => {
    try {
      setIsLoading(true);
      const response = await authApiRequest.forgotPassword({
        phoneNumber: formatPhoneSubmit(data.phoneNumber),
        otp: data.otp,
        password: data.password,
      });
      if (checkResSuccess(response.payload.code)) {
        toastSuccess(t("common.success"));
        setIsLoading(false);
        setIsOpen({ mode: "LOGIN" });
      } else {
        toastError(response.payload.message || t("common.error"));
        setIsLoading(false);
      }
    } catch (error) {
      console.log({ error });
      setIsLoading(false);
    }
  };

  const handleGetOTP = async (
    phone: string,
    setError: UseFormSetError<ForgotFormValues>,
    clearErrors: UseFormClearErrors<ForgotFormValues>
  ) => {
    if (isNewGetOtp) return;
    const error = validatePhone(phone);
    if (error) {
      setError("phoneNumber", error);
      return;
    } else {
      clearErrors("phoneNumber");
    }
    setIsLoading(true);
    authApiRequest
      .getOtpLogin({
        phoneNumber: formatPhoneSubmit(phone),
        actionType: "FORGOT_PASSWORD",
      })
      .then((response) => {
        if (checkResSuccess(response.payload.code)) {
          toastSuccess(response?.payload?.message);
          focusInput("forgot-otp");
          setIsExpiredOtp(300);
          setIsNewGetOtp(true);
          setIsGetOtp(true);
          otpRef?.current?.reset();
        } else {
          toastError(response.payload.message || t("common.error"));
        }
      })
      .catch(() => {
        setIsNewGetOtp(false);
        setIsLoading(false);
        setError("phoneNumber", {
          message: t("login.please_check_phone"),
          type: "custome",
        });
      })
      .finally(() => {
        setIsLoading(false);
      });
  };

  return (
    <Form<ForgotFormValues, typeof ForgotPasswordBodySchema>
      onSubmit={handleSubmit}
      schema={ForgotPasswordBodySchema}
      options={{
        mode: "onChange",
      }}
      defaultValue={{
        phoneNumber: "",
        password: "",
        confirmPassword: "",
        otp: "",
      }}
    >
      {({
        control,
        setError,
        clearErrors,
        getValues,
        formState: { errors },
      }) => {
        return (
          <div className="flex flex-col mt-4 lg:mt-6">
            <InputPhoneNumberField
              autoFocus
              control={control}
              errors={errors}
              name="phoneNumber"
              type="text"
              placeholder={t("register.phone_number")}
            />
            <InputField
              className="mt-3 lg:mt-6"
              id="forgot-otp"
              control={control}
              errors={errors}
              name="otp"
              formatValueRegex={REGEX_INPUT_OTP}
              placeholder={t("forgot.otp_code")}
            />
            {isGetOtp &&
              (isExpiredOtp ? (
                <span className="text-xs lg:text-sm text-neutral mt-3 lg:mt-6">
                  <i>{t("forgot.otp_valid_period")}</i>
                  <CountdownTimer
                    ref={otpRef as LegacyRef<CountdownTimerHandle>}
                    time={isExpiredOtp}
                    callback={() => {
                      setIsExpiredOtp(0);
                    }}
                  />
                </span>
              ) : (
                <span className="text-xs lg:text-sm text-error mt-3 lg:mt-6">
                  {t("forgot.resend_otp")}
                </span>
              ))}
            <div className="text-primary font-semibold text-sm  text-center flex justify-center gap-2 mt-2 lg:mt-6">
              <p
                className={clsx(
                  "font-semibold text-sm underline text-center cursor-pointer transition-all duration-300 ease-in-out md:hover:opacity-70",
                  {
                    "pointer-events-none": isNewGetOtp,
                    "text-gray-400": isNewGetOtp,
                    "cursor-default": isNewGetOtp,
                  }
                )}
                onClick={() =>
                  handleGetOTP(getValues("phoneNumber"), setError, clearErrors)
                }
              >
                {t("forgot.get_otp_code")}
              </p>
              {isNewGetOtp && (
                <CountdownTimer
                  time={20}
                  callback={() => {
                    setIsNewGetOtp(false);
                  }}
                />
              )}
            </div>
            <div className="mt-4 lg:mt-6">
              <InputField
                formatValueRegex={REGEX_INPUT_PASSWORD}
                control={control}
                errors={errors}
                name="password"
                type="password"
                placeholder={t("forgot.new_password")}
              />
              {!getValues("password") && !errors["password"]?.message && (
                <span className="mt-2 text-neutral2 text-xs lg:text-[13px] leading-[21px]">
                  {t("forgot.password_rule")}
                </span>
              )}
            </div>
            <InputField
              className="mt-3 lg:mt-6"
              formatValueRegex={REGEX_INPUT_PASSWORD}
              control={control}
              errors={errors}
              name="confirmPassword"
              type="password"
              placeholder={t("forgot.confirm_password")}
            />
            <Button type="submit" className="w-full mt-4 lg:mt-6">
              {t("common.confirm")}
            </Button>
            <p className="text-center text-neutral text-xs lg:text-sm mt-3 lg:mt-6">
              {t.rich("forgot.question", {
                guidelines: (chunks) => (
                  <span
                    onClick={() => {
                      setIsOpen({ mode: "LOGIN" });
                    }}
                    className="font-semibold text-primary underline transition-all duration-300 ease-in-out md:hover:opacity-80 cursor-pointer"
                  >
                    {chunks}
                  </span>
                ),
              })}
            </p>
          </div>
        );
      }}
    </Form>
  );
};

export default ForgotPasswordForm;
