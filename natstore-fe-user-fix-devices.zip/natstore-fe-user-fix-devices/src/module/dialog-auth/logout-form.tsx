import { useDialogAuthStore } from "@/_stores/useDialogAuth.store";
import { useProfileStore } from "@/_stores/useProfile.store";
import { Button } from "@/components/ui/button";
import { storage } from "@/lib/storage";
import authApiRequest from "@/services/auth";
import { useTranslations } from "next-intl";
import { useRouter } from "next/navigation";
import React from "react";

const LogoutForm = () => {
  const router = useRouter();
  const { setIsOpen } = useDialogAuthStore();
  const { setProfile } = useProfileStore();
  const t = useTranslations();
  return (
    <div>
      <span className="text-neutral-dark-04 text-sm inline-block text-center">
        {t("logout.message")}
      </span>
      <div className="flex justify-center mt-4 lg:mt-6 gap-4">
        <Button
          className="w-full"
          variant="secondary"
          onClick={() => setIsOpen({ isOpen: false })}
        >
          {t("logout.cancel")}
        </Button>
        <Button
          className="rounded-full w-full"
          onClick={async () => {
            await authApiRequest.logout();
            storage.removeAll();
            setIsOpen({ isOpen: false });
            setProfile({ user: null });
            setTimeout(() => {
              router.refresh();
            }, 1000);
          }}
        >
          {t("logout.confirm")}
        </Button>
      </div>
    </div>
  );
};

export default LogoutForm;
