"use client";
import React, { LegacyRef, useEffect, useMemo, useRef, useState } from "react";
import { Form, InputField, RefForm } from "@/components/form";
import { Button } from "@/components/ui/button";
import { useTranslations } from "next-intl";
import { useDialogAuthStore } from "@/_stores/useDialogAuth.store";
import authApiRequest from "@/services/auth";
import { RegisterBody } from "@/schemaValidations/auth.schema";
import { InputPhoneNumberField } from "@/components/form/input-phone-number-field";
import CountdownTimer, {
  CountdownTimerHandle,
} from "@/components/count-down-timer";
import { UseFormClearErrors, UseFormSetError } from "react-hook-form";
import { useLoadingStore } from "@/_stores/useLoading,store";
import clsx from "clsx";
import { toastError, toastSuccess } from "@/hooks/use-toast";
import {
  checkIsPhoneHaiti,
  checkResSuccess,
  formatPhoneSubmit,
  validateEmail,
  validatePhone,
} from "@/lib/utils";
import { REGEX_INPUT_OTP, REGEX_INPUT_PASSWORD } from "@/constants/regex";
import { useRouter } from "next/navigation";

type RegisterFormValues = {
  phoneNumber: string;
  otp: string;
  password: string;
  confirmPassword: string;
  [key: string]: string;
};

const RegisterForm = () => {
  const router = useRouter();
  const { setIsLoading } = useLoadingStore();
  const formRef = useRef<RefForm<RegisterFormValues> | null>(null);
  const t = useTranslations();
  const { setIsOpen } = useDialogAuthStore();
  const [isGetOtp, setIsGetOtp] = useState(false);
  const [isExpiredOtp, setIsExpiredOtp] = useState(0);
  const [isNewGetOtp, setIsNewGetOtp] = useState(false);
  const otpRef = useRef<CountdownTimerHandle>();
  const [phoneNumber, setPhoneNumber] = useState("");

  const handleRedirectTerms = () => {
    setIsOpen({ isOpen: false });
    router.push("/customer-care/support?name=terms");
  };

  const handleSubmit = async (data: RegisterFormValues) => {
    try {
      setIsLoading(true);
      const isPhoneHaiti = checkIsPhoneHaiti(data.phoneNumber);
      const response = await authApiRequest.register({
        email: isPhoneHaiti ? undefined : data.email,
        phoneNumber: formatPhoneSubmit(data.phoneNumber),
        password: data.password,
        otp: data.otp,
        ...(isPhoneHaiti ? {} : { email: data.email }),
      });
      if (checkResSuccess(response.payload.code)) {
        toastSuccess(t("common.success"));
        setIsOpen({ mode: "LOGIN" });
      } else {
        toastError(response.payload.message || t("common.error"));
      }
      setIsLoading(false);
    } catch (error) {
      console.log({ error });
      setIsLoading(false);
    }
  };

  const handleGetOTP = async (
    phone: string,
    email: string,
    setError: UseFormSetError<RegisterFormValues>,
    clearErrors: UseFormClearErrors<RegisterFormValues>
  ) => {
    if (isNewGetOtp) return;
    const error = validatePhone(phone);
    const isPhoneHaiti = checkIsPhoneHaiti(phone);
    const errorErmail = validateEmail(email);
    if (error) {
      setError("phoneNumber", error);
    } else {
      clearErrors("phoneNumber");
    }
    if (errorErmail && !isPhoneHaiti) {
      setError("email", errorErmail);
    } else {
      clearErrors("errorEmail");
    }
    if (error || (errorErmail && !isPhoneHaiti)) {
      return;
    }
    setIsLoading(true);
    authApiRequest
      .getOtpRegister({
        phoneNumber: formatPhoneSubmit(phone),
        actionType: "LOGIN",
        ...(!isPhoneHaiti ? { email } : {}),
      })
      .then((response) => {
        if (checkResSuccess(response.payload.code)) {
          toastSuccess(response?.payload?.message);
          setIsExpiredOtp(300);
          setIsNewGetOtp(true);
          setIsGetOtp(true);
          otpRef?.current?.reset();
        } else {
          toastError(response.payload.message || t("common.error"));
        }
      })
      .catch(() => {
        setIsNewGetOtp(false);
        setIsLoading(false);
        toastError(t("register.please_check_phone"));
      })
      .finally(() => {
        setIsLoading(false);
      });
  };

  const RegisterBodySchema = useMemo(() => {
    const isPhoneHaiti = checkIsPhoneHaiti(phoneNumber);
    if (isPhoneHaiti && formRef.current) {
      formRef.current?.methods.clearErrors("email");
    }
    return RegisterBody({
      isRequiredEmail: !checkIsPhoneHaiti(phoneNumber),
    });
  }, [phoneNumber]);

  return (
    <Form<RegisterFormValues, typeof RegisterBodySchema>
      ref={formRef}
      onSubmit={handleSubmit}
      schema={RegisterBodySchema}
      options={{
        mode: "onChange",
      }}
      defaultValue={{
        phoneNumber: "",
        password: "",
        confirmPassword: "",
        otp: "",
        email: "",
      }}
    >
      {({
        control,
        getValues,
        setError,
        clearErrors,
        watch,
        formState: { errors },
      }) => {
        const phoneVal = watch("phoneNumber");
        // eslint-disable-next-line react-hooks/rules-of-hooks
        useEffect(() => {
          setPhoneNumber(phoneVal);
        }, [phoneVal]);
        return (
          <div className="flex flex-col mt-4 lg:mt-6">
            <InputPhoneNumberField
              autoFocus
              control={control}
              errors={errors}
              id="register-phone"
              name="phoneNumber"
              type="text"
              placeholder={t("register.phone_number")}
            />
            {phoneVal && !checkIsPhoneHaiti(phoneVal) && (
              <>
                <span className="mt-3 text-neutral2 text-xs lg:text-sm text-center">
                  {t("register.noti_email")}
                </span>
                <InputField<RegisterFormValues>
                  maxLength={255}
                  className="mt-3"
                  control={control}
                  errors={errors}
                  name="email"
                  placeholder={t("register.email")}
                />
              </>
            )}

            <InputField<RegisterFormValues>
              formatValueRegex={REGEX_INPUT_OTP}
              className="mt-3"
              control={control}
              errors={errors}
              name="otp"
              id="register-otp"
              placeholder={t("register.otp_code")}
            />
            {isGetOtp &&
              (isExpiredOtp ? (
                <span className="text-xs lg:text-sm  text-neutral mt-3 lg:mt-6">
                  <i>{t("register.otp_valid_period")}</i>
                  <CountdownTimer
                    ref={otpRef as LegacyRef<CountdownTimerHandle>}
                    time={isExpiredOtp}
                    callback={() => {
                      setIsExpiredOtp(0);
                    }}
                  />
                </span>
              ) : (
                <span className="text-xs lg:text-sm text-error mt-3 lg:mt-6">
                  {t("register.resend_otp")}
                </span>
              ))}

            <div className="text-primary font-semibold text-sm  text-center flex justify-center gap-2 mt-2 lg:mt-6">
              <p
                className={clsx(
                  "font-semibold text-sm underline text-center cursor-pointer transition-all duration-300 ease-in-out md:hover:opacity-70",
                  {
                    "pointer-events-none": isNewGetOtp,
                    "text-gray-400": isNewGetOtp,
                    "cursor-default": isNewGetOtp,
                  }
                )}
                onClick={() =>
                  handleGetOTP(
                    getValues("phoneNumber"),
                    getValues("email"),
                    setError,
                    clearErrors
                  )
                }
              >
                {t("register.get_otp_code")}
              </p>
              {isNewGetOtp && (
                <CountdownTimer
                  time={20}
                  callback={() => {
                    setIsNewGetOtp(false);
                  }}
                />
              )}
            </div>
            <div className="mt-4 lg:mt-6">
              <InputField
                formatValueRegex={REGEX_INPUT_PASSWORD}
                control={control}
                errors={errors}
                name="password"
                type="password"
                placeholder={t("register.new_password")}
              />
              {!getValues("password") && !errors["password"]?.message && (
                <span className="mt-2 text-neutral2 text-xs lg:text-[13px] leading-[21px]">
                  {t("register.password_rule")}
                </span>
              )}
            </div>
            <InputField
              formatValueRegex={REGEX_INPUT_PASSWORD}
              className="mt-3 lg:mt-6"
              control={control}
              errors={errors}
              name="confirmPassword"
              type="password"
              placeholder={t("register.confirm_password")}
            />
            <div className="mt-4">
              <p className="text-center text-neutral text-xs lg:text-sm">
                {t("register.terms_title")}
              </p>
              <p
                className="text-center text-primary text-xs lg:text-sm font-semibold underline cursor-pointer"
                onClick={handleRedirectTerms}
              >
                {t("register.terms")}
              </p>
            </div>
            <Button type="submit" className="w-full mt-4 lg:mt-6">
              {t("common.confirm")}
            </Button>
            <p className="text-center text-neutral text-xs lg:text-sm mt-3 lg:mt-6">
              {t.rich("register.question", {
                guidelines: (chunks) => (
                  <span
                    onClick={() => {
                      setIsOpen({ mode: "LOGIN" });
                    }}
                    className="font-semibold text-primary underline transition-all duration-300 ease-in-out md:hover:opacity-80 cursor-pointer"
                  >
                    {chunks}
                  </span>
                ),
              })}
            </p>
          </div>
        );
      }}
    </Form>
  );
};

export default RegisterForm;
