import { useChatOnline } from "@/_stores/useChatOnline";
import { useLangStore } from "@/_stores/useLang.store";
import { useProfileStore } from "@/_stores/useProfile.store";
import { Form, InputField, SelectField } from "@/components/form";
import { InputPhoneNumberField } from "@/components/form/input-phone-number-field";
import { Button } from "@/components/ui/button";
import { storage } from "@/lib/storage";
import { formatPhoneSubmit, formatPhoneView } from "@/lib/utils";
import { StartChatSchema } from "@/schemaValidations/common.schema";
import { chatApiRequest } from "@/services/chat-service";
import { ServiceChatType } from "@/types/common";
import { useTranslations } from "next-intl";
import React, { useEffect, useMemo, useState } from "react";

type StartChatFormValues = {
  name: string;
  phone: string;
  service: string;
};

const StartScreen = () => {
  const t = useTranslations();
  const { user } = useProfileStore();
  const { lang } = useLangStore();
  const [servicesChat, setServicesChat] = useState<ServiceChatType[]>([]);
  const { setStateChatOnline } = useChatOnline();
  const handleSubmit = async (values: StartChatFormValues) => {
    chatApiRequest
      .getRoomId(formatPhoneSubmit(values.phone), values.name)
      .then((roomRes) => {
        setStateChatOnline({
          mode: "CHAT",
          isStart: true,
          phoneSupporting: formatPhoneSubmit(values.phone),
          serviceChoosedId: values.service,
          nameSupporting: values.name,
          roomData: roomRes?.payload?.data,
          roomIsExist: true,
        });
        storage.setPhoneSupporting(formatPhoneSubmit(values.phone));
      });
  };

  const defaultValue = useMemo(() => {
    return {
      phone: formatPhoneView(user?.isdn ?? ""),
      name: user?.userName ?? "",
      service: "",
    };
  }, [user?.userName, user?.isdn]);

  useEffect(() => {
    chatApiRequest.getListService().then((response) => {
      setServicesChat(response?.payload?.data ?? []);
    });
  }, [lang]);
  const schema = StartChatSchema({ isRequiredPhone: !user?.isdn });
  return (
    <div className="p-6 pb-8 md:pb-6  h-full relative">
      <Form<StartChatFormValues, typeof schema>
        schema={schema}
        className="h-full"
        isUpdateDefault={true}
        onSubmit={handleSubmit}
        options={{
          mode: "onChange",
        }}
        defaultValue={defaultValue}
      >
        {({ control, formState: { errors } }) => {
          return (
            <div className="flex flex-col gap-6 justify-between h-full">
              <div className="md:flex-shrink-0 w-full flex flex-col gap-6 relative h-full">
                <div className="md:text-sm font-bold text-neutral-dark2 text-center">
                  {t("chat_online.title_start")}
                </div>
                <div className="flex flex-col lg:flex-row items-start lg:justify-between lg:items-center">
                  <div className="flex-1 w-[100%]">
                    <div className="text-sm text-neutral-dark-04">
                      {t("chat_online.your_name")}
                    </div>
                    <InputField
                      disabled={!!user?.userName}
                      autoFocus
                      name="name"
                      placeholder={t("chat_online.enter_your_name")}
                      type="text"
                      className=""
                      control={control}
                      errors={errors}
                      maxLength={20}
                    />
                  </div>
                </div>
                <div className="flex flex-col lg:flex-row items-start lg:justify-between lg:items-center">
                  <div className="flex-1 w-[100%]">
                    <div className="text-sm text-neutral-dark-04">
                      {t("chat_online.your_phone_number")}
                    </div>
                    <InputPhoneNumberField
                      disabled={!!user?.isdn}
                      isPrefix={!user?.isdn}
                      name="phone"
                      type="text"
                      className="text-sm lg:text-xl"
                      control={control}
                      errors={errors}
                    />
                  </div>
                </div>
                <div className="flex flex-col lg:flex-row items-start lg:justify-between lg:items-center">
                  <div className="flex-1 w-[100%]">
                    <SelectField
                      error={errors?.service}
                      control={control}
                      placeholder={t("chat_online.choose_services")}
                      name="service"
                      options={servicesChat.map((item) => ({
                        label: item.name,
                        value: item.id + "",
                      }))}
                    />
                  </div>
                </div>
              </div>
              <div className="flex justify-center">
                <Button type="submit" className="w-full rounded-3xl h-[45px]">
                  {t("common.start")}
                </Button>
              </div>
            </div>
          );
        }}
      </Form>
    </div>
  );
};

export default StartScreen;
