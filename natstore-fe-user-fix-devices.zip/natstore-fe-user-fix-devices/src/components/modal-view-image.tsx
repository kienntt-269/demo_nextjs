import Modal from "@/components/common/modal/Modal";
// import dayjs from "dayjs";
import Image from "next/image";
import React, { useState } from "react";

type Props = {
  images: string[];
  isOpen: boolean;
  indexDefault?: number;
  date?: string;
  onClose: () => void;
};

// const formatTime = (time: string) => {
//   const date = dayjs(time);
//   const now = dayjs();

//   if (date.isSame(now, "day")) {
//     return `Today at ${date.format("HH:mm")}`;
//   } else {
//     return `${date.format("YYYY/MM/DD")} at ${date.format("HH:mm")}`;
//   }
// };

export const ModalViewImage = ({
  images,
  isOpen,
  indexDefault,
  // date,
  onClose,
}: Props) => {
  const [selectedIndex, setSelectedIndex] = useState(indexDefault ?? 0);
  return (
    <Modal
      isOpen={isOpen}
      onClose={() => onClose()}
      contentClassName="max-w-[765px]"
      contentChildWrapper="!px-0 lg:px-2"
      // subTitle={formatTime(date ?? "")}
    >
      <div className="w-full">
        <div className="relative bg-white lg:p-4 rounded-lg flex flex-col items-center w-full">
          <div className="relative h-[190px] lg:h-[280px] max-w-[463px] w-full">
            <Image
              src={images[selectedIndex - 1]}
              alt="Preview"
              fill
              className="object-contain rounded-2xl"
            />
          </div>
          <div className="my-4 lg:my-6 text-neutral-dark-04 text-xs">
            {selectedIndex} of {images.length}
          </div>
          <div className="w-full overflow-auto">
            <div className="flex gap-2 min-w-max px-3 lg:px-4 py-2">
              {images.map((img, index) => (
                <div
                  key={index}
                  className={`cursor-pointer w-[40px] h-[40px] lg:h-24 lg:w-24 rounded-[8px] overflow-hidden border-2 lg:border-4 ${index === selectedIndex - 1 ? "border-primary" : "border-transparent"}`}
                  onClick={() => setSelectedIndex(index + 1)}
                >
                  <Image
                    src={img}
                    alt={`Thumbnail ${index}`}
                    width={96}
                    height={96}
                    className="object-cover h-full"
                  />
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </Modal>
  );
};
