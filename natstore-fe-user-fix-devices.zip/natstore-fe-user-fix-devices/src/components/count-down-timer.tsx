import React, {
  useState,
  useEffect,
  useImperativeHandle,
  forwardRef,
} from "react";
import dayjs from "dayjs";
import { cn } from "@/lib/utils";

interface CountdownTimerProps {
  time: number;
  callback: () => void;
  className?: string;
}

export interface CountdownTimerHandle {
  reset: () => void;
}

const CountdownTimer = forwardRef<CountdownTimerHandle, CountdownTimerProps>(
  ({ time, className, callback }: CountdownTimerProps, ref) => {
    const [remainingTime, setRemainingTime] = useState(time);

    // Use useImperativeHandle to expose methods to the parent component
    useImperativeHandle(ref, () => ({
      reset: () => {
        setRemainingTime(time);
      },
    }));

    useEffect(() => {
      if (remainingTime <= 0) return;

      const timer = setInterval(() => {
        setRemainingTime((prevTime) => {
          if (prevTime <= 1) {
            clearInterval(timer);
            callback(); // Call the callback function when time reaches zero
            return 0;
          }
          return prevTime - 1;
        });
      }, 1000);

      return () => clearInterval(timer); // Clean up the timer on component unmount
    }, [remainingTime, callback]);

    useEffect(() => {
      setRemainingTime(time);
    }, [time]);

    return (
      <span className={cn(className)}>
        {dayjs(remainingTime * 1000).format("mm:ss")}s
      </span>
    );
  }
);

CountdownTimer.displayName = "CountdownTimer";

export default CountdownTimer;
