"use client";
import React from "react";

type ITitle = {
  children: React.ReactNode;
  classStyle?: string;
};

const TitleStyle: React.FC<ITitle> = ({ children, classStyle }) => {
  return (
    <div
      className={`text-[32px] leading-[39px] max-2xl:text-[28px] max-2xl:leading-4 max-xl:text-[24px] max-md:text-[20px] font-bold ${classStyle}`}
    >
      {children}
    </div>
  );
};

export default TitleStyle;
