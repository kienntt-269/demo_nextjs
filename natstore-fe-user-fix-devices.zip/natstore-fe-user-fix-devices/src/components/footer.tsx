"use client";
import { useLangStore } from "@/_stores/useLang.store";
import { useIsMobile } from "@/hooks/use-mobile";
import { titilliumWeb } from "@/lib/font";
import { useTranslations } from "next-intl";
import Image from "next/image";
import Link from "next/link";
import React from "react";

export default function FooterComponent() {
  const isMobile = useIsMobile();
  const t = useTranslations();
  const { lang } = useLangStore();
  return (
    <footer
      className={`${titilliumWeb.className} bg-black text-white pt-11 max-md:pt-7 h-auto rounded-t-2xl`}
    >
      <div className="container mx-auto md:flex md:flex-wrap gap-10 pb-12 w-full max-w-[1689px] px-16 max-lg:px-10 max-md:px-4 max-md:pb-4">
        <div className="">
          <Image
            unoptimized
            quality={100}
            src={"/natcom-white.png"}
            width={isMobile ? 71 : 94}
            height={isMobile ? 15 : 45}
            alt="natcom image"
          />
        </div>

        {/* About Us */}
        <div className="max-md:hidden">
          <h5 className="font-bold mb-5 text-xl">{t("footer.about_us")}</h5>
          <ul className="space-y-2">
            <li className="text-sm md:hover:text-primary transition-colors duration-300 ease-in-out">
              <Link href={"/about-us?slug=history"}>{t("footer.history")}</Link>
            </li>

            <li className="text-sm md:hover:text-primary transition-colors duration-300 ease-in-out">
              <Link href={"/about-us?slug=vision"}>{t("footer.vision")}</Link>
            </li>

            <li className="text-sm md:hover:text-primary transition-colors duration-300 ease-in-out">
              <Link href={"/about-us?slug=mission"}>{t("footer.mission")}</Link>
            </li>
          </ul>
        </div>

        {/* Products & Services */}
        <div className="max-md:hidden">
          <h5 className="font-bold mb-5 text-xl">
            {t("footer.products_services")}
          </h5>
          <ul className="space-y-2">
            <li className="text-sm md:hover:text-primary transition-colors duration-300 ease-in-out">
              <Link href={"/mobile-package"}>
                {t("mobile_package.roaming.mobile_service")}
              </Link>
            </li>

            <li className="text-sm md:hover:text-primary transition-colors duration-300 ease-in-out">
              <Link href={"/internet"}>{t("footer.mobile_internet")}</Link>
            </li>

            <li className="text-sm md:hover:text-primary transition-colors duration-300 ease-in-out">
              <Link href={"/mobile-package/vas"}>
                {t("footer.vas_services")}
              </Link>
            </li>

            <li className="text-sm md:hover:text-primary transition-colors duration-300 ease-in-out">
              <Link href={"/"}>{t("footer.devices")}</Link>
            </li>
          </ul>
        </div>

        {/* Support */}
        <div className="max-md:hidden">
          <h5 className="font-bold mb-5 text-xl">{t("footer.support")}</h5>
          <ul className="space-y-2">
            <li className="text-sm md:hover:text-primary transition-colors duration-300 ease-in-out">
              <Link href={"/"}>{t("footer.news")}</Link>
            </li>

            <li className="text-sm md:hover:text-primary transition-colors duration-300 ease-in-out">
              <Link href={"/customer-care/support"}>{t("footer.faqs")}</Link>
            </li>

            <li className="text-sm md:hover:text-primary transition-colors duration-300 ease-in-out">
              <Link href={"/"}>{t("footer.find_a_store")}</Link>
            </li>

            <li className="text-sm md:hover:text-primary transition-colors duration-300 ease-in-out">
              <Link href={"/"}>{t("footer.repair_warranty")}</Link>
            </li>
          </ul>
        </div>

        {/* Contact Us */}
        <div className="flex-1  max-md:mt-6">
          <h5 className="font-bold mb-5 text-xl max-md:hidden">
            {t("footer.contact_us")}
          </h5>
          <div className="flex gap-6">
            <div className="w-1/2 max-md:w-full">
              <p className="font-bold text-sm mb-2  max-md:mb-0">
                {t("footer.natcom_sa")}
              </p>
              <p className="text-sm mb-6 max-md:max-w-64 max-md:mb-2">
                {t("footer.address")}
              </p>
              <p className="font-bold text-sm mb-2 max-md:mb-0 ">
                {t("footer.customer_services_hotline")}
              </p>
              <Link href="tel:+123456" className="text-sm">
                {t("footer.hotline_numbers")}
              </Link>
              <p className="font-bold text-sm mb-2 mt-6 max-md:mt-2 max-md:mb-0">
                {t("footer.email")}
              </p>
              {/* <p className="text-sm break-words auto">
                {t("footer.email_address")}
              </p> */}
              <a
                href="mailto:customercare@natcom.com.ht"
                className="text-sm break-word max-md:my-0"
              >
                {t("footer.email_address")}
              </a>
            </div>
            <div className="w-1/2 max-md:hidden">
              <p className="font-bold text-sm mb-2">{t("footer.voice_line")}</p>
              <div className="text-sm">{t("footer.mobile_natcash_111")}</div>
              <div className="text-sm">{t("footer.fixed_line_22226666")}</div>
              <div className="text-sm">{t("footer.channel_line_22229999")}</div>
              <Link href="tel:+123456" className="text-sm">
                {t("footer.hotline_22228888")}
              </Link>
              <div className="text-sm">{t("footer.sms_flash_sms_mms")}</div>
              <div className="text-sm">{t("footer.ussd_111")}</div>
              <div className="text-sm">{t("footer.ivr_110")}</div>
              <div className="flex gap-8 mt-4">
                <Link
                  href={"https://www.facebook.com/messages/t/360709100683725"}
                  target="_blank"
                  className="transition-transform duration-300 ease-in-out md:hover:scale-125"
                >
                  <Image
                    src="/images/icon/messenger.svg"
                    width={24}
                    height={24}
                    alt={t("footer.social_media.messenger")}
                  />
                </Link>
                <Link
                  href={"https://www.facebook.com/natcomht"}
                  target="_blank"
                  className="transition-transform duration-300 ease-in-out md:hover:scale-125"
                >
                  <Image
                    src="/images/icon/facebook.svg"
                    width={24}
                    height={24}
                    alt={t("footer.social_media.facebook")}
                  />
                </Link>
                <Link
                  href={"https://wa.me/50933251111"}
                  target="_blank"
                  className="transition-transform duration-300 ease-in-out md:hover:scale-125"
                >
                  <Image
                    src="/images/icon/whatsapp.svg"
                    width={24}
                    height={24}
                    alt={t("footer.social_media.whatsapp")}
                  />
                </Link>
              </div>
            </div>
          </div>
        </div>

        {/* My Natcom App */}
        <div>
          <div className="flex justify-between items-center max-md:mb-3 max-md:mt-6" >
            <h5 className="font-bold  text-xl">
              {t("footer.my_natcom_app")}
            </h5>
            <div className=" gap-4 hidden max-md:flex ">
              <Link
                href={"https://www.facebook.com/messages/t/360709100683725"}
                target="_blank"
                className="transition-transform duration-300 ease-in-out md:hover:scale-125"
              >
                <Image
                  src="/images/icon/messenger.svg"
                  width={24}
                  height={24}
                  alt={t("footer.social_media.messenger")}
                />
              </Link>
              <Link
                href={"https://www.facebook.com/natcomht"}
                target="_blank"
                className="transition-transform duration-300 ease-in-out md:hover:scale-125"
              >
                <Image
                  src="/images/icon/facebook.svg"
                  width={24}
                  height={24}
                  alt={t("footer.social_media.facebook")}
                />
              </Link>
              <Link
                href={"https://wa.me/50933251111"}
                target="_blank"
                className="transition-transform duration-300 ease-in-out md:hover:scale-125"
              >
                <Image
                  src="/images/icon/whatsapp.svg"
                  width={24}
                  height={24}
                  alt={t("footer.social_media.whatsapp")}
                />
              </Link>
            </div>
          </div>
          <div className="mb-3">
            <Link
              href={
                "https://play.google.com/store/apps/details?id=com.vtg.app.mynatcom"
              }
              target="_blank"
              className="w-full"
            >
              {lang === "en" && (
                <Image
                  className="w-full"
                  unoptimized
                  quality={100}
                  src={"/footer-img.svg"}
                  width={351}
                  height={72}
                  alt={t("footer.footer_img_alt")}
                />
              )}
              {lang === "ht" && (
                <Image
                  className="w-full"
                  unoptimized
                  quality={100}
                  src={"/footer-img-ht.svg"}
                  width={351}
                  height={72}
                  alt={t("footer.footer_img_alt")}
                />
              )}
              {lang === "fr" && (
                <Image
                  className="w-full"
                  unoptimized
                  quality={100}
                  src={"/footer-img-fr.svg"}
                  width={351}
                  height={72}
                  alt={t("footer.footer_img_alt")}
                />
              )}
            </Link>
          </div>
          <div className="flex space-x-4">
            <Link
              className="flex-1"
              href={"https://www.apple.com/vn/app-store/"}
              target="_blank"
            >
              {lang === "en" && (
                <Image
                  className="w-full"
                  unoptimized
                  quality={100}
                  src={"/app-store.svg"}
                  width={168}
                  height={48}
                  alt={t("footer.app_store")}
                />
              )}
              {lang === "ht" && (
                <Image
                  className="w-full"
                  unoptimized
                  quality={100}
                  src={"/app-store-ht.svg"}
                  width={168}
                  height={48}
                  alt={t("footer.app_store")}
                />
              )}
              {lang === "fr" && (
                <Image
                  className="w-full"
                  unoptimized
                  quality={100}
                  src={"/app-store-fr.svg"}
                  width={168}
                  height={48}
                  alt={t("footer.app_store")}
                />
              )}
            </Link>

            <Link
              href={
                "https://play.google.com/store/apps/details?id=com.vtg.app.mynatcom"
              }
              className="flex-1"
              target="_blank"
            >
              {lang === "en" && (
                <Image
                  className="w-full"
                  unoptimized
                  quality={100}
                  src={"/google-play.svg"}
                  width={168}
                  height={48}
                  alt={t("footer.google_play")}
                />
              )}
              {lang === "ht" && (
                <Image
                  className="w-full"
                  unoptimized
                  quality={100}
                  src={"/google-play-ht.svg"}
                  width={168}
                  height={48}
                  alt={t("footer.google_play")}
                />
              )}
              {lang === "fr" && (
                <Image
                  className="w-full"
                  unoptimized
                  quality={100}
                  src={"/google-play-fr.svg"}
                  width={168}
                  height={48}
                  alt={t("footer.google_play")}
                />
              )}
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
