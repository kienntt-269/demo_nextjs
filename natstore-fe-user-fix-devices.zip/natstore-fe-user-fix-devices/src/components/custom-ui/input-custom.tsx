import React, { RefObject, useEffect, useRef } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";
import CloseIcon from "@/components/icons/close-icon";
import EyeOpenIcon from "@/components/icons/eye-open-icon";
import clsx from "clsx";
import EyeCloseIcon from "@/components/icons/eye-close-icon";
type Props = {
  inputProps?: React.ComponentProps<"input">;
  label?: string;
  isShadow?: boolean;
  value?: string;
  variant?: "text" | "email" | "password" | "file" | "number";
  isPassValue?: boolean;
  timeRenderDefaultValue?: number;
  formatValueRegex?: RegExp;
  isError?: boolean;
  classNameWrapper?: string;
  disabled?: boolean;
  prefix?: string;
  onChange?: (event: React.ChangeEvent<HTMLInputElement>) => void;
};

const InputCustom = ({
  inputProps = {},
  label,
  isShadow = true,
  value: defaultValue = "",
  variant = "text",
  isPassValue,
  formatValueRegex,
  isError,
  classNameWrapper,
  prefix,
  onChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    console.log({ event });
  },
}: Props) => {
  const inputRef = useRef<HTMLInputElement>();
  const [value, setValue] = React.useState<string>(defaultValue);
  const [type, setType] = React.useState<string>(variant);
  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    let value = event.target.value;

    if (inputProps.maxLength) {
      if (value.length > inputProps.maxLength) {
        event.preventDefault();
        return;
      }
    }
    if (formatValueRegex) {
      value = value.replace(formatValueRegex, "");
    }
    // if (inputRef.current) inputRef.current.value = value;
    setValue(value);
    onChange?.(event);
  };

  const handleClearValue = () => {
    setValue("");
    onChange?.({
      target: { value: "" },
    } as React.ChangeEvent<HTMLInputElement>);
    inputRef.current?.focus();
  };

  const handleChangeType = () => {
    setType(type === "text" ? "password" : "text");
  };

  useEffect(() => {
    if (isPassValue) {
      setValue(defaultValue);
    }
  }, [defaultValue, isPassValue]);

  return (
    <div className={cn("w-full", classNameWrapper)}>
      {!!label && (
        <div className="mb-2">
          <Label
            className="text-neutral-dark-01 text-sm md:text-base"
            htmlFor="email"
          >
            {label}
          </Label>
        </div>
      )}
      <div className="relative w-full">
        {prefix && (
          <Input
            className="absolute h-12 w-[55px] lg:w-[58px] py-3 pl-4 pr-0 z-10 outline-none border-b-2 border-transparent bg-transparent text-sm lg:text-base text-neutral-dark3 lg:text-neutral-dark-04 pointer-events-none"
            style={{ letterSpacing: "-0.41px" }}
            value={prefix}
          />
        )}
        <Input
          {...inputProps}
          disabled={inputProps.disabled}
          ref={inputRef as RefObject<HTMLInputElement>}
          type={type}
          value={value}
          onChange={handleChange}
          isError={isError}
          className={cn(
            "w-full h-12 rounded-xl !placeholder-[#A2A2A2] placeholder-font-normal placeholder-opacity-0",
            {
              "shadow-input-custom": isShadow,
              "pr-12": true,
              "pr-24": variant === "password",
              "pl-[52px] lg:pl-[58px]": !!prefix,
            },
            inputProps.className
          )}
        />
        {!!value && !inputProps.disabled && (
          <div
            className={clsx(
              "absolute top-1/2 -translate-y-1/2 h-7 w-7 text-gray-500 hover:text-gray-900 dark:text-gray-400 dark:hover:text-gray-100 cursor-pointer flex justify-center items-center",
              variant === "password" ? "right-14" : "right-4"
            )}
            onClick={handleClearValue}
          >
            <CloseIcon />
          </div>
        )}
        {variant === "password" && (
          <div
            className={clsx(
              "absolute right-4 top-1/2 -translate-y-1/2 h-7 w-7 text-gray-500 hover:text-gray-900 dark:text-gray-400 dark:hover:text-gray-100 cursor-pointer flex justify-center items-center"
            )}
            onClick={handleChangeType}
          >
            {type === "text" ? <EyeCloseIcon /> : <EyeOpenIcon />}
          </div>
        )}
      </div>
    </div>
  );
};

export default InputCustom;
