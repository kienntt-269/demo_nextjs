"use client";
import InputCustom from "@/components/custom-ui/input-custom";
import { FieldWrapper } from "@/components/form";
import React, { useState } from "react";
import { FieldError } from "react-hook-form";

type InputPhoneNumberProps = {
  label?: string;
  isPrefix?: boolean;
  required?: boolean;
  error?: FieldError;
  className?: string;
  classNameLabel?: string;
  onChange?: (value: string) => void;
};

const InputPhoneNumber = ({
  label,
  isPrefix = true,
  required,
  error,
  className,
  classNameLabel,
  onChange,
  ...rest
}: InputPhoneNumberProps) => {
  const [value, setValue] = useState("");

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formattedValue = e.target.value.replace(/[^0-9+]+/g, ""); // Remove invalid characters
    setValue(formattedValue);
    if (onChange) {
      onChange(formattedValue);
    }
  };

  return (
    <FieldWrapper
      label={label}
      error={error}
      required={required}
      className={className}
      classNameLabel={classNameLabel}
    >
      <InputCustom
        isError={!!error}
        formatValueRegex={/[^0-9+]+/g}
        prefix={isPrefix ? "+509" : ""}
        isPassValue
        value={value}
        onChange={handleChange}
        inputProps={{
          maxLength: 8,
          ...rest,
        }}
      />
    </FieldWrapper>
  );
};

export default InputPhoneNumber;
