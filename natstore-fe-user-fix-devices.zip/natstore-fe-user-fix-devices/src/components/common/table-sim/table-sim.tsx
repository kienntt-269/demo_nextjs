"use client";
import React, { useEffect, useState } from "react";
import { useTranslations } from "next-intl";

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { IColumnTable } from "@/types/common";
import PaginationCustom from "@/components/pagination-custom";
import { usePathname, useRouter } from "next/navigation";
import {
  ISimCard,
  ISimCardListRes,
  ISimType,
} from "@/schemaValidations/sim-card.schema";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useSimCardStore } from "@/_stores/useSimCard.store";
import Image from "next/image";

interface ITableSim {
  response?: ISimCardListRes;
  searchParams: { [key in string]: string };
  simType: ISimType;
}

export function TableSIM({ response, searchParams, simType }: ITableSim) {
  const t = useTranslations();
  const router = useRouter();
  const { setSimDetail } = useSimCardStore();
  // const [open, setOpen] = useState<boolean>(false);
  const [chooseSim, setChooseSim] = useState<string | number>();
  const pathname = usePathname();
  const [total, setTotal] = useState<number>(0);
  const [page, setPage] = useState<number>(1);
  useEffect(() => {
    setSimDetail({} as ISimCard);

    setTotal(response?.data?.total_records ?? 0);
    setPage(response?.data?.current_page ?? 0);
    if (searchParams?.chooseSim) {
      const detail = response?.data.pagination.find(
        (val) => val.id == searchParams?.chooseSim
      );
      setChooseSim(Number(searchParams?.chooseSim));
      setSimDetail(detail as ISimCard);
    }
  }, [searchParams]);

  const updateSearchParams = (
    newParams: Record<string, string | null> | { [x: string]: boolean }
  ) => {
    const params = new URLSearchParams(searchParams);

    Object.entries(newParams).forEach(([key, value]) => {
      if (value === null) {
        params.delete(key);
      } else {
        params.set(key, value);
      }
    });
    return `?${params.toString()}`;
  };
  const column: IColumnTable<ISimCard>[] = [
    {
      header: t("common.no"),
      key: "id",
      classStyleHeader:
        "pl-8 w-[250px] 2xl:w-[300px] max-md:pl-3 max-xl:w-auto",
      render: (value, record, i) => {
        return (
          <div className="text-[20px] max-md:w-[20px] max-md:text-[14px] font-bold">
            <div>{page * 10 - 10 + i + 1}</div>
          </div>
        );
      },
    },

    {
      header: t("common.sim_number"),
      key: "phone",
      render: (value, record) => {
        return (
          <div className="text-[20px] max-md:text-[14px] max-md:w-[100px] font-bold max-md:font-normal">
            <div>{record?.isdn}</div>
          </div>
        );
      },
      classStyleHeader: "max-md:px-3",
    },
    {
      header: t("common.price"),
      key: "price",
      render: (value, record) => {
        return (
          <div className="text-primary font-bold text-[20px] max-md:text-[14px] flex gap-x-1">
            <div> {Number(record.price).toLocaleString("en-US")}</div>
            <div>{t("mobile_package.htg")}</div>
          </div>
        );
      },
      classStyleHeader: "max-xl:w-auto max-md:px-3",
    },
    {
      header: t("mobile_package.type_card"),
      key: "cycle",
      render: (value, record) => {
        return (
          <div className="text-[20px] max-md:text-[14px] max-md:w-[100px] font-bold">
            <div>{record?.typeCard ?? "-"}</div>
          </div>
        );
      },
      classStyleHeader: "max-md:px-3",
    },
    {
      header: "",
      key: "id",
      render: (value, record) => {
        return (
          <div className="flex items-center justify-center">
            <RadioGroup value={`${chooseSim}`}>
              <div className="flex items-center space-x-2">
                <RadioGroupItem
                  onClick={() => {
                    console.log(record);
                    setChooseSim(record?.id ?? "");
                    setSimDetail(record);
                  }}
                  value={`${record?.id ?? ""}`}
                  id={record?.id ?? ""}
                  className="border border-solid border-primary"
                />
              </div>
            </RadioGroup>
          </div>
        );
      },
      classStyleHeader: "max-md:px-3",
    },
  ];

  const simTypeChange = () => {
    switch (searchParams.type) {
      case "1":
        return t("mobile_package.sim_normal.xchange_sim");
      case "2":
        return t("mobile_package.sim_normal.student_sim");
      case "3":
        return t("mobile_package.sim_normal.dcom_sim");
      default:
        return t("mobile_package.sim_normal.xchange_sim");
    }
  };

  const simTypeChangeBg = () => {
    switch (searchParams.type) {
      case "1":
        return "md:bg-[url('/mobile-package/bg_description_sim.png')]";
      case "2":
        return "md:bg-[url('/mobile-package/student-sim.png')]";
      case "3":
        return "md:bg-[url('/mobile-package/d-com-sim.png')]";
      default:
        return "md:bg-[url('/mobile-package/bg_description_sim.png')]";
    }
  };
  return (
    <div>
      <div className="mt-6 max-md:mt-4">
        <div
          className={`${simTypeChangeBg()} w-full relative h-80 max-xl:h-60 max-2xl:h-72 max-lg:h-44 max-md:h-[149px] max-md:rounded-2xl overflow-hidden max-md:bg-primary bg-[url('/mobile-package/bg_description_sim_mob.png')] bg-no-repeat bg-contain p-0 border-0 max-md:p-4`}
          style={{
            backgroundSize: "100% 100%",
          }}
        >
          <div className="absolute max-md:hidden top-0 left-0 w-[58.5%] py-[71px] max-2xl:py-16 max-xl:py-10 px-14 h-full text-white font-bold">
            <div className="text-[32px] max-xl:text-[24px]">
              {simTypeChange()}
            </div>
            <div className="mt-6 max-xl:mt-3 text-2xl max-xl:text-[18px] line-clamp-4 max-2xl:line-clamp-3 max-lg:line-clamp-2">
              {simType.value}
            </div>
          </div>
          <div className="hidden max-md:block text-white font-bold">
            <div className="text-base">{simTypeChange()}</div>
            <div className="mt-4 line-clamp-4 text-xs">{simType.value}</div>
          </div>
        </div>
        <div className="mt-6 max-md:mt-4">
          <Table className="rounded-t-lg md:rounded-t-2xl overflow-hidden">
            <TableHeader className="bg-[#212121] text-white h-14 max-md:h-8">
              <TableRow className="hover:bg-[#212121]">
                {column.map((col, index) => (
                  <TableHead
                    key={`header-table${index}`}
                    className={`text-white font-bold text-xl max-md:text-[12px] ${col.classStyleHeader}`}
                  >
                    {col.header}
                  </TableHead>
                ))}
              </TableRow>
            </TableHeader>
            <TableBody className="bg-white">
              {response?.data?.pagination &&
                response?.data?.pagination.length > 0 &&
                response?.data.pagination?.map((row, indexRow) => (
                  <TableRow
                    key={indexRow}
                    onClick={() => {
                      setChooseSim(row?.id ?? "");
                      setSimDetail(row);
                    }}
                    className={`text-xl h-20 max-md:h-[54px] hover:bg-[#ffebd6] ${chooseSim === row.id ? "bg-[#ffebd6]" : ""}`}
                  >
                    {column.map((col, i) => (
                      <TableCell
                        className={`font-bold text-neutral-dark-02 ${col.classStyleHeader}`}
                        key={i}
                      >
                        {col?.render
                          ? col.render(
                              row[col.key as keyof typeof row],
                              row,
                              indexRow
                            )
                          : (row as unknown as Record<string, string>)[col.key]}
                      </TableCell>
                    ))}
                  </TableRow>
                ))}
            </TableBody>
          </Table>
          {response?.data?.pagination.length === 0 && (
            <div className="py-28 max-lg:py-12 max-md:py-4 max-lg:h-auto text-neutral-dark-03 bg-[white] flex flex-col items-center justify-center w-full">
              <Image
                src={"/unavailable.svg"}
                alt=""
                unoptimized
                quality={100}
                className="object-contain max-lg:w-[400px] max-lg:h-[200px]"
                width={600}
                height={600}
              />
              <div className="text-[28px] max-lg:text-[20px] font-bold mt-4 max-lg:mt-2">
                {t("mobile_package.no_sim_found")}
              </div>
              <div className="text-[20px] max-lg:text-[14px] font-normal mt-4 max-lg:mt-2">
                {t("mobile_package.please_try_another_number")}
              </div>
            </div>
          )}
        </div>
        {total > 0 && (
          <div className="mt-6 max-md:mt-3">
            <PaginationCustom
              totalItems={total}
              itemsPerPage={10}
              current={page}
              onChange={(value) => {
                router.push(
                  `${pathname}${updateSearchParams({
                    page: `${value}`,
                  })}`,
                  {
                    scroll: false,
                  }
                );
              }}
            />
          </div>
        )}
      </div>
    </div>
  );
}

export default TableSIM;
