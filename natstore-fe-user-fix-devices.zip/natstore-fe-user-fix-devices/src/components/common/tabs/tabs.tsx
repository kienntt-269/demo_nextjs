import React from "react";
import Link from "next/link";
import { TabsProps } from "@/types/package";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { truncateText } from "@/lib/utils";

const TabsCommon: React.FC<TabsProps> = ({
  data,
  defaultTab,
  textLength = 50,
}) => {
  return (
    <Tabs
      value={defaultTab}
      defaultValue={defaultTab ? defaultTab : String(data?.[0]?.id)}
    >
      <TabsList>
        {data.map((item) => (
          <TabsTrigger
            key={item.id}
            value={String(item.id)}
            className="transition-colors duration-300 ease-in-out hover:text-[hsl(var(--primary))] relative h-9 data-[state=active]:text-primary data-[state=active]:after:content-[''] data-[state=active]:after:absolute data-[state=active]:after:left-0 data-[state=active]:after:top-8 data-[state=active]:after:w-full data-[state=active]:after:h-2 data-[state=active]:after:bg-[#FF8600] data-[state=active]:after:rounded-full data-[state=active]:after:clip-path-[ellipse(100%_100%_at_center_bottom)]"
            asChild
          >
            {item.params.includes("?") ? (
              <Link scroll={false} href={item?.params || "#"}>
                {truncateText(item.label, textLength)}
              </Link>
            ) : (
              <div>{truncateText(item.label, textLength)}</div>
            )}
          </TabsTrigger>
        ))}
      </TabsList>
      <div className="mt-3 lg:mt-10">
        {data.map((item) => (
          <TabsContent key={item.id} value={String(item.id)}>
            {item.content}
          </TabsContent>
        ))}
      </div>
    </Tabs>
  );
};

export default TabsCommon;
