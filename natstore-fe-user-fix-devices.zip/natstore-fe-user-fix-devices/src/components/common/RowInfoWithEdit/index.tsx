import InputCustom from "@/components/custom-ui/input-custom";
import CloseIcon from "@/components/icons/close-icon";
import EditIcon from "@/components/icons/edit-icon";
import { Button } from "@/components/ui/button";
import { useTranslations } from "next-intl";
import React, { useEffect, useRef, useState } from "react";
import { z } from "zod";

type Props = {
  value: string;
  placeholder?: string;
  maxLength?: number;
  onSubmit: (value: string) => Promise<boolean | undefined>;
  validateFunc?: (value: string) => z.ZodIssue | null;
};

const RowInfoWithEdit = ({
  value,
  placeholder,
  maxLength,
  onSubmit,
  validateFunc,
}: Props) => {
  const t = useTranslations();
  const isAmounted = useRef<boolean>();
  const [valueState, setValueState] = useState(value);
  const [mode, setMode] = useState<"view" | "edit">("view");
  const [errorState, setErrorState] = useState<{ message: string } | null>(
    null
  );

  const handleChangeValue = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (maxLength && valueState.length > maxLength) {
      e.preventDefault();
      return;
    }
    setValueState(e.target.value?.trim());
  };

  const handleSubmit = async () => {
    if (errorState?.message) return;
    if (validateFunc) {
      const er = validateFunc(valueState);
      if (er) {
        setErrorState(er);
        return;
      }
    }
    const res = await onSubmit(valueState);
    console.log({ res });
    if (!res) return;
    setMode("view");
  };

  useEffect(() => {
    setValueState(value);
  }, [value]);

  useEffect(() => {
    if (!isAmounted.current) {
      isAmounted.current = true;
      return;
    }

    if (validateFunc) {
      setErrorState(validateFunc(valueState));
    }
  }, [valueState]);

  return (
    <>
      <div className="flex items-center gap-2 w-full">
        {mode === "view" ? (
          <>
            <span
              className="text-base lg:text-lg"
              style={{ wordBreak: "break-word" }}
            >
              {valueState}
            </span>
            <span
              className="cursor-pointer"
              onClick={() => {
                setMode("edit");
              }}
            >
              <EditIcon />
            </span>
          </>
        ) : (
          <>
            <InputCustom
              classNameWrapper="flex-1 max-w-[448px]"
              value={valueState}
              onChange={handleChangeValue}
              inputProps={{
                placeholder: placeholder,
              }}
            />
            <Button
              className="font-bold rounded-3xl !h-[32px]"
              onClick={handleSubmit}
            >
              {t("common.save")}
            </Button>
            <div>
              <Button
                variant="secondary"
                className="font-bold rounded-3xl !w-[32px] !h-[32px]"
                onClick={async () => {
                  setValueState(value);
                  setMode("view");
                }}
              >
                <CloseIcon />
              </Button>
            </div>
          </>
        )}
      </div>
      {errorState?.message && mode === "edit" && (
        <div
          role="alert"
          aria-label={errorState.message}
          className="mt-1 text-xs sm:text-sm text-error"
        >
          {t(`common.message.${errorState.message}`)}
        </div>
      )}
    </>
  );
};

export default RowInfoWithEdit;
