"use client";

import React from "react";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { cn } from "@/lib/utils";

type ModalProps = React.ComponentProps<typeof Dialog> & {
  isOpen: boolean;
  contentClassName?: string;
  onClose: (open: boolean) => void;
  children: React.ReactNode;
  title?: string;
  subTitle?: string;
  contentChildWrapper?: string;
  onInteractOutside?: (e: CustomEvent) => void;
};

const Modal = ({
  isOpen,
  contentClassName = "",
  contentChildWrapper = "",
  onClose,
  children,
  title,
  subTitle,
  onInteractOutside,
  ...props
}: ModalProps) => {
  return (
    <Dialog {...props} open={isOpen} onOpenChange={onClose}>
      <DialogContent
        title={title}
        subTitle={subTitle}
        className={cn("rounded-2xl", contentClassName)}
        // onOpenAutoFocus={(e) => e.preventDefault()}
        onInteractOutside={onInteractOutside}
      >
        <div
          className={cn(
            "px-0 md:px-2 max-h-[calc(90vh-104px)] overflow-y-auto",
            contentChildWrapper
          )}
        >
          {children}
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default Modal;
