import React from "react";
import { Search } from "lucide-react";
import { cn } from "@/lib/utils";

type Props = {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  className?: string;
  inputClassName?: string;
};

const SearchInput: React.FC<Props> = ({
  value,
  onChange,
  placeholder = "Search",
  className = "",
  inputClassName = "",
}) => {
  return (
    <div className={`relative w-full ${className}`}>
      <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
      <input
        type="text"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className={cn(
          "w-full pl-10 pr-4 py-1.5 bg-[#F5F6F7] rounded-3xl  focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent",
          inputClassName
        )}
      />
    </div>
  );
};

export default SearchInput;
