import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";
import clsx from "clsx";
import { useTranslations } from "next-intl";
import * as React from "react";
import { FieldError } from "react-hook-form";

type FieldWrapperProps = {
  label?: string;
  className?: string;
  classNameLabel?: string;
  children: React.ReactNode;
  error?: (FieldError & { data?: { [key: string]: string } }) | undefined;
  description?: string;
  required?: boolean;
  label2?: React.ReactNode;
};

export type TFieldWrapperPassThroughProps = Omit<
  FieldWrapperProps,
  "className" | "children"
>;

export const FieldWrapper = (props: FieldWrapperProps) => {
  const {
    label,
    label2,
    className,
    classNameLabel,
    error,
    required,
    children,
  } = props;
  const t = useTranslations("common.message");
  return (
    <div className={clsx("", className)}>
      <div>
        {(label || label2) && (
          <div className="flex justify-between mb-2 items-center">
            {label && (
              <Label
                className={cn(
                  "text-neutral-dark-01 text-sm md:text-base",
                  classNameLabel
                )}
              >
                {label}
                {required && <span className="text-red-500">*</span>}
              </Label>
            )}
            {label2}
          </div>
        )}
      </div>
      <div className="">{children}</div>
      {!!error?.message && (
        <div
          role="alert"
          aria-label={t(error.message)}
          className="mt-1 font-normal lg:mt-2 text-xs lg:text-sm text-error"
        >
          {t(error.message, error.data || {})}
        </div>
      )}
    </div>
  );
};
