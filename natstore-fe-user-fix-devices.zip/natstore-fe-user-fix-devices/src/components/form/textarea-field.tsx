import clsx from "clsx";
import { UseFormRegisterReturn } from "react-hook-form";

import { FieldWrapper, TFieldWrapperPassThroughProps } from "./field-wrapper";

type TTextAreaFieldProps = TFieldWrapperPassThroughProps & {
  className?: string;
  placeholder?: string;
  registration: Partial<UseFormRegisterReturn>;
};

export const TextAreaField = (props: TTextAreaFieldProps) => {
  const { label, className, registration, error, ...rest } = props;
  return (
    <FieldWrapper label={label} error={error}>
      <textarea
        className={clsx(
          "block w-full appearance-none rounded-md border px-3 py-2 text-sm",
          className,
        )}
        {...rest}
        {...registration}
      />
    </FieldWrapper>
  );
};
