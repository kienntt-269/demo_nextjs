import ErrorPage from "@/components/error";
import RefreshAccessToken from "@/components/refresh-accesstoken";
import { HttpError } from "@/lib/http";
import React from "react";

type Props = {
  error: unknown | HttpError;
};

export default function ServerError({ error }: Props) {
  if (error instanceof HttpError) {
    if (error?.status === 401 || error?.status === 412) {
      return <RefreshAccessToken />;
    }
  }

  return <ErrorPage />;
}
