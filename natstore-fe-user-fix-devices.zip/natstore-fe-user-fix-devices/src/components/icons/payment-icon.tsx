import React from "react";

const PaymentIcon = () => {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width={24} height={24} fill="none">
      <path
        stroke="#000"
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth={1.5}
        d="M2 11.639a10 10 0 1 0 20 0 10 10 0 0 0-20 0v0Z"
      />
      <path
        stroke="#000"
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth={1.5}
        d="M2 11.639a10 10 0 1 0 20 0 10 10 0 0 0-20 0v0Z"
      />
      <path
        stroke="#000"
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth={1.5}
        d="M10 13.639a2 2 0 1 0 2-2 2 2 0 1 1 2-2M12 6.305v1.333M12 15.639v1.333"
      />
    </svg>
  );
};

export default PaymentIcon;
