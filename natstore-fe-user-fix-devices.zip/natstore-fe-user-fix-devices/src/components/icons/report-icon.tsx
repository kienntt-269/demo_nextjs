import React from "react";

const ReportIcon = () => {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width={24} height={24} fill="none">
      <path
        stroke="#000"
        strokeWidth={0.125}
        d="m16.563 9.724-.02-.018-3.75-3.75-.017-.019H7.563V3.75a.688.688 0 0 1 .687-.688h7.475l3.713 3.713V17.25a.687.687 0 0 1-.688.688h-2.188V9.723Z"
      />
      <path
        stroke="#000"
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth={1.5}
        d="M15.75 21H5.25a.75.75 0 0 1-.75-.75V6.75A.75.75 0 0 1 5.25 6h7.5l3.75 3.75v10.5a.75.75 0 0 1-.75.75Z"
      />
      <path
        stroke="#000"
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth={1.5}
        d="M7.5 6V3.75A.75.75 0 0 1 8.25 3h7.5l3.75 3.75v10.5a.75.75 0 0 1-.75.75H16.5M8.25 14.25h4.5M8.25 17.25h4.5"
      />
    </svg>
  );
};

export default ReportIcon;
