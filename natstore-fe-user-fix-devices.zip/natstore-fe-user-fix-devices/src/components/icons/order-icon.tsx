import React from "react";

const OrderIcon = () => {
  return (
    <svg
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M20.3333 20.3073C20.3333 20.6609 20.1929 21.0001 19.9428 21.2501C19.6928 21.5002 19.3536 21.6406 19 21.6406H4.33333C3.97971 21.6406 3.64057 21.5002 3.39052 21.2501C3.14048 21.0001 3 20.6609 3 20.3073V2.97396C3 2.62034 3.14048 2.2812 3.39052 2.03115C3.64057 1.7811 3.97971 1.64063 4.33333 1.64062H13.7813C14.1347 1.6407 14.4736 1.78105 14.7236 2.03085L19.9431 7.2504C20.1929 7.50036 20.3333 7.83925 20.3333 8.19262V20.3073Z"
        stroke="black"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M10.26 7.88672L8.36492 10.4129C8.30759 10.4893 8.23453 10.5524 8.15068 10.5981C8.06683 10.6437 7.97415 10.6709 7.87892 10.6776C7.78368 10.6843 7.68811 10.6706 7.59866 10.6372C7.50922 10.6038 7.42799 10.5516 7.36048 10.4841L6.33203 9.4565"
        stroke="black"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M10.26 13.8867L8.36492 16.4129C8.30759 16.4893 8.23453 16.5524 8.15068 16.5981C8.06683 16.6437 7.97415 16.6709 7.87892 16.6776C7.78368 16.6844 7.68811 16.6706 7.59866 16.6372C7.50922 16.6038 7.42799 16.5516 7.36048 16.4841L6.33203 15.4556"
        stroke="black"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M13 10.6797H17"
        stroke="black"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M13 16.0156H17"
        stroke="black"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
};

export default OrderIcon;
