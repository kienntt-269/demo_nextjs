"use client";

import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Tree, TreeDataItem } from "@/components/ui/TreeMenu";
import { useTranslations } from "next-intl";
import Image from "next/image";
import Link from "next/link";
import { useDialogAuthStore } from "@/_stores/useDialogAuth.store";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { IDataListMenu } from "@/schemaValidations/list-menu.chema";
import LanguageSelect from "@/components/language-select";
import { Locale } from "@/i18n/config";
import OrderTrackingIcon from "@/components/icons/order-tracking-icon";
export default function MobileMenu({
  isLogin,
  listMenu,
  locale,
}: {
  isLogin: boolean;
  listMenu?: IDataListMenu[];
  locale: Locale;
}) {
  const [isOpenMenu, setIsOpenMenu] = useState(false);
  const t = useTranslations();
  const [selectedItem, selectItem] = useState<string>("home");
  const { setIsOpen } = useDialogAuthStore();
  const router = useRouter();
  const [isOpenSearch, setIsOpenSearch] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [history, setHistory] = useState<string[]>([]);
  const searchParams = useSearchParams();
  const pathname = usePathname();

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      handleSearch();
      (e.target as HTMLInputElement).blur();
    }
  };
  const updateSearchHistory = (
    term: string,
    updateHistoryFn: React.Dispatch<React.SetStateAction<string[]>>
  ) => {
    const trimmed = term.trim();
    if (!trimmed) return;

    updateHistoryFn((prev: string[]) => {
      const updated = [
        trimmed,
        ...prev.filter((item: string) => item !== trimmed),
      ].slice(0, 5);
      localStorage.setItem("search_history", JSON.stringify(updated));
      return updated;
    });
  };

  const handleSearch = () => {
    if (!searchTerm.trim()) return;

    updateSearchHistory(searchTerm, setHistory);
    router.push(
      `/search?key=${encodeURIComponent(searchTerm.trim())}&parent=packages`
    );
  };

  useEffect(() => {
    const value = searchParams.get("key") || "";
    setSearchTerm(value);
    updateSearchHistory(value, setHistory);
  }, [searchParams.toString()]);

  useEffect(() => {
    const value = searchParams.get("key") || "";
    setSearchTerm(value);
    if (isOpenMenu || isOpenSearch) {
      setIsOpenMenu(false);
      setIsOpenSearch(false);
    }
  }, [searchParams.toString(), pathname]);

  const handleClearHistory = () => {
    localStorage.removeItem("search_history");
    setHistory([]);
  };

  const handleRemove = (indexToRemove: number) => {
    const updatedHistory = history.filter(
      (_, index) => index !== indexToRemove
    );
    setHistory(updatedHistory);
    localStorage.setItem("search_history", JSON.stringify(updatedHistory));
  };
  const searchRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: PointerEvent) => {
      if (
        searchRef.current &&
        !searchRef.current.contains(event.target as Node)
      ) {
        setIsOpenSearch(false);
      }
    };

    document.addEventListener("pointerdown", handleClickOutside);
    return () => {
      document.removeEventListener("pointerdown", handleClickOutside);
    };
  }, []);
  return (
    <div className="relative flex items-center h-16 w-full">
      <div className="flex justify-between items-center w-full">
        <div className="flex gap-3 items-center">
          <Button
            onClick={() => setIsOpenMenu(true)}
            className="text-white rounded-lg !p-0"
            variant={"ghost"}
          >
            <Image
              unoptimized
              quality={100}
              src={"/svg/hamburger.svg"}
              width={24}
              height={24}
              alt="hamburger image"
            />
          </Button>
          <Link href={"/"}>
            <Image
              unoptimized
              quality={100}
              src={"/natcom.svg"}
              width={71}
              height={15}
              alt="natcom image"
            />
          </Link>
        </div>
        <div className="flex items-center gap-4">
          <div className=" flex items-center gap-1">
            <div className="w-full" id="search-result" ref={searchRef}>
              <Button
                variant={"link"}
                className="!p-0 "
                onClick={() => setIsOpenSearch(true)}
              >
                <Image
                  unoptimized
                  quality={100}
                  src={"/svg/search-mobile.svg"}
                  width={24}
                  height={24}
                  alt="search image"
                  className="max-md:size-6"
                />
              </Button>

              {isOpenSearch && (
                <div className="absolute z-[999999] left-0 w-full flex-col bg-white text-black shadow-lg p-4 rounded-md ">
                  <div className="flex items-center border border-none bg-[#E3E4E5] rounded-3xl h-8 mb-4">
                    <Image
                      unoptimized
                      quality={100}
                      src={"/svg/search.svg"}
                      width={16}
                      height={16}
                      alt="search image"
                      className="max-md:size-4 ml-4 mr-2"
                    />
                    <div className="relative w-full">
                      <input
                        type="text"
                        placeholder={t("common.search")}
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        onKeyDown={handleKeyDown}
                        className="w-full bg-transparent outline-none text-gray-700 placeholder:text-neutral-mid-01 pr-8" // tăng pr để tránh nút x đè
                      />

                      {searchTerm && (
                        <button
                          type="button"
                          onClick={() => setSearchTerm("")}
                          className="absolute flex items-center right-3  top-[10px]  -translate-y-1/2 text-gray-400 hover:text-gray-600"
                        >
                          &times;
                        </button>
                      )}
                    </div>
                  </div>
                  <div className="flex justify-between mb-4">
                    <div
                      className="font-bold text-sm text-neutral-dark-01"
                      onClick={handleSearch}
                    >
                      {t("search.search_history")}
                    </div>
                    {history.length > 0 && (
                      <div
                        className="font-bold text-xs text-primary cursor-pointer"
                        onMouseDown={(e) => {
                          e.preventDefault();
                          handleClearHistory();
                        }}
                      >
                        {t("search.clear_history")}
                      </div>
                    )}
                  </div>
                  {
                    <div className=" flex flex-col overflow-y-auto max-h-96">
                      {" "}
                      {history.map((item, index) => (
                        <div
                          key={index}
                          className="flex justify-between items-center cursor-pointer mb-4 overflow-visible hover:bg-gray-100 hover:text-primary rounded-md"
                        >
                          <Link
                            className="flex-1"
                            href={`/search?key=${item}&parent=packages`}
                            key={index}
                            onClick={(e) => {
                              (e.target as HTMLInputElement).blur();
                            }}
                          >
                            <span style={{ wordBreak: "break-word" }}>
                              {item}
                            </span>
                          </Link>

                          <Button
                            variant={"ghost"}
                            onClick={() => handleRemove(index)}
                          >
                            <X size={20} className="!p-0" color="black" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  }
                </div>
              )}
            </div>
          </div>
          {/* <Button variant={"link"} className="!p-0">
            <Image
              unoptimized
              quality={100}
              src={"/shopping-cart.svg"}
              width={24}
              height={24}
              alt="shopping image"
              className="max-md:size-6"
            />
          </Button> */}
          <Link href={"/order-tracking"}>
            <OrderTrackingIcon />
          </Link>
          <LanguageSelect defaultLocale={locale} />

          {isLogin ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Avatar className="w-6 h-6">
                  <AvatarImage src="https://github.com/shadcn.png" />
                  <AvatarFallback>CN</AvatarFallback>
                </Avatar>
              </DropdownMenuTrigger>
              <DropdownMenuContent
                align="end"
                className="w-[226px] p-4 flex flex-col gap-2.5 rounded-2xl"
              >
                <DropdownMenuItem
                  className="font-bold text-neutral-dark-02 cursor-pointer "
                  onClick={() => {
                    router.push("/personal");
                  }}
                >
                  {t("homePage.accountInformation")}
                </DropdownMenuItem>
                <DropdownMenuItem
                  className="font-bold text-neutral-dark-02 cursor-pointer "
                  onClick={() => {
                    router.push("/personal?type=change-password");
                  }}
                >
                  {t("homePage.changePassword")}
                </DropdownMenuItem>
                <DropdownMenuItem
                  className="font-bold text-neutral-dark-02 cursor-pointer "
                  onClick={() => setIsOpen({ isOpen: true, mode: "LOGOUT" })}
                >
                  {t("homePage.logout")}
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <Button
              variant={"link"}
              className="!p-0"
              onClick={() => setIsOpen({ isOpen: true, mode: "LOGIN" })}
            >
              <Image
                unoptimized
                quality={100}
                src={"/user.svg"}
                width={24}
                height={24}
                alt="user image"
                className="max-md:size-6"
              />
            </Button>
          )}
        </div>
      </div>

      {isOpenMenu && (
        <div
          className="fixed inset-0 z-40 bg-black bg-opacity-50"
          onClick={() => setIsOpenMenu(false)}
        ></div>
      )}

      <motion.div
        initial={{ x: "-100%" }}
        animate={{ x: isOpenMenu ? 0 : "-100%" }}
        transition={{ type: "spring", stiffness: 100, damping: 15 }}
        className="fixed inset-y-0 left-0 z-50 w-[80%] h-full bg-white shadow-lg"
      >
        <div className="flex justify-end p-4">
          <Button
            onClick={() => setIsOpenMenu(false)}
            variant={"link"}
            className="!p-0"
          >
            <X size={28} className="!p-0" color="black" />
          </Button>
        </div>

        <Tree
          data={listMenu || ({} as TreeDataItem[])}
          className="flex-shrink-0 w-full h-full max-h-[calc(100vh-80px)]"
          initialSlelectedItemId={selectedItem}
          onSelectChange={(item) => {
            selectItem(item?.id ?? "home");
          }}
        />
      </motion.div>
    </div>
  );
}
