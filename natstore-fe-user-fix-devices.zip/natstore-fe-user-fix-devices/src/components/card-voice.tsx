"use client";
import React from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { ICardVoice } from "@/types/package";

type IPropsCard = {
  data?: ICardVoice;
  action?: () => void;
  onRegister?: () => void;
  type: "large" | "medium";
};

const CardVoice: React.FC<IPropsCard> = ({
  data,
  type = "medium",
  action,
  onRegister,
}) => {
  return (
    <Card
      className="rounded-3xl max-md:rounded-2xl overflow-hidden border-none"
      style={{
        boxShadow: "0px 3.09px 12.37px 0px #00000014",
      }}
      onClick={() => {
        if (action) action();
      }}
    >
      <CardHeader
        className={`p-0 text-center space-y-0  ${
          type === "large" ? "" : " py-5"
        }`}
      >
        <div className="font-bold text-2xl">{data?.title}</div>
      </CardHeader>
      <CardContent>
        <div className="pt-4">
          <div className="flex items-center justify-center mb-6">
            <div className="text-[28px] text-primary font-bold mr-2">
              {data?.price}
            </div>
            <span className="text-xl text-primary font-semibold">
              {data?.day}
            </span>
          </div>
          <div className="text-sm text-neutral-dark-04 font-normal">
            {data?.content}
          </div>
        </div>

        <button
          className={`mt-4 max-md:mt-3 max-md:h-8 max-md:text-[14px] h-8 md:h-12 flex items-center justify-center w-full border border-solid border-primary py-[13.5px] text-center text-primary font-semibold rounded-3xl  relative overflow-hidden group ${
            type === "large" ? "text-white bg-primary" : ""
          }`}
          onClick={() => {
            if (onRegister) onRegister();
          }}
        >
          <span className="z-10 relative group-hover:text-white">
            {data?.textBtn ?? "Detail"}
          </span>
          <span className="absolute inset-0 bg-primary transform -translate-x-full transition-transform duration-300 ease-in-out group-hover:translate-x-0"></span>
        </button>
      </CardContent>
    </Card>
  );
};

export default CardVoice;
