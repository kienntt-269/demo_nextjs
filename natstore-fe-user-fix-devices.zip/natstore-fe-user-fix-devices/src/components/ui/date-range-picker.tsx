/* eslint-disable max-lines */
"use client";

import React, { FC, useState, useEffect, useRef } from "react";
import { Button } from "./button";
import { Popover, PopoverContent, PopoverTrigger } from "./popover";
import { Calendar } from "./calendar";
import { Label } from "./label";
import { formatDate } from "@/lib/utils";
import CalendarIcon from "@/components/icons/calendar-icon";
import clsx from "clsx";
import { FORMAT_DATE } from "@/constants/common";
import { useTranslations } from "next-intl";

export interface DateRangePickerProps {
  onUpdate?: (values: { range: DateRange; rangeCompare?: DateRange }) => void;
  initialDateFrom?: Date | string;
  initialDateTo?: Date | string;
  align?: "start" | "center" | "end";
  label?: string;
  required?: boolean;
  format?: string;
}

interface DateRange {
  from: Date;
  to: Date | undefined;
}

const getDateAdjustedForTimezone = (dateInput: Date | string): Date => {
  if (typeof dateInput === "string") {
    const parts = dateInput.split("-").map((part) => parseInt(part, 10));
    return new Date(parts[0], parts[1] - 1, parts[2]);
  } else {
    return dateInput;
  }
};

export const DateRangePicker: FC<DateRangePickerProps> & {
  filePath: string;
} = ({
  initialDateFrom = new Date(new Date().setHours(0, 0, 0, 0)),
  initialDateTo,
  onUpdate,
  align = "center",
  label,
  required,
  format = FORMAT_DATE,
}) => {
  const t = useTranslations();
  const [isOpen, setIsOpen] = useState(false);

  const [range, setRange] = useState<DateRange>({
    from: getDateAdjustedForTimezone(initialDateFrom),
    to: initialDateTo
      ? getDateAdjustedForTimezone(initialDateTo)
      : getDateAdjustedForTimezone(initialDateFrom),
  });

  const openedRangeRef = useRef<DateRange>();

  const resetValues = (): void => {
    setRange({
      from:
        typeof initialDateFrom === "string"
          ? getDateAdjustedForTimezone(initialDateFrom)
          : initialDateFrom,
      to: initialDateTo
        ? typeof initialDateTo === "string"
          ? getDateAdjustedForTimezone(initialDateTo)
          : initialDateTo
        : typeof initialDateFrom === "string"
          ? getDateAdjustedForTimezone(initialDateFrom)
          : initialDateFrom,
    });
  };

  const areRangesEqual = (a?: DateRange, b?: DateRange): boolean => {
    if (!a || !b) return a === b;
    return (
      a.from.getTime() === b.from.getTime() &&
      (!a.to || !b.to || a.to.getTime() === b.to.getTime())
    );
  };

  useEffect(() => {
    if (isOpen) {
      openedRangeRef.current = range;
    }
  }, [isOpen]);

  return (
    <Popover
      modal={true}
      open={isOpen}
      onOpenChange={(open: boolean) => {
        if (!open) {
          resetValues();
        }
        setIsOpen(open);
      }}
    >
      <div
        className={clsx(
          "text-neutral-dark-01 md:font-bold !text-sm md:!text-base"
        )}
      >
        {label && (
          <div className="flex justify-between mb-2 items-center">
            <Label>
              {label}
              {required && <span className="text-red-500">*</span>}
            </Label>
          </div>
        )}
      </div>
      <PopoverTrigger asChild>
        <div className="flex items-center justify-between gap-6 h-12 rounded-xl border border-[#E3E4E5] input-box-shadow px-4 py-3">
          <div className="text-start">
            <div>
              <div>{`${formatDate(range.from, format)}${range.to != null ? " - " + formatDate(range.to, format) : ""}`}</div>
            </div>
          </div>
          <div>
            <CalendarIcon />
          </div>
        </div>
      </PopoverTrigger>
      <PopoverContent align={align} className="w-auto">
        <div className="flex py-2">
          <Calendar
            mode="range"
            onSelect={(value: { from?: Date; to?: Date } | undefined) => {
              if (value?.from != null) {
                setRange({ from: value.from, to: value?.to });
              }
            }}
            selected={range}
            numberOfMonths={2}
            defaultMonth={
              new Date(new Date().setMonth(new Date().getMonth() - 1))
            }
          />
        </div>
        <div className="flex justify-end gap-2 py-2 pr-4">
          <Button
            onClick={() => {
              setIsOpen(false);
              resetValues();
            }}
            variant="ghost"
          >
            
            {t("common.cancel")}
          </Button>
          <Button
            onClick={() => {
              setIsOpen(false);
              if (!areRangesEqual(range, openedRangeRef.current)) {
                onUpdate?.({ range });
              }
            }}
          >
            {t("common.update")}
          </Button>
        </div>
      </PopoverContent>
    </Popover>
  );
};

DateRangePicker.displayName = "DateRangePicker";
DateRangePicker.filePath =
  "libs/shared/ui-kit/src/lib/date-range-picker/date-range-picker.tsx";
