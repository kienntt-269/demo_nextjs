import React from "react";
import * as AccordionPrimitive from "@radix-ui/react-accordion";
import { type LucideIcon } from "lucide-react";
import useResizeObserver from "use-resize-observer";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";
import Link from "next/link";
import {
  Accordion,
  AccordionContent,
  AccordionTrigger,
} from "@/components/ui/accordion";

interface TreeDataItem {
  id: string;
  label: string;
  icon?: LucideIcon;
  url?: string;
  children?: TreeDataItem[];
  hidden?: boolean;
}

const iconProps = {
  width: 20,
  height: 20,
  color: "var(--destructive-foreground)",
};

type TreeProps = React.HTMLAttributes<HTMLDivElement> & {
  data: TreeDataItem[] | TreeDataItem;
  initialSlelectedItemId?: string;
  onSelectChange?: (item: TreeDataItem | undefined) => void;
  expandAll?: boolean;
  folderIcon?: LucideIcon;
};

const Tree = React.forwardRef<HTMLDivElement, TreeProps>(
  (
    {
      data,
      initialSlelectedItemId,
      onSelectChange,
      expandAll,
      folderIcon,
      className,
      ...props
    },
    ref
  ) => {
    const [selectedItemId, setSelectedItemId] = React.useState<
      string | undefined
    >(initialSlelectedItemId);

    const handleSelectChange = React.useCallback(
      (item: TreeDataItem | undefined) => {
        setSelectedItemId(item?.id);
        if (onSelectChange) {
          onSelectChange(item);
        }
      },
      [onSelectChange]
    );

    const expandedItemIds = React.useMemo(() => {
      if (!initialSlelectedItemId) {
        return [] as string[];
      }

      const ids: string[] = [];

      function walkTreeItems(
        items: TreeDataItem[] | TreeDataItem,
        targetId: string
      ) {
        if (items instanceof Array) {
          // eslint-disable-next-line @typescript-eslint/prefer-for-of
          for (let i = 0; i < items.length; i++) {
            ids.push(items[i]!.id);
            if (walkTreeItems(items[i]!, targetId) && !expandAll) {
              return true;
            }
            if (!expandAll) ids.pop();
          }
        } else if (!expandAll && items.id === targetId) {
          return true;
        } else if (items.children) {
          return walkTreeItems(items.children, targetId);
        }
      }

      walkTreeItems(data, initialSlelectedItemId);
      return ids;
    }, [data, initialSlelectedItemId]);

    const { ref: refRoot, width, height } = useResizeObserver();

    return (
      <div ref={refRoot} className={cn("", className)}>
        <ScrollArea style={{ width, height }}>
          <div className="relative">
            <TreeItem
              data={data}
              ref={ref}
              selectedItemId={selectedItemId}
              handleSelectChange={handleSelectChange}
              expandedItemIds={expandedItemIds}
              FolderIcon={folderIcon}
              {...props}
            />
          </div>
        </ScrollArea>
      </div>
    );
  }
);

Tree.displayName = "Tree";

type TreeItemProps = TreeProps & {
  selectedItemId?: string;
  handleSelectChange: (item: TreeDataItem | undefined) => void;
  expandedItemIds: string[];
  FolderIcon?: LucideIcon;
};

const TreeItem = React.forwardRef<HTMLDivElement, TreeItemProps>(
  (
    {
      className,
      data,
      selectedItemId,
      handleSelectChange,
      expandedItemIds,
      FolderIcon,
      ...props
    },
    ref
  ) => {
    return (
      <div ref={ref} role="tree" className={className} {...props}>
        <ul>
          {data instanceof Array ? (
            data.map((item) => (
              <li key={item.id} className={cn(item.hidden && "hidden")}>
                {item.children ? (
                  <Accordion type="multiple" defaultValue={expandedItemIds}>
                    <AccordionPrimitive.Item value={item.id}>
                      {item.children.length !== 0 ? (
                        <AccordionTrigger
                          className={cn(
                            "leading-6 py-2 px-3 rounded-lg hover:before:opacity-100 before:absolute before:left-0 before:w-full before:opacity-0 before:bg-muted/80 before:h-[1.75rem] before:-z-10",
                            selectedItemId === item.id && "bg-secondary"
                          )}
                          onClick={() => handleSelectChange(item)}
                        >
                          {item.icon && (
                            <item.icon
                              className="shrink-0 mr-2 text-accent-foreground/50"
                              aria-hidden="true"
                              {...iconProps}
                            />
                          )}
                          {!item.icon && FolderIcon && (
                            <FolderIcon
                              className="h-4 w-4 shrink-0 mr-2 text-accent-foreground/50"
                              aria-hidden="true"
                            />
                          )}
                          <Link href={item?.url || "#"}>
                            <span
                              className={`text-base !no-underline font-semibold truncate ml-2 ${selectedItemId === item.id ? "text-[#FF8600]" : ""}`}
                            >
                              {item.label}
                            </span>
                          </Link>
                        </AccordionTrigger>
                      ) : (
                        <Link href={item?.url || "#"}>
                          <div
                            className={`font-semibold text-base ml-2 text-foreground py-2 px-3`}
                          >
                            {item.label}
                          </div>
                        </Link>
                      )}

                      {item.children.length !== 0 && (
                        <AccordionContent className="">
                          <TreeItem
                            data={item.children ? item.children : item}
                            selectedItemId={selectedItemId}
                            handleSelectChange={handleSelectChange}
                            expandedItemIds={expandedItemIds}
                            FolderIcon={FolderIcon}
                          />
                        </AccordionContent>
                      )}
                    </AccordionPrimitive.Item>
                  </Accordion>
                ) : (
                  <Leaf
                    item={item}
                    isSelected={selectedItemId === item.id}
                    onClick={() => handleSelectChange(item)}
                  />
                )}
              </li>
            ))
          ) : (
            <li>
              <Leaf
                item={data}
                isSelected={selectedItemId === data.id}
                onClick={() => handleSelectChange(data)}
              />
            </li>
          )}
        </ul>
      </div>
    );
  }
);

TreeItem.displayName = "TreeItem";

const Leaf = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement> & {
    item: TreeDataItem;
    isSelected?: boolean;
  }
>(({ className, item, isSelected, ...props }, ref) => {
  return (
    <div
      ref={ref}
      className={cn(
        "flex items-center py-2 px-3 cursor-pointer rounded-lg \
        hover:before:opacity-100 before:absolute before:left-0 before:right-1 before:w-full before:opacity-0 before:bg-muted/80 before:h-[1.75rem] before:-z-10",
        className,
        isSelected && "bg-secondary"
      )}
      {...props}
    >
      {item.icon && (
        <item.icon
          {...iconProps}
          className="shrink-0 mr-2 text-accent-foreground/50"
          aria-hidden="true"
        />
      )}

      <Link
        href={item?.url ?? ""}
        className={cn(
          "ml-2 font-normal flex-grow text-sm truncate leading-6",
          !item.icon && "ml-7"
        )}
      >
        {item.label}
      </Link>
    </div>
  );
});

Leaf.displayName = "Leaf";

export { Tree, type TreeDataItem };
