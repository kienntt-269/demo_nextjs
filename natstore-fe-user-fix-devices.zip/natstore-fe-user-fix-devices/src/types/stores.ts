import { IDevicePreOrder } from "@/schemaValidations/device.schema";
import { ActivateStatusUser } from "@/schemaValidations/mobile-package.schema";
import { SwapSimForm } from "@/schemaValidations/swap-sim.schema";
import { IUserProfile } from "@/types/user";

export interface IProfileStore {
  user?: IUserProfile | null;
  token?: string | null;
  refreshToken?: string | null;
}
export interface IUseProfileStore {
  user: IUserProfile | null;
  token: string | null;
  refreshToken: string | null;
  setProfile: (profile: IProfileStore) => void;
}

export interface IStepStore {
  currentStep: number;
  setCurrentStep: (step: number) => void;
  nextStep: () => void;
  nextStepWithNumber: (number: number) => void;
  prevStep: () => void;
  resetSteps: () => void; // Thêm resetSteps
}

export interface ISwapSimStore {
  data?: SwapSimForm;
  requestId?: string;
  setData: (data: SwapSimForm, requestId: string) => void;
}

export interface IRoamingStore {
  data: ActivateStatusUser;
  setData: (data: ActivateStatusUser) => void;
}

export interface IDeviceStore {
  data?: IDevicePreOrder;
  setData: (data: IDevicePreOrder) => void;
}
