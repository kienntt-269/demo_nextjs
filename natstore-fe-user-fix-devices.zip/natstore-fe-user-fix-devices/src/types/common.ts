export type Option = {
  label: string;
  value: string;
};

export type IColumnTable<T> = {
  key: string;
  header: string;
  render?: (value: T[keyof T], record: T, i: number) => React.ReactNode;
  classStyleHeader?: string;
};
export type ITable<T> = {
  data: T[];
  onChangePage?: (page: number, pageSize: number) => void;
  column: IColumnTable<T>[];
  sizePage?: number;
  showPagination?: boolean;
  eventSearch?: (text: string) => void;
  searchParams: { [key in string]: string };
};

export type ServiceChatType = {
  id: number;
  name: string;
};

export type MessageDataType = {
  id?: string;
  senderId?: string;
  roomId?: string;
  message?: string;
  imagePath?: string;
  createdTime?: string;
  receiverId?: string;
  isSupporter?: number;
  isRead?: number;
  isAuto?: number;
  type?: "1" | "2" | "3";
};

export type RegistrationType = "NORMAL" | "AUTO_RENEW" | "SHARE_PLAN";

export type paymentInternetData = {
  id: number;
  contactID: number;
  account: number;
  totalDebt: number;
  status: string;
};

export type paymentInternetFormValue = {
  searchType: string;
  valueSearch: string;
  captchaToken: string;
};
export type PaymentParams = {
  transactionId: string;
  code: string;
  ncTransId: string;
  signature: string;
};

export type StateUsePointType = {
  isUsedPoint?: boolean;
  redeemPoint?: number;
  error?: string;
};
