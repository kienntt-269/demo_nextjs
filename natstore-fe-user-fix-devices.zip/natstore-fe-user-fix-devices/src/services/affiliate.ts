import http from "@/lib/http";
import { IAffiliateFAQRes, IBannerAffiliateRes } from "@/types/affiliate";

const affiliateApiRequest = {
  getFAQ() {
    return http.get<IAffiliateFAQRes>(`/v1/public/affiliate-home/faq`, {
      cache: "no-cache",
    });
  },
  getBannerAffiliate() {
    return http.get<IBannerAffiliateRes>(`/v1/public/affiliate-home/banner`, {
      cache: "no-cache",
    });
  },
};

export default affiliateApiRequest;
