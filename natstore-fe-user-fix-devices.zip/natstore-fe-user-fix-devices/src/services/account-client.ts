import envConfig from "@/config";
import http from "@/lib/http";
import { AccountResType } from "@/schemaValidations/account.schema";

const accountApiRequest = {
  updateProfile: ({
    userId,
    address,
    email,
  }: {
    userId: string | number;
    address: string;
    email: string;
  }) => {
    return http.put<AccountResType>(
      `/api/proxy/v1/api/user`,
      { email, address } as unknown as BodyInit,
      {
        headers: {
          "Content-Type": "application/json; charset=UTF-8",
          "user-id": `${userId}`,
        },
        baseUrl: envConfig.NEXT_PUBLIC_URL,
      }
    );
  },
  updatePassword: ({
    userId,
    newPassword,
    password,
    otp,
  }: {
    userId: string;
    newPassword: string;
    password: string;
    otp: string;
  }) =>
    http.post<AccountResType>(
      `/api/proxy/v1/api/auth/update-password`,
      { newPassword, password, otp } as unknown as BodyInit,
      {
        headers: {
          "user-id": userId,
        },
        baseUrl: envConfig.NEXT_PUBLIC_URL,
      }
    ),
};

export default accountApiRequest;
