import http from "@/lib/http";
import {
  DataPlansTypeList,
  IDataPlanRes,
} from "@/schemaValidations/mobile-service.schema";
import { buildEndpoint } from "@/lib/utils";
import { IParamsDataPlans } from "@/types/mobile-package";
import { IDataServiceCategoriesRes } from "@/schemaValidations/service-categories";

const mobileApiRequest = {
  getDataMobileService: (params?: IParamsDataPlans) => {
    const url = buildEndpoint("/v1/public/data", { ...params });
    return http.get<DataPlansTypeList>(url, {
      cache: "no-cache",
    });
  },

  getDetailData: (idOrSlug: string) =>
    http.get<IDataPlanRes>(`/v1/public/data/${idOrSlug}`, {
      cache: "no-cache",
    }),

  getListSimilar: (packageId: string) =>
    http.get<DataPlansTypeList>(
      `/v1/public/data/similar?packageId=${packageId}`,
      {
        cache: "no-cache",
      },
    ),

  getListHomepage: () =>
    http.get<DataPlansTypeList>(
      `/v1/data-service/docs/v1/public/data/homepage`,
      {
        cache: "no-cache",
      },
    ),

  getListCategoriesMobile: () => {
    return http.get<IDataServiceCategoriesRes>(`/v1/public/data/categories`, {
      cache: "no-cache",
    });
  },
};

export default mobileApiRequest;
