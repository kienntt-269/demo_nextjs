import {
  REGEX_VALIDATE_PHONE_NUMBER,
  REGEX_VALIDATE_EMAIL,
  REGEX_VALIDATE_PASSWORD,
  REGEX_VALIDATE_ID_CARD,
  REGEX_VALIDATE_NAME,
  REGEX_VALIDATE_ADDRESS,
  REGEX_VALIDATE_LICENSE_DRIVER,
  REGEX_VALIDATE_PHONE_NUMBER_ON_NET,
} from "@/constants/regex";
import { z } from "zod";

export const phoneSchemaFnc = (options?: { checkPrefix?: boolean }) => {
  const schema = z
    .string({
      required_error: "phone.required",
      invalid_type_error: "phone.required",
    })
    .trim()
    .nonempty("phone.format")
    .regex(REGEX_VALIDATE_PHONE_NUMBER, "phone.format")
    .min(8, "phone.min")
    .max(8, "phone.min");
  if (options?.checkPrefix) {
    return schema.refine(
      (val) => REGEX_VALIDATE_PHONE_NUMBER_ON_NET.test(val),
      {
        message: "natcom.register_user_phone_natcom",
      }
    );
  }
  return schema;
};

export const phoneSchemaNoRequireFnc = () => {
  return z.union([
    z
      .string()
      .trim()
      .regex(REGEX_VALIDATE_PHONE_NUMBER, "phone.format")
      .min(8, "phone.max")
      .max(12, "phone.max"),
    z.string().length(0),
    z.undefined(),
  ]);
};

export const emailSchemaFnc = ({ isRequired = true } = {}) => {
  return isRequired
    ? z
        .string()
        .trim()
        .nonempty("MSG0034")
        .regex(REGEX_VALIDATE_EMAIL, "MSG0033")
    : z
        .string()
        .trim()
        .optional()
        .nullable()
        .refine((val) => !val || REGEX_VALIDATE_EMAIL.test(val), {
          message: "MSG0033",
        });
};

export const emailSchemaNoRequireFnc = () => {
  return z.union([
    z.string().trim().regex(REGEX_VALIDATE_EMAIL, "MSG0033").length(0),
    z.undefined(),
  ]);
};
export const passwordSchemaFnc = (type?: "login" | "other") => {
  if (type === "login") {
    return z.string().trim().nonempty("password.required_login");
  }
  return z
    .string()
    .trim()
    .nonempty("password.required")
    .regex(REGEX_VALIDATE_PASSWORD, "password.format")
    .min(6, "password.format")
    .max(20, "password.format");
};

export const newPasswordSchemaFnc = () => {
  return (
    z
      .string()
      .trim()
      .nonempty("new_password.required")
      // .regex(REGEX_VALIDATE_PASSWORD, "new_password.format")
      .min(6, "new_password.format")
      .max(20, "new_password.format")
  );
};

export const confirmPasswordSchemaFnc = () => {
  return z.string().trim().nonempty("confirm_password.required");
};

export const currentPasswordSchemaFnc = () => {
  return z.string().trim().nonempty("current_password.required");
};

export const otpSchemaFnc = () => {
  return z.string().trim().nonempty("otp.required").min(6, "otp.min");
};

export const nameSchemaFnc = () => {
  return z
    .string({
      required_error: "name.required",
      invalid_type_error: "name.required",
    })
    .trim()
    .nonempty("name.required")
    .regex(REGEX_VALIDATE_NAME, "name.format")
    .max(50, "");
};

export const nameInternetSchemaFnc = () => {
  return z
    .string({
      required_error: "name.required",
    })
    .trim()
    .nonempty("name.required")
    .max(50, "");
};

export const customerNameSchemaFnc = () => {
  return z
    .string()
    .trim()
    .nonempty("name.required")
    .regex(REGEX_VALIDATE_NAME, "name.format")
    .max(50, "");
};

export const typeOfDocSchemaFnc = () => {
  return z
    .string({
      required_error: "type_of_doc..required",
      invalid_type_error: "type_of_doc.required",
    })
    .trim()
    .nonempty("type_of_doc.required");
};

export const dateSchemaFnc = () => {
  return z.date({
    required_error: "date.required",
    invalid_type_error: "MSG0002",
  });
};

export const addressSchemaFnc = () => {
  return z.union([
    z
      .string()
      .trim()
      .regex(REGEX_VALIDATE_ADDRESS, "")
      .max(100, "address.format"),
    z.string().length(0),
    z.undefined(),
  ]);
};

export const idCardSchemaFnc = () => {
  return z
    .string({
      required_error: "id_card.required",
      invalid_type_error: "id_card.required",
    })
    .trim()
    .nonempty("id_card.required")
    .regex(REGEX_VALIDATE_ID_CARD, "id_card.format");
};

export const idCardInternetSchemaFnc = () => {
  return z
    .string({
      required_error: "id_card_internet.required",
      invalid_type_error: "id_card_internet.required",
    })
    .trim()
    .nonempty("id_card_internet.required");
};

export const fileSchemaFnc = ({ fileSizeLimit = 15 }) => {
  return z
    .array(
      z
        .unknown()
        .refine(
          (file: unknown) => {
            if (file && typeof file === "object" && "type" in file) {
              const fileType = (file as { type: string }).type;
              return ["image/png", "image/jpeg", "image/jpg"].includes(
                fileType
              );
            }
            return false;
          },
          {
            message: "file.max_15mb",
          }
        )
        .refine(
          (file: unknown) => {
            if (file && typeof file === "object" && "size" in file) {
              const fileSize = (file as { size: number }).size;
              return fileSize <= fileSizeLimit * 1024 * 1024;
            }
            return false;
          },
          {
            message: "file.max_15mb",
          }
        )
    )
    .max(3, {
      message: "file.max",
    })
    .nonempty({
      message: "file.required",
    });
};

export const validateAndAddIssue = (
  ctx: z.RefinementCtx,
  schema: z.ZodTypeAny,
  value: string | number | File | File[] | Date | null | undefined,
  path: (string | number)[]
) => {
  const result = schema.safeParse(value);
  if (!result.success) {
    ctx.addIssue({
      code: "custom",
      path,
      message: result.error.issues[0]?.message || "Invalid value",
    });
  }
};

export const serviceSchemaFnc = () => {
  return z.string().nonempty("service.required");
};

export const provinceSchemaFnc = () => {
  return z
    .string({
      required_error: "province.required",
      invalid_type_error: "province.required",
    })
    .nonempty("province).required");
};

export const districtSchemaFnc = () => {
  return z
    .string({
      required_error: "district.required",
      invalid_type_error: "district.required",
    })
    .nonempty("district.required");
};

export const precinctSchemaFnc = () => {
  return z
    .string({
      required_error: "precinct.required",
      invalid_type_error: "precinct.required",
    })
    .nonempty("precinct.required");
};

export const driverLicenseSchemaFnc = () => {
  return z
    .string()
    .nonempty("driver_license.required")
    .max(15, { message: "driver_license.required" })
    .regex(REGEX_VALIDATE_LICENSE_DRIVER, {
      message: "driver_license.required",
    });
};

export const identityNewCardSchemaFnc = () => {
  return z
    .string({
      required_error: "id_card_internet.required",
    })
    .max(12, { message: "new_id.required" })
    .regex(/^\d+$/, {
      message: "new_id.required",
    });
};

export const identityOldCardSchemaFnc = () => {
  return z
    .string({
      required_error: "id_card_internet.required",
    })
    .max(25, { message: "old_id.required" })
    .regex(/^[0-9-]*$/, {
      message: "old_id.required",
    });
};

export const passportSchemaFnc = () => {
  return z
    .string({
      required_error: "id_card_internet.required",
    })
    .max(15, { message: "driver_license.required" })
    .regex(REGEX_VALIDATE_LICENSE_DRIVER, {
      message: "driver_license.required",
    });
  // .regex(/^[a-zA-Z0-9\s]+$/, {
  //   message: "driver_license.required",
  // });
};

export const checkPaymentPhoneFnc = () => {
  return z
    .string()
    .trim()
    .regex(/^(32|33|35|40|41|42|43|55)\d{6}$/, {
      message: "natcom.phone",
    });
};
