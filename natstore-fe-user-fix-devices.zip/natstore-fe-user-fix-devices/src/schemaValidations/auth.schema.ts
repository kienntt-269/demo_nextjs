import {
  confirmPasswordSchemaFnc,
  emailSchemaFnc,
  newPasswordSchemaFnc,
  otpSchemaFnc,
  passwordSchemaFnc,
  phoneSchemaFnc,
} from "@/lib/schema";
import z from "zod";

export const phoneSchema = z.object({
  phoneNumber: phoneSchemaFnc(),
});

export const emailSchema = z.object({
  email: emailSchemaFnc(),
});

export const RegisterBody = (
  { isRequiredEmail } = { isRequiredEmail: true }
) => {
  return z
    .object({
      email: emailSchemaFnc({ isRequired: isRequiredEmail }),
      phoneNumber: phoneSchemaFnc(),
      password: newPasswordSchemaFnc(),
      confirmPassword: confirmPasswordSchemaFnc(),
      otp: otpSchemaFnc(),
    })
    .strict()
    .superRefine(({ confirmPassword, password }, ctx) => {
      if (confirmPassword !== password) {
        ctx.addIssue({
          code: "custom",
          message: "confirm_password.match",
          path: ["confirmPassword"],
        });
      }
    });
};

export const OrderTrackingBody = (
  { isRequiredEmail } = { isRequiredEmail: true }
) => {
  return z
    .object({
      email: emailSchemaFnc({ isRequired: isRequiredEmail }),
      phoneNumber: phoneSchemaFnc(),
    })
    .strict();
};

export const ForgotPasswordBody = () => {
  return z
    .object({
      phoneNumber: phoneSchemaFnc(),
      password: newPasswordSchemaFnc(),
      confirmPassword: confirmPasswordSchemaFnc(),
      otp: otpSchemaFnc(),
    })
    .strict()
    .superRefine(({ confirmPassword, password }, ctx) => {
      if (confirmPassword !== password) {
        ctx.addIssue({
          code: "custom",
          message: "confirm_password.match",
          path: ["confirmPassword"],
        });
      }
    });
};

export const LoginBody = z
  .object({
    phoneNumber: phoneSchemaFnc(),
    password: passwordSchemaFnc("login"),
    otp: z.string().optional(),
    typeLogin: z.string().optional(),
  })
  .strict();

export const RegisterRes = z.object({
  code: z.string(),
  message: z.string(),
  data: z.object({
    accessToken: z.string(),
    refreshToken: z.string(),
  }),
});

export const RegisterBodySchema = RegisterBody();
export const ForgotPasswordBodySchema = ForgotPasswordBody();

export type RegisterBodyType = Omit<
  z.TypeOf<typeof RegisterBodySchema>,
  "confirmPassword"
>;

export type RegisterResType = z.TypeOf<typeof RegisterRes> & {
  code?: string;
  message?: string;
};
export type RegisterOtpResType = {
  code: string;
  message: string;
};

export type LoginBodyType = z.TypeOf<typeof LoginBody>;

export const LoginRes = RegisterRes;

export type LoginResType = z.TypeOf<typeof LoginRes>;
export const SlideSessionBody = z.object({}).strict();

export type SlideSessionBodyType = z.TypeOf<typeof SlideSessionBody>;
export const SlideSessionRes = RegisterRes;

export type SlideSessionResType = z.TypeOf<typeof SlideSessionRes>;
