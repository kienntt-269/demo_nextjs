import { CategoriesDataPlans } from "@/schemaValidations/mobile-service.schema";
import z from "zod";

export const TypePackage = z.object({
  id: z.string().nullable(),
  name: z.string().nullable(),
  description: z.string().nullable(),
  shortDescription: z.string().nullable(),
  categoryId: z.string().nullable(),
  hot: z.string().nullable(),
  home: z.string().nullable(),
  active: z.boolean().nullable(),
  displayFrontend: z.string().nullable(),
  bestSeller: z.string().nullable(),
  useTimeValue: z.string().nullable(),
  recommend: z.string().nullable(),
  rating: z.number().nullable(),
  ratingCount: z.string().nullable(),
  price: z.string().nullable(),
  useTime: z.string().nullable(),
  packageValue: z.string().nullable(),
  packageUnit: z.string().nullable(),
  type: z.string().nullable(),
  promotionType: z.string().nullable(),
  promotionPrice: z.string().nullable(),
  promotionTime: z.string().nullable(),
  promotionStartTime: z.string().nullable(),
  promotionEndTime: z.string().nullable(),
  createdAt: z.string().nullable(),
  createdBy: z.string().nullable(),
  updatedAt: z.string().nullable(),
  updatedBy: z.string().nullable(),
  slug: z.string().nullable(),
  imagePath: z.string().nullable(),
  speed: z.string().nullable(),
  categories: z.array(CategoriesDataPlans),
  vote: z.number().nullable(),
  imageUrl: z.string().nullable(),
  note: z.string().nullable(),
  detail: z.string().nullable(),
  code: z.string().nullable(),
});

export const TypeCategorySearch = z.object({
  id: z.string(),
  name: z.string(),
  description: z.string(),
  active: z.boolean(),
  home: z.boolean(),
  icon: z.string().nullable(),
  order: z.string().nullable(),
  type: z.string().nullable(),
  parentId: z.string().nullable(),
  createdAt: z.string(),
  updatedAt: z.string(),
  createdBy: z.string(),
  updatedBy: z.string(),
  slug: z.string(),
});

export const TypeSearchMobile = z.object({
  category: TypeCategorySearch,
  mobiles: z.array(TypePackage),
});

export const TypeInternet = z.object({
  id: z.number().nullable(),
  name: z.string(),
  price: z.number(),
  speed: z.number(),
  promotion: z.string(),
  note: z.string(),
  slug: z.string(),
  updatedAt: z.string(),
});

export const TypeSearchInternet = z.object({
  category: TypeCategorySearch,
  internets: z.array(TypeInternet),
});

export const SearchHome = z.object({
  searchPackages: z.object({
    searchMobiles: z.array(TypeSearchMobile),
    searchInternets: z.array(TypeSearchInternet),
  }),
});

export const SearchHomeRes = z.object({
  data: SearchHome,
  message: z.string(),
  code: z.number(),
});

export const ParamsSearchHome = z.object({
  name: z.string(),
});

export type ISearchHomeRes = z.TypeOf<typeof SearchHomeRes>;
export type ISearchHome = z.TypeOf<typeof SearchHome>;
export type ITypeCategorySearch = z.TypeOf<typeof TypeCategorySearch>;
export type ITypePackage = z.TypeOf<typeof TypePackage>;
export type ITypeSearchMobiles = z.TypeOf<typeof TypeSearchMobile>;
export type ITypeSearchInternet = z.TypeOf<typeof TypeSearchInternet>;
