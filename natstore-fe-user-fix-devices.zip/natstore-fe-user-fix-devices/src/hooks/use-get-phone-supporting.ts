import { useChatOnline } from "@/_stores/useChatOnline";
import { useProfileStore } from "@/_stores/useProfile.store";
import { storage } from "@/lib/storage";
import { useEffect, useState } from "react";

const useGetPhoneSupporting = () => {
  const { user } = useProfileStore();

  const { phoneSupporting: phoneSupportingState, setStateChatOnline } =
    useChatOnline();
  const [phoneSupporting, setPhoneSupporting] = useState<string>();

  const handleSetPhoneSupporting = (phoneSupporting: string) => {
    setStateChatOnline({ phoneSupporting });
    storage.setPhoneSupporting(phoneSupporting);
  };

  useEffect(() => {
    const phoneIsSupporting = storage.getPhoneSupporting();
    setPhoneSupporting(phoneSupportingState || phoneIsSupporting);
  }, [phoneSupportingState]);

  useEffect(() => {
    setStateChatOnline({ phoneSupporting: user?.isdn ?? "" });
    if (user?.isdn) {
      storage.setPhoneSupporting(user?.isdn);
      storage.removeIsShowSuggestionChat();
    }
  }, [user?.isdn]);

  return { phoneSupporting, handleSetPhoneSupporting };
};

export default useGetPhoneSupporting;
