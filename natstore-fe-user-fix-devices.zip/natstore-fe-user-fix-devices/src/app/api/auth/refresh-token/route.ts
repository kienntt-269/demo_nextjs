import envConfig from "@/config";
import {
  XSRF_REFRESH_TOKEN,
  XSRF_TOKEN,
  XSRF_USERID,
} from "@/constants/authority";
import { checkResSuccess, decodeAccessToken } from "@/lib/utils";
import { cookies } from "next/headers";
import { NextResponse } from "next/server";
const isProd = process.env.NODE_ENV === "production";
export async function POST() {
  const cookieStore = cookies();
  const refreshToken = cookieStore.get(XSRF_REFRESH_TOKEN)?.value;
  if (!refreshToken) {
    cookieStore.delete(XSRF_TOKEN);
    cookieStore.delete(XSRF_USERID);
    cookieStore.delete(XSRF_REFRESH_TOKEN);
    return NextResponse.json(
      { error: "refreshToken not provide" },
      { status: 403 }
    );
  }
  const res = await fetch(
    `${envConfig.NEXT_PUBLIC_API_ENDPOINT}/v1/public/auth/refresh-token`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        refreshToken: refreshToken,
      }),
    }
  );

  const data = await res.json();
  const headers = new Headers();

  if (!checkResSuccess(data.code + "")) {
    cookieStore.delete(XSRF_TOKEN);
    cookieStore.delete(XSRF_USERID);
    cookieStore.delete(XSRF_REFRESH_TOKEN);
  } else {
    const cookieOptions = [
      "Path=/",
      "HttpOnly",
      isProd ? "Secure" : "",
      "SameSite=Lax",
    ]
      .filter(Boolean)
      .join("; ");
    headers.append(
      "Set-Cookie",
      `${XSRF_TOKEN}=${data.data.accessToken}; ${cookieOptions} `
    );
    headers.append(
      "Set-Cookie",
      `${XSRF_REFRESH_TOKEN}=${data.data.refreshToken}; ${cookieOptions} `
    );
    headers.append(
      "Set-Cookie",
      `${XSRF_USERID}=${decodeAccessToken(data.data.accessToken).sub}; ${cookieOptions} `
    );
  }

  return NextResponse.json(data, { status: res.status, headers: headers });
}
