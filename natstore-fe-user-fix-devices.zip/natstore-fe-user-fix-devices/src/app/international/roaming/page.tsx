import { ILinks, ITabs } from "@/types/package";
import BreadCrumbCommon from "@/components/breadcrumb-common";
import Register from "@/app/international/roaming/register/page";
import Active from "@/app/international/roaming/activate/activate";
import TabsCommon from "@/components/common/tabs/tabs";
import { useTranslations } from "next-intl";
import DataManagement from "@/app/international/roaming/data-management/page";
import BannerHomePage from "@/module/home-page/banner-home-page";
import PageContent from "@/components/page-content";

type RoamingPageProps = {
  params: { slug: string };
  searchParams: { [key: string]: string | undefined };
};

const RoamingPage = ({ searchParams }: RoamingPageProps) => {
  const t = useTranslations();
  const breadCrumb: ILinks[] = [
    {
      label: t("personal.home"),
      link: "/",
    },
    {
      label: t("mobile_package.roaming.international"),
      link: "/international",
    },
    {
      label: t("personal.roaming"),
      link: "/international/roaming",
    },
  ];

  const tabs: ITabs[] = [
    {
      id: "activate",
      label: t("mobile_package.roaming.activate"),
      content: <Active />,
      params: "/international/roaming?name=activate",
    },
    {
      id: "register",
      label: t("mobile_package.roaming.register"),
      content: <Register />,
      params: "/international/roaming?name=register",
    },
    {
      id: "data_management",
      label: t("mobile_package.roaming.data_management"),
      content: <DataManagement />,
      params: "/international/roaming?name=data_management",
    },
  ];

  return (
    <PageContent className="!pb-0">
      <BannerHomePage />
      <BreadCrumbCommon content={breadCrumb} />
      <div className="mt-6">
        <TabsCommon data={tabs} defaultTab={searchParams.name as string} />
      </div>
    </PageContent>
  );
};

export default RoamingPage;
