"use client";

import React, { useEffect, useState } from "react";
import { buildStyles, CircularProgressbar } from "react-circular-progressbar";

import Image from "next/image";
import { useTranslations } from "next-intl";
import "react-circular-progressbar/dist/styles.css";
import dayjs from "dayjs";
import SwitchModal from "@/app/international/roaming/activate/_components/switch-modal";
import { getStatusRoaming } from "@/app/international/roaming/activate/activate";
import { ActivateStatusUser } from "@/schemaValidations/mobile-package.schema";
import { useRoamingStore } from "@/_stores/useRoaming.store";

const DataManagementPage = () => {
  const t = useTranslations("mobile_package.roaming");
  const { data } = useRoamingStore();
  const [status, setStatus] = useState<ActivateStatusUser>(data);

  const ActivateSection = (data: ActivateStatusUser) => (
    <>
      <div className="text-sm text-neutral-dark-03 text-center">
        {t.rich("content_data_management", {
          data: data.usageStatus.remainingDataInByte / 1024,
          strong: (chunks) => <strong>{chunks}</strong>,
        })}
      </div>
      <div className="text-sm text-neutral-dark-03 text-center">
        {t("expire_package", {
          date: dayjs(data.expireAt).format("DD/MM/YYYY"),
        })}
      </div>
      <div className="relative w-[139px] lg:w-[264px] mt-6">
        <CircularProgressbar
          value={
            (data.usageStatus.usingDataInByte * 100) /
            (data.usageStatus.remainingDataInByte +
              data.usageStatus.usingDataInByte)
          }
          styles={buildStyles({
            pathColor: "#d6d6d6",
            textColor: "#d6d6d6",
            trailColor: "#FF8600",
            strokeLinecap: "butt",
          })}
        />
        <div
          style={{
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            width: "75%",
          }}
          className="text-xl lg:text-size-28 font-bold text-center"
        >
          <span className="text-primary">
            {data.usageStatus.remainingDataInByte / 1024} /
          </span>
          <span style={{ color: "#C5C5C5" }}>
            {" "}
            {(data.usageStatus.remainingDataInByte +
              data.usageStatus.usingDataInByte) /
              1024}
            GB
          </span>
        </div>
      </div>
    </>
  );

  const NotActivateSection = () => (
    <>
      <div className="text-sm lg:text-xl text-neutral-dark-03 text-center">
        {t("service_not_activate")}
      </div>
      <SwitchModal status={status} setStatus={setStatus} />
    </>
  );

  const NotFoundSection = () => (
    <>
      <div className="mb-6 mt-4">
        <Image
          src="/unavailable.svg"
          alt="illustration roaming"
          width={480}
          height={216}
        />
      </div>
      <div className="text-neutral-dark-03 text-sm lg:text-xl">
        {t("you_not_registered")}
      </div>
      <div className="text-neutral-dark-03 text-sm lg:text-xl">
        {t("select_package")}
      </div>
    </>
  );

  const render = () => {
    if (status.id === 9007199254740991) return NotFoundSection();
    if (
      status.activationStatus === "ACTIVATED" &&
      status.registerStatus === "REGISTERED"
    ) {
      return ActivateSection(status);
    }
    if (status.activationStatus === "NOT_ACTIVATED") {
      return NotActivateSection();
    }
    return NotFoundSection();
  };

  useEffect(() => {
    if (status.id === 9007199254740991) {
      getStatusRoaming()
        .then((res) => {
          setStatus(res);
        })
        .catch((err) => {
          console.log("🚀 ~ getStatusRoaming ~ err:", err);
        });
    }
  }, [status.id]);

  return (
    <div className="data-management flex flex-col items-center mt-7 lg:mt-[72px]">
      {render()}
      <div className="mt-[16px] lg:-mt-[18px]">
        <Image
          src="/mobile-package/illustration_roaming.png"
          alt="illustration roaming"
          width={991}
          height={456}
        />
      </div>
    </div>
  );
};

export default DataManagementPage;
