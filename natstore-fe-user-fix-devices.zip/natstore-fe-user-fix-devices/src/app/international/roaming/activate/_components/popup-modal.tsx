import Modal from "@/components/common/modal/Modal";
import { Button } from "@/components/ui/button";
import { Dialog } from "@radix-ui/react-dialog";
import { useTranslations } from "next-intl";
import React from "react";

export type PopupProps = React.ComponentProps<typeof Dialog> & {
  isPopupModal: boolean;
  status: string;
  onClose: () => void;
  onSubmit: () => void;
};

export const PopupModal = ({
  isPopupModal,
  status,
  onSubmit,
  onClose,
}: PopupProps) => {
  const t = useTranslations("mobile_package.roaming");
  return (
    <Modal
      isOpen={isPopupModal}
      onClose={onClose}
      contentClassName=" w-full max-w-[343px] lg:max-w-[504px] pb-[24px] pt-2 px-[16px] lg:p-6"
    >
      <h3 className="font-bold text-xl lg:text-2xl text-center text-black mb-4">
        {status === "on" ? t("data_roaming_on") : t("data_roaming_off")}
      </h3>
      <div className="max-sm:text-sm text-base text-neutral-dark-04 mb-5">
        {status === "on"
          ? t("confirm_use_roaming_on")
          : t("confirm_use_roaming_off")}
      </div>
      <div className="max-sm:text-sm text-base text-neutral-dark-04">
        {t("service_roaming")}
      </div>
      <div className="mt-4 lg:mt-6 flex justify-center items-center gap-3">
        <Button
          variant="secondary"
          className=" text-primary border-primary-orange min-w-[148px]  lg:min-w-[212px] rounded-3xl"
          onClick={onClose}
        >
          {t("cancel")}
        </Button>
        <Button
          className=" min-w-[148px] lg:min-w-[212px]  rounded-3xl"
          onClick={onSubmit}
        >
          {t("confirm")}
        </Button>
      </div>
    </Modal>
  );
};

export default PopupModal;
