import { warrantyService } from "@/services/warranty-service";
import { useTranslations } from "next-intl";
import React, { useEffect } from "react";

const WarrantyPolicyContent = () => {
  const t = useTranslations();
  const [information, setInformation] = React.useState<string>("");
  useEffect(() => {
    warrantyService.getInformation().then((res) => {
      setInformation(res.payload.data.information || "");
    });
  }, []);
  return (
    <div className="py-4 px-6 rounded-xl bg-[#F5F6F7] border border-[#DEDEDE]">
      <p className="font-bold text-xl text-neutral-dark-03">
        {t("personal.warranty_information.warranty_conditions")}
      </p>
      <div className="mt-2">
        <p dangerouslySetInnerHTML={{ __html: information }}></p>
      </div>
    </div>
  );
};

export default WarrantyPolicyContent;
