"use client";
import ContentPagePersonal from "@/app/personal/components/content-page";
import OrderTrackingEmpty from "@/app/personal/components/order-tracking-empty";
import OrderTrackingItem from "@/app/personal/components/order-tracking-item";
import SearchInput from "@/components/common/search-input";
import TabCommon from "@/components/tabs-common";
import { FORMAT_DATE_TIME_ORDER } from "@/constants/common";
import { formatDateTime } from "@/lib/utils";
import { ITab } from "@/types/package";
import { useTranslations } from "next-intl";
import React, { useState } from "react";

const OrderTracking = () => {
  const t = useTranslations("");
  const [query, setQuery] = useState("");
  const tabs: ITab[] = [
    {
      label: t("order_tracking.all"),
      slug: "all",
    },
    {
      label: t("order_tracking.processing"),
      slug: "processing",
    },
    {
      label: t("order_tracking.completed"),
      slug: "completed",
    },
    {
      label: t("order_tracking.cancelled"),
      slug: "cancelled",
    },
  ];
  return (
    <ContentPagePersonal title={t("order_tracking.title")}>
      <div className="flex justify-between">
        <TabCommon tabs={tabs} tabItemClassName="!text-base text-[#000]" />
        <SearchInput
          className="w-[342px] h-8"
          value={query}
          onChange={setQuery}
          placeholder={t("order_tracking.placeholder_input_search")}
        />
      </div>
      <OrderTrackingEmpty />
      <div className="flex flex-col gap-6 overflow-auto max-h-[396px] pr-4">
        <OrderTrackingItem
          orderId="2025140412"
          productCount={2}
          customer="0569828869"
          product="Sumo 4G T1"
          orderDate={formatDateTime(new Date(), FORMAT_DATE_TIME_ORDER)}
          total="100 HTG"
          paymentMethod="Natcash"
          status="delivered"
        />
        <OrderTrackingItem
          orderId="2025140412"
          productCount={2}
          customer="0569828869"
          product="Sumo 4G T1"
          orderDate="04/15/2025 10:45"
          total="100 HTG"
          paymentMethod="Natcash"
          status="delivered"
        />
        <OrderTrackingItem
          orderId="2025140412"
          productCount={2}
          customer="0569828869"
          product="Sumo 4G T1"
          orderDate="04/15/2025 10:45"
          total="100 HTG"
          paymentMethod="Natcash"
          status="delivered"
        />
        <OrderTrackingItem
          orderId="2025140412"
          productCount={2}
          customer="0569828869"
          product="Sumo 4G T1"
          orderDate="04/15/2025 10:45"
          total="100 HTG"
          paymentMethod="Natcash"
          status="delivered"
        />
      </div>
    </ContentPagePersonal>
  );
};

export default OrderTracking;
