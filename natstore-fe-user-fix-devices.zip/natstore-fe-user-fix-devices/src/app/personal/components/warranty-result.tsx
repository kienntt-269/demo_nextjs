import { Typography } from "@/components/ui/typography";
import Image from "next/image";
import React from "react";

const WarrantyResult = () => {
  return (
    <div className="p-6 rounded-2xl bg-[#F5F6F7] grid grid-cols-2 gap-10">
      <div className="grid grid-cols-1 gap-10">
        <div>
          <Typography className="text-xl font-bold">
            Product information
          </Typography>
          <div className="mt-6 flex flex-col gap-4">
            <div className="flex justify-between">
              <Typography className="text-neutral-dark3">
                Product name
              </Typography>
              <Typography className="font-bold">Sumo 4G T1</Typography>
            </div>
            <div className="flex justify-between">
              <Typography className="text-neutral-dark3">
                Serial number
              </Typography>
              <Typography className="font-bold">Sumo 4G T1</Typography>
            </div>
          </div>
        </div>
        <div>
          <Typography className="text-xl font-bold">
            Product information
          </Typography>
          <div className="mt-6 flex flex-col gap-4">
            <div className="flex justify-between">
              <Typography className="text-neutral-dark3">
                Warranty activation date
              </Typography>
              <Typography className="font-bold">Sumo 4G T1</Typography>
            </div>
            <div className="flex justify-between">
              <Typography className="text-neutral-dark3">
                Warranty period
              </Typography>
              <Typography className="font-bold">Sumo 4G T1</Typography>
            </div>
            <div className="flex justify-between">
              <Typography className="text-neutral-dark3">
                Current warranty status
              </Typography>
              <Typography className="font-bold">Sumo 4G T1</Typography>
            </div>
            <div className="flex justify-between">
              <Typography className="text-neutral-dark3">
                Warranty Type
              </Typography>
              <Typography className="font-bold">Sumo 4G T1</Typography>
            </div>
          </div>
        </div>
      </div>
      <div className="rounded-xl bg-white flex items-center justify-center">
        <Image alt="img" width={258} height={258} src="/mobile_warranty.png" />
      </div>
    </div>
  );
};

export default WarrantyResult;
