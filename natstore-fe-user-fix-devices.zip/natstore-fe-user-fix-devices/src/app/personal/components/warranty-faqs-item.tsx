import React from "react";

type Props = {
  question?: string;
  answer?: string;
};

const WarrantyFaqsItem = ({ question, answer }: Props) => {
  return (
    <div className="py-4 px-6 rounded-xl bg-[#F5F6F7] border border-[#DEDEDE]">
      <p className=" text-neutral-dark-01">{question}:</p>
      <div
        className="mt-2"
        dangerouslySetInnerHTML={{ __html: answer || "" }}
      ></div>
    </div>
  );
};

export default WarrantyFaqsItem;
