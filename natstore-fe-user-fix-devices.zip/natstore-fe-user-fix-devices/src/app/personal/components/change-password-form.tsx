import { useDialogAuthStore } from "@/_stores/useDialogAuth.store";
import { useLoadingStore } from "@/_stores/useLoading,store";
import ContentPagePersonal from "@/app/personal/components/content-page";
import CountdownTimer, {
  CountdownTimerHandle,
} from "@/components/count-down-timer";
import { Form, InputField } from "@/components/form";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { REGEX_INPUT_OTP, REGEX_INPUT_PASSWORD } from "@/constants/regex";
import { toastError, toastSuccess } from "@/hooks/use-toast";
import { checkResSuccess, focusInput } from "@/lib/utils";
import { changePasswordSchema } from "@/schemaValidations/account.schema";
import accountApiRequest from "@/services/account-client";
import authApiRequest from "@/services/auth";
import { IUserProfile } from "@/types/user";
import clsx from "clsx";
import { useTranslations } from "next-intl";
import { useRouter } from "next/navigation";
import React, { LegacyRef, useRef, useState } from "react";

type Props = {
  user?: IUserProfile;
};

type ChangePasswordFormValues = {
  currentPassword: string;
  otp: string;
  newPassword: string;
  confirmNewPassword: string;
  [key: string]: string;
};

const ChangePasswordForm = ({ user }: Props) => {
  const t = useTranslations();
  const { setIsLoading } = useLoadingStore();
  const router = useRouter();
  const { setIsOpen } = useDialogAuthStore();

  const [isGetOtp, setIsGetOtp] = useState(false);
  const [isExpiredOtp, setIsExpiredOtp] = useState(0);
  const [isNewGetOtp, setIsNewGetOtp] = useState(false);
  const otpRef = useRef<CountdownTimerHandle>();

  const handleSubmit = async (data: ChangePasswordFormValues) => {
    try {
      setIsLoading(true);
      const response = await accountApiRequest.updatePassword({
        userId: user?.id + "" || "",
        newPassword: data.newPassword,
        password: data.currentPassword,
        otp: data.otp,
      });
      if (checkResSuccess(response.payload.code)) {
        await authApiRequest.logout();
        router.refresh();
        setIsOpen({ isOpen: true, mode: "LOGIN" });
      } else {
        toastError(
          t(
            `personal.changePassword.error_change_password.${response.payload.code}`
          ) || t("common.error")
        );
      }
    } catch (error) {
      console.log({ error });
      toastError(t("common.error"));
    } finally {
      setIsLoading(false);
    }
  };
  const handleGetOTP = async () => {
    if (!user) return;
    if (isNewGetOtp) return;
    setIsLoading(true);
    authApiRequest
      .getOtpUpdatePassword(user?.id + "")
      .then((response) => {
        if (checkResSuccess(response.payload.code)) {
          toastSuccess(response?.payload?.message);
          setIsExpiredOtp(300);
          otpRef.current?.reset();
          setIsNewGetOtp(true);
          setIsGetOtp(true);
          focusInput("change-pass-otp");
        } else {
          toastError(response?.payload?.message || t("common.error"));
        }
      })
      .catch(() => {
        setIsNewGetOtp(false);
        setIsLoading(false);
        toastError(t("common.error"));
      })
      .finally(() => {
        setIsLoading(false);
      });
  };

  return (
    <ContentPagePersonal title={t("personal.changePassword.title")}>
      <Form<ChangePasswordFormValues, typeof changePasswordSchema>
        schema={changePasswordSchema}
        onSubmit={handleSubmit}
        options={{
          mode: "onChange",
        }}
        defaultValue={{
          otp: "",
          currentPassword: "",
          newPassword: "",
          confirmPassword: "",
        }}
      >
        {({ control, getValues, formState: { errors } }) => {
          return (
            <>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-x-4 sm:gap-y-6 xl:gap-x-8 xl:gap-y-10">
                <InputField
                  isShadow
                  formatValueRegex={REGEX_INPUT_PASSWORD}
                  control={control}
                  errors={errors}
                  name="currentPassword"
                  type="password"
                  required
                  label={
                    t("personal.changePassword.current_password") as string
                  }
                  placeholder={t(
                    "personal.changePassword.placeholder_current_password"
                  )}
                />
                <div>
                  <InputField
                    isShadow
                    id="change-pass-otp"
                    formatValueRegex={REGEX_INPUT_OTP}
                    control={control}
                    errors={errors}
                    name="otp"
                    required
                    label={t("personal.changePassword.otp_code") as string}
                    label2={
                      <div className=" justify-between hidden md:flex">
                        <div className="text-primary font-semibold text-sm  text-center flex justify-center gap-2">
                          <Label>
                            <span
                              className={clsx(
                                "font-semibold text-sm leading-[14px] transition-all duration-300 ease-in-out md:hover:opacity-80 underline cursor-pointer",
                                {
                                  "pointer-events-none": isNewGetOtp,
                                  "text-gray-400": isNewGetOtp,
                                  "cursor-default": isNewGetOtp,
                                }
                              )}
                              onClick={() => handleGetOTP()}
                            >
                              {t("login.get_otp_code")}
                            </span>
                          </Label>

                          {isNewGetOtp && (
                            <CountdownTimer
                              className="leading-[14px]"
                              time={20}
                              callback={() => {
                                setIsNewGetOtp(false);
                              }}
                            />
                          )}
                        </div>
                      </div>
                    }
                    placeholder={t("personal.changePassword.input_otp")}
                  />
                  {isGetOtp &&
                    (isExpiredOtp ? (
                      <span className="text-xs lg:text-sm text-neutral mt-3 lg:mt-0">
                        <i>{t("personal.changePassword.otp_valid_period")}</i>
                        <CountdownTimer
                          ref={otpRef as LegacyRef<CountdownTimerHandle>}
                          time={isExpiredOtp}
                          callback={() => {
                            setIsExpiredOtp(0);
                          }}
                        />
                      </span>
                    ) : (
                      <span className="text-xs lg:text-sm text-error mt-3 lg:mt-0">
                        {t("personal.changePassword.resend_otp")}
                      </span>
                    ))}
                </div>
                <div className="flex justify-center mb-2  md:hidden">
                  <div className="text-primary font-semibold text-sm  text-center flex justify-center gap-2">
                    <p
                      className={clsx(
                        "font-semibold text-sm transition-all duration-300 ease-in-out md:hover:opacity-80 underline cursor-pointer",
                        {
                          "pointer-events-none": isNewGetOtp,
                          "text-gray-400": isNewGetOtp,
                          "cursor-default": isNewGetOtp,
                        }
                      )}
                      onClick={() => handleGetOTP()}
                    >
                      {t("login.get_otp_code")}
                    </p>
                    {isNewGetOtp && (
                      <CountdownTimer
                        time={20}
                        callback={() => {
                          setIsNewGetOtp(false);
                        }}
                      />
                    )}
                  </div>
                </div>
                <div>
                  <InputField
                    isShadow
                    formatValueRegex={REGEX_INPUT_PASSWORD}
                    control={control}
                    errors={errors}
                    name="newPassword"
                    type="password"
                    required
                    label={t("personal.changePassword.new_password") as string}
                    placeholder={t(
                      "personal.changePassword.placeholder_new_password"
                    )}
                  />
                  {!getValues("newPassword") &&
                    !errors["newPassword"]?.message && (
                      <span className="mt-2 text-neutral2 text-xs lg:text-[13px] leading-[21px]">
                        {t("personal.changePassword.password_rule")}
                      </span>
                    )}
                </div>
                <InputField
                  isShadow
                  formatValueRegex={REGEX_INPUT_PASSWORD}
                  control={control}
                  errors={errors}
                  name="confirmPassword"
                  type="password"
                  required
                  label={
                    t("personal.changePassword.confirm_password") as string
                  }
                  placeholder={t(
                    "personal.changePassword.placeholder_confirm_password"
                  )}
                />
              </div>
              <div className="mt-6 lg:mt-10">
                <Button className="w-full max-w-full lg:w-[227px]">
                  {t("common.confirm")}
                </Button>
              </div>
            </>
          );
        }}
      </Form>
    </ContentPagePersonal>
  );
};

export default ChangePasswordForm;
