import LocationIcon from "@/components/icons/location-icon";
import { IShowroomDetail } from "@/types/swap-sim";
import { useTranslations } from "next-intl";
import React from "react";

const ServicePointItem = ({
  item,
  index,
}: {
  item: IShowroomDetail;
  index: number;
}) => {
  const t = useTranslations();
  return (
    <div className="p-4 rounded-2xl bg-[#F5F6F7] flex gap-3">
      <LocationIcon />
      <div className="flex flex-col gap-2 break-all">
        <p className="font-bold text-neutral-dark-01">
          {index}. {item.name}
        </p>
        <p className="text-neutral-dark-04">{item.location}</p>
        <p className="text-neutral-dark-04">{item.hotline}</p>
        <p className="text-neutral-dark-04">
          {t("personal.warranty_information.open_time")}: {item.openTime} - {item.closeTime}
        </p>
      </div>
    </div>
  );
};

export default ServicePointItem;
