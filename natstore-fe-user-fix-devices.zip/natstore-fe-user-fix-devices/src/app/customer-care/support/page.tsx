import FAQs from "@/app/customer-care/support/_components/faqs";
import SupportContent from "@/app/customer-care/support/_components/support-content";
import Terms from "@/app/customer-care/support/_components/terms";
import BreadCrumbCommon from "@/components/breadcrumb-common";
import TabsCommon from "@/components/common/tabs/tabs";
import PageContent from "@/components/page-content";
import BannerHomePage from "@/module/home-page/banner-home-page";
import customerSupportApiRequest from "@/services/customer-service";
import { ILinks, ITabs } from "@/types/package";
import { getTranslations } from "next-intl/server";
import React from "react";
import "./suport.css";

type CustomerSupportPageProps = {
  params: { slug: string };
  searchParams: { [key: string]: string | undefined };
};

const getCustomerStatic = async () => {
  try {
    const res = await customerSupportApiRequest.getCustomerStatic();
    return res.payload.data;
  } catch (error) {
    console.log(error);
    throw Error("error");
  }
};

export default async function CustomerSupport({
  searchParams,
}: CustomerSupportPageProps) {
  const t = await getTranslations();
  const customerStatic = await getCustomerStatic();
  const breadCrumb: ILinks[] = [
    {
      label: t("personal.home"),
      link: "/",
    },
    {
      label: t("common.customer_support"),
      link: "/customer-support",
    },
  ];

  const tabs: ITabs[] = customerStatic?.map((item) => ({
    id: item.id,
    label: item.name,
    content: <SupportContent tabName={item.name} remaining={item} />,
    params: `?name=${item.id}`,
  }));

  const tabFix = [
    {
      id: "frequently_asked_questions",
      label: t("customer_support.frequently_asked_questions"),
      content: <FAQs tabName={searchParams?.tabFaqs} />,
      params: "?name=frequently_asked_questions",
    },
    {
      id: "terms",
      label: t("customer_support.terms"),
      content: <Terms />,
      params: "?name=terms",
    },
  ];

  tabs.unshift(...tabFix);

  return (
    <PageContent className="customer-support-page">
      <BannerHomePage />
      <BreadCrumbCommon content={breadCrumb} />
      <div className="mt-6 max-md:mt-3">
        <TabsCommon data={tabs} defaultTab={searchParams.name as string} />
      </div>
    </PageContent>
  );
}
