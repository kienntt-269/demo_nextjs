import FaqsTabs from "@/app/customer-care/support/_components/faqs-tab";
import SupportContent from "@/app/customer-care/support/_components/support-content";
import customerSupportApiRequest from "@/services/customer-service";
import React from "react";

type FAQsProps = {
  tabName?: string;
};

const getFaqCategory = async () => {
  try {
    const res = await customerSupportApiRequest.getFaqCategory();
    return res.payload.data;
  } catch (error) {
    console.log(error);
    throw Error("error");
  }
};

const getFaq = async (categoryId: number) => {
  try {
    const res = await customerSupportApiRequest.getFaq(categoryId);
    return res.payload.data;
  } catch (error) {
    console.log(error);
    throw Error("error");
  }
};

const FAQs = async ({ tabName }: FAQsProps) => {
  const faqCategory = await getFaqCategory();
  const faqId = tabName
    ? faqCategory?.find((item) => item.name === tabName)?.id
    : faqCategory?.[0]?.id;
  const faqs = await getFaq(faqId || 0);
  return (
    <div className="">
      <FaqsTabs active={tabName} serviceTab={faqCategory}></FaqsTabs>
      <SupportContent tabName={tabName ?? faqCategory?.[0]?.name} faqs={faqs} />
    </div>
  );
};

export default FAQs;
