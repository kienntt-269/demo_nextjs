import NotFound from "@/components/common/not-found";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import {
  ICustomerSupportFaq,
  ICustomerSupportStatic,
} from "@/schemaValidations/customer-support.schema";
import clsx from "clsx";
import React from "react";
import { parseStringToHTML } from "@/lib/utils";

type SupportContentProps = {
  tabName: string;
  faqs?: ICustomerSupportFaq[];
  remaining?: ICustomerSupportStatic;
};

const SupportContent = ({ tabName, faqs, remaining }: SupportContentProps) => {
  return (
    <div className="flex flex-col justify-center items-center bg-white mt-4 lg:mt-6 py-6 px-4 lg:p-8 rounded-3xl">
      {!!faqs?.length || !!remaining?.content ? (
        <>
          <h2 className="font-bold text-xl lg:text-2xl text-neutral-dark-01 mb-4 lg:mb-8">
            {tabName}
          </h2>
          <div className="flex flex-col w-full">
            {faqs
              ? faqs.map((faq, index) => (
                  <div
                    key={faq.id}
                    className={clsx(
                      "border-solid border-[1px] border-[#C5C5C5] bg-[#F5F6F7] rounded-lg",
                      {
                        "mb-4": index !== faqs.length - 1,
                      }
                    )}
                  >
                    <Accordion type="single" collapsible>
                      <AccordionItem value={String(faq.id)}>
                        <AccordionTrigger className="!no-underline px-3 lg:px-6 py-3 text-xs md:text-sm text-neutral-dark-01 font-bold">
                          {index + 1}. {faq?.question}
                        </AccordionTrigger>
                        <AccordionContent className="px-3 lg:px-6 text-xs md:text-sm text-neutral-dark-04 whitespace-pre-normal break-words">
                          {parseStringToHTML(faq?.answer)}
                        </AccordionContent>
                      </AccordionItem>
                    </Accordion>
                  </div>
                ))
              : null}
            {remaining?.content ? (
              <div className="border-solid border-[1px] border-[#C5C5C5] bg-[#F5F6F7] rounded-lg py-3 px-3 lg:px-6 flex flex-col w-full whitespace-normal break-words">
                {parseStringToHTML(remaining.content)}
              </div>
            ) : null}
          </div>
        </>
      ) : (
        <NotFound />
      )}
    </div>
  );
};

export default SupportContent;
