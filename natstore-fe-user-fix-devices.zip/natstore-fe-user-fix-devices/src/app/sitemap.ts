import { getDevice, getDeviceCategories } from "@/lib/repository";
import { IDeviceCategories } from "@/schemaValidations/device.schema";
import fs from "fs";
import { MetadataRoute } from "next";
import path from "path";

export const dynamic = "force-dynamic";

const baseUrl = "https://natcomstore.arabicatech.vn";
const baseDir = "src/app";
const excludeDirs = ["api", "fonts"];

export const revalidate = 3600; // revalidate at most every hour

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const fullPath = path.join(process.cwd(), baseDir);
  const entries = fs.readdirSync(fullPath, { withFileTypes: true });
  const routes: string[] = ["/"];

  entries.forEach((entry) => {
    if (entry.isDirectory() && !excludeDirs.includes(entry.name)) {
      routes.push(`/${entry.name}`);
    }
  });
  const categories = await getDeviceCategories();
  const deviceCategories: IDeviceCategories[] = await Promise.all(
    categories.map(async (category) => {
      const deviceTop3Rate = await getDevice({ categoryId: category.id });
      return {
        ...category,
        children: {
          ...deviceTop3Rate,
        },
      };
    })
  );
  const devicesCategoryUrls: MetadataRoute.Sitemap = deviceCategories.map(
    (category) => {
      return {
        url: `${baseUrl}/devices/${category.slug}`,
        lastModified: new Date(),
        priority: 1,
        changeFrequency: "weekly" as const,
      };
    }
  );
  // const devicesUrls: MetadataRoute.Sitemap[] = deviceCategories.map(
  //   (category) => {
  //     return category?.children?.pagination?.map((device) => {
  //       return {
  //         url: `${baseUrl}/devices/${category.slug}/${device.slug}?name=${device.name}&id=${device.id}`
  //           .replace(/&/g, "&amp;")
  //           .replace(/"/g, "&quot;")
  //           .replace(/'/g, "&apos;")
  //           .replace(/</g, "&lt;")
  //           .replace(/>/g, "&gt;"),
  //         lastModified: new Date(),
  //         priority: 1,
  //         changeFrequency: "weekly",
  //       };
  //     });
  //   }
  // );

  const urls = [
    ...routes.map((route) => ({
      url: `${baseUrl}${route}`,
      lastModified: new Date(),
      changeFrequency: "weekly",
      priority: 1.0,
    })),
    ...devicesCategoryUrls,
    // ...devicesUrls.flat(),
  ];

  return urls as MetadataRoute.Sitemap;
}
