import React from "react";
import BreadCrumbCommon from "@/components/breadcrumb-common";
import PageContent from "@/components/page-content";
import { ILinks } from "@/types/package";
import Image from "next/image";
import { getTranslations } from "next-intl/server";
import TitleStyle from "@/components/title-common";
import BannerHomePage from "@/module/home-page/banner-home-page";
import internetApiRequest from "@/services/internet";
import InternetClient from "@/module/internet-service/internet-client";
import { Metadata } from "next";
// import { IDataServiceCategories } from "@/schemaValidations/service-categories";

export const dynamic = "force-dynamic";
const dataGetInternet = async () => {
  const res = await internetApiRequest.getDataInternet({
    type: "BUY_INTERNET_PACKAGE",
  });
  return res.payload.data;
};

const dataCategoriesList = async () => {
  const res = await internetApiRequest.getDataInternetCategory();
  return res.payload.data;
};

interface InternetProps {
  searchParams: {
    [key: string]: string | string[] | undefined;
  };
}

async function Internet({ searchParams }: InternetProps) {
  const dataInternet = await dataGetInternet();
  const serviceCategoriesList = await dataCategoriesList();
  const t = await getTranslations();
  const listChildren = serviceCategoriesList?.[0]?.children;
  const internetView =
    searchParams?.["internet-view"] || listChildren?.[0]?.slug;
  const chilrenActive = listChildren.find((item) => item.slug === internetView);
  const breadCrumb: ILinks[] = [
    {
      label: t("personal.home"),
      link: "/",
    },
    {
      label: t("internet.internet"),
      link: "/internet",
    },
    {
      label: chilrenActive?.name,
      link: `/internet?internet-view=${chilrenActive?.slug}`,
    },
  ];
  const jsonLd = {
    "@context": "https://schema.org/",
    "@type": "Product",
    name: "Super Stream & Surf Package",
    image:
      "https://minio-natstore.arabicatech.vn/public/image…nshot%202025-03-26%20at%2011.18.16%E2%80%AFPM.png",
    description:
      "Experience lightning-fast internet speeds of up to 500 Mbps and access to over 200 premium HD TV channels, including sports, movies, and family entertainment. Perfect for avid streamers and large households.",
    sku: "PKG-SSS-001",
    mpn: "ISPT-500-200HD",
    brand: {
      "@type": "Brand",
      name: "YourTelecomCo",
    },
    aggregateRating: {
      "@type": "AggregateRating",
      ratingValue: "4.8",
      reviewCount: "450",
    },
    offers: {
      "@type": "Offer",
      url: "https://natcomstore.arabicatech.vn/internet",
      priceCurrency: "HTG",
      price: "79.99",
      priceValidUntil: "2025-12-31",
      itemCondition: "https://schema.org/NewCondition",
      availability: "https://schema.org/InStock",
      seller: {
        "@type": "Organization",
        name: "YourTelecomCo Inc.",
      },
      hasProductTemplate: {
        "@type": "Product",
        name: "Internet Service",
        additionalProperty: [
          {
            "@type": "PropertyValue",
            name: "Download Speed",
            value: "500 Mbps",
          },
          {
            "@type": "PropertyValue",
            name: "Upload Speed",
            value: "50 Mbps",
          },
          {
            "@type": "PropertyValue",
            name: "Data Cap",
            value: "Unlimited",
          },
        ],
      },
      includesObject: {
        "@type": "Product",
        name: "Premium TV Channels",
        description: "Access to 200+ HD channels",
        additionalProperty: [
          {
            "@type": "PropertyValue",
            name: "Number of Channels",
            value: "200+",
          },
          {
            "@type": "PropertyValue",
            name: "Channel Quality",
            value: "HD",
          },
        ],
      },
    },
    additionalProperty: [
      {
        "@type": "PropertyValue",
        name: "Contract Term",
        value: "12 Months",
      },
      {
        "@type": "PropertyValue",
        name: "Installation Fee",
        value: "Free",
      },
      {
        "@type": "PropertyValue",
        name: "Customer Support",
        value: "24/7",
      },
    ],
    review: {
      "@type": "Review",
      reviewRating: {
        "@type": "Rating",
        ratingValue: "5",
        bestRating: "5",
      },
      author: {
        "@type": "Person",
        name: "John Doe",
      },
      reviewBody:
        "Fantastic speed and a great selection of channels. Installation was quick and easy!",
    },
    hasOfferCatalog: {
      "@type": "OfferCatalog",
      name: "Internet & TV Packages",
      numberOfItems: 5,
      itemListElement: [
        {
          "@type": "Offer",
          itemOffered: {
            "@type": "Service",
            name: "Basic Surf Package",
          },
        },
        {
          "@type": "Offer",
          itemOffered: {
            "@type": "Service",
            name: "Movie Lover Bundle",
          },
        },
      ],
    },
  };
  return (
    <PageContent>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />
      <BannerHomePage />
      <div className="mt-6">
        <BreadCrumbCommon content={breadCrumb} />
      </div>
      <div className="mt-10 flex items-center gap-x-4 max-md:hidden">
        <Image
          src={"/svg/internet.svg"}
          alt="phone mobile"
          unoptimized
          quality={100}
          width={72}
          height={72}
        />

        <TitleStyle>{t("internet.internet")}</TitleStyle>
      </div>
      <InternetClient
        isList={true}
        dataInternet={dataInternet}
        serviceCategoriesList={serviceCategoriesList}
      />
    </PageContent>
  );
}

export const generateMetadata = async (): Promise<Metadata> => {
  const url = "https://natcomstore.arabicatech.vn/internet";
  return {
    title: "Internet Package Natcom",
    description:
      "Experience lightning-fast internet speeds of up to 500 Mbps and access to over 200 premium HD TV channels, including sports, movies, and family entertainment. Perfect for avid streamers and large households.",
    keywords: [
      `internet natcom`,
      `internet`,
      `natcom internet`,
      `internet package`,
    ],
    alternates: {
      canonical: url,
    },
    openGraph: {
      title: "Internet Package Natcom",
      description:
        "Experience lightning-fast internet speeds of up to 500 Mbps and access to over 200 premium HD TV channels, including sports, movies, and family entertainment. Perfect for avid streamers and large households.",
      images:
        "https://minio-natstore.arabicatech.vn/public/image…nshot%202025-03-26%20at%2011.18.16%E2%80%AFPM.png",
      type: "website",
      url: url,
    },
    metadataBase: new URL(url),
    twitter: {
      card: "summary_large_image",
      title: "Internet Package Natcom",
      description:
        "Experience lightning-fast internet speeds of up to 500 Mbps and access to over 200 premium HD TV channels, including sports, movies, and family entertainment. Perfect for avid streamers and large households.",
      images:
        "https://minio-natstore.arabicatech.vn/public/image…nshot%202025-03-26%20at%2011.18.16%E2%80%AFPM.png",
    },
  };
};

export default Internet;
