"use client";

import { Button } from "@/components/ui/button";
import { useTranslations } from "next-intl";
import Image from "next/image";
import React from "react";
import { storage } from "@/lib/storage";
import { isEmpty } from "lodash";
import ErrorPage from "@/components/error";
import { IDataInternetDetail } from "@/schemaValidations/internet.shema";
import { formatMoney, formatTimeWithDay } from "@/lib/utils";

const InternetError = ({
  dataDetail,
}: {
  dataDetail?: IDataInternetDetail;
}) => {
  const data = storage.getResponsePaymentDataInternet();
  const t = useTranslations();

  if (isEmpty(data) || !data) {
    return <ErrorPage />;
  }

  const renderItemViewComponent = (title: string, value: string) => {
    return (
      <div className="py-2 flex justify-between items-center text-sm lg:text-base text-neutral-dark-02 gap-4">
        <div className="self-start whitespace-nowrap">{title}</div>
        <div className="text-end font-bold" style={{ wordBreak: "break-word" }}>
          {value ?? "-"}
        </div>
      </div>
    );
  };

  return (
    <div className="flex justify-center mt-10 max-md:mt-4">
      <div className="bg-white lg:w-[768px] px-4 py-6 lg:p-8 max-lg:mt-8 shadow-[0px_3.09px_12.37px_0px_#00000014] rounded-3xl">
        <div className="p-4 flex justify-center">
          <Image
            alt="check circle"
            src={"/images/icon/check-error.svg"}
            width={64}
            height={64}
            className="size-[64px]"
          />
        </div>
        <h2 className="my-6 text-xl lg:leading-8 lg:text-[28px] font-bold text-black text-center">
          {t("internet.payment_error.title")}
        </h2>
        <div className="bg-[#F5F6F7] rounded-2xl p-4">
          {renderItemViewComponent(
            t("internet.payment_success.id_number"),
            data.transactionId
          )}
          {renderItemViewComponent(
            t("internet.payment_success.time_register"),
            formatTimeWithDay(t, data?.transactionTime)
          )}

          {renderItemViewComponent(
            t("internet.full_name_placeholder"),
            data?.customer?.fullName
          )}
          {data?.customer?.email &&
            renderItemViewComponent(t("register.email"), data?.customer?.email)}
          {renderItemViewComponent(
            t("internet.id_card"),
            data?.customer?.idCardNumber
          )}

          {renderItemViewComponent(
            t("internet.phone_number"),
            `(+509) ${data?.customer?.phoneNumber}`
          )}

          {renderItemViewComponent(
            t("common.installation_address"),
            data.address
          )}

          {renderItemViewComponent(
            t("internet.product_name"),
            dataDetail?.name ?? ""
          )}

          <div className="py-2 flex justify-between items-center text-sm lg:text-base text-neutral-dark-02 gap-4">
            <div className="whitespace-nowrap self-start">
              {t("internet.number_of_months_of_use")}
            </div>
            <div className=" text-end flex flex-col justify-end">
              <div className="font-bold">
                {data.monthBase ?? "-"}{" "}
                {data.monthBase === 1 ? t("common.month") : t("common.months")}
              </div>
              {!!data.monthBonus && (
                <div className="text-[#616161] text-sm">
                  (
                  {data.monthBonus === 1
                    ? t("internet.month_number_bonus", {
                        monthNumberBonus: data.monthBonus,
                      })
                    : t("internet.months_number_bonus", {
                        monthNumberBonus: data.monthBonus,
                      })}{" "}
                  )
                </div>
              )}
            </div>
          </div>
          {renderItemViewComponent(
            t("internet.installation_fee_register"),
            data?.installationFee !== undefined &&
              data?.installationFee !== null
              ? String(data.installationFee) + " $"
              : t("common.free")
          )}
          <div className="py-2 flex justify-between items-center text-sm lg:text-base text-[#212121]">
            <div className="self-start">{t("common.total")}</div>
            <div className=" text-end flex flex-col justify-end">
              <div className="font-bold">
                {formatMoney(data?.total) ?? "-"} {data?.total ? " $" : ""}
              </div>
              <div className="text-neutral-dark-04 text-sm">
                ({t("internet.included_VAT")})
              </div>
            </div>
          </div>
        </div>
        <div className="mt-4 mb-6 text-sm lg:text-base text-neutral-dark-04 text-center">
          <div className="">
            {t("internet.payment_success.desc_1", {
              phone: data?.customer?.phoneNumber ?? "-",
            })}
          </div>
          <div className="">{t("internet.payment_success.desc_2")}</div>
        </div>
        <div className="flex justify-center">
          <Button className="max-sm:w-full min-w-[243px]" navigate="/">
            {t("common.back_home_page")}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default InternetError;
