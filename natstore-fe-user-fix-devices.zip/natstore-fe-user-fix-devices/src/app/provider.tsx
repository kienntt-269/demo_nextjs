"use client";

import React, { useEffect, useState } from "react";
import { useProfileStore } from "@/_stores/useProfile.store";
import { IProfileStore } from "@/types/stores";
import { usePathname, useSearchParams } from "next/navigation";
import LoadingBar from "react-top-loading-bar";
import { storage } from "@/lib/storage";
import { PAYMENT_INTERNET_PACKAGE_SLUG } from "@/constants/common";
import { useInternetDebtStore } from "@/_stores/useInternetDebt.store";

type ProviderProps = {
  account: IProfileStore | null;
  children: React.ReactNode;
};

function Loading() {
  const pathname = usePathname();
  const [progress, setProgress] = useState(0);
  const searchParams = useSearchParams();
  const { clear } = useInternetDebtStore();

  useEffect(() => {
    setProgress(25);
    const timeout = setTimeout(() => setProgress(100), 300);
    return () => clearTimeout(timeout);
  }, [pathname]);

  useEffect(() => {
    const internetView = searchParams.get("internet-view");
    if (internetView !== PAYMENT_INTERNET_PACKAGE_SLUG) {
      storage.removeDataPaymentPackage();
      clear();
    }
  }, [searchParams]);

  return (
    <div>
      <LoadingBar
        color="#ff8600"
        progress={progress}
        onLoaderFinished={() => setProgress(0)}
      />
    </div>
  );
}

export function Provider({ account, children }: ProviderProps): JSX.Element {
  const { setProfile } = useProfileStore();
  React.useEffect(() => {
    if (account) {
      setProfile(account);
    }
  }, [account?.user]);

  return (
    <div>
      <Loading />
      {children}
    </div>
  );
}
