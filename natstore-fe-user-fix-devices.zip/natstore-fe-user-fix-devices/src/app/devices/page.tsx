import { ILinks } from "@/types/package";
import BreadCrumbCommon from "@/components/breadcrumb-common";
import { getTranslations } from "next-intl/server";
import PageContent from "@/components/page-content";
import BannerHomePage from "@/module/home-page/banner-home-page";
import TabDeviceList from "@/app/devices/_components/tab-device-list";
import { IDeviceCategories } from "@/schemaValidations/device.schema";
import { getDevice, getDeviceCategories } from "@/lib/repository";
export const dynamic = "force-dynamic";

export default async function Device() {
  const categories = await getDeviceCategories();
  const deviceCategories: IDeviceCategories[] = await Promise.all(
    categories.map(async (category) => {
      const deviceTop3Rate = await getDevice({ categoryId: category.id });
      return {
        ...category,
        children: {
          ...deviceTop3Rate,
        },
      };
    })
  );

  const t = await getTranslations();

  const breadCrumb: ILinks[] = [
    {
      label: t("personal.home"),
      link: "/",
    },
    {
      label: t("search.device"),
      link: "/devices",
    },
  ];

  return (
    <PageContent>
      <BannerHomePage />
      <BreadCrumbCommon content={breadCrumb} />
      {deviceCategories.map((deviceCategory) => (
        <div key={deviceCategory.id}>
          <TabDeviceList data={deviceCategory} />
        </div>
      ))}
    </PageContent>
  );
}
