"use client";

import BreadCrumbCommon from "@/components/breadcrumb-common";
import { Form, InputField, SelectField } from "@/components/form";
import DatePickerField from "@/components/form/date-picker-field";
import { InputPhoneNumberField } from "@/components/form/input-phone-number-field";
import UploadFileSingle from "@/components/form/upload-file-single";
import PageContent from "@/components/page-content";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { TYPE_OF_DOC } from "@/constants/variable";
import {
  RegisterAccountAffiliateType,
  schemaRegisterAccountAffiliate,
} from "@/schemaValidations/device.schema";
import { IAddressDetail } from "@/schemaValidations/sim-card.schema";
import simApiRequest from "@/services/sim-service";
import { Option } from "@/types/common";
import { ILinks } from "@/types/package";
import clsx from "clsx";
import { useTranslations } from "next-intl";
import Image from "next/image";
import { useRouter } from "next/navigation";
import React, { useEffect, useMemo, useState } from "react";
import { Controller } from "react-hook-form";

const RegisterAccountAffiliate = () => {
  const t = useTranslations("");
  const schema = useMemo(() => schemaRegisterAccountAffiliate, []);
  const router = useRouter();
  const [provinces, setProvinces] = useState<IAddressDetail[]>([
    { name: t("common.no_data"), id: 0 },
  ]);
  const [districts, setDistricts] = useState<IAddressDetail[]>([
    { name: t("common.no_data"), id: 0 },
  ]);
  const [wards, setwards] = useState<IAddressDetail[]>([
    { name: t("common.no_data"), id: 0 },
  ]);
  const [checkCondition, setCheckCondition] = useState<boolean>(false);

  const breadCrumb: ILinks[] = [
    {
      label: t("personal.home"),
      link: "/",
    },
    {
      label: "Affiliate",
      link: "/device",
    },
    {
      label: t("common.register"),
      link: `/`,
    },
  ];

  const optionRadios: Option[] = [
    {
      label: "Male",
      value: "male",
    },
    {
      label: "Female",
      value: "female",
    },
  ];

  const getProvince = async () => {
    try {
      const res = await simApiRequest.getAddress({
        type: 1,
      });
      setProvinces(res.payload.data);
    } catch (error) {
      console.log(error);
    }
  };

  const getDistrict = async (id: string) => {
    try {
      const res = await simApiRequest.getAddress({
        type: 2,
        parentId: id,
      });
      setDistricts(
        res?.payload?.data.length > 0
          ? res.payload.data
          : [{ name: t("common.no_data"), id: 0 }]
      );
      setwards([{ name: t("common.no_data"), id: 0 }]);
    } catch (error) {
      console.log(error);
    }
  };
  const getward = async (id: string) => {
    try {
      const res = await simApiRequest.getAddress({
        type: 3,
        parentId: id,
      });
      setwards(
        res?.payload?.data.length > 0
          ? res.payload.data
          : [{ name: t("common.no_data"), id: 0 }]
      );
    } catch (error) {
      console.log(error);
    }
  };

  const handleSubmit = (data: RegisterAccountAffiliateType) => {
    console.log("🚀 ~ handleSubmit ~ data:", data);
  };

  useEffect(() => {
    getProvince();
  }, []);
  return (
    <PageContent>
      <BreadCrumbCommon content={breadCrumb} />
      <div className="mt-10 max-md:mt-6">
        <Form<RegisterAccountAffiliateType, typeof schema>
          schema={schema}
          onSubmit={handleSubmit}
          options={{
            mode: "onChange",
          }}
        >
          {({
            control,
            formState: { errors, isValid },
            setValue,
            watch,
            trigger,
          }) => {
            const values = watch();
            return (
              <div>
                <div className="w-full bg-white rounded-3xl p-8 max-md:p-4">
                  <div className="text-[28px] max-md:text-[20px] font-bold mb-4 max-md:mb-2 text-black">
                    {t("phone_device.register_account")}
                  </div>
                  <div className="flex items-center gap-2 text-primary text-sm font-bold mb-8 max-md:mb-6">
                    <Image
                      alt="info"
                      src="/info.svg"
                      width={24}
                      height={24}
                      className="max-md:size-[20px]"
                    />
                    {t("phone_device.collaborator_policy")}
                  </div>
                  <div className="text-[20px] font-bold max-md:text-[16px]">
                    {t("phone_device.login_information")}
                  </div>
                  <div className="mt-2 text-neutral-dark-04 text-[14px] max-md:text-[12px]">
                    (*) {t("mobile_package.sim_normal.please_fill_in")}
                  </div>
                  <div className="flex flex-row max-md:flex-col lg:items-center justify-center gap-6 max-lg:gap-3 mt-4 max-md:mt-2">
                    <div className="flex-1">
                      <InputField
                        maxLength={50}
                        name="userName"
                        label={t("common.userName")}
                        classNameLabel="!font-normal text-sm lg:text-base !text-neutral-dark-01"
                        placeholder={`${t("common.userName")}*`}
                        type="text"
                        control={control}
                        errors={errors}
                        required
                      />
                    </div>
                    <div className="flex-1">
                      <InputField
                        maxLength={255}
                        name="email"
                        label={t("register.email")}
                        classNameLabel="!font-normal text-sm lg:text-base !text-neutral-dark-01"
                        placeholder={`${t("register.email")}*`}
                        type="text"
                        control={control}
                        errors={errors}
                      />
                    </div>
                  </div>
                  <div className="text-[20px] font-bold mt-8 max-md:mt-6 max-md:text-[16px]">
                    {t("phone_device.identity_document_information")}
                  </div>
                  <div className="grid grid-cols-3 gap-x-6 gap-y-4 max-lg:gap-3 max-md:grid-cols-1 mt-4 max-md:mt-2">
                    <InputField
                      maxLength={50}
                      name="fullName"
                      label={t("mobile_package.swap_sim.full_name")}
                      classNameLabel="!font-normal text-sm lg:text-base !text-neutral-dark-01"
                      placeholder={`${t("mobile_package.swap_sim.full_name")}*`}
                      type="text"
                      control={control}
                      errors={errors}
                      required
                    />
                    <DatePickerField
                      name="dob"
                      label={t("mobile_package.swap_sim.date_placholder")}
                      control={control}
                      errors={errors}
                      placeholder={t("mobile_package.swap_sim.date_placholder")}
                      classNameLabel="!font-normal text-sm lg:text-base !text-neutral-dark-01"
                      required
                    />
                    <SelectField
                      name="gender"
                      label={t("mobile_package.swap_sim.gender")}
                      control={control}
                      placeholder={`${t("mobile_package.swap_sim.gender")}*`}
                      options={optionRadios}
                      trigger={trigger}
                      error={errors?.gender}
                    />
                    <SelectField
                      error={errors?.typeOfDoc}
                      control={control}
                      placeholder={t("mobile_package.swap_sim.type_of_doc")}
                      name="typeOfDoc"
                      label={t("mobile_package.swap_sim.type_of_doc")}
                      classNameLabel="!font-normal text-xs lg:text-base !text-neutral-dark-01"
                      options={TYPE_OF_DOC.map((item) => ({
                        label: item.name,
                        value: item.id + "",
                      }))}
                      required
                    />
                    <InputField
                      maxLength={50}
                      name="idCard"
                      label={t("mobile_package.swap_sim.passport_placholder")}
                      classNameLabel="!font-normal text-sm lg:text-base !text-neutral-dark-01"
                      placeholder={`${t("mobile_package.swap_sim.passport_placholder")}*`}
                      type="text"
                      control={control}
                      errors={errors}
                      required
                    />
                    <InputField
                      maxLength={50}
                      name="taxCode"
                      label={t("phone_device.tax_code")}
                      classNameLabel="!font-normal text-sm lg:text-base !text-neutral-dark-01"
                      placeholder={`${t("phone_device.tax_code")}*`}
                      type="text"
                      control={control}
                      errors={errors}
                      required
                    />
                  </div>
                  <div className="mt-4 grid grid-cols-2 gap-4 max-md:grid-cols-1">
                    <div>
                      <label className="text-sm md:text-base" htmlFor="">
                        {t("mobile_package.sim_normal.province_city")}
                        <span className="text-red-500">*</span>
                      </label>
                      <Controller
                        name="provinceId"
                        control={control}
                        render={({
                          field: { onChange },
                          fieldState: { error },
                        }) => {
                          return (
                            <div className="flex flex-col">
                              <Select
                                onValueChange={(value) => {
                                  setValue("districtId", "");
                                  setValue("wardId", "");
                                  onChange(value);
                                  getDistrict(value);
                                }}
                              >
                                <SelectTrigger
                                  className={clsx(
                                    "flex-1 py-[12px] px-[16px] h-[48px] rounded-xl mt-2 data-[placeholder]:text-neutral-mid-01",
                                    {
                                      "border-solid border border-error":
                                        !!error,
                                    }
                                  )}
                                >
                                  <SelectValue
                                    placeholder={t(
                                      "mobile_package.sim_normal.province_city"
                                    )}
                                  />
                                </SelectTrigger>
                                <SelectContent>
                                  {provinces?.map((val) => {
                                    return (
                                      <SelectItem
                                        key={val.id}
                                        value={`${val.id}`}
                                      >
                                        {val.name}
                                      </SelectItem>
                                    );
                                  })}
                                </SelectContent>
                              </Select>
                              {error && (
                                <p className="text-red-500 text-sm mt-1">
                                  {t(`common.message.${error.message}`)}
                                </p>
                              )}
                            </div>
                          );
                        }}
                      />
                    </div>
                    <div>
                      <label className="text-sm md:text-base" htmlFor="">
                        {t("mobile_package.sim_normal.disctrict")}
                        <span className="text-red-500">*</span>
                      </label>
                      <Controller
                        name="districtId"
                        control={control}
                        render={({
                          field: { onChange, value },
                          fieldState: { error },
                        }) => {
                          return (
                            <div className="flex flex-col">
                              <Select
                                onValueChange={(value) => {
                                  setValue("wardId", "");
                                  onChange(value);
                                  getward(value);
                                }}
                                value={value}
                              >
                                <SelectTrigger
                                  className={clsx(
                                    "flex-1 py-[12px] px-[16px] h-[48px] rounded-xl mt-2 data-[placeholder]:text-neutral-mid-01",
                                    {
                                      "border-solid border border-error":
                                        !!error,
                                    }
                                  )}
                                >
                                  <SelectValue
                                    key={values.wardId}
                                    placeholder={t(
                                      "mobile_package.sim_normal.disctrict"
                                    )}
                                  />
                                </SelectTrigger>
                                <SelectContent>
                                  {districts?.map((val) => {
                                    return (
                                      <SelectItem
                                        key={val.id}
                                        value={`${val.id ? val.id : null}`}
                                        disabled={districts?.[0].id === 0}
                                      >
                                        {val.name}
                                      </SelectItem>
                                    );
                                  })}
                                </SelectContent>
                              </Select>
                              {error && (
                                <p className="text-red-500 text-sm mt-1">
                                  {t(`common.message.${error.message}`)}
                                </p>
                              )}
                            </div>
                          );
                        }}
                      />
                    </div>
                    <div>
                      <label className="text-sm md:text-base" htmlFor="">
                        {t("phone_device.ward")}
                      </label>
                      <span className="text-red-500">*</span>
                      <Controller
                        name="wardId"
                        control={control}
                        render={({
                          field: { onChange, value },
                          fieldState: { error },
                        }) => {
                          return (
                            <div className="flex flex-col">
                              <Select
                                onValueChange={(value) => {
                                  onChange(value);
                                }}
                                value={value}
                              >
                                <SelectTrigger
                                  className={clsx(
                                    "flex-1 py-[12px] px-[16px] h-[48px] rounded-xl mt-2 data-[placeholder]:text-neutral-mid-01",
                                    {
                                      "border-solid border border-error":
                                        !!error,
                                    }
                                  )}
                                >
                                  <SelectValue
                                    placeholder={t("phone_device.ward")}
                                  />
                                </SelectTrigger>
                                <SelectContent>
                                  {wards?.map((val) => {
                                    return (
                                      <SelectItem
                                        key={val.id}
                                        value={`${val.id}`}
                                        disabled={wards?.[0].id === 0}
                                      >
                                        {val.name}
                                      </SelectItem>
                                    );
                                  })}
                                </SelectContent>
                              </Select>
                              {error && (
                                <p className="text-red-500 text-sm mt-1">
                                  {t(`common.message.${error.message}`)}
                                </p>
                              )}
                            </div>
                          );
                        }}
                      />
                    </div>

                    <div>
                      <label className="text-sm md:text-base" htmlFor="">
                        {t("common.address")}
                      </label>
                      <InputField
                        name="address"
                        placeholder={t("phone_device.detai_address")}
                        className="mt-2"
                        control={control}
                        maxLength={200}
                        required={false}
                      />
                    </div>
                  </div>
                  <div className="text-base md:text-[20px] font-bold mt-8 max-md:mt-6">
                    {t("common.upload_id_image")}
                    <span className="text-red-500">*</span>
                  </div>
                  <>
                    <div className="my-4 text-neutral-dark-04 text-xs md:text-[14px]">
                      {t("internet.file_upload")}
                    </div>
                    <div className="mt-4 flex gap-6 max-md:gap-4">
                      <div className="flex flex-col">
                        <UploadFileSingle
                          label={t("common.upload")}
                          name="faceImage"
                          control={control}
                          labelBottom={t(
                            "mobile_package.sim_normal.face_photo"
                          )}
                          className="max-md:h-[72px] max-md:w-[72px]"
                        />
                      </div>
                      <div className="flex flex-col">
                        <UploadFileSingle
                          label={t("common.upload")}
                          name="backIdcard"
                          control={control}
                          className="max-md:h-[72px] max-md:w-[72px]"
                          labelBottom={t("internet.back_photo")}
                        />
                      </div>
                      <div className="flex flex-col">
                        <UploadFileSingle
                          label={t("common.upload")}
                          name="frontIdCard"
                          control={control}
                          className="max-md:h-[72px] max-md:w-[72px]"
                          labelBottom={t("internet.front_photo")}
                        />
                      </div>
                    </div>
                  </>
                  <div className="flex items-center flex-row max-md:flex-col max-md:items-start gap-4 mt-8 mb-4 max-md:mt-6 max-md:mb-4">
                    <div className="text-[20px] max-md:text-[16px] font-bold">
                      {t("mobile_package.swap_sim.payment_method")}
                    </div>
                    <RadioGroup defaultValue={"1"} value={"1"}>
                      <div className="grid grid-cols-3 gap-x-4 max-md:grid-cols-1 max-md:gap-y-2">
                        <label
                          htmlFor="paymentMethod"
                          className={`w-full flex items-center cursor-pointer justify-between`}
                        >
                          <div className="flex items-center space-x-2 cursor-pointer gap-x-2 max-lg:text-[14px]">
                            <RadioGroupItem
                              value="1"
                              id="paymentMethod"
                              className={`border-primary border-[2px]`}
                            />
                            {t("payment.natcash")}
                          </div>
                        </label>
                      </div>
                    </RadioGroup>
                  </div>
                  <div className="">
                    <InputPhoneNumberField
                      maxLength={50}
                      name="phoneNumber"
                      label={t("phone_device.phone_wallet")}
                      classNameLabel="!font-normal text-sm lg:text-base !text-neutral-dark-01"
                      placeholder={`${t("login.phone_number")}*`}
                      type="text"
                      control={control}
                      errors={errors}
                      required
                    />
                  </div>
                  <div className="mt-4 text-sm lg:text-base font-bold text-neutral-dark-04">
                    {t("common.note")}:
                  </div>
                  <div className="list-item list-disc ml-5 text-xs lg:text-sm text-neutral-dark-04">
                    {t("phone_device.note_register_ffiliate")}
                  </div>
                  <div className="my-6 lg:my-8 flex gap-x-2 items-start">
                    <Checkbox
                      checked={checkCondition}
                      onCheckedChange={(value) =>
                        setCheckCondition(value as boolean)
                      }
                      className="size-6"
                    />
                    <div className="text-sm text-[#A2A2A2]">
                      {t("payment.i_agree_to_the")}
                      <span
                        className="font-semibold text-primary underline ml-1 cursor-pointer"
                        onClick={() => {
                          router.push(`/customer-care/support?name=terms`);
                        }}
                      >
                        {t("payment.terms_of_purchase")}
                      </span>
                    </div>
                  </div>
                  <div className="flex flex-col items-center gap-2 lg:gap-4">
                    <Button
                      className="min-w-[197px] max-md:w-full font-bold rounded-3xl max-md:rounded-2xl py-[12px]"
                      disabled={!checkCondition || !isValid}
                      type="submit"
                    >
                      {t("common.register")}
                    </Button>
                  </div>
                </div>
              </div>
            );
          }}
        </Form>
      </div>
    </PageContent>
  );
};

export default RegisterAccountAffiliate;
