"use client";

import { useLangStore } from "@/_stores/useLang.store";
import TitleStyle from "@/components/title-common";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { useTranslations } from "next-intl";
import React from "react";

const SwapSim = () => {
  const t = useTranslations("");
  const { lang } = useLangStore();
  return (
    <div className="mt-6 max-lg:mt-4">
      <div className="flex justify-between items-center w-full">
        <TitleStyle classStyle="text-[28px]">{t("common.swap_sim")}</TitleStyle>
      </div>
      <div className="mt-6 max-md:mt-3 flex flex-col xl:flex-row items-center gap-6">
        <div className="flex-1 text-sm xl:text-base text-neutral-dark-03">
          {t("mobile_package.swap_sim.desc_4")}
        </div>
        <div className="flex-1 flex items-center flex-wrap gap-4">
          <Button
            className="flex-1 font-bold min-w-[150px] lg:min-w-[212px] rounded-3xl"
            variant="secondary"
            navigate="/mobile-package/swap-sim"
          >
            {t("mobile_package.detail")}
          </Button>
          <Button
            className={cn(
              "flex-1 font-bold min-w-[150px] lg:min-w-[212px] rounded-3xl",
              {
                "max-sm:!text-[13px]": lang == "fr",
              },
            )}
            variant="secondary"
            navigate="/mobile-package/swap-sim/compatible-equipment"
          >
            {t("mobile_package.swap_sim.compatible_equipment")}
          </Button>
          <Button
            navigate="/mobile-package/swap-sim/register"
            className={cn(
              "flex-1 font-bold min-w-[150px] lg:min-w-[212px] rounded-3xl",
              {
                "!text-[14px]": lang == "fr",
                "max-sm:!text-[13px]": lang == "fr",
              },
            )}
          >
            {t("mobile_package.swap_sim.swap_sim_now")}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default SwapSim;
