import VasDetail from "@/app/mobile-package/vas/_components/detail";
import VasItem from "@/app/mobile-package/vas/_components/vas-item";
import BreadCrumbCommon from "@/components/breadcrumb-common";
import CarouselData from "@/components/common/carousel-data/carousel-data";
import PageContent from "@/components/page-content";
import TextWithTooltip from "@/components/text-width-tooltip";
import mobilePackageApiRequest from "@/services/mobile-package";
import mobileApiRequest from "@/services/mobile-service";
import { ILinks } from "@/types/package";
import { getTranslations } from "next-intl/server";
export const dynamic = "force-dynamic";

type VasDetailProps = {
  params: { slug: string };
};

const getVasCategories = async () => {
  try {
    const res = await mobilePackageApiRequest.getVasCategories();
    return res.payload.data;
  } catch (error) {
    console.log(error);
    throw Error("error");
  }
};

const getListSimilar = async (packageId: string) => {
  try {
    const res = await mobileApiRequest.getListSimilar(packageId);
    return res.payload.data;
  } catch (error) {
    console.log(error);
    throw Error("error");
  }
};

const getDetailVas = async (idOrSlug: string) => {
  try {
    const res = await mobilePackageApiRequest.getDetailVas(idOrSlug);
    return res.payload.data;
  } catch (error) {
    console.log(error);
    throw Error("error");
  }
};

const VasDetailPage = async ({ params }: VasDetailProps) => {
  const t = await getTranslations();
  const vasDetail = await getDetailVas(params.slug);
  const vasCategories = await getVasCategories();
  const category = vasCategories?.[0].children.find(
    (item) => item.id === vasDetail.categoryId
  );
  const vasListSimila = await getListSimilar(params.slug);
  const breadCrumb: ILinks[] = [
    {
      label: t("personal.home"),
      link: "/",
    },
    {
      label: t("mobile_package.roaming.mobile_service"),
      link: "/mobile-package",
    },
    {
      label: t("mobile_package.vas"),
      link: "/mobile-package/vas",
    },
    {
      label: <TextWithTooltip content={`${category?.name}`} />,
      link: `/mobile-package/vas?vasSlug=${category?.slug}`,
    },
    {
      label: (
        <TextWithTooltip
          content={vasDetail.name || ""}
          textSuffix={t("mobile_package.detail")}
        />
      ),
      link: `/mobile-package/vas/${params.slug}`,
    },
  ];

  return (
    <PageContent>
      <BreadCrumbCommon content={breadCrumb} />
      <VasDetail data={vasDetail} />
      <div className="mb-2.5 bg-[#f5f6f7]">
        <h3 className="text-size-32 font-bold mb-3 lg:mb-6">
          {t("mobile_package.simila_vas_package")}
        </h3>
        <CarouselData quantity={4} length={vasListSimila?.length}>
          {vasListSimila?.map((data) => (
            <VasItem key={data.slug} data={data} />
          ))}
        </CarouselData>
      </div>
    </PageContent>
  );
};

export default VasDetailPage;
