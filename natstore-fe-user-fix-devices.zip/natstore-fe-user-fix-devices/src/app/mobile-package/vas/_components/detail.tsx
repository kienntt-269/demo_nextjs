import React from "react";
import { getTranslations } from "next-intl/server";
import ImageCommon from "@/components/common/image-common";
import { getImageUrl } from "@/constants/imageUrl";
import PlanSummary from "@/module/mobile-services/component/plan-summary";
import { IDataPlan } from "@/schemaValidations/mobile-service.schema";

type VasDetailProps = {
  data: IDataPlan;
};

export default async function VasDetail({ data }: VasDetailProps) {
  const t = await getTranslations();
  return (
    <div className="my-10 px-28 max-md:my-6 max-2xl:px-16 max-lg:px-8 max-md:px-0">
      <PlanSummary data={data} />
      <div className="bg-white mt-6 rounded-3xl p-4 lg:p-8 flex gap-y-3 lg:gap-x-8">
        <div className="flex-1">
          <div className="mb-4 lg:mb-6">
            {data.description && (
              <>
                <div className="mb-3 lg:mb-4 text-base font-semibold">
                  {t("mobile_package.data.bonus_information")}
                </div>
                <p className="mt-4 max-md:mt-3 max-sm:text-sm text-neutral-dark-04 font-normal break-all whitespace-pre-line">
                  {data.description}
                </p>
              </>
            )}
          </div>
          <div className="mb-4 lg:mb-6">
            {data.shortDescription && (
              <>
                <div className="mb-3 lg:mb-4 text-base font-semibold">
                  {t("mobile_package.data.benefit")}
                </div>
                <p className="mt-4 max-md:mt-3 max-sm:text-sm text-neutral-dark-04 font-normal break-all whitespace-pre-line">
                  {data.shortDescription}
                </p>
              </>
            )}
          </div>
        </div>
        <div className="">
          <ImageCommon
            src={data.imagePath ? getImageUrl(data.imagePath) : "/"}
            alt="bon_info"
            width={361}
            height={252}
            className="h-[252px] object-contain rounded-2xl hidden sm:block"
          />
        </div>
      </div>
    </div>
  );
}
