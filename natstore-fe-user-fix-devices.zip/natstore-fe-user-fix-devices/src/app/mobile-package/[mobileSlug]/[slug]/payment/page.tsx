"use client";
import React, { useEffect, useMemo, useState } from "react";
import BreadCrumbCommon from "@/components/breadcrumb-common";
import PageContent from "@/components/page-content";
import { Checkbox } from "@/components/ui/checkbox";
import {
  useParams,
  usePathname,
  useRouter,
  useSearchParams,
} from "next/navigation";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import InformationPayment from "./information-payment";
import { ILinks } from "@/types/package";
import { useTranslations } from "next-intl";
import mobileApiRequest from "@/services/mobile-service";
import {
  ICategoriesDataPlant,
  IDataPlan,
  PaymentDataPackage,
} from "@/schemaValidations/mobile-service.schema";
import { paymentService } from "@/services/payment-service";
import { PAYMENT_METHOD } from "@/constants/common";
import { RegistrationType, StateUsePointType } from "@/types/common";
import { Form } from "@/components/form";
import { InputPhoneNumberField } from "@/components/form/input-phone-number-field";
import RadioButtonField from "@/components/form/radio-button-field";
import { PaymentFormValues } from "@/types/mobile-package";
import { useLoadingStore } from "@/_stores/useLoading,store";
import PaymentError from "@/module/payment/payment-error";
import PaymentSuccess from "@/module/payment/payment-success";
import { toastError, toastSuccess } from "@/hooks/use-toast";
import { storage } from "@/lib/storage";
import { checkResErrorData, checkResSuccess } from "@/lib/utils";
import TextWithTooltip from "@/components/text-width-tooltip";
import { IPaymentMethod } from "@/types/payment";
import OtpModal from "@/app/mobile-package/swap-sim/_component/otp-modal";
import { Controller } from "react-hook-form";
import { REGEX_VALIDATE_PHONE_NUMBER_ON_NET } from "@/constants/regex";
import { useProfileStore } from "@/_stores/useProfile.store";

const getData = async (slug: string) => {
  try {
    const res = await mobileApiRequest.getDetailData(slug);
    return res.payload;
  } catch (error) {
    console.log(error);
    throw Error("error");
  }
};

const PaymentDataPlans = () => {
  const params = useParams();
  const { setIsLoading } = useLoadingStore();
  const [method, setMethod] = useState<string>("");
  const [productInfoRes, setProductInfoRes] = useState<IDataPlan>();
  const [acceptPolicy, setAcceptPolicy] = useState<boolean>(true);
  const [isPromotionType, setIsPromotionType] = useState<boolean>(false);
  const [orderId, setOrderId] = useState<string>("");
  const [listPaymentMethod, setListPaymentMethod] = useState<IPaymentMethod[]>(
    []
  );
  const [phoneNumber, setPhoneNumber] = useState<string>("");
  const [isGetOtp, setIsGetOtp] = useState(false);
  const [formValues, setFormValues] = useState<PaymentFormValues>();
  const [packageId, setPackageId] = useState<string>("");
  const [isVisible, setIsVisible] = useState<boolean>(false);
  const [error, setError] = useState<string>("");
  const [stateUsePoint, setStateUsePoint] = useState<
    StateUsePointType | undefined
  >();
  const searchParams = useSearchParams();
  const t = useTranslations();
  const pathName = usePathname();
  const router = useRouter();
  const { user } = useProfileStore();
  const optionRadios = [
    {
      label: t("payment.register_normal"),
      value: "NORMAL",
    },
    {
      label: t("payment.register_auto_renew"),
      value: "AUTO_RENEW",
    },
    {
      label: t("payment.share_plan"),
      value: "SHARE_PLAN",
    },
  ];
  const breadCrumb: ILinks[] = [
    {
      label: t("personal.home"),
      link: "/",
    },
    {
      label: t("mobile_package.roaming.mobile_service"),
      link: "/mobile-package",
    },
    {
      label: `${productInfoRes?.categories[1]?.name ?? ""}`,
      link: `/mobile-package/${productInfoRes?.categories[1]?.slug ?? ""}`,
    },
    {
      label: (
        <TextWithTooltip
          content={`${productInfoRes?.categories[2]?.name ?? ""}`}
        />
      ),
      link: `/mobile-package/${productInfoRes?.categories[1].slug}?categoryId=${productInfoRes?.categories[2]?.id}`,
    },
    {
      label: <TextWithTooltip content={productInfoRes?.name || ""} />,
      link: `/mobile-package/${productInfoRes?.categories[1]?.slug}/${params.slug}`,
    },
    {
      label: t("common.register"),
      link: `/mobile-package/${productInfoRes?.categories[1]?.slug}/${params.slug}/payment`,
    },
  ];

  const handleChangePoint = (point: StateUsePointType) => {
    setStateUsePoint(point);
  };

  const handlePayment = (
    registration: RegistrationType,
    sharePhoneNumber?: string,
    paymentPhoneNumber?: string
  ) => {
    setIsLoading(true);
    storage.setDataPackageRegister(
      JSON.stringify({ slug: params.slug as string, orderId: orderId })
    );
    if (method === PAYMENT_METHOD.NATCOM) {
      paymentService
        .dataPlanOrdeNatcomPayment({
          orderId: orderId,
          registrationType: registration,
          sharePhoneNumber:
            registration === "SHARE_PLAN" ? sharePhoneNumber : undefined,
          paymentPhoneNumber: paymentPhoneNumber,
          debitedPoint: stateUsePoint?.redeemPoint || undefined,
        })
        .then((res) => {
          setIsLoading(false);
          if (checkResSuccess(res.payload.code ?? "")) {
            if (
              res.payload.data.status === "REGISTER_SUCCESS" ||
              res.payload.data.status === "WAITING_PAYMENT" ||
              res.payload.data.status === "NEW"
            ) {
              router.push(
                `${pathName}?statusPayment=success&paymentMethod=natcom&orderId=${orderId}`
              );
            }
            // navigate to success page or error page
            if (
              res.payload.data.status === "REGISTER_FAILED" ||
              res.payload.data.status === "PAYMENT_ERROR"
            ) {
              router.push(
                `${pathName}?statusPayment=error&paymentMethod=natcom&orderId=${orderId}`
              );
            }
          } else {
            toastError(t(`payment.message.${res.payload.code}`));
          }
        });
    } else if (method === PAYMENT_METHOD.NATCASH) {
      paymentService
        .dataPlanbeginNatcashPayment({
          orderId: orderId,
          registrationType: registration,
          sharePhoneNumber:
            registration === "SHARE_PLAN" ? sharePhoneNumber : undefined,
          debitedPoint: stateUsePoint?.redeemPoint || undefined,
        })
        .then((res) => {
          setIsLoading(false);
          if (res?.payload?.data?.paymentUrl) {
            window.open(res.payload.data.paymentUrl, "_self");
          } else {
            if (checkResErrorData(res.payload?.code ?? "")) {
              router.push(
                `${pathName}?statusPayment=error&paymentMethod=natcash&orderId=${orderId}`
              );
            } else {
              toastError(res.payload.data.price);
            }
          }
        });
    }
  };

  function isValidPhoneNumber(code: string): boolean {
    const regex = REGEX_VALIDATE_PHONE_NUMBER_ON_NET;
    return regex.test(code);
  }

  const handleVerifyOTP = async (values: PaymentFormValues) => {
    try {
      const res = await paymentService.natcomPayment(values);
      if (res.payload.code === "27") {
        setIsVisible(true);
        setIsGetOtp(true);
      }
    } catch (error) {
      console.log(error);
    }
  };

  const sendOTPPayment = async (otp: string) => {
    setIsLoading(true);
    try {
      const res = await paymentService.natcomPayment({
        ...formValues,
        orderId: orderId,
        otp: otp,
      });
      if (res.payload.code === "00" && otp) {
        setIsVisible(false);
        router.push(
          `${pathName}?statusPayment=success&paymentMethod=natcom&orderId=${orderId}`
        );
      } else if (res.payload.code === "28" && otp) {
        toastError(t(`forgot.error.89`));
      } else if (res.payload.code === "27") {
        toastSuccess(t(`login.otp_sent`));
        setIsGetOtp(true);
      } else if (otp) {
        router.push(
          `${pathName}?statusPayment=error&paymentMethod=natcom&orderId=${orderId}`
        );
      }
    } catch (error) {
      console.log(error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (!params.slug) return;
    getData(params.slug as string).then((res) => {
      const isPromotion: ICategoriesDataPlant = res.data.categories.find(
        (val) => val.slug === "promotion"
      ) as ICategoriesDataPlant;
      setIsPromotionType(isPromotion?.id ? true : false);
      setProductInfoRes(res?.data);
      if (!res.data.id || searchParams.get("paymentStatus")) return;
      setPackageId(res.data.id);
      paymentService
        .createDataPlanOrder({
          packageId: res.data.id,
        })
        .then((res) => {
          setOrderId(res?.payload?.data?.orderId);
        });
    });
    getPaymentMethods();
  }, [params.slug, searchParams]);

  const handleSubmit = async (data: PaymentFormValues) => {
    console.log(data);
  };
  const schema = useMemo(() => PaymentDataPackage(), []);

  const getPaymentMethods = async () => {
    try {
      const res = await paymentService.getPaymentMethods("data");
      setListPaymentMethod(res.payload.data ?? []);
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <PageContent className="bg-background-content">
      <BreadCrumbCommon content={breadCrumb} />
      {isVisible && (
        <OtpModal
          isModal={isVisible}
          onSubmit={(otp) => {
            sendOTPPayment(otp);
          }}
          time={20}
          phoneNumber={`(+509) ${phoneNumber}`}
          error={error}
          onClose={() => {
            setIsVisible(false);
          }}
          isGetOTP={isGetOtp}
          timeExpired={299}
          setError={(val) => {
            setError(val);
          }}
          onResend={() => {
            setIsGetOtp(false);
            sendOTPPayment("");
          }}
        />
      )}

      {searchParams.get("statusPayment") === "success" && (
        <PaymentSuccess
          paymentTarget="data"
          paymentMethod={searchParams.get("paymentMethod") ?? "natcash"}
          idPackage={params.slug as string}
          orderId={searchParams.get("orderId") ?? ""}
        />
      )}
      {searchParams.get("statusPayment") === "error" && (
        <PaymentError
          paymentTarget="data"
          paymentMethod={searchParams.get("paymentMethod") ?? "natcash"}
          idPackage={params.slug as string}
          typeError={searchParams.get("typeError")}
          orderId={searchParams.get("orderId") ?? ""}
        />
      )}

      {!searchParams.get("statusPayment") && (
        <Form<PaymentFormValues, typeof schema>
          onSubmit={handleSubmit}
          schema={schema}
          options={{
            mode: "all",
          }}
          defaultValue={{
            registrationType: "NORMAL",
            orderId: orderId,
            sharePhoneNumber: "",
            paymentPhoneNumber: "",
            method: method ?? "",
            isdn: user?.isdn,
          }}
        >
          {({
            control,
            formState: { errors, isValid },
            watch,
            trigger,
            setValue,
          }) => {
            const values = watch();
            // eslint-disable-next-line react-hooks/rules-of-hooks
            useEffect(() => {
              trigger("sharePhoneNumber");
            }, [method]);
            return (
              <div className="mt-10 max-xl:mt-8 max-md:mt-4 grid grid-cols-7fr-3fr max-lg:block gap-x-6 max-xl:gap-x-3">
                <div className="w-full bg-white rounded-3xl p-8 max-xl:p-6">
                  <div className="text-[28px] leading-[34px] max-xl:text-[22px] max-xl:leading-6 max-lg:text-[20px] font-bold">
                    {t("payment.payment_method")}
                  </div>
                  <div className="mt-8 max-xl:mt-4">
                    <div className="text-[20px] max-xl:text-[18px] max-lg:text-[16px] font-bold leading-6">
                      {t("payment.select_registration_form")}
                    </div>
                  </div>
                  <div className="mt-4 max-lg:mt-2">
                    <RadioButtonField
                      name="registrationType"
                      control={control}
                      options={
                        isPromotionType
                          ? [
                              {
                                label: t("payment.register_normal"),
                                value: "NORMAL",
                              },
                            ]
                          : optionRadios
                      }
                      className="flex max-lg:flex-col max-lg:gap-y-2 gap-x-7"
                    />
                  </div>
                  {values.registrationType === "SHARE_PLAN" && (
                    <div className="mt-6">
                      <InputPhoneNumberField
                        autoFocus
                        control={control}
                        errors={errors}
                        name="sharePhoneNumber"
                        type="text"
                        placeholder={t("register.phone_number")}
                      />
                    </div>
                  )}

                  <div className="mt-8 max-lg:mt-4">
                    <div className="text-[20px] max-xl:text-[18px] max-lg:text-[16px] font-bold leading-6">
                      {t("payment.select_payment_method")}
                    </div>
                  </div>
                  <div className="mt-4 max-lg:mt-2">
                    <Controller
                      name="method"
                      control={control}
                      render={({ field }) => (
                        <RadioGroup
                          {...field}
                          value={values.method}
                          onValueChange={(val) => {
                            // console.log(val);
                            // trigger("sharePhoneNumber");
                            setMethod(val);
                            setValue("method", val);
                          }}
                        >
                          <div className="grid grid-cols-3 max-2xl:grid-cols-2 max-xl:gap-3 max-lg:block gap-4">
                            {listPaymentMethod.length > 0 &&
                              listPaymentMethod.map((val) => (
                                <div
                                  key={val.code}
                                  className={`w-full ${method === val.code ? "bg-primary/20 border-primary text-primary font-bold" : "bg-[#F5F6F7] border-neutral font-normal text-neutral-dark-04"}   border-[2px] border-solio rounded-xl py-3 px-6 max-lg:mt-2`}
                                >
                                  <label
                                    htmlFor={`${val.code}`}
                                    className="flex items-center space-x-2 cursor-pointer gap-x-2 max-lg:text-[14px]"
                                  >
                                    <RadioGroupItem
                                      value={`${val.code}`}
                                      id={`${val.code}`}
                                      className={`${method === val.code ? "border-primary" : "border-neutral"}  border-[2px]`}
                                      disabled={!val.active}
                                    />
                                    {val.name ?? ""}
                                  </label>
                                </div>
                              ))}
                          </div>
                        </RadioGroup>
                      )}
                    />
                  </div>
                  {method !== "natcash" && method !== "" && (
                    <div className="mt-6">
                      <InputPhoneNumberField
                        autoFocus
                        control={control}
                        errors={errors}
                        name="paymentPhoneNumber"
                        label={t("register.phone_number")}
                        required
                        type="text"
                        placeholder={t("register.phone_number")}
                      />
                    </div>
                  )}

                  <div className="mt-8 max-lg:mt-4 h-6 flex gap-x-2 items-center">
                    <Checkbox
                      checked={acceptPolicy}
                      className="size-6 max-lg:size-4"
                      onClick={() => {
                        setAcceptPolicy(!acceptPolicy);
                      }}
                    />
                    <div className="font-bold text-[14px] text-neutral">
                      {t("payment.i_agree_to_the")}
                      <span
                        className="text-primary underline ml-1 cursor-pointer"
                        onClick={() => {
                          router.push(`/customer-care/support?name=terms`);
                        }}
                      >
                        {t("payment.terms_of_purchase")}
                      </span>
                    </div>
                  </div>
                </div>

                <InformationPayment
                  onChangeStatePoint={handleChangePoint}
                  stateUsePoint={stateUsePoint}
                  orderId={orderId}
                  planInfo={productInfoRes}
                  disable={isValid && acceptPolicy && method !== ""}
                  onPay={() => {
                    if (method === PAYMENT_METHOD.NATCASH) {
                      handlePayment(
                        values.registrationType,
                        values.sharePhoneNumber,
                        values.paymentPhoneNumber
                      );
                    } else {
                      setPhoneNumber(values.paymentPhoneNumber ?? "");
                      setFormValues(values);
                      if (
                        !isValidPhoneNumber(`${user?.isdn}`) &&
                        values.registrationType !== "SHARE_PLAN"
                      ) {
                        toastError(
                          t(`common.message.natcom.register_user_phone_natcom`)
                        );
                      } else {
                        handleVerifyOTP({
                          ...values,
                          packageId: packageId,
                          orderId: orderId,
                          otp: "",
                        });
                      }
                    }
                  }}
                />
              </div>
            );
          }}
        </Form>
      )}
    </PageContent>
  );
};

export default PaymentDataPlans;
