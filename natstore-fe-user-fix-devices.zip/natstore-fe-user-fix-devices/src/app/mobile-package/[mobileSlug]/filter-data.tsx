"use client";
import React, { useEffect, useState } from "react";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { ChevronDown, ChevronUp } from "lucide-react";
import { useTranslations } from "next-intl";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { usePathname, useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";

interface IProps {
  searchParams: { [key in string]: string };
}

const FilterDataPackage: React.FC<IProps> = ({ searchParams }) => {
  const [isOpen, setIsOpen] = useState<boolean>(false);
  const router = useRouter();
  const t = useTranslations();
  const pathname = usePathname();
  const updateSearchParams = (
    newParams: Record<string, string | null> | { [x: string]: boolean }
  ) => {
    const params = new URLSearchParams(searchParams);

    Object.entries(newParams).forEach(([key, value]) => {
      if (value === null) {
        params.delete(key);
      } else {
        params.set(key, value);
      }
    });
    return `?${params.toString()}`;
  };
  useEffect(() => {
    setIsOpen(false);
  }, [searchParams]);
  return (
    <Popover
      open={isOpen}
      onOpenChange={() => {
        setIsOpen(!isOpen);
      }}
    >
      <PopoverTrigger asChild>
        <button
          className={`py-3 px-5 max-xl:py-2 max-md:px-3 max-md:py-[6px] rounded-3xl ${
            searchParams.sortBy ||
            searchParams.categorize ||
            searchParams.hot ||
            searchParams.recommend ||
            searchParams.bestSeller
              ? "bg-[#FF860029]"
              : "border-[#333333] text-neutral-dark-03 border-solid border"
          }  flex items-center gap-x-2`}
        >
          {searchParams.sortBy ||
          searchParams.categorize ||
          searchParams.hot ||
          searchParams.recommend ||
          searchParams.bestSeller ? (
            <ChevronUp className="text-[24px] max-xl:size-5 max-md:size-4" />
          ) : (
            <ChevronDown className="text-[24px] max-xl:size-5 max-md:size-4" />
          )}
          <div className="font-semibold max-xl:text-[14px]">
            {t("common.filter")}
          </div>
        </button>
      </PopoverTrigger>
      <PopoverContent className="w-60 rounded-xl border-white shadow-md">
        <div className="font-semibold"> {t("common.filter")}</div>
        <div className="flex flex-col gap-y-4 mt-3">
          <label
            htmlFor="hot_plan"
            className="flex items-center space-x-2 cursor-pointer gap-x-2 text-neutral4 hover:text-primary"
          >
            <Checkbox
              className="size-6 max-lg:size-4"
              id="hot_plan"
              checked={searchParams.hot === "true"}
              onCheckedChange={(event) => {
                if (event) {
                  const newparams = updateSearchParams({
                    hot: `${event}`,
                  });
                  router.push(newparams, { scroll: false });
                } else {
                  const newparams = updateSearchParams({
                    hot: `false`,
                  });
                  router.push(newparams, { scroll: false });
                }
              }}
            />
            {t("mobile_package.hot_plan")}
          </label>
          <label
            htmlFor="recommended"
            className="flex items-center space-x-2 cursor-pointer gap-x-2 text-neutral4 hover:text-primary"
          >
            <Checkbox
              className="size-6 max-lg:size-4"
              id="recommended"
              checked={searchParams.recommend === "true"}
              onCheckedChange={(event) => {
                if (event) {
                  const newparams = updateSearchParams({
                    recommend: `${event}`,
                  });
                  router.push(newparams, { scroll: false });
                } else {
                  const newparams = updateSearchParams({
                    recommend: `false`,
                  });
                  router.push(newparams, { scroll: false });
                }
              }}
            />
            {t("common.recommended")}
          </label>
          <label
            htmlFor="best_sellers"
            className="flex items-center space-x-2 cursor-pointer gap-x-2 text-neutral4 hover:text-primary"
          >
            <Checkbox
              className="size-6 max-lg:size-4"
              id="best_sellers"
              checked={searchParams.bestSeller === "true"}
              onCheckedChange={(event) => {
                if (event) {
                  const newparams = updateSearchParams({
                    bestSeller: `${event}`,
                  });
                  router.push(newparams, { scroll: false });
                } else {
                  const newparams = updateSearchParams({
                    bestSeller: `false`,
                  });
                  router.push(newparams, { scroll: false });
                }
              }}
            />
            {t("common.best_sellers")}
          </label>
        </div>
        <div className="mt-4">
          <div className="font-semibold">{t("common.sort_by")}</div>
          <RadioGroup
            defaultValue="register_normal"
            value={searchParams.sortBy ? searchParams.sortBy : "latest"}
            className="flex flex-col gap-y-4 mt-3"
            onValueChange={(event) => {
              if (event === "latest") {
                const newparams = updateSearchParams({
                  latest: "true",
                  sortBy: "",
                });
                router.push(newparams);
              }
              // console.log(event);
            }}
          >
            <label
              htmlFor="lastest"
              className="flex items-center space-x-2 cursor-pointer gap-x-2 text-neutral4 hover:text-primary"
            >
              <RadioGroupItem
                value="latest"
                id="lastest"
                className="max-md:size-[18px]"
              />
              {t("mobile_package.lastest")}
            </label>
            <label
              htmlFor="low_to_high"
              className="flex items-center space-x-2 cursor-pointer gap-x-2 text-neutral4 hover:text-primary"
            >
              <RadioGroupItem
                value="PRICE_ASC"
                id="low_to_high"
                className="max-md:size-[18px]"
                onClick={() => {
                  const newparams = updateSearchParams({
                    sortBy: "PRICE_ASC",
                    lastest: "false",
                  });
                  router.push(newparams, { scroll: false });
                }}
              />
              {t("mobile_package.low_to_high")}
            </label>
            <label
              htmlFor="high_to_low"
              className="flex items-center space-x-2 cursor-pointer gap-x-2 text-neutral4 hover:text-primary"
            >
              <RadioGroupItem
                value="PRICE_DESC"
                id="high_to_low"
                className="max-md:size-[18px]"
                onClick={() => {
                  const newparams = updateSearchParams({
                    sortBy: "PRICE_DESC",
                    lastest: "false",
                  });
                  router.push(newparams, { scroll: false });
                }}
              />
              {t("mobile_package.high_to_low")}
            </label>
          </RadioGroup>
          <div className="mt-2 flex justify-end">
            <Button
              variant={"ghost"}
              onClick={() => {
                router.push(pathname);
              }}
            >
              {t("common.clear")}
            </Button>
          </div>
        </div>
      </PopoverContent>
    </Popover>
  );
};

export default FilterDataPackage;
