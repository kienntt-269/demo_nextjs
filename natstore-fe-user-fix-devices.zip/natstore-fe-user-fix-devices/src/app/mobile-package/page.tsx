import React from "react";
import BreadCrumbCommon from "@/components/breadcrumb-common";
import PageContent from "@/components/page-content";
import { ILinks } from "@/types/package";
import VasMobileService from "@/app/mobile-package/vas-mobile-service";
import DataPlansMobile from "@/app/mobile-package/data-plans";
import Image from "next/image";
import { getTranslations } from "next-intl/server";
import TitleStyle from "@/components/title-common";
import BannerHomePage from "@/module/home-page/banner-home-page";
// import SwapSim from "@/app/mobile-package/swap-sim";
import TableSimService from "@/app/mobile-package/table-sim-service";
// import ListSimPackage from "@/app/mobile-package/buy-sim/list-sim-package";

type MobilePageProps = {
  params: { slug: string };
  searchParams: { [key: string]: string | undefined };
};

export const dynamic = "force-dynamic";

async function MobilePackagePage({ searchParams }: MobilePageProps) {
  const t = await getTranslations();
  const breadCrumb: ILinks[] = [
    {
      label: t("personal.home"),
      link: "/",
    },
    {
      label: t("mobile_package.roaming.mobile_service"),
      link: "/mobile-package",
    },
  ];
  return (
    <PageContent>
      <BannerHomePage />
      <BreadCrumbCommon content={breadCrumb} />
      <div className="mt-10 flex items-center gap-x-4 max-md:hidden max-md:mt-6">
        <div className="size-[72px] rounded-full border-[2px] border-solid border-primary flex justify-center items-center">
          <Image
            src={"/mobile-package/phone_mobile.png"}
            alt="phone mobile"
            unoptimized
            quality={100}
            width={25}
            height={40}
          />
        </div>
        <TitleStyle>{t("mobile_package.roaming.mobile_service")}</TitleStyle>
      </div>
      <DataPlansMobile />
      <TableSimService />
      {/* <SwapSim /> */}
      <VasMobileService searchParams={searchParams} />
    </PageContent>
  );
}

export default MobilePackagePage;
