"use client";

import React, { useState } from "react";
import { useTranslations } from "next-intl";
import {
  SimChangeRequestSim,
  SimChangeRequestSimType,
} from "@/schemaValidations/swap-sim.schema";
import { Option } from "@/types/common";
import { Form, InputField, SelectField } from "@/components/form";
import RadioButtonField from "@/components/form/radio-button-field";
import DatePickerField from "@/components/form/date-picker-field";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";
import { useLoadingStore } from "@/_stores/useLoading,store";
import { useSwapSimStore } from "@/_stores/useSwapSwim.store";
import mobilePackageApiRequest from "@/services/mobile-package";
import {
  FAIL_CODE,
  FAIL_CODE5,
  SUCCESS_CODE3,
} from "@/constants/http-response";
import ResultEmailModal from "@/app/mobile-package/swap-sim/sim-change-request-form/_components/result-email-modal";
import { toastError } from "@/hooks/use-toast";
import { TYPE_OF_DOC } from "@/constants/variable";

const RequestForm = () => {
  const t = useTranslations("mobile_package.swap_sim");
  const { setIsLoading } = useLoadingStore();
  const requestId = useSwapSimStore((state) => state.requestId);
  const [checkCondition, setCheckCondition] = useState<boolean>(false);
  const [isShowConfirm, setIsShowConfirm] = useState<boolean>(false);

  const optionRadios: Option[] = [
    {
      label: "Male",
      value: "male",
    },
    {
      label: "Female",
      value: "female",
    },
  ];
  const optionRadiosSimSwap: Option[] = [
    {
      label: t("physical_sim_to_esim"),
      value: "physical_sim_to_esim",
    },
    {
      label: t("esim_to_physical_sim"),
      value: "esim_to_physical_sim",
    },
  ];

  const handleSubmit = async (data: SimChangeRequestSimType) => {
    try {
      if (requestId) {
        setIsLoading(true);
        const res = await mobilePackageApiRequest.formsSwapSim(requestId, data);
        if (res.payload.code === FAIL_CODE || res.payload.code === FAIL_CODE5) {
          toastError(res.payload.message);
          return;
        }
        if (res.payload.code === SUCCESS_CODE3) {
          //show popup confirm
          setIsShowConfirm(true);
        }
      }
    } catch (error) {
      console.log({ error });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex justify-center">
      <div className="w-[343px] rounded-3xl bg-white flex flex-col lg:w-[1032px] lg:max-w-full p-8 overflow-y-auto scrollbar-thin scrollbar-thumb-gray-400 scrollbar-track-gray-200">
        <h2 className="mt-2 mb-6 lg:text-[28px] lg:leading-[34px] text-neutral-dark-01 font-bold">
          {t("sim_change_form")}
        </h2>
        <p className="text-sm lg:text-base text-neutral-dark-02 mb-6">
          {t("sim_change_form_desc")}
        </p>
        <Form<SimChangeRequestSimType, typeof SimChangeRequestSim>
          schema={SimChangeRequestSim}
          onSubmit={handleSubmit}
          options={{
            mode: "onChange",
          }}
          defaultValue={{
            phoneNumber: "",
            contactNumber1: "",
            contactNumber2: "",
            contactNumber3: "",
            contactNumber4: "",
            contactNumber5: "",
            gender: "male",
            contactPhoneNumber: "",
            identityNumber: "",
            typeOfDoc: "",
            address: "",
            email: "",
            sim_swap: "physical_sim_to_esim",
          }}
        >
          {({ control, formState: { errors }, reset, watch }) => {
            const requiredFields: (keyof SimChangeRequestSimType)[] = [
              "contactNumber1",
              "contactNumber2",
              "contactNumber3",
              "fullname",
              "contactPhoneNumber",
              "identityNumber",
              "dob",
            ];
            const isFormValid = requiredFields.every((field) =>
              watch(field)?.toString()?.trim()
            );
            return (
              <>
                <h3 className="font-bold text-xl mb-4">
                  {t("sim_change_form_1")}
                </h3>
                <div className="p-4 bg-[#F5F6F7] rounded-2xl">
                  <p className="mb-4 text-sm text-neutral-dark-03">
                    {t("sim_change_form_1_desc_1")}
                  </p>
                  <div className="-mt-2">
                    <InputField
                      name="phoneNumber"
                      placeholder={t("phone")}
                      type="text"
                      className=""
                      control={control}
                      errors={errors}
                    />
                  </div>
                  <p className="mt-4 text-sm text-neutral-dark-03">
                    {t("sim_change_form_1_desc_2")}
                  </p>
                </div>
                <div className="mt-4 p-4 bg-[#F5F6F7] rounded-2xl">
                  <p className="mb-4 text-sm text-neutral-dark-03">
                    {t("sim_change_form_1_desc_3")}
                  </p>
                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-2">
                    <div className="basis-1 lg:basis-1/3">
                      <div className="flex items-start justify-center gap-2">
                        <div className="text-sm lg:text-base text-neutral-dark-01 font-bold px-4 py-3 rounded-xl border border-[#A2A2A2] border-solid">
                          1
                        </div>
                        <InputField
                          name="contactNumber1"
                          placeholder={`${t("phone")}*`}
                          type="text"
                          className="-mt-2"
                          control={control}
                          errors={errors}
                        />
                      </div>
                    </div>
                    <div className="basis-1 lg:basis-1/3">
                      <div className="flex items-start justify-center gap-2">
                        <div className="text-sm lg:text-base text-neutral-dark-01 font-bold px-4 py-3 rounded-xl border border-[#A2A2A2] border-solid">
                          2
                        </div>
                        <InputField
                          name="contactNumber2"
                          placeholder={`${t("phone")}*`}
                          type="text"
                          className="-mt-2"
                          control={control}
                          errors={errors}
                        />
                      </div>
                    </div>
                    <div className="basis-1 lg:basis-1/3">
                      <div className="flex items-start justify-center gap-2">
                        <div className="text-sm lg:text-base text-neutral-dark-01 font-bold px-4 py-3 rounded-xl border border-[#A2A2A2] border-solid">
                          3
                        </div>
                        <InputField
                          name="contactNumber3"
                          placeholder={`${t("phone")}*`}
                          type="text"
                          className="-mt-2"
                          control={control}
                          errors={errors}
                        />
                      </div>
                    </div>
                    <div className="basis-1 lg:basis-1/3">
                      <div className="flex items-start justify-center gap-2">
                        <div className="text-sm lg:text-base text-neutral-dark-01 font-bold px-4 py-3 rounded-xl border border-[#A2A2A2] border-solid">
                          4
                        </div>
                        <InputField
                          name="contactNumber4"
                          placeholder={t("phone")}
                          type="text"
                          className="-mt-2"
                          control={control}
                          errors={errors}
                        />
                      </div>
                    </div>
                    <div className="basis-1 lg:basis-1/3">
                      <div className="flex items-start justify-center gap-2">
                        <div className="text-sm lg:text-base text-neutral-dark-01 font-bold px-4 py-3 rounded-xl border border-[#A2A2A2] border-solid">
                          5
                        </div>
                        <InputField
                          name="contactNumber5"
                          placeholder={t("phone")}
                          type="text"
                          className="-mt-2"
                          control={control}
                          errors={errors}
                        />
                      </div>
                    </div>
                  </div>
                </div>
                {/* 2 */}
                <h3 className="font-bold text-xl mb-4 mt-6">
                  {t("sim_change_form_2")}
                </h3>
                <div className="p-4 bg-[#F5F6F7] rounded-2xl">
                  <div className="mb-3 text-sm lg:text-base font-bold">
                    {t("sim_change_form_2_desc_1")}
                  </div>
                  <div className="flex flex-col gap-4">
                    <div className="flex flex-col lg:flex-row lg:justify-center gap-4">
                      <div className="flex-1">
                        <InputField
                          name="fullname"
                          label={t("name")}
                          classNameLabel="!font-normal text-xs lg:text-base !text-neutral-dark-01"
                          placeholder={t("name")}
                          type="text"
                          control={control}
                          errors={errors}
                          required
                        />
                      </div>
                      <div className="flex-1">
                        <div className="text-xs lg:text-base text-neutral-dark-01">
                          {t("gender")}
                        </div>
                        <RadioButtonField
                          name="gender"
                          control={control}
                          options={optionRadios}
                          className="mt-2 flex-1 flex items-center"
                          isBackgroundBorder
                        />
                      </div>
                    </div>
                    <div className="flex flex-col lg:flex-row lg:justify-center gap-4">
                      <div className="flex-1">
                        <InputField
                          name="contactPhoneNumber"
                          label={t("contact_phone")}
                          classNameLabel="!font-normal text-xs lg:text-base !text-neutral-dark-01"
                          placeholder={t("phone")}
                          type="text"
                          className=""
                          control={control}
                          errors={errors}
                          required
                        />
                      </div>
                      <div className="flex-1">
                        <InputField
                          name="identityNumber"
                          label={t("id_card")}
                          classNameLabel="!font-normal text-xs lg:text-base !text-neutral-dark-01"
                          placeholder={t("id_card")}
                          type="text"
                          className=""
                          control={control}
                          errors={errors}
                          required
                        />
                      </div>
                      <div className="flex-1">
                        <SelectField
                          error={errors?.typeOfDoc}
                          control={control}
                          placeholder={t("passport_placholder")}
                          name="typeOfDoc"
                          label={t("type_of_doc")}
                          classNameLabel="!font-normal text-xs lg:text-base !text-neutral-dark-01"
                          options={TYPE_OF_DOC.map((item) => ({
                            label: item.name,
                            value: item.id + "",
                          }))}
                          required
                        />
                      </div>
                    </div>
                    <div className="flex flex-col lg:flex-row lg:justify-center gap-4">
                      <div className="flex-1">
                        <DatePickerField
                          name="dob"
                          label={t("date")}
                          classNameLabel="!font-normal text-xs lg:text-base !text-neutral-dark-01"
                          control={control}
                          errors={errors}
                          placeholder={t("date")}
                          className="h-12"
                          required
                        />
                      </div>
                      <div className="flex-1">
                        <div className="text-xs lg:text-base text-neutral-dark-01">
                          {t("address")}
                        </div>
                        <InputField
                          name="address"
                          placeholder={t("address")}
                          type="text"
                          className=""
                          control={control}
                          errors={errors}
                        />
                      </div>
                      <div className="flex-1">
                        <div className="text-xs lg:text-base text-neutral-dark-01">
                          {t("email")}
                        </div>
                        <InputField
                          maxLength={255}
                          name="email"
                          placeholder={t("email_placholder")}
                          type="text"
                          className=""
                          control={control}
                          errors={errors}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="my-3 text-xs lg:text-base font-bold">
                    {t("sim_change_form_2_desc_2")}
                  </div>
                  <div className="flex w-[54%]">
                    <div className="flex-1">
                      <RadioButtonField
                        name="sim_swap"
                        control={control}
                        options={optionRadiosSimSwap}
                        className="mt-2 flex-1 flex flex-col lg:flex-row"
                        isBackgroundBorder
                      />
                    </div>
                  </div>
                </div>
                <div className="mt-6 lg:mt-8 mb-6 flex gap-x-2 items-start">
                  <Checkbox
                    checked={checkCondition}
                    onCheckedChange={(value) =>
                      setCheckCondition(value as boolean)
                    }
                    className="size-6"
                  />
                  <div className="text-sm text-neutral-mid-01">
                    {t("sim_change_form_4")}
                  </div>
                </div>
                <div className="flex justify-center mt-2">
                  <Button
                    disabled={!(isFormValid && checkCondition)}
                    type="submit"
                    className="w-[100%] lg:w-[212px] rounded-3xl"
                  >
                    {t("confirm")}
                  </Button>
                </div>
                {isShowConfirm && (
                  <ResultEmailModal
                    isModal={isShowConfirm}
                    onClose={() => {
                      setIsShowConfirm(false);
                      reset();
                    }}
                  />
                )}
              </>
            );
          }}
        </Form>
      </div>
    </div>
  );
};

export default RequestForm;
