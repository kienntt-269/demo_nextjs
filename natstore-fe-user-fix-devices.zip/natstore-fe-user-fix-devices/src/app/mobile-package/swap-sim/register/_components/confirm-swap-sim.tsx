import { useSwapSimStore } from "@/_stores/useSwapSwim.store";
import { Button } from "@/components/ui/button";
import { useTranslations } from "next-intl";
import Image from "next/image";
import { useRouter } from "next/navigation";
import React from "react";

export default function ConfirmSwapSim() {
  const t = useTranslations("mobile_package.swap_sim");
  const navigate = useRouter();
  const dataFormSwapSim = useSwapSimStore((state) => state.data);
  return (
    <div className="flex flex-col items-center lg:m-8 mt-9 lg:mt-12">
      <Image
        src={"/images/icon/check-success.svg"}
        alt="check-success"
        width={64}
        height={64}
        className="rounded-full hidden sm:block"
      />
      <Image
        src={"/images/icon/check-success.svg"}
        alt="check-success"
        width={48}
        height={48}
        className="rounded-full block sm:hidden"
      />
      <h2 className="text-xl font-bold mt-7 lg:mt-10 mb-6">{t("confirm")}</h2>
      <p className="text-sm text-center">
        {dataFormSwapSim?.type === "esim"
          ? t("confirm_message_1")
          : t("confirm_message_2")}
      </p>
      <p className="text-sm text-center">
        {dataFormSwapSim?.address_receive === "showroom"
          ? t("confirm_message_3")
          : t("confirm_message_4")}
      </p>
      <Button
        onClick={() => navigate.push("/")}
        className="mt-6 w-[100%] lg:w-[212px] rounded-3xl"
      >
        {t("ok")}
      </Button>
    </div>
  );
}
