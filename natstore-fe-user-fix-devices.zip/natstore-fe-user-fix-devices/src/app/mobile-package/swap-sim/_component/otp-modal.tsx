"use client";

import { useSwapSimStore } from "@/_stores/useSwapSwim.store";
import Modal from "@/components/common/modal/Modal";
import CountdownTimer, {
  CountdownTimerHandle,
} from "@/components/count-down-timer";
import { Button } from "@/components/ui/button";
import {
  InputOTP,
  InputOTPGroup,
  InputOTPSlot,
} from "@/components/ui/input-otp";
import { Dialog } from "@radix-ui/react-dialog";
import { useTranslations } from "next-intl";
import Image from "next/image";
import React, { LegacyRef, useEffect, useRef, useState } from "react";

export type OtpModalProps = React.ComponentProps<typeof Dialog> & {
  isModal: boolean;
  onSubmit: (otp: string) => void;
  onClose: () => void;
  error?: string;
  setError: (error: string) => void;
  phoneNumber?: string | number;
  onResend?: () => void;
  time?: number;
  timeExpired?: number;
  isGetOTP?: boolean;
};

export const OtpModal = ({
  isModal,
  onSubmit,
  onClose,
  error,
  setError,
  phoneNumber,
  onResend,
  time = 60,
  timeExpired = 299,
  isGetOTP,
}: OtpModalProps) => {
  const t = useTranslations();
  const dataFormSwapSim = useSwapSimStore((state) => state.data);
  const [otp, setOtp] = useState("");
  const [timeLeft, setTimeLeft] = useState(time);
  const [canResend, setCanResend] = useState(false);
  const [isExpiredOtp, setIsExpiredOtp] = useState(0);

  const otpRef = useRef<CountdownTimerHandle>();

  const handleOtpChange = (value: string) => {
    const numericValue = value.replace(/[^0-9]/g, "");
    setOtp(numericValue);
  };

  const handleResend = () => {
    setTimeLeft(time);
    setIsExpiredOtp(timeExpired);
    setCanResend(false);
    setOtp("");
    setError("");
    onResend?.();
  };

  useEffect(() => {
    if (timeLeft > 0) {
      const timer = setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
      return () => clearInterval(timer);
    } else {
      setCanResend(true);
    }
  }, [timeLeft, isModal]);

  useEffect(() => {
    setTimeLeft(time);
    setIsExpiredOtp(timeExpired);
  }, [isModal]);

  return (
    <Modal
      isOpen={isModal}
      onClose={onClose}
      onInteractOutside={(e) => {
        e.preventDefault();
      }}
      title={t("forgot.otp_code")}
      contentClassName="w-[343px] lg:w-[504px] lg:max-w-full pb-[24px] pt-2 px-2 lg:p-6"
    >
      <div className="flex flex-col items-center space-y-4 py-4 pb-6 rounded-lg max-sm:overflow-hidden">
        <Image
          src="/images/icon/input-otp.png"
          alt="input-otp"
          width={148}
          height={148}
          className="max-sm:size-24 lg:size-[148px] rounded-t-2xl"
        />
        <div className="pb-6 text-sm lg:text-base text-neutral-dark-02 text-center">
          <div className="">{t("mobile_package.swap_sim.otp_code_desc")}</div>
          <div className="">{dataFormSwapSim?.phoneNumber ?? phoneNumber}</div>
        </div>

        <div className="w-full flex justify-center">
          <InputOTP
            autoFocus
            maxLength={6}
            value={otp}
            onChange={handleOtpChange}
            type="text"
            inputMode="numeric"
            pattern="[0-9]*"
          >
            <InputOTPGroup>
              <InputOTPSlot
                className="max-sm:size-[42px] lg:size-[52px] bg-[#F2F2F2]"
                index={0}
              />
            </InputOTPGroup>
            <InputOTPGroup>
              <InputOTPSlot
                className="max-sm:size-[42px] lg:size-[52px] bg-[#F2F2F2]"
                index={1}
              />
            </InputOTPGroup>
            <InputOTPGroup>
              <InputOTPSlot
                className="max-sm:size-[42px] lg:size-[52px] bg-[#F2F2F2]"
                index={2}
              />
            </InputOTPGroup>
            <InputOTPGroup>
              <InputOTPSlot
                className="max-sm:size-[42px] lg:size-[52px] bg-[#F2F2F2]"
                index={3}
              />
            </InputOTPGroup>
            <InputOTPGroup>
              <InputOTPSlot
                className="max-sm:size-[42px] lg:size-[52px] bg-[#F2F2F2]"
                index={4}
              />
            </InputOTPGroup>
            <InputOTPGroup>
              <InputOTPSlot
                className="max-sm:size-[42px] lg:size-[52px] bg-[#F2F2F2]"
                index={5}
              />
            </InputOTPGroup>
          </InputOTP>
        </div>
        {isGetOTP &&
          (isExpiredOtp ? (
            <span className="text-xs lg:text-sm text-neutral mt-3 lg:mt-0">
              <i>{t("personal.changePassword.otp_valid_period")}</i>
              <CountdownTimer
                ref={otpRef as LegacyRef<CountdownTimerHandle>}
                time={isExpiredOtp}
                callback={() => {
                  setIsExpiredOtp(0);
                }}
              />
            </span>
          ) : (
            <span className="text-xs lg:text-sm text-error mt-3 lg:mt-0">
              {t("personal.changePassword.resend_otp")}
            </span>
          ))}
        <Button
          onClick={handleResend}
          disabled={!canResend}
          className={`text-sm font-bold ${canResend ? "" : "text-neutral-mid-01 opacity-50 cursor-not-allowed"}`}
          variant={!canResend ? "ghost" : "secondary"}
        >
          {t("mobile_package.swap_sim.resend_otp")}{" "}
          {!canResend && <>({timeLeft}s)</>}
        </Button>
        {!!error?.length && (
          <div className="font-bold text-[#FF3B30] text-xs lg:text-base text-center">
            {error}
          </div>
        )}
        <Button
          onClick={() => onSubmit(otp)}
          className="w-[100%] mt-6"
          variant="default"
          disabled={otp.length < 6}
        >
          {t("mobile_package.swap_sim.confirm")}
        </Button>
      </div>
    </Modal>
  );
};

export default OtpModal;
