"use client";

import ImageCommon from "@/components/common/image-common";
import TextWithTooltip from "@/components/text-width-tooltip";
import { getImageUrl } from "@/constants/imageUrl";
import { useIsMobile } from "@/hooks/use-mobile";
import { IDeviceDetail } from "@/schemaValidations/mobile-package.schema";
import Image from "next/image";
import React, { useState } from "react";

type RenderContent = {
  data: IDeviceDetail[];
};

const RenderContent = ({ data }: RenderContent) => {
  const isMobile = useIsMobile();
  const [active, setActive] = useState<IDeviceDetail>(data?.[0]);

  return (
    <div className="relative mt-12 lg:mb-10">
      <div className="w-full grid max-sm:grid-cols-4 grid-cols-3 gap-6 mb-8 pb-8">
        <div className="max-sm:col-span-2 max-sm:row-start-2 col-span-1 row-start-1 flex flex-col gap-8">
          {data.map((item, index) => (
            <>
              {index % 2 === 0 && (
                <div
                  key={`${item?.id}-${index}`}
                  className={`flex gap-4 items-center lg:items-start justify-end flex-row cursor-pointer`}
                  onClick={() => setActive((prev) => ({ ...prev, ...item }))}
                >
                  <TextWithTooltip
                    content={item?.deviceName}
                    limit={10}
                    className={`block text-sm lg:text-xl ${active?.id === item?.id ? "text-primary font-bold" : "text-neutral-dark-01"}`}
                  />
                  <div className="">
                    <Image
                      alt="check circle"
                      src="/mobile-package/circle_check.svg"
                      width={24}
                      height={24}
                    />
                  </div>
                </div>
              )}
            </>
          ))}
        </div>
        <div className="max-sm:col-span-4 max-sm:row-start-1 col-span-1 row-start-1 flex justify-center h-[168px] lg:h-[508px]">
          {data.map((item, index) => {
            return (
              item.deviceImage && (
                <div key={`${item?.id}-${index}`}>
                  {active?.id === item?.id ? (
                    <>
                      <ImageCommon
                        key={item?.id}
                        alt=""
                        src={
                          item?.deviceImage
                            ? getImageUrl(item?.deviceImage)
                            : "/"
                        }
                        width={isMobile ? 168 : 642}
                        height={isMobile ? 168 : 508}
                        className="object-contain max-h-[168px] lg:max-h-[508px] h-auto w-full"
                      />
                    </>
                  ) : null}
                </div>
              )
            );
          })}
        </div>
        <div className="max-sm:col-span-2 max-sm:row-start-2 col-span-1 row-start-1 flex flex-col gap-8">
          {data.map((item, index) => (
            <>
              {index % 2 !== 0 && (
                <div
                  key={`${item?.id}-${index}`}
                  className={`flex gap-2 items-center lg:items-start justify-end flex-row-reverse cursor-pointer`}
                  onClick={() => setActive((prev) => ({ ...prev, ...item }))}
                >
                  <TextWithTooltip
                    content={item?.deviceName}
                    limit={10}
                    className={`block text-sm lg:text-xl ${active?.id === item?.id ? "text-primary font-bold" : "text-neutral-dark-01"}`}
                  />
                  <div className="">
                    <Image
                      alt="check circle"
                      src="/mobile-package/circle_check.svg"
                      width={24}
                      height={24}
                    />
                  </div>
                </div>
              )}
            </>
          ))}
        </div>
      </div>
    </div>
  );
};

export default RenderContent;
