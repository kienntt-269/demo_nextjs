import { useLangStore } from "@/_stores/useLang.store";
import ComponentWithTooltip from "@/components/component-with-tooltip";
import TitleStyle from "@/components/title-common";
import { Button } from "@/components/ui/button";
import { formatTimeWithDay } from "@/lib/utils";
import { IDataPlan } from "@/schemaValidations/mobile-service.schema";
import { ISimCard } from "@/schemaValidations/sim-card.schema";
import mobileApiRequest from "@/services/mobile-service";
import simApiRequest from "@/services/sim-service";
import { useTranslations } from "next-intl";
import Image from "next/image";
import { ReadonlyURLSearchParams } from "next/navigation";
import React, { useEffect, useState } from "react";

interface IProps {
  searchParams: ReadonlyURLSearchParams;
}

const OrderSimError = ({ searchParams }: IProps) => {
  const t = useTranslations();
  const { lang } = useLangStore();
  const [simDetail, setSimDetail] = useState<ISimCard>();
  const [dataPackage, setDataPackage] = useState<IDataPlan>();
  const getSimDetail = async () => {
    try {
      const res = await simApiRequest.getSimDetail(
        searchParams.get("idSim") ?? ""
      );
      setSimDetail(res.payload.data);
    } catch (error) {
      console.log(error);
    }
  };

  const getDataPackage = async () => {
    try {
      const res = await mobileApiRequest.getDetailData(
        searchParams.get("package") ?? ""
      );
      setDataPackage(res.payload.data);
    } catch (error) {
      console.log(error);
    }
  };

  const simTypeChange = () => {
    switch (searchParams.get("type")) {
      case "1":
        return t("mobile_package.sim_normal.xchange_sim");
      case "2":
        return t("mobile_package.sim_normal.student_sim");
      case "3":
        return t("mobile_package.sim_normal.dcom_sim");
      default:
        return t("mobile_package.sim_normal.xchange_sim");
    }
  };

  useEffect(() => {
    if (searchParams.get("idSim")) {
      getSimDetail();
    }
    if (searchParams.get("package")) {
      getDataPackage();
    }
  }, [searchParams, lang]);

  return (
    <div className="flex justify-center py-10 max-md:py-4 max-md:px-4">
      <div className="max-w-[768px] flex flex-col items-center w-full gap-y-6 max-md:gap-y-3 bg-white shadow-box-custom p-8 max-md:p-4 rounded-3xl">
        <Image
          src={"/images/icon/check-error.svg"}
          quality={100}
          unoptimized
          height={64}
          width={64}
          alt=""
          className="max-md:size-12"
        />
        <div className="">
          <TitleStyle classStyle="max-sm:leading-8 text-center">
            {t("mobile_package.sim_normal.order_creation_failed")}!
          </TitleStyle>
          <div className="text-neutral-dark-04 text-[14px] max-md:text-[12px] font-normal text-center mt-4 max-md:mt-2">
            {formatTimeWithDay(t, new Date())}
          </div>
        </div>
        <div className="w-full">
          <div className="w-full rounded-2xl p-4 bg-[#F5F6F7]">
            <div className="flex items-center justify-between h-9 max-md:text-[12px]">
              <div>{t("payment.order_id")}</div>
              <div className="font-bold text-neutral-dark-02">
                {searchParams?.get("orderId")}
              </div>
            </div>
            <div className="flex items-center justify-between h-9 max-md:text-[12px]">
              <div>{t("mobile_package.sim_normal.sim_release_version")}</div>
              <div className="font-bold text-neutral-dark-02">
                {searchParams?.get("esim")
                  ? t("mobile_package.swap_sim.esim")
                  : t("mobile_package.swap_sim.physical_sim")}
              </div>
            </div>
            {simDetail?.id && (
              <>
                <div className="flex items-center justify-between h-9 max-md:text-[12px]">
                  <div>{t("mobile_package.sim_normal.sim_card")}</div>
                  <div className="font-bold text-neutral-dark-02">
                    {simDetail?.isdn}
                  </div>
                </div>
                <div className="flex items-center justify-between h-9 max-md:text-[12px]">
                  <div>{t("mobile_package.sim_normal.type_sim")}</div>
                  <div className="font-bold text-neutral-dark-02">
                    {simTypeChange()}
                  </div>
                </div>{" "}
                <div className="flex items-center justify-between h-9 max-md:text-[12px]">
                  <div>{t("mobile_package.sim_normal.sim_price")}</div>
                  <div className="font-bold text-neutral-dark-02">
                    {simDetail?.price.toLocaleString("en-US")}{" "}
                    {t("mobile_package.htg")}
                  </div>
                </div>
              </>
            )}
            {dataPackage?.id && (
              <>
                <div className="flex items-center justify-between h-9 gap-x-10 max-md:text-[12px]">
                  <div className="flex-shrink-0">
                    {t("mobile_package.sim_normal.data_plan")}
                  </div>
                  <ComponentWithTooltip content={dataPackage?.name}>
                    <div className="font-bold text-neutral-dark-02 overflow-hidden text-ellipsis whitespace-nowrap max-w-full text-right">
                      {dataPackage?.name}
                    </div>
                  </ComponentWithTooltip>
                </div>
                <div className="flex items-center justify-between h-9 max-md:text-[12px]">
                  <div className="flex-shrink-0">
                    {t("mobile_package.sim_normal.data_plan_price")}
                  </div>
                  <div className="font-bold text-neutral-dark-02">
                    {Number(dataPackage?.price ?? 0).toLocaleString("en-US")}{" "}
                    {t("mobile_package.htg")}
                  </div>
                </div>
              </>
            )}
            <div className="flex items-center justify-between h-9 max-md:text-[12px]">
              <div>{t("common.total")}</div>
              <div className="font-bold text-neutral-dark-02">
                {(
                  Number(simDetail?.price ?? 0) +
                  Number(dataPackage?.price ?? 0)
                ).toLocaleString("en-US")}{" "}
                {t("mobile_package.htg")}
              </div>
            </div>
            <div className="flex items-center justify-between h-9 max-md:text-[12px]">
              <div>{t("payment.payment_method")}</div>
              <div className="font-bold text-neutral-dark-02">
                {" "}
                {searchParams?.get("esim")
                  ? t("payment.natcash")
                  : t("payment.pay_at_store")}
              </div>
            </div>
          </div>
        </div>
        <Button navigate="/" className="px-14 max-md:px-8">
          {t("common.back_home_page")}
        </Button>
      </div>
    </div>
  );
};

export default OrderSimError;
