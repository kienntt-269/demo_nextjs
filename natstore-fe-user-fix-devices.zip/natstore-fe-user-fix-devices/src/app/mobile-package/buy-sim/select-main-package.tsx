"use client";
import TitleStyle from "@/components/title-common";
import React, { useEffect, useState } from "react";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  ArrowDownRight,
  ArrowUpRight,
  ChevronDown,
  ChevronUp,
} from "lucide-react";
import { useSearchParams } from "next/navigation";
import { Button } from "@/components/ui/button";
import { useTranslations } from "next-intl";
import mobileApiRequest from "@/services/mobile-service";
import CarouselData from "@/components/common/carousel-data/carousel-data";
import { IDataPlan } from "@/schemaValidations/mobile-service.schema";
import CardCommon from "@/components/card-common";
import SimDetailModal from "@/app/mobile-package/buy-sim/sim-detail";
import { useSimCardStore } from "@/_stores/useSimCard.store";
import { useRouter } from "next/navigation";
import { useLangStore } from "@/_stores/useLang.store";

const SelectMainPackageSim = () => {
  const { packageData, simDetail, setPackageData } = useSimCardStore();
  const [isOpen, setIsOpen] = useState<boolean>(false);
  const router = useRouter();
  const { lang } = useLangStore();
  const searchParams = useSearchParams();
  const [selectPackage, setSelectPackage] = useState<IDataPlan>();
  const [sortBy, setSortBy] = useState<string>("");
  const [isVisible, setIsVisible] = useState<boolean>(false);
  const [listDataPackage, setListDataPackage] = useState<IDataPlan[]>([]);

  const t = useTranslations();

  const getDataPackage = async () => {
    try {
      const res = await mobileApiRequest.getDataMobileService({
        sortBy: sortBy,
        simCard: true,
      });
      setListDataPackage(res.payload.data);
    } catch (error) {
      console.log(error);
      throw Error("error");
    }
  };

  useEffect(() => {
    getDataPackage();
  }, [sortBy, lang]);

  useEffect(() => {
    setPackageData();
    console.log(simDetail);
  }, []);

  return (
    <div className="mt-10 max-md:mt-4">
      <SimDetailModal
        isVisible={isVisible}
        dataPlant={selectPackage}
        onClose={(data: boolean) => {
          setIsVisible(data);
        }}
      />
      {searchParams.get("type") === "3" && (
        <>
          <div className="flex justify-between items-center">
            <TitleStyle>{t("mobile_package.select_main_package")}</TitleStyle>
            <Popover
              open={isOpen}
              onOpenChange={() => {
                setIsOpen(!isOpen);
              }}
            >
              <PopoverTrigger asChild>
                <button
                  className={`py-3 px-5 max-xl:py-2 max-md:px-3 max-md:py-[6px] rounded-3xl ${sortBy ? "bg-[#FF860029]" : "border-[#333333] text-neutral-dark-03 border-solid border"}  flex items-center gap-x-2`}
                >
                  {sortBy ? (
                    <ChevronUp className="text-[24px] max-xl:size-5 max-md:size-4" />
                  ) : (
                    <ChevronDown className="text-[24px] max-xl:size-5 max-md:size-4" />
                  )}
                  <div className="font-semibold max-xl:text-[14px]">
                    {t("common.sort_by")}
                  </div>
                </button>
              </PopoverTrigger>
              <PopoverContent className="w-60 rounded-xl border-white shadow-md">
                <div className="">
                  <div className="font-semibold">{t("common.name")}</div>
                  <div
                    className="flex gap-x-[10px] text-neutral3 items-center mt-3 cursor-pointer group"
                    onClick={() => {
                      setSortBy("NAME_ASC");
                      setIsOpen(false);
                    }}
                  >
                    <ArrowUpRight
                      strokeWidth={1.5}
                      className={`group-hover:text-primary ${sortBy === "NAME_ASC" ? "text-primary" : ""}`}
                    />
                    <div
                      className={`group-hover:text-primary ${sortBy === "NAME_ASC" ? "text-primary" : ""}`}
                    >
                      A to Z
                    </div>
                  </div>
                  <div
                    className="flex gap-x-[10px] text-neutral3 items-center mt-4 cursor-pointer group"
                    onClick={() => {
                      setSortBy("NAME_DESC");
                      setIsOpen(false);
                    }}
                  >
                    <ArrowDownRight
                      strokeWidth={1.5}
                      className={`group-hover:text-primary ${sortBy === "NAME_DESC" ? "text-primary" : ""}`}
                    />
                    <div
                      className={`group-hover:text-primary ${sortBy === "NAME_DESC" ? "text-primary" : ""}`}
                    >
                      Z to A
                    </div>
                  </div>
                  <div className="font-semibold mt-4">{t("common.price")}</div>
                  <div
                    className="flex gap-x-[10px] text-neutral3 items-center mt-3 cursor-pointer group"
                    onClick={() => {
                      setSortBy("PRICE_ASC");
                      setIsOpen(false);
                    }}
                  >
                    <ArrowUpRight
                      strokeWidth={1.5}
                      className={`group-hover:text-primary ${sortBy === "PRICE_ASC" ? "text-primary" : ""}`}
                    />
                    <div
                      className={`group-hover:text-primary ${sortBy === "PRICE_ASC" ? "text-primary" : ""}`}
                    >
                      {t("mobile_package.low_to_high")}
                    </div>
                  </div>
                  <div
                    className="flex gap-x-[10px] text-neutral3 items-center mt-4 cursor-pointer group"
                    onClick={() => {
                      setSortBy("PRICE_DESC");
                      setIsOpen(false);
                    }}
                  >
                    <ArrowDownRight
                      strokeWidth={1.5}
                      className={`group-hover:text-primary ${sortBy === "PRICE_DESC" ? "text-primary" : ""}`}
                    />
                    <div
                      className={`group-hover:text-primary ${sortBy === "PRICE_DESC" ? "text-primary" : ""}`}
                    >
                      {t("mobile_package.high_to_low")}
                    </div>
                  </div>
                  <div className="mt-2 flex justify-end">
                    <Button
                      variant={"ghost"}
                      onClick={() => {
                        setSortBy("");
                        setIsOpen(false);
                      }}
                    >
                      {t("common.clear")}
                    </Button>
                  </div>
                </div>
              </PopoverContent>
            </Popover>
          </div>
          <div className="mt-6 max-md:mt-4">
            <CarouselData
              quantity={4}
              length={listDataPackage?.length}
              quantityMobile={2}
            >
              {listDataPackage?.length > 0 &&
                listDataPackage?.map((item) => {
                  return (
                    <CardCommon
                      key={item.id}
                      type="medium"
                      data={item}
                      target="sim"
                      onDetail={() => {
                        setSelectPackage(item);
                        setIsVisible(true);
                      }}
                    />
                  );
                })}
            </CarouselData>
          </div>
        </>
      )}
      <div className="flex justify-center">
        {/* bg-[#E3E4E5] text-neutral3 */}
        <Button
          className={`${packageData && simDetail?.id && searchParams.get("type") === "3" ? "bg-primary text-white" : searchParams.get("type") !== "3" && simDetail?.id ? "text-white bg-primary" : "bg-[#E3E4E5] text-neutral3"} px-[87px] mt-8  hover:text-white max-md:w-full`}
          variant={"ghost"}
          onClick={() => {
            if (packageData && simDetail) {
              router.push(
                `/mobile-package/buy-sim/detail?idSim=${simDetail.id}&package=${packageData.id}&type=${searchParams.get("type") ?? 1}&typeSim=${searchParams.get("slug") === "physical" ? "1" : "2"}`
              );
            } else if (simDetail) {
              router.push(
                `/mobile-package/buy-sim/detail?idSim=${simDetail.id}&type=${searchParams.get("type") ?? 1}&typeSim=${searchParams.get("slug") === "physical" ? "1" : "2"}`
              );
            }
          }}
        >
          {t("common.continue")}
        </Button>
      </div>
    </div>
  );
};

export default SelectMainPackageSim;
