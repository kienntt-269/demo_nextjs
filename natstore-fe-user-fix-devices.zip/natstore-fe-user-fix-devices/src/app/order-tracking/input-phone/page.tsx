import React from "react";
import FormInputPhone from "@/app/order-tracking/components/form-input-phone";

function OrderTrackingInputPhonePage() {
  return (
    <div className="mt-4 md:mt-10 rounded-3xl p-4 md:p-8 max-w-[1032px] mx-auto bg-white form-box-shadow">
      <FormInputPhone />
    </div>
  );
}

export default OrderTrackingInputPhonePage;
