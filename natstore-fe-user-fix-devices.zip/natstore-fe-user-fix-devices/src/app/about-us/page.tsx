import React from "react";
import BreadCrumbCommon from "@/components/breadcrumb-common";
import PageContent from "@/components/page-content";
import { ILinks } from "@/types/package";
import { getTranslations } from "next-intl/server";
import TabCommon from "@/components/tabs-common";
import ContentAboutUs from "@/app/about-us/content-about-us";

type SlugProps = {
  searchParams: { slug: string | undefined };
};

export const dynamic = "force-dynamic";

async function AboutUsPage({ searchParams }: SlugProps) {
  console.log("searchParams", searchParams.slug);
  const t = await getTranslations();
  const aboutUsCategories = [
    {
      label: t("about_us.history"),
      slug: "history",
    },
    {
      label: t("about_us.vision"),
      slug: "vision",
    },
    {
      label: t("about_us.mission"),
      slug: "mission",
    },
  ];
  const breadCrumb: ILinks[] = [
    {
      label: t("personal.home"),
      link: "/",
    },
    {
      label: t("about_us.about_us"),
      link: "#",
    },
    {
      label: aboutUsCategories?.filter(
        (item) => item?.slug === searchParams?.slug
      )?.[0]?.label || t("about_us.history"),
      link: "",
    },
  ];

  return (
    <PageContent>
      <BreadCrumbCommon content={breadCrumb} />
      <div className="flex mt-10 justify-center">
        <TabCommon
          tabs={aboutUsCategories}
          defaultTab={aboutUsCategories.findIndex(
            (item) => item.slug === searchParams.slug
          )}
        />
      </div>
        <div className="mt-6">
        <ContentAboutUs slug={searchParams?.slug || 'history'}/>
        </div>
    </PageContent>
  );
}

export default AboutUsPage;
