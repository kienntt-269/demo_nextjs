import React from "react";

type ContentAboutUsProps = {
  slug: string;
};
const ContentAboutUs = ({ slug }: ContentAboutUsProps) => {
  return (
    <div>
      {slug === "history" && (
        <div className="h-auto min-h-[460px]">
          <div className="rounded-3xl bg-white p-8">
            <div className="flex justify-center font-bold text-2xl pb-8">
              Who we are?
            </div>
            <div className="p-4 bg-[#F5F6F7] border-[#C5C5C5] border-[1px] border-solid text-[#616161] text-sm rounded-[8px]">
              <div className="mb-4">
                National Telecom S.A, a Haitian mobile telecommunications
                company, serves currently over 2 million subscribers under the
                &lsquo;Natcom&rsquo; brand. Natcom is a joint venture between
                and T&eacute;l&eacute;communications d&#39;Haiti S.A.M (Haiti)
                and Viettel Global (Vietnam).
              </div>
              <div className="mb-4">
                Viettel is the largest telecom group in Vietnam and also listed
                among the top 15 largest telecom companies in the world in terms
                of number of customers, successfully investing in 10 countries
                over 3 continents, including Asia, Africa and South America.
              </div>
              <div className="mb-4">
                Launched in 2011, Natcom has developed in Haiti a reliable
                world-class network, made of over 6,000km of fiber optic cable,
                1,550 base stations (2G & 3G), covering 93% nationwide and
                offering a full range of mobile communications and entertainment
                services for consumer and corporate markets.
              </div>
              <div className="mb-4">
                The company acquired the license in 2010, before the Haiti
                history earthquake, and despite all difficulties, the Company
                began commercial operations on September 11, 2011. So far, it
                has invested over USD 230 million in the local economy and has
                created 2,400 direct and 25,000 plus indirect jobs. It also has
                a network of over 200,000 retailers, thus providing means of
                livelihood to thousands of Haitians.
              </div>
              <div className="mb-4">
                As a national operator, Natcom has been the pioneer in
                innovation to deliver latest technology solutions and best
                products to contribute to the development of the country.
              </div>
              <div className="mb-4">
                For its efforts and contribution to society, Natcom has been
                awarded as Best corporate social responsibility operator in 2015
                by Stevie International Business Awards.
              </div>
            </div>
          </div>
        </div>
      )}
      {slug === "vision" && (
        <div className="h-auto min-h-[460px]">
          <div className="rounded-3xl bg-white p-8">
            <div className="flex justify-center font-bold text-2xl pb-8">
              Caring – Innovator
            </div>
            <div className="p-4 bg-[#F5F6F7] border-[#C5C5C5] border-[1px] border-solid text-[#616161] text-sm rounded-[8px]">
              <div>
                Pioneering in innovation and creation. Listening to and
                understanding in order to serve the people.
              </div>
              <div>
                Customers are cared as separate individuals. We listen to and
                try to understand each customer so as to provide tailored
                services that most come up to their demands.
              </div>
            </div>
          </div>
        </div>
      )}
      {slug === "mission" && (
        <div className="h-auto min-h-[460px]">
          <div className="rounded-3xl bg-white p-8">
            <div className="p-4 bg-[#F5F6F7] border-[#C5C5C5] border-[1px] border-solid text-[#616161] text-sm rounded-[8px]">
              <div className="mb-4">
                Our mission is to make our customers’ lives whole lot better by
                continuously innovate and personalize our products and services
                that suit each individual needs.
              </div>
              <div className="font-bold">Our business strategy</div>
              <div>
                - Universalizing telecommunications services to every corner of
                social life
              </div>
              <div>
                - Investing to build the largest and best network infrastructure
              </div>
              <div>- Applying the latest technologies</div>
              <div>- Diversifying our services to all customers</div>
              <div>- Pricing to suit every market segment</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ContentAboutUs;
