"use client";
import SelectComponent from "@/components/custom-ui/select-component";
import { DateRangePicker } from "@/components/ui/date-range-picker";
import { Input } from "@/components/ui/input";
import { formatDate, updateSearchParams } from "@/lib/utils";
import { Search } from "lucide-react";
import { useTranslations } from "next-intl";
import { usePathname, useRouter } from "next/navigation";
import React, { useState } from "react";
type Props = {
  searchParams: { [key in string]: string };
};

const PointTableSearch = ({ searchParams }: Props) => {
  const t = useTranslations();
  const pathname = usePathname();
  const router = useRouter();
  const [paramSearch, setParamSearch] = useState<{
    filter: string;
    searchKey: string;
    timeRange: { start: Date; end: Date } | null;
  }>({ filter: "0", searchKey: "", timeRange: null });

  const handleChange = (key: string, value: string | object) => {
    setParamSearch((prev) => {
      const newParams = {
        ...prev,
        [key]: value,
      };
      return newParams;
    });
  };

  const handleUpdateParamsSearch = (param: { [key: string]: string }) => {
    router.push(`${pathname}${updateSearchParams(param, searchParams)}`, {
      scroll: false,
    });
  };

  return (
    <div className="flex flex-col gap-4 lg:gap-6 items-start lg:flex-row lg:items-center">
      <div className="w-full">
        <DateRangePicker
          label={t("natcom_points.tracking_time")}
          onUpdate={({ range }) => {
            handleChange("timeRange", {
              start: range.from,
              end: range.to,
            });
            handleUpdateParamsSearch({
              from: formatDate(range.from),
              to: formatDate(range.to),
              page: "1",
            });
          }}
        />
      </div>
      <div className="w-full">
        <SelectComponent
          label={t("natcom_points.point_type")}
          placeholder={t("natcom_points.point_plus")}
          value={paramSearch.filter}
          onChange={(value) => {
            handleChange("filter", value);
            handleUpdateParamsSearch({
              filter: value,
            });
          }}
          options={[
            { label: t("natcom_points.all"), value: "0" },
            { label: t("natcom_points.point_plus"), value: "-1" },
            { label: t("natcom_points.point_minus"), value: "1" },
          ]}
        />
      </div>
      <div className="w-full flex gap-x-2 self-end">
        <div className="relative xl:max-w-[596px] max-xl:w-full">
          <Input
            className="xl:w-[329px] max-lg:w-full text-normal pl-8 h-[38px] bg-[#f2f2f2] rounded-xl font-normal outline-none border-none"
            placeholder={t("natcom_points.placeholder_search")}
            value={paramSearch.searchKey}
            onChange={(event) => {
              if (
                event.target.value === "" ||
                (/^\d*$/.test(event.target.value) &&
                  Number(event.target.value) >= 0)
              ) {
                handleChange("searchKey", event.target.value);
              }
            }}
            onKeyDown={(event) => {
              if (event.key === "Enter") {
                handleUpdateParamsSearch({
                  searchKey: paramSearch.searchKey,
                  page: "1",
                });
              }
            }}
          />
          <Search
            strokeWidth={1}
            className="absolute top-[11px] left-2 size-4"
          />
        </div>
        <button
          onClick={() => {
            handleUpdateParamsSearch({
              searchKey: paramSearch.searchKey,
              page: "1",
            });
          }}
          className="h-[38px] max-md:h-[38px] px-[12px] xl:px-[52px] flex items-center justify-center rounded-2xl bg-primary border-none text-white font-bold text-[14px]"
        >
          {t("common.search")}
        </button>
      </div>
    </div>
  );
};

export default PointTableSearch;
