"use client";
import PaymentDashboard from "@/app/affiliate/dashboard/payment-dashboard";
import ReportDashboard from "@/app/affiliate/dashboard/report-dashboard";
import TrackingLinkDashboard from "@/app/affiliate/dashboard/tracking-link";
import LeftSectionItem from "@/app/personal/components/sidebar-left";
import BreadCrumbCommon from "@/components/breadcrumb-common";
import LinkIcon from "@/components/icons/link-icon";
import PaymentIcon from "@/components/icons/payment-icon";
import ReportIcon from "@/components/icons/report-icon";
import PageContent from "@/components/page-content";
import { ILinks } from "@/types/package";
import { useTranslations } from "next-intl";
import React from "react";

const DASHBOARD_PAGE_TYPE = {
  report: "report",
  tracking_link: "tracking-link",
  payment: "payment",
};

const DashboardAffiliatePage = ({
  searchParams,
}: {
  searchParams: { [key: string]: string | string[] | undefined };
}) => {
  const t = useTranslations();
  const type = searchParams["type"] || DASHBOARD_PAGE_TYPE.report;

  const breadCrumb: ILinks[] = [
    {
      label: t("personal.home"),
      link: "/",
    },
    {
      label: t("affiliate.title"),
      link: "/affiliate",
    },
    {
      label: t("affiliate.dashboard"),
      link: "/affiliate/dashboard",
    },
  ];

  const listMenuLeft = [
    {
      icon: <ReportIcon />,
      title: t("affiliate.report"),
      url: `?type=${DASHBOARD_PAGE_TYPE.report}`,
      isActive: type === DASHBOARD_PAGE_TYPE.report,
    },
    {
      icon: <LinkIcon />,
      title: t("affiliate.tracking_link"),
      url: `?type=${DASHBOARD_PAGE_TYPE.tracking_link}`,
      isActive: type === DASHBOARD_PAGE_TYPE.tracking_link,
    },
    {
      icon: <PaymentIcon />,
      title: t("customer_support.payment"),
      url: `?type=${DASHBOARD_PAGE_TYPE.payment}`,
      isActive: type === DASHBOARD_PAGE_TYPE.payment,
    },
  ];

  const renderRightContent = () => {
    switch (type) {
      case DASHBOARD_PAGE_TYPE.report:
        return <ReportDashboard />;
      case DASHBOARD_PAGE_TYPE.tracking_link:
        return <TrackingLinkDashboard />;
      case DASHBOARD_PAGE_TYPE.payment:
        return <PaymentDashboard />;
      default:
        return <ReportDashboard />;
    }
  };

  return (
    <PageContent>
      <div className="max-md:hidden">
        <BreadCrumbCommon content={breadCrumb} />
      </div>
      <div className="mt-10">
        <div className="grid grid-cols-12 gap-4 xl:gap-6">
          <div className="col-span-12 md:col-span-4 xl:col-span-3 rounded-2xl md:rounded-3xl">
            <div className="w-full flex justify-between md:justify-normal md:flex-col md:h-full md:gap-4 h-[72px] gap-2  bg-white p-2 rounded-2xl md:rounded-3xl shadow-box-custom md:shadow-none">
              {listMenuLeft.map((item, index) => (
                <LeftSectionItem
                  key={index}
                  title={item.title}
                  icon={item.icon}
                  url={item.url}
                  isActive={item.isActive}
                />
              ))}
            </div>
          </div>{" "}
          <div className="col-span-12 md:col-span-8 xl:col-span-9 shadow-box-custom md:shadow-none rounded-2xl md:rounded-3xl">
            <div className="w-full h-full bg-white p-4 lg:p-8 rounded-2xl md:rounded-3xl">
              {renderRightContent()}
            </div>
          </div>
        </div>
      </div>
    </PageContent>
  );
};

export default DashboardAffiliatePage;
