import { Button } from "@/components/ui/button";
import { IColumnTable } from "@/types/common";
import { useTranslations } from "next-intl";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import React, { useState } from "react";
import { Input } from "@/components/ui/input";

interface IDataPayment {
  id?: string;
  date?: string;
  description?: string;
  amount?: string;
  balance?: string;
}

const PaymentDashboard = () => {
  const t = useTranslations();
  const [isOpen, setIsOpen] = useState<boolean>(false);
  const column: IColumnTable<IDataPayment>[] = [
    {
      header: t("affiliate.date"),
      key: "id",
      classStyleHeader: "pl-8 text-center",
      render: () => {
        return <div className="text-sm">10:00:25 01/03/2025</div>;
      },
    },
    {
      header: t("affiliate.transaction_description"),
      key: "id",
      classStyleHeader: "pl-8 text-center",
      render: () => {
        return <div className="text-sm">Commission from Order #123</div>;
      },
    },
    {
      header: t("affiliate.amount"),
      key: "id",
      classStyleHeader: "pl-8 text-center",
      render: () => {
        return <div className="text-sm">-500</div>;
      },
    },
    {
      header: t("affiliate.balance_after_transaction"),
      key: "id",
      classStyleHeader: "pl-8 text-center",
      render: () => {
        return <div className="text-sm">1000</div>;
      },
    },
  ];

  const dataLink: IDataPayment[] = [
    {
      id: "string",
      date: "string",
      description: "string",
    },
  ];

  return (
    <div>
      <div className="text-[28px] font-bold">{t("common.payment")}</div>
      <div className="mt-8 flex justify-between">
        <div className="flex items-center gap-x-8">
          <div>
            <div className="text-neutral-dark-04">{t("common.name")}:</div>
            <div className="font-bold">Nguyen Van A</div>
          </div>
          <div>
            <div className="text-neutral-dark-04">
              {t("affiliate.affiliate_id")}
            </div>
            <div className="font-bold">987654321</div>
          </div>
          <div>
            <div className="text-neutral-dark-04">
              {t("affiliate.natcash_wallet")}:
            </div>
            <div className="font-bold">987654321</div>
          </div>
        </div>
        <div>
          <div className="text-neutral-dark-04">
            {t("affiliate.available_commission")}:
          </div>
          <div className="text-primary text-[28px] font-bold">
            300 {t("mobile_package.htg")}
          </div>
        </div>
        <div>
          <Dialog
            open={isOpen}
            onOpenChange={(open) => {
              setIsOpen(open);
            }}
          >
            <DialogTrigger asChild>
              <Button className="w-[243px]">{t("affiliate.withdraw")}</Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[504px]">
              <DialogHeader>
                <DialogTitle>
                  <div className="text-center text-[24px] font-bold">
                    {t("affiliate.withdraw")}
                  </div>
                </DialogTitle>
              </DialogHeader>
              <div className="mt-6">
                <div>{t("affiliate.natcash_wallet")}</div>
                <div className="font-bold mt-2">987654321</div>
                <div className="mt-6">
                  <div>
                    {t("affiliate.withdrawal_amount")} (
                    {t("mobile_package.htg")})
                  </div>
                  <Input className="border-solid border border-[#E3E4E5] shadow h-12 rounded-xl mt-2" />
                  <div className="text-[#A2A2A2] text-[14px] mt-2">
                    {t("affiliate.available_commission")}: 1000{" "}
                    {t("mobile_package.htg")}
                  </div>
                </div>
              </div>
              {/* <div className="mt-2">
                <Textarea className="rounded-2xl bg-[#F5F6F7] max-h-[88px] min-h-[88px] border-[2px] border-solid border-[#E3E4E5]" />
              </div> */}
              <div className="flex justify-center">
                <Button className="w-[212px] mt-6 ">
                  {t("affiliate.withdraw")}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>
      <div className="mt-8">
        <div className="font-bold text-[20px]">
          {t("affiliate.transaction_history")}
        </div>
        <div className="rounded-t-lg md:rounded-xl mt-4 overflow-hidden border border-solid border-[#F2F2F2]">
          <Table>
            <TableHeader className="bg-[#DEDEDE] h-11">
              <TableRow>
                {column.map((col, index) => (
                  <TableHead
                    key={`header-table${index}`}
                    className={`text-[#212121] font-bold text-sm- max-md:text-[12px] ${col.classStyleHeader}`}
                  >
                    {col.header}
                  </TableHead>
                ))}
              </TableRow>
            </TableHeader>
            <TableBody>
              {dataLink?.length > 0 &&
                dataLink?.map((row, indexRow) => (
                  <TableRow
                    key={indexRow}
                    className="text-sm h-14 max-md:h-[54px]"
                  >
                    {column.map((col, i) => (
                      <TableCell
                        className={`text-[#212121] ${col.classStyleHeader}`}
                        key={i}
                      >
                        {col?.render
                          ? col.render(
                              row[col.key as keyof typeof row],
                              row,
                              indexRow
                            )
                          : (row as unknown as Record<string, string>)[col.key]}
                      </TableCell>
                    ))}
                  </TableRow>
                ))}
            </TableBody>
          </Table>
        </div>
      </div>
    </div>
  );
};

export default PaymentDashboard;
